<?php
session_start();
require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get the JSON data from the request
$data = json_decode(file_get_contents('php://input'), true);

// Check if data is received
if (!$data) {
    echo json_encode(['success' => false, 'message' => 'No data received.']);
    exit();
}

// Extract order details
$username = $data['username'];
$total = $data['total'];
$cash = $data['cash'];
$change = $data['change'];
$items = $data['items'];

// Prepare to insert the order into the orders table
$stmt = $conn->prepare("INSERT INTO orders (Username, Total, Cash, T_Change) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $username, $total, $cash, $change);

if ($stmt->execute()) {
    $orderId = $stmt->insert_id; // Get the last inserted OrderID

    // Prepare to insert items into the order_items table
    $itemStmt = $conn->prepare("INSERT INTO order_items (OrderID, ProductName, Quantity, Price) VALUES (?, ?, ?, ?)");
    
    if (!$itemStmt) {
        echo json_encode(['success' => false, 'message' => 'Failed to prepare order items statement: ' . $conn->error]);
        exit();
    }

    foreach ($items as $item) {
        $productName = $item['name'];
        $quantity = $item['quantity'];
        $price = $item['price'];

        // Check inventory before processing the sale
        $inventoryCheckStmt = $conn->prepare("SELECT Quantity FROM inventory WHERE InventoryName = ?");
        $inventoryCheckStmt->bind_param("s", $productName);
        $inventoryCheckStmt->execute();
        $inventoryCheckStmt->bind_result($availableQuantity);
        $inventoryCheckStmt->fetch();
        $inventoryCheckStmt->close();

        // Check if there is enough inventory
        if ($availableQuantity < $quantity) {
            echo json_encode(['success' => false, 'message' => 'Not enough inventory for ' . $productName . '. Available: ' . $availableQuantity]);
            exit(); // Exit if not enough inventory
        }

        // Insert order item
        $itemStmt->bind_param("isid", $orderId, $productName, $quantity, $price);
        
        if (!$itemStmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Failed to insert order item: ' . $itemStmt->error]);
            exit();
        }

        // Update inventory stock
        $updateStmt = $conn->prepare("UPDATE inventory SET Quantity = Quantity - ? WHERE InventoryName = ?");
        $updateStmt->bind_param("is", $quantity, $productName);
        
        if (!$updateStmt->execute()) {
            echo json_encode(['success' => false, 'message' => 'Failed to update inventory: ' . $updateStmt->error]);
            exit();
        }
        
        $updateStmt->close();
    }

    $itemStmt->close();
    $stmt->close();

    // Return success response
    echo json_encode(['success' => true, 'message' => 'Order placed successfully!']);
} else {
    // Return error response
    echo json_encode(['success' => false, 'message' => 'Failed to place order: ' . $stmt->error]);
}

$conn->close();
?>