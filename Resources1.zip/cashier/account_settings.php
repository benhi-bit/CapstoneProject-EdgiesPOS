<?php
session_start();
if (!isset($_SESSION['Username']) || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true || $_SESSION['Role'] !== 'Cashier') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

$userId = $_SESSION['UserID'];
$currentUsername = $_SESSION['Username'];
$message = '';
$messageType = '';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE UserID = ?");
$userQuery->bind_param("i", $userId);
$userQuery->execute();
$userResult = $userQuery->get_result();
$userData = $userResult->fetch_assoc();
$userFullName = $userData['FullName'] ?? $currentUsername;
$userQuery->close();

$currentPage = basename($_SERVER['PHP_SELF']);
function isActive($page, $current) {
    return ($page === $current) ? 'active' : '';
}

// Handle password change
if (isset($_POST['change_password'])) {
    $currentPassword = $_POST['currentPassword'];
    $newPassword = trim($_POST['newPassword']);
    $confirmPassword = trim($_POST['confirmPassword']);
    
    // Validate inputs
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $message = 'All password fields are required.';
        $messageType = 'error';
    } elseif ($newPassword !== $confirmPassword) {
        $message = 'New passwords do not match.';
        $messageType = 'error';
    } else {
        // Verify current password
        $verifyStmt = $conn->prepare("SELECT Password FROM loginaccount WHERE UserID = ?");
        $verifyStmt->bind_param("i", $userId);
        $verifyStmt->execute();
        $verifyResult = $verifyStmt->get_result();
        $verifyData = $verifyResult->fetch_assoc();
        $verifyStmt->close();
        
        if (!password_verify($currentPassword, $verifyData['Password'])) {
            $message = 'Current password is incorrect.';
            $messageType = 'error';
        } else {
            // Validate password pattern: at least 6 characters, 1 uppercase letter, 1 number
            $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/';
            if (!preg_match($passwordPattern, $newPassword)) {
                $message = 'Password must be at least 6 characters long and contain at least one uppercase letter and one number.';
                $messageType = 'error';
            } else {
                // Update password
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateStmt = $conn->prepare("UPDATE loginaccount SET Password = ? WHERE UserID = ?");
                $updateStmt->bind_param("si", $hashedPassword, $userId);
                
                if ($updateStmt->execute()) {
                    // Log the change
                    $description = "Cashier password changed: " . $currentUsername;
                    addSystemLog($conn, "Password Changed", $description, $userFullName);
                    
                    $message = 'Password changed successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Error changing password: ' . $updateStmt->error;
                    $messageType = 'error';
                }
                $updateStmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings - Cashier</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, [class*="btn-"], input[type="submit"], input[type="button"] {
            box-shadow: none !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
            color: #1e293b;
        }

        /* Sidebar - same as cashier product_availability / pos */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        nav.sidebar.sidebar-expanded { width: 200px; }
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * { transition: none !important; }
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0;
        }
        .sidebar-nav-items::-webkit-scrollbar { width: 6px; }
        .sidebar-nav-items::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.2); }
        .sidebar-nav-items::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.3); border-radius: 3px; }
        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0;
            cursor: pointer;
        }
        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }
        nav.sidebar.sidebar-expanded .sidebar-logo img { max-height: 80px; margin-bottom: 10px; }
        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }
        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name { opacity: 1; max-height: 100px; }
        .sidebar-footer {
            flex-shrink: 0;
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto;
        }
        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }
        .sidebar-footer .cashier-name i { font-size: 14px; }
        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }
        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span { opacity: 1; width: auto; }
        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }
        .sidebar-footer .sidebar-datetime #sidebar-date,
        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 500;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .sidebar-footer .sidebar-datetime #sidebar-time { font-weight: 600; color: #face0b; font-size: 16px; }
        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date,
        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time { opacity: 1; max-height: 30px; }
        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }
        nav.sidebar a:hover { background-color: #ddd; color: black; }
        nav.sidebar a.active { background-color: #face0b; color: black; }
        nav.sidebar a i { margin-right: 0; width: 20px; text-align: center; display: inline-block; }
        nav.sidebar.sidebar-expanded a i { margin-right: 10px; }
        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }
        nav.sidebar.sidebar-expanded a span { opacity: 1; width: auto; white-space: normal; word-wrap: break-word; max-width: 140px; display: inline-block; line-height: 1.3; }
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease;
        }
        nav.sidebar.sidebar-expanded ~ main { margin-left: 220px; }
        nav.sidebar.no-transition ~ main { transition: none !important; }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        h1 {
            color: #1e293b;
            border-bottom: 3px solid #face0b;
            padding-bottom: 10px;
            margin-bottom: 30px;
            font-size: 24px;
            font-weight: 700;
        }

        h1 i {
            color: #b58500;
            font-size: 24px;
            margin-right: 10px;
        }

        .card {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 25px;
            margin-bottom: 20px;
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .card-header i {
            font-size: 18px;
            color: #b58500;
            margin-right: 10px;
        }

        .card-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 600;
            color: #1e293b;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
        }

        input[type="password"] {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            color: #1e293b;
            box-sizing: border-box;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25);
        }

        .btn-primary {
            background: #face0b;
            color: #000;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }

        .btn-primary:hover {
            background: #e6c009;
        }

        .btn-secondary {
            background: #333;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 6px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }

        .btn-secondary:hover {
            background: #444;
        }

        .password-requirements {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            color: #64748b;
        }

        .password-requirements ul {
            margin: 10px 0 0 0;
            padding-left: 20px;
        }

        .password-requirements li {
            margin-bottom: 5px;
        }

        .message {
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
        }

        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>
        <div class="sidebar-nav-items">
            <a href="pos.php" class="<?php echo isActive('pos.php', $currentPage); ?>">
                <i class="fas fa-cash-register"></i>
                <span>Take Out</span>
            </a>
            <a href="pos.php" id="tablesTab">
                <i class="fas fa-table"></i>
                <span>Dine In</span>
            </a>
            <a href="product_availability.php" class="<?php echo isActive('product_availability.php', $currentPage); ?>">
                <i class="fas fa-box-open"></i>
                <span>Products</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>
    <main>
    <div class="container">
        <h1><i class="fas fa-user-cog"></i> Account Settings</h1>
        
        <?php if ($message): ?>
            <div class="message <?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <i class="fas fa-key"></i>
                <h3>Change Password</h3>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="change_password" value="1">
                
                <div class="password-requirements">
                    <strong>Password Requirements:</strong>
                    <ul>
                        <li>At least 6 characters long</li>
                        <li>At least one uppercase letter</li>
                        <li>At least one number</li>
                    </ul>
                </div>

                <div class="form-group">
                    <label for="currentPassword">Current Password</label>
                    <input type="password" id="currentPassword" name="currentPassword" required autocomplete="current-password">
                </div>

                <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <input type="password" id="newPassword" name="newPassword" required autocomplete="new-password" pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm New Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" required autocomplete="new-password" pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                </div>

                <div style="display: flex; gap: 10px;">
                    <button type="submit" class="btn-primary" id="changePasswordBtn">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </div>
            </form>
        </div>
    </div>
    </main>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', sidebar.classList.contains('sidebar-expanded') ? 'true' : 'false');
            }
        }
        function confirmLogout(event) {
            event.preventDefault();
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout Confirmation',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#face0b',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = '../authentication/logout.php';
                });
            } else {
                if (confirm('Are you sure you want to logout?')) window.location.href = '../authentication/logout.php';
            }
        }
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.add('no-transition');
                if (localStorage.getItem('sidebarExpanded') === 'true') sidebar.classList.add('sidebar-expanded');
                else sidebar.classList.remove('sidebar-expanded');
                setTimeout(function() { sidebar.classList.remove('no-transition'); }, 50);
            }
        });
        function updateSidebarDateTime() {
            const now = new Date();
            const dateEl = document.getElementById('sidebar-date');
            const timeEl = document.getElementById('sidebar-time');
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });
            if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
        }
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        // Show success/error message with SweetAlert if needed
        <?php if ($message && $messageType === 'success'): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo addslashes($message); ?>',
                timer: 3000,
                showConfirmButton: false
            }).then(() => {
                // Optionally redirect or clear form
                document.getElementById('currentPassword').value = '';
                document.getElementById('newPassword').value = '';
                document.getElementById('confirmPassword').value = '';
            });
        <?php elseif ($message && $messageType === 'error'): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?php echo addslashes($message); ?>'
            });
        <?php endif; ?>
    </script>
</body>
</html>

<?php
$conn->close();
?>
