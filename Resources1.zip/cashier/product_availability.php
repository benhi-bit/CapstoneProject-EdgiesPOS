<?php
session_start();
if (!isset($_SESSION['Username']) || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php';
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

// Ensure is_available column exists
$availabilityColumnCheck = $conn->query("SHOW COLUMNS FROM inventory LIKE 'is_available'");
if ($availabilityColumnCheck && $availabilityColumnCheck->num_rows === 0) {
    $conn->query("ALTER TABLE inventory ADD COLUMN is_available TINYINT(1) NOT NULL DEFAULT 1");
}
if ($availabilityColumnCheck) {
    $availabilityColumnCheck->close();
}

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userQuery->close();
$userFullName = (!empty($userData['FullName']) && trim($userData['FullName']) !== '') ? trim($userData['FullName']) : ($userData['Username'] ?? $_SESSION['Username']);

// Handle availability toggle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_status'], $_POST['inventory_id'])) {
    $id = (int)$_POST['inventory_id'];
    $stmt = $conn->prepare("SELECT InventoryName, is_available FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $productData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($productData) {
        $newStatus = $productData['is_available'] ? 0 : 1;
        $updateStmt = $conn->prepare("UPDATE inventory SET is_available = ? WHERE InventoryID = ?");
        $updateStmt->bind_param("ii", $newStatus, $id);

        if ($updateStmt->execute()) {
            $statusLabel = $newStatus ? 'Available' : 'Unavailable';
            $description = sprintf("Product status updated: %s is now %s", $productData['InventoryName'], $statusLabel);
            addSystemLog($conn, "Product Status Updated", $description, $userFullName);
            $_SESSION['success_message'] = 'Product status updated successfully.';
        } else {
            $_SESSION['error_message'] = 'Error updating product status.';
        }
        $updateStmt->close();
        $redirectUrl = 'product_availability.php';
        if (!empty($_POST['redirect_category'])) $redirectUrl .= '?category=' . (int)$_POST['redirect_category'];
        if (!empty($_POST['redirect_search'])) $redirectUrl .= (strpos($redirectUrl, '?') !== false ? '&' : '?') . 'search=' . urlencode(trim($_POST['redirect_search']));
        header('Location: ' . $redirectUrl);
        exit();
    }
}

// Fetch categories for filter (with formatted date for display if needed)
$categoriesResult = $conn->query("SELECT CategoryID, CategoryName FROM categories ORDER BY CategoryName");
$categories = [];
while ($row = $categoriesResult->fetch_assoc()) {
    $categories[] = $row;
}

// Filters
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$categoryFilter = isset($_GET['category']) ? (int)$_GET['category'] : 0;

$query = "SELECT i.InventoryID, i.InventoryName, i.Price, c.CategoryName, i.CategoryID, i.ImagePath, i.is_available
          FROM inventory i
          JOIN categories c ON i.CategoryID = c.CategoryID
          WHERE 1=1";
$params = [];
$types = '';

if ($searchTerm !== '') {
    $query .= " AND (i.InventoryName LIKE ? OR i.InventoryID = ?)";
    $searchParam = '%' . $searchTerm . '%';
    $params[] = $searchParam;
    $params[] = $searchTerm;
    $types .= 'si';
}
if ($categoryFilter > 0) {
    $query .= " AND i.CategoryID = ?";
    $params[] = $categoryFilter;
    $types .= 'i';
}

$query .= " ORDER BY c.CategoryName, i.InventoryName";

if (count($params) > 0) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

$currentPage = basename($_SERVER['PHP_SELF']);

function isActive($page, $current) {
    return ($page === $current) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Availability - Cashier</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }

        /* Sidebar - same as pos.php */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0;
        }

        .sidebar-nav-items::-webkit-scrollbar { width: 6px; }
        .sidebar-nav-items::-webkit-scrollbar-track { background: rgba(0, 0, 0, 0.2); }
        .sidebar-nav-items::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.3); border-radius: 3px; }
        .sidebar-nav-items::-webkit-scrollbar-thumb:hover { background: rgba(255, 255, 255, 0.5); }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0;
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        .sidebar-footer {
            flex-shrink: 0;
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto;
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i { font-size: 14px; }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i { margin-right: 10px; }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a {
            padding: 14px 20px;
            text-align: left;
        }

        /* Main - same as Product Management (admin) */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
        }

        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        /* Split layout - same as product_management */
        .management-container {
            display: flex;
            gap: 20px;
            height: calc(100vh - 100px);
        }

        .categories-panel {
            width: 280px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .products-panel {
            flex: 1;
            min-width: 0;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .panel-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            gap: 16px;
            min-width: 0;
        }

        .panel-header h2 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
            flex: 0 1 auto;
            min-width: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .panel-header h2 i {
            margin-right: 8px;
            color: #face0b;
            font-size: 18px;
        }

        .panel-header .header-actions {
            display: flex;
            align-items: center;
            flex-shrink: 0;
            margin-left: 16px; /* small gap from title, aligned to the left */
        }

        .panel-header .header-actions .search-container {
            flex-shrink: 0;
        }

        .panel-body {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }

        .products-panel .panel-body {
            display: flex;
            flex-direction: column;
            overflow: hidden;
            padding: 20px;
        }

        .products-panel .panel-body:not(:has(.table-scroll-wrapper)) {
            overflow-y: auto;
        }

        .table-scroll-wrapper {
            flex: 1;
            min-height: 0;
            overflow-y: auto;
            margin: 0 -20px;
            padding: 0 20px;
            background: #fff;
            border-radius: 12px;
        }

        .category-item {
            padding: 15px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid transparent;
        }

        .category-item:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }

        .category-item.active {
            background: #fff3cd;
            border-color: #face0b;
        }

        .category-name {
            font-weight: 600;
            font-size: 16px;
            color: #1e293b;
        }

        .search-box {
            padding: 10px 14px 10px 40px;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            font-size: 14px;
            color: #1e293b;
            transition: border 0.2s ease, box-shadow 0.2s ease;
        }

        .search-box::placeholder {
            color: #94a3b8;
        }

        .search-box:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }

        .btn-primary {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            padding: 8px 16px;
            border: none;
            border-radius: 999px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            text-decoration: none;
            font-size: 14px;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
            color: #000;
        }

        .products-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
        }

        .products-table thead {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #333;
            transform: translateZ(0);
            isolation: isolate;
        }

        .products-table thead tr {
            background: #333;
        }

        .products-table th {
            background-color: #333 !important;
            color: #ffffff;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 4px 0 0 #333;
            border-bottom: 4px solid #333;
        }

        .products-table th:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 0;
        }

        .products-table th:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 0;
        }

        .products-table tbody {
            position: relative;
            z-index: 1;
        }

        .products-table tbody tr {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .products-table td {
            padding: 12px;
            font-size: 14px;
        }

        .product-image-cell {
            width: 80px;
            height: 80px;
            padding: 8px;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 8px;
        }

        .status-toggle-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            color: #fff;
        }

        .status-available {
            background: #22c55e;
            color: white;
        }

        .status-unavailable {
            background: #ef4444;
            color: white;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }

        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 16px; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert-error { background: #fee2e2; color: #b91c1c; }
        /* Search bar: same as User Management */
        .search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
            padding: 10px 14px 10px 40px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px !important;
            outline: none !important;
        }
        .search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
        }
        .search-container { position: relative; }
        .search-container .input-with-icon { position: relative; }
        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
    </style>
</head>
<body>
    <!-- Sidebar - same structure as pos.php -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <div class="sidebar-nav-items">
            <a href="pos.php" class="<?php echo isActive('pos.php', $currentPage); ?>">
                <i class="fas fa-cash-register"></i>
                <span>Take Out</span>
            </a>
            <a href="pos.php" id="tablesTab">
                <i class="fas fa-table"></i>
                <span>Dine In</span>
            </a>
            <a href="product_availability.php" class="<?php echo isActive('product_availability.php', $currentPage); ?>">
                <i class="fas fa-box-open"></i>
                <span>Products</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

    <main>
        <div class="management-container">
            <!-- Left Panel: Categories (same as product_management) -->
            <div class="categories-panel">
                <div class="panel-header">
                    <h2><i class="fas fa-list-alt"></i> Categories</h2>
                </div>
                <div class="panel-body">
                    <div id="categoriesList">
                        <a href="product_availability.php<?php echo $searchTerm !== '' ? '?search=' . urlencode($searchTerm) : ''; ?>" class="category-item <?php echo $categoryFilter === 0 ? 'active' : ''; ?>" style="text-decoration: none; color: inherit; display: block;">
                            <span class="category-name">All</span>
                        </a>
                        <?php foreach ($categories as $cat): ?>
                            <a href="product_availability.php?category=<?php echo (int)$cat['CategoryID']; ?><?php echo $searchTerm !== '' ? '&search=' . urlencode($searchTerm) : ''; ?>" class="category-item <?php echo $categoryFilter === (int)$cat['CategoryID'] ? 'active' : ''; ?>" style="text-decoration: none; color: inherit; display: block;">
                                <span class="category-name"><?php echo htmlspecialchars($cat['CategoryName']); ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right Panel: Products (same as product_management) -->
            <div class="products-panel">
                <div class="panel-header">
                    <h2><i class="fas fa-box-open"></i> Product Availability</h2>
                    <div class="header-spacer" aria-hidden="true"></div>
                    <div class="header-actions">
                        <form method="get" id="searchForm" style="display: flex; align-items: center;">
                            <?php if ($categoryFilter > 0): ?>
                                <input type="hidden" name="category" value="<?php echo $categoryFilter; ?>">
                            <?php endif; ?>
                            <div class="search-container">
                                <div class="input-with-icon" style="width: 200px;">
                                    <i class="fas fa-search"></i>
                                    <input type="text" name="search" id="productSearchInput" class="search-box" placeholder="Search products..." value="<?php echo htmlspecialchars($searchTerm); ?>" style="width: 100%; margin: 0;" autocomplete="off">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel-body">
                    <?php if (!empty($_SESSION['success_message'])) { ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?></div>
                    <?php } ?>
                    <?php if (!empty($_SESSION['error_message'])) { ?>
                        <div class="alert alert-error"><?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?></div>
                    <?php } ?>

                    <?php if ($result && $result->num_rows > 0): ?>
                        <div class="table-scroll-wrapper">
                        <table class="products-table">
                            <thead>
                                <tr>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Category</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $result->fetch_assoc()):
                                    $imagePath = !empty($row['ImagePath']) ?
                                        (strpos($row['ImagePath'], '../') === 0 ? $row['ImagePath'] : '../' . $row['ImagePath']) :
                                        '../images/no-image.png';
                                    $isAvailable = (int)$row['is_available'] === 1;
                                    $statusLabel = $isAvailable ? 'Available' : 'Unavailable';
                                    $statusClass = $isAvailable ? 'status-available' : 'status-unavailable';
                                ?>
                                    <tr>
                                        <td class="product-image-cell">
                                            <img src="<?php echo htmlspecialchars($imagePath); ?>" alt="<?php echo htmlspecialchars($row['InventoryName']); ?>" class="product-image">
                                        </td>
                                        <td><?php echo htmlspecialchars($row['InventoryName']); ?></td>
                                        <td>₱<?php echo number_format((float)$row['Price'], 2); ?></td>
                                        <td><?php echo htmlspecialchars($row['CategoryName']); ?></td>
                                        <td>
                                            <form method="post" style="display: inline;">
                                                <input type="hidden" name="inventory_id" value="<?php echo (int)$row['InventoryID']; ?>">
                                                <input type="hidden" name="redirect_category" value="<?php echo $categoryFilter; ?>">
                                                <input type="hidden" name="redirect_search" value="<?php echo htmlspecialchars($searchTerm); ?>">
                                                <button type="submit" name="toggle_status" class="status-toggle-btn <?php echo $statusClass; ?>"><?php echo $statusLabel; ?></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                        </div>
                    <?php else: ?>
                        <div class="empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>No products found<?php echo $categoryFilter ? ' in this category' : ''; ?>.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }

        function confirmLogout(event) {
            event.preventDefault();
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout Confirmation',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#face0b',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../authentication/logout.php';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../authentication/logout.php';
                }
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.add('no-transition');
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    sidebar.classList.remove('sidebar-expanded');
                }
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }
        });

        function updateSidebarDateTime() {
            const now = new Date();
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateEl = document.getElementById('sidebar-date');
            const timeEl = document.getElementById('sidebar-time');
            if (dateEl) dateEl.textContent = now.toLocaleDateString('en-US', dateOptions);
            if (timeEl) timeEl.textContent = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
        }
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        // Search bar: submit form as user types (debounced) so search works without a button
        (function() {
            var form = document.getElementById('searchForm');
            var input = document.getElementById('productSearchInput');
            if (!form || !input) return;
            var debounceTimer;
            input.addEventListener('input', function() {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(function() { form.submit(); }, 400);
            });
        })();
    </script>
</body>
</html>
