<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Cashier') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Initialize date range variables
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-01'); // Default to the first day of the current month
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-t'); // Default to the last day of the current month

// Fetch sales data based on the selected date range
$salesQuery = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        SUM(oi.Quantity * oi.Price) AS TotalSales, 
        COUNT(oi.OrderItemID) AS TotalOrders 
    FROM 
        orders o 
    JOIN 
        order_items oi ON o.OrderID = oi.OrderID 
    WHERE 
        o.OrderDate BETWEEN ? AND ? 
    GROUP BY 
        o.OrderID, o.OrderDate 
    ORDER BY 
        o.OrderDate DESC
";
$salesStmt = $conn->prepare($salesQuery);
$salesStmt->bind_param("ss", $startDate, $endDate);
$salesStmt->execute();
$salesResult = $salesStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- SweetAlert2 for consistent logout confirmation -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
        header {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: #333;
    color: white;
    position: fixed; /* Fixed position */
    top: 0; /* Stick to the top */
    left: 0;
    z-index: 1000; /* Ensure it stays above other content */
    height: 50px; /* Set a fixed height for the header */
}

/* Header content flex container */
.header-content {
    display: flex;
    align-items: center; /* Center items vertically */
}

.company-logo img {
    height: 50px; /* Adjust logo height */
    margin-right: 10px; /* Space between logo and company name */
}

.company-name {
    font-size: 1.5em;
    font-weight: bold;
}

/* Main content area */
main {
    margin-left: 220px;
    margin-top: 60px; /* Height of the header */
    padding: 20px;
    flex-grow: 1;
}
        header .company-logo img {
            height: 50px; /* Adjust logo height */
            margin-right: 10px; /* Space between logo and company name */
        }

        header .company-name {
            font-size: 1.5em;
            font-weight: bold;
        }

        header .user-profile {
            display: flex;
            align-items: center;
        }

        header .user-profile span {
            margin-right: 10px; /* Space between username and icon */
        }

        header .user-profile img {
            height: 30px; /* Adjust icon height */
        }

        /* Sidebar Navigation */
      

        nav.sidebar a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            display: block; /* Make links block elements */
            text-align: left;
        }
        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }
        nav.sidebar a.active {
    background-color: #face0b; /* Highlight active link */
    color: black; /* Change text color for active link */
}
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #face0b;
        }
        tbody tr:nth-child(odd) {
    background-color: #f2f2f2; /* Light gray for odd rows */
}

tbody tr:nth-child(even) {
    background-color: #ffffff; /* White for even rows */
}
        tr:hover {
            background-color: #f1f1f1;
        }
        .button {
            padding: 6px 8px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .button:hover {
            background-color: #face0b;
        }
        .date-selector {
            margin-bottom: 20px;
        }
        nav.sidebar {
    width: 200px; /* Set the width of the sidebar */
    background-color: #333;
    height: 100vh; /* Full height */
    position: fixed; /* Fixed sidebar */
    top: 60px; /* Below the header */
    left: 0;
    overflow: auto; /* Enable scrolling if needed */
    padding-top: 20px;
}

/* Dropdown container */
.dropdown {
    position: relative; /* Position relative for absolute positioning of dropdown content */
}

/* Dropdown button */
.dropbtn {
    color: white;
    padding: 14px 20px;
    text-decoration: none;
    display: block; /* Make it block element */
}

/* Dropdown content (hidden by default) */
.dropdown-content {
    display: none; /* Hidden by default */
    position: relative; /* Change to relative to push down other items */
    background-color: #444; /* Dark background color for emphasis */
    min-width: 200px; /* Minimum width */
    z-index: 1; /* Sit on top */
    border-radius: 5px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for better visibility */
}

/* Links inside the dropdown */
.dropdown-content a {
    color: white; /* Text color */
    padding: 12px 16px; /* Padding */
    text-decoration: none; /* No underline */
    display: flex; /* Use flexbox for alignment */
    align-items: center; /* Center items vertically */
}

/* Style for icons */
.dropdown-content a i {
    margin-right: 10px; /* Space between icon and text */
}

/* Show the dropdown content on hover */
.dropdown:hover .dropdown-content {
    display: block; /* Show the dropdown */
}

/* Change background color on hover */
.dropdown-content a:hover {
    background-color: #555; /* Light background on hover */
    color: white; /* Keep text color white on hover */
}
.user-profile {
            display: flex; /* Use flexbox for alignment */
            align-items: center; /* Center items vertically */
            margin-right: 50px;
        }
        .user-profile img{
            width:30px;
            height:30px
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="company-logo">
            <img src="logo.png" alt="Company Logo"> <!-- Add your logo image path -->
        </div>
        <div class="company-name">EDGIE'S RESTAURANT AND EVENT PLACE</div>
    </div>
    <div class="user-profile">
        <span><?php echo $_SESSION['Username']; ?></span>
        <img src="user.png" alt="User  Icon"> <!-- Add your user icon path -->
    </div>
</header>
<nav class="sidebar">
<a href="pos.php"><i class="fas fa-shopping-cart"></i> Order</a>
    <a href="cashier_dashboard.php" ><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <div class="dropdown">
        <a href="cashier_inventory.php"  class="dropbtn"><i class="fas fa-boxes"></i> Inventory</a>
        <div class="dropdown-content">
            <a href="cashier_stockin.php"><i class="fas fa-arrow-up"></i> Stock In</a>
            <a href="stock_out.php"><i class="fas fa-arrow-down"></i> Stock Out</a>
        </div>
    </div>
    <a href="cashier_category.php"><i class="fas fa-list-alt"></i> Category</a>
    <a href="cashier_transaction_history.php"><i class="fas fa-receipt"></i> Transaction History</a>
    <a href="cashier_inventory_history.php"><i class="fas fa-history"></i> Inventory History</a>
    <a href="cashier_sales_report.php" class="active"><i class="fas fa-chart-line"></i> Sales Report</a>
    <a href="#" onclick="confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>
<main>
    <h2>Sales Overview</h2>
    
    <!-- Date Selector Form -->
    <form method="POST" class="date-selector">
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" value="<?php echo $startDate; ?>" required>
        
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" value="<?php echo $endDate; ?>" required>
        
        <button type="submit" class="button">Filter</button>
        <button type="button" onclick="generateReport()" class="button">Generate Sales Report</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Total Sales</th>
                <th>Total Orders</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($salesResult->num_rows > 0): ?>
                <?php while ($sale = $salesResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $sale['OrderID']; ?></td>
                        <td><?php echo date('Y-m-d H:i:s', strtotime($sale['OrderDate'])); ?></td>
                        <td>₱ <?php echo number_format($sale['TotalSales'], 2); ?></td>
                        <td><?php echo $sale['TotalOrders']; ?></td>
                        <td>
                            <a href="order_details.php?order_id=<?php echo $sale['OrderID']; ?>" class="button">View Details</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5">No sales found for the selected date range.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</main>

<script>
function generateReport() {
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    
    // Redirect to the report generation page with all parameters
    window.location.href = `generate_cashier_report.php?start_date=${startDate}&end_date=${endDate}`;
}

function confirmLogout(event) {
    event.preventDefault();
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            title: 'Logout Confirmation',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#face0b',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../authentication/logout.php';
            }
        });
    } else {
        if (confirm('Are you sure you want to logout?')) {
        window.location.href = '../authentication/logout.php';
        }
    }
}
</script>
</body>
</html>

<?php
$salesStmt->close();
$conn->close();
?>