<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Cashier') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'];

// Get parameters from URL
$startDateParam = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$endDateParam = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');
$startDateForDisplay = date('Y-m-d', strtotime($startDateParam));
$endDateForDisplay = date('Y-m-d', strtotime($endDateParam));
$startDate = date('Y-m-d 00:00:00', strtotime($startDateParam));
$endDate = date('Y-m-d 23:59:59', strtotime($endDateParam));

// Build query for sales data
$salesQuery = "
    SELECT 
        o.OrderID, 
        o.OrderDate, 
        SUM(oi.Quantity * oi.Price) AS TotalSales, 
        COUNT(oi.OrderItemID) AS TotalOrders,
        GROUP_CONCAT(CONCAT(p.InventoryName, ' (', oi.Quantity, ')') SEPARATOR ', ') as Details
    FROM 
        orders o 
    JOIN 
        order_items oi ON o.OrderID = oi.OrderID 
    JOIN
        inventory p ON oi.InventoryID = p.InventoryID
    WHERE 
        o.OrderDate BETWEEN ? AND ?
        AND o.Username = ?
    GROUP BY 
        o.OrderID, o.OrderDate 
    ORDER BY 
        o.OrderDate DESC
";

$salesStmt = $conn->prepare($salesQuery);
$salesStmt->bind_param("sss", $startDate, $endDate, $_SESSION['Username']);
$salesStmt->execute();
$salesResult = $salesStmt->get_result();

// Set headers for CSV download
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="cashier_sales_report_' . $startDateForDisplay . '_to_' . $endDateForDisplay . '.csv"');
header('Pragma: no-cache');
header('Expires: 0');

// Create output stream
$output = fopen('php://output', 'w');

// Add UTF-8 BOM for proper Excel encoding
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// Write report header information with better formatting
fputcsv($output, array("EDGIE'S RESTAURANT AND EVENT PLACE"));
fputcsv($output, array('CASHIER SALES REPORT'));
fputcsv($output, array('Period', date('F d, Y', strtotime($startDateForDisplay)) . ' to ' . date('F d, Y', strtotime($endDateForDisplay))));
fputcsv($output, array('Generated', date('F d, Y h:i A')));
fputcsv($output, array('Cashier', $userFullName));
fputcsv($output, array('')); // spacer

// Write CSV header with better column names
fputcsv($output, array('Order ID', 'Date & Time', 'Total Sales', 'Total Orders', 'Details'));

// Initialize total amount
$totalAmount = 0;

// Write data rows
while ($row = $salesResult->fetch_assoc()) {
    // Format date cleanly - Excel will auto-size columns when opening CSV
    $formattedDate = date('m/d/Y h:i A', strtotime($row['OrderDate']));
    
    fputcsv($output, array(
        $row['OrderID'],
        $formattedDate,
        number_format((float)$row['TotalSales'], 2, '.', ''),
        $row['TotalOrders'],
        preg_replace("/[\\r\\n]+/", ' | ', strip_tags((string)$row['Details']))
    ));
    $totalAmount += (float)$row['TotalSales'];
}

// Summary block
fputcsv($output, array('')); // spacer
fputcsv($output, array('SUMMARY'));
fputcsv($output, array('Total Amount', number_format($totalAmount, 2, '.', '')));

// Close the output stream
fclose($output);

// Log the report generation
$description = sprintf(
    "Generated cashier sales report for period %s to %s",
    $startDateForDisplay,
    $endDateForDisplay
);
addSystemLog($conn, "Report Generated", $description, $userFullName);

// Close database connections
$salesStmt->close();
$conn->close();
?> 