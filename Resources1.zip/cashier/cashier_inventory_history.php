<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Cashier') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Fetch inventory history
$result = $conn->query("SELECT i.InventoryName, c.CategoryName, iu.Quantity, iu.Action, iu.Date_Updated 
FROM inventory i 
JOIN inventory_update iu ON i.InventoryID = iu.InventoryID 
JOIN categories c ON i.CategoryID = c.CategoryID;");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory History</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- SweetAlert2 for consistent logout confirmation -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }
       
        header {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 30px;
    background: #333;
    color: white;
    position: fixed; /* Fixed position */
    top: 0; /* Stick to the top */
    left: 0;
    z-index: 1000; /* Ensure it stays above other content */
    height: 50px; /* Set a fixed height for the header */
}

/* Header content flex container */
.header-content {
    display: flex;
    align-items: center; /* Center items vertically */
}

.company-logo img {
    height: 50px; /* Adjust logo height */
    margin-right: 10px; /* Space between logo and company name */
}

.company-name {
    font-size: 1.5em;
    font-weight: bold;
}

/* Main content area */
main {
    margin-left: 220px;
    margin-top: 60px; /* Height of the header */
    padding: 20px;
    flex-grow: 1;
}
        header .company-logo img {
            height: 50px; /* Adjust logo height */
            margin-right: 10px; /* Space between logo and company name */
        }

        header .company-name {
            font-size: 1.5em;
            font-weight: bold;
        }

        header .user-profile {
            display: flex;
            align-items: center;
        }

        header .user-profile span {
            margin-right: 10px; /* Space between username and icon */
        }

        header .user-profile img {
            height: 30px; /* Adjust icon height */
        }

        /* Sidebar Navigation */
        
        nav.sidebar a {
            color: white;
            padding: 14px 20px;
            text-decoration: none;
            display: block; /* Make links block elements */
            text-align: left;
        }
        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }
        nav.sidebar a.active {
    background-color: #face0b; /* Highlight active link */
    color: black; /* Change text color for active link */
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    border-radius:50px;
    
}

th, td {
    padding: 10px;
    text-align: left;
    font-size: 16px;
}

th {
    background-color: #face0b;
    cursor: pointer;
}

/* Striped table rows */
tbody tr:nth-child(odd) {
    background-color: #f2f2f2; /* Light gray for odd rows */
}

tbody tr:nth-child(even) {
    background-color: #ffffff; /* White for even rows */
}

/* Remove table border */
table, th, td {
    border: none; /* No borders around the table or cells */
}

/* Hover effect on table rows */
tbody tr:hover {
    background-color: #f1f1f1; /* Slightly darker when hovering */
}
nav.sidebar {
    width: 200px; /* Set the width of the sidebar */
    background-color: #333;
    height: 100vh; /* Full height */
    position: fixed; /* Fixed sidebar */
    top: 60px; /* Below the header */
    left: 0;
    overflow: auto; /* Enable scrolling if needed */
    padding-top: 20px;
}

/* Dropdown container */
.dropdown {
    position: relative; /* Position relative for absolute positioning of dropdown content */
}

/* Dropdown button */
.dropbtn {
    color: white;
    padding: 14px 20px;
    text-decoration: none;
    display: block; /* Make it block element */
}

/* Dropdown content (hidden by default) */
.dropdown-content {
    display: none; /* Hidden by default */
    position: relative; /* Change to relative to push down other items */
    background-color: #444; /* Dark background color for emphasis */
    min-width: 200px; /* Minimum width */
    z-index: 1; /* Sit on top */
    border-radius: 5px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for better visibility */
}

/* Links inside the dropdown */
.dropdown-content a {
    color: white; /* Text color */
    padding: 12px 16px; /* Padding */
    text-decoration: none; /* No underline */
    display: flex; /* Use flexbox for alignment */
    align-items: center; /* Center items vertically */
}

/* Style for icons */
.dropdown-content a i {
    margin-right: 10px; /* Space between icon and text */
}

/* Show the dropdown content on hover */
.dropdown:hover .dropdown-content {
    display: block; /* Show the dropdown */
}

/* Change background color on hover */
.dropdown-content a:hover {
    background-color: #555; /* Light background on hover */
    color: white; /* Keep text color white on hover */
}
.user-profile {
            display: flex; /* Use flexbox for alignment */
            align-items: center; /* Center items vertically */
            margin-right: 50px;
        }
        .user-profile img{
            width:30px;
            height:30px
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="company-logo">
            <img src="logo.png" alt="Company Logo"> <!-- Add your logo image path -->
        </div>
        <div class="company-name">EDGIE'S RESTAURANT AND EVENT PLACE</div>
    </div>
    <div class="user-profile">
        <span><?php echo $_SESSION['Username']; ?></span>
        <img src="user.png" alt="User  Icon"> <!-- Add your user icon path -->
    </div>
</header>
<nav class="sidebar">
    <a href="admin_dashboard.php" ><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <div class="dropdown">
        <a href="inventory.php"  class="dropbtn"><i class="fas fa-boxes"></i> Inventory</a>
        <div class="dropdown-content">
            <a href="stockin.php"><i class="fas fa-arrow-up"></i> Stock In</a>
            <a href="stock_out.php"><i class="fas fa-arrow-down"></i> Stock Out</a>
        </div>
    </div>
    <a href="category.php"><i class="fas fa-list-alt"></i> Category</a>
    <a href="#.php"><i class="fas fa-receipt"></i> Transaction History</a>
    <a href="inventory_history.php" class="active"><i class="fas fa-history"></i> Inventory History</a>
    <a href="sales_report.php" ><i class="fas fa-chart-line"></i> Sales Report</a>
    <a href="user_management.php"><i class="fas fa-users-cog"></i> User Management</a>
    <a href="#" onclick="confirmLogout(event)"><i class="fas fa-sign-out-alt"></i> Logout</a>
</nav>
<main>
    <h2>Inventory History</h2>

    <table>
        <thead>
            <tr>
                <th>Inventory Name</th>
                <th>Category Name</th>
                <th>Quantity</th>
                <th>Action</th>
                <th>Date Updated</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): 
                echo "<tr>
                        <td>{$row['InventoryName']}</td>
                        <td>{$row['CategoryName']}</td>
                        <td>{$row['Quantity']}</td>
                        <td>{$row['Action']}</td>
                        <td>{$row['Date_Updated']}</td>
                      </tr>";
            endwhile; ?>
        </tbody>
    </table>
</main>
<script>
    function confirmLogout(event) {
        event.preventDefault(); // Prevent the default link behavior
        if (typeof Swal !== 'undefined') {
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        } else {
        const confirmation = confirm("Are you sure you want to logout?");
        if (confirmation) {
            window.location.href = '../authentication/logout.php'; // Redirect to logout page if confirmed
            }
        }
    }
</script>
</body>
</html>