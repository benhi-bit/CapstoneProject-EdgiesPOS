<?php
session_start();
if (!isset($_SESSION['Username']) || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php'; // Include logging functionality
require_once __DIR__ . '/../lib/ensure_transactions_table.php';

ensureTransactionsTable($conn);

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userQuery->close();

// Determine display name
if (!empty($userData) && !empty($userData['FullName']) && trim($userData['FullName']) !== '') {
    $userFullName = trim($userData['FullName']);
} elseif (!empty($userData) && !empty($userData['Username'])) {
    $userFullName = $userData['Username'];
} else {
    $userFullName = $_SESSION['Username'] ?? 'Cashier';
}

// Function to format numbers with commas
function formatNumber($number) {
    return number_format($number, 2, '.', ',');
}

// Handle inventory update and transaction history on order confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order'])) {
    // Set header for JSON response
    header('Content-Type: application/json');
    
    $cartJson = $_POST['cart'] ?? '[]';
    $cart = json_decode($cartJson, true); // Decode the cart from JSON
    
    // Check if JSON decode was successful
    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid cart data format.']);
        exit();
    }
    
    // Validate cart is not empty
    if (empty($cart) || !is_array($cart)) {
        echo json_encode(['status' => 'error', 'message' => 'Cart is empty.']);
        exit();
    }
    
    $subtotal = 0; // Initialize subtotal (VAT inclusive)
    $subtotalVatExempt = 0; // Subtotal for VAT exempt items (PWD discounted items)
    $subtotalVatable = 0; // Subtotal for VATable items
    $totalVatAmount = 0; // Total VAT amount
    $totalPwdDiscount = 0; // Total PWD discount
    // Manual discount is sent as percentage (0-100)
    $manualDiscountPercent = isset($_POST['manual_discount']) ? floatval($_POST['manual_discount']) : 0.0;
    if ($manualDiscountPercent > 100) {
        $manualDiscountPercent = 100;
    }
    if ($manualDiscountPercent < 0) {
        $manualDiscountPercent = 0;
    }
    
    // Get payment method from POST, default to cash
    $paymentMethod = isset($_POST['payment_method']) ? $_POST['payment_method'] : 'cash';
    $referenceNo = isset($_POST['reference_no']) ? $_POST['reference_no'] : null;
    $cash = isset($_POST['cash']) ? floatval($_POST['cash']) : 0.0;
    $orderType = isset($_POST['order_type']) ? $_POST['order_type'] : 'dine-in';

    // Calculate totals with item-level PWD discount
    // Prices are VAT inclusive, so we need to extract VAT
    foreach ($cart as $item) {
        $itemPrice = floatval($item['price']);
        $itemQuantity = intval($item['quantity']);
        $itemHasPwdDiscount = isset($item['hasPwdDiscount']) && $item['hasPwdDiscount'] === true;
        
        $itemSubtotal = $itemPrice * $itemQuantity;
        $subtotal += $itemSubtotal;
        
        if ($itemHasPwdDiscount) {
            // PWD discount: 20% off, and item becomes VAT exempt
            $itemPwdDiscount = $itemSubtotal * 0.20;
            $totalPwdDiscount += $itemPwdDiscount;
            $itemAfterDiscount = $itemSubtotal - $itemPwdDiscount;
            $subtotalVatExempt += $itemAfterDiscount;
        } else {
            // Regular item: extract VAT (VAT inclusive price)
            // Base price = price / 1.12, VAT = price - base price
            $itemBasePrice = $itemSubtotal / 1.12;
            $itemVatAmount = $itemSubtotal - $itemBasePrice;
            $totalVatAmount += $itemVatAmount;
            $subtotalVatable += $itemSubtotal;
        }
    }
    
    // Apply manual discount (percentage of total before manual discount)
    $totalBeforeManualDiscount = $subtotal - $totalPwdDiscount;
    $manualDiscount = $totalBeforeManualDiscount * ($manualDiscountPercent / 100);
    
    // Final total calculation
    $totalAmount = $subtotal - $totalPwdDiscount - $manualDiscount;

    // Validate payment based on method
    if ($paymentMethod === 'cash') {
        if ($totalAmount > 0 && $cash <= 0) {
            echo json_encode(['status' => 'error', 'message' => 'Please enter the amount paid.']);
            exit();
        }
        // Block transaction if cash tendered is less than total amount due
        if ($totalAmount > 0 && $cash < $totalAmount) {
            echo json_encode(['status' => 'error', 'message' => 'Amount paid is less than the total. Please enter a sufficient amount.']);
            exit();
        }
        $change = $cash - $totalAmount;
    } else {
        // GCash or Maya - no cash input needed, payment equals total
        $cash = $totalAmount;
        $change = 0;
        if (empty($referenceNo)) {
            echo json_encode(['status' => 'error', 'message' => 'Please enter the reference number.']);
            exit();
        }
        // Validate reference number based on payment method
        if ($paymentMethod === 'gcash') {
            // GCash requires exactly 9 digits
            if (!preg_match('/^\d{9}$/', $referenceNo)) {
                echo json_encode(['status' => 'error', 'message' => 'GCash reference number must be exactly 9 digits.']);
                exit();
            }
        } else if ($paymentMethod === 'paymaya') {
            // Maya requires exactly 6 digits
            if (!preg_match('/^\d{6}$/', $referenceNo)) {
                echo json_encode(['status' => 'error', 'message' => 'Maya reference number must be exactly 6 digits.']);
                exit();
            }
        }
    }

    // Get the next transaction number (internal, numeric)
    $transactionNumQuery = $conn->query("SELECT COALESCE(MAX(transaction_num), 0) FROM transactions");
    $transactionNumRow = $transactionNumQuery->fetch_row();
    $transactionNum = (int)$transactionNumRow[0] + 1;
    
    // Generate Sales Invoice No (customer-facing), date-based per month: YYYYMM001 (no '#' or '-')
    $currentPeriod = date('Ym'); // e.g. 202603
    $salesInvoiceNo = null;
    $salesInvoiceQuery = $conn->prepare("SELECT MAX(sales_invoice_no) FROM transactions WHERE sales_invoice_no LIKE CONCAT(?, '%')");
    if ($salesInvoiceQuery) {
        $salesInvoiceQuery->bind_param('s', $currentPeriod);
        if ($salesInvoiceQuery->execute()) {
            $salesInvoiceQuery->bind_result($maxInvoice);
            $salesInvoiceQuery->fetch();
            if ($maxInvoice) {
                // Extract last 3 digits
                $lastSeq = (int)substr($maxInvoice, -3);
                $nextSeq = $lastSeq + 1;
            } else {
                $nextSeq = 1;
            }
            $salesInvoiceNo = sprintf('%s%03d', $currentPeriod, $nextSeq); // e.g. 202603001
        }
        $salesInvoiceQuery->close();
    }
    // Fallback if for some reason generation failed
    if (empty($salesInvoiceNo)) {
        $salesInvoiceNo = sprintf('%s001', $currentPeriod);
    }

    // Prepare details with product names, quantities, and PWD discount indicators
    $detailsArray = array_map(function($item) {
        $pwdMarker = (isset($item['hasPwdDiscount']) && $item['hasPwdDiscount']) ? '[PWD]' : '';
        return $item['name'] . '(' . $item['quantity'] . ')' . $pwdMarker;
    }, $cart);
    if ($manualDiscount > 0) {
        $detailsArray[] = 'Manual Discount: ' . number_format($manualDiscount, 2);
    }
    $detailsArray[] = $userFullName; // Add user's full name at the end
    $details = implode(', ', $detailsArray);

    // Insert into transactions table with payment, change_amount, payment_method, reference_no, and processed_by (username)
    $processedBy = $_SESSION['Username'] ?? null;
    
    // Validate cart data
    if (empty($cart) || !is_array($cart)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid cart data.']);
        exit();
    }
    
    // Validate required fields (allow totalAmount 0 when e.g. 100% manual discount)
    if (empty($transactionNum) || $totalAmount < 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid transaction data.']);
        exit();
    }

    // Insert both transaction_num (internal) and sales_invoice_no (customer-facing) separately
    $stmt = $conn->prepare("INSERT INTO transactions (transaction_num, sales_invoice_no, transaction_date, total_amount, details, payment, change_amount, payment_method, reference_no, processed_by) VALUES (?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?)");
    
    if (!$stmt) {
        echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $conn->error]);
        exit();
    }
    
    // Bind: transaction_num, sales_invoice_no, total_amount, details, payment, change_amount, payment_method, reference_no, processed_by
    $stmt->bind_param("ssdsddsss", $transactionNum, $salesInvoiceNo, $totalAmount, $details, $cash, $change, $paymentMethod, $referenceNo, $processedBy);

    if ($stmt->execute()) {
        // Add system log
        $logDescription = sprintf(
            "Transaction #%s completed",
            $transactionNum
        );
        addSystemLog($conn, "POS Transaction", $logDescription, $userFullName);

        echo json_encode([
            'status' => 'success',
            'transaction_num' => $transactionNum,
            'sales_invoice_no' => $salesInvoiceNo,
            'order_type' => $orderType,
            'total_amount' => formatNumber($totalAmount),
            'change' => formatNumber($change),
            'cash' => formatNumber($cash),
            'payment_method' => $paymentMethod,
            'reference_no' => $referenceNo,
            'cashier' => $userFullName,
            'cart' => $cart,
            'subtotal' => formatNumber($subtotal),
            'pwd_discount' => formatNumber($totalPwdDiscount),
            'manual_discount' => formatNumber($manualDiscount),
            'vat_amount' => formatNumber($totalVatAmount),
            'vat_exempt_amount' => formatNumber($subtotalVatExempt)
        ]);
    } else {
        $errorMessage = 'Failed to insert transaction.';
        if ($stmt->error) {
            $errorMessage .= ' Error: ' . $stmt->error;
        }
        echo json_encode(['status' => 'error', 'message' => $errorMessage]);
    }
    
    $stmt->close();
    exit();
}

// Set current page for sidebar
$currentPage = basename($_SERVER['PHP_SELF']);

// Get user role
$userRole = isset($_SESSION['Role']) ? $_SESSION['Role'] : '';

// Function to get icon for category
function getCategoryIcon($categoryName) {
    $categoryName = strtolower(trim($categoryName));
    
    // Map category names to icons
    $iconMap = [
        'all-day meals' => 'fa-utensils',
        'all day meals' => 'fa-utensils',
        'sharing menu' => 'fa-users',
        'sizzling plates' => 'fa-fire',
        'chicken wings' => 'fa-drumstick-bite',
        'add-ons' => 'fa-plus-circle',
        'add ons' => 'fa-plus-circle',
        'pulutan' => 'fa-beer',
        'pancit menu' => 'fa-utensils',
        'pancit' => 'fa-utensils',
        'noodles' => 'fa-utensils',
        'cocktails & drinks' => 'fa-cocktail',
        'cocktails and drinks' => 'fa-cocktail',
        'drinks' => 'fa-wine-glass',
        'beverages' => 'fa-glass-water',
        'desserts' => 'fa-birthday-cake',
        'appetizers' => 'fa-seedling',
        'salads' => 'fa-leaf',
        'soups' => 'fa-bowl-food',
        'rice' => 'fa-bowl-rice',
        'pasta' => 'fa-bowl-food',
        'pizza' => 'fa-pizza-slice',
        'burgers' => 'fa-hamburger',
        'sandwiches' => 'fa-bread-slice',
    ];
    
    // Check for exact match first
    if (isset($iconMap[$categoryName])) {
        return $iconMap[$categoryName];
    }
    
    // Check for partial matches
    foreach ($iconMap as $key => $icon) {
        if (strpos($categoryName, $key) !== false) {
            return $icon;
        }
    }
    
    // Default icon
    return 'fa-tag';
}

// Fetch categories - order Add-Ons to the bottom
$categoriesResult = $conn->query("SELECT * FROM categories ORDER BY 
    CASE 
        WHEN LOWER(CategoryName) LIKE '%add-on%' OR LOWER(CategoryName) LIKE '%add on%' THEN 1 
        ELSE 0 
    END, 
    CategoryName ASC");

// Ensure is_available column exists
$availabilityColumnCheck = $conn->query("SHOW COLUMNS FROM inventory LIKE 'is_available'");
if ($availabilityColumnCheck && $availabilityColumnCheck->num_rows === 0) {
    $conn->query("ALTER TABLE inventory ADD COLUMN is_available TINYINT(1) NOT NULL DEFAULT 1");
}
if ($availabilityColumnCheck) {
    $availabilityColumnCheck->close();
}

// Fetch all products - ensure is_available is included
// Sort alphabetically by InventoryName for POS display
$productsResult = $conn->query("SELECT p.*, c.CategoryName FROM inventory p JOIN categories c ON p.CategoryID = c.CategoryID ORDER BY p.InventoryName ASC");
$products = [];
while ($product = $productsResult->fetch_assoc()) {
    // Ensure is_available is set and properly cast (default to 1 if not set or NULL)
    if (!isset($product['is_available']) || $product['is_available'] === null) {
        $product['is_available'] = 1;
    } else {
        // Cast to integer to ensure proper comparison
        $product['is_available'] = (int)$product['is_available'];
    }
    $products[] = $product; // Store all products in an array
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ordering System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Add SweetAlert2 CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-warning {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        
        /* Remove yellow line/divider in the middle of SweetAlert */
        .swal2-actions {
            border-top: none !important;
            border-color: transparent !important;
        }
        
        .swal2-popup hr,
        .swal2-popup .swal2-actions::before,
        .swal2-popup .swal2-actions::after {
            display: none !important;
        }
        
        /* Remove any horizontal dividers or lines */
        .swal2-popup .swal2-html-container::after,
        .swal2-popup .swal2-title::after,
        .swal2-popup .swal2-content::after {
            display: none !important;
        }
        
        /* Remove border from actions container */
        .swal2-actions {
            border: none !important;
            border-top: none !important;
            margin-top: 0 !important;
            padding-top: 0 !important;
        }
        
        /* Remove any yellow/yellowish borders or dividers */
        .swal2-popup * {
            border-color: transparent !important;
        }
        
        .swal2-popup .swal2-actions {
            border-top: 1px solid transparent !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar:hover .sidebar-nav-items,
        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a {
            padding: 14px 20px;
            text-align: left;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            display: flex;
            gap: 20px;
            height: calc(100vh - 40px);
            transition: margin-left 0.3s ease;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        .content-section {
            background: white;
            border-radius: 10px;
            padding: 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .menu-section {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        .cart-section {
            width: 380px;
            min-width: 380px;
            max-width: 380px;
            flex-shrink: 0;
            display: flex;
            flex-direction: column;
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        h2 {
            color: #333;
            margin-bottom: 15px;
            font-size: 20px;
            border-bottom: 2px solid #face0b;
            padding-bottom: 10px;
        }

        /* Menu Section Styles */
        .menu-content {
            display: flex;
            height: 100%;
            gap: 0;
            padding: 0;
        }

        /* Categories Vertical Sidebar */
        .categories-sidebar {
            width: 120px;
            min-width: 120px;
            flex-shrink: 0;
            background: #f8f9fa;
            border-right: 2px solid #e9ecef;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        .categories-scroll-container {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 12px 8px;
            -webkit-overflow-scrolling: touch;
        }

        .categories-scroll-container::-webkit-scrollbar {
            width: 6px;
        }

        .categories-scroll-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .categories-scroll-container::-webkit-scrollbar-thumb {
            background: #face0b;
            border-radius: 3px;
        }

        .categories-scroll-container::-webkit-scrollbar-thumb:hover {
            background: #ffd700;
        }

        .categories-vertical {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .category-card {
            background: #ffffff;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            padding: 12px 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 6px;
            width: 100%;
            min-height: 80px;
            flex-shrink: 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.06);
            box-sizing: border-box;
        }

        .category-card i {
            font-size: 22px;
            color: #6c757d;
            transition: all 0.3s ease;
        }

        .category-card span {
            font-size: 11px;
            font-weight: 500;
            color: #495057;
            text-align: center;
            white-space: nowrap;
            transition: all 0.3s ease;
            line-height: 1.2;
        }

        .category-card:hover {
            transform: translateX(4px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border-color: #face0b;
            background: #fffef5;
        }

        .category-card:hover i,
        .category-card:hover span {
            color: #face0b;
        }

        .category-card.active {
            background: #face0b;
            border-color: #face0b;
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.3);
        }

        .category-card.active i,
        .category-card.active span {
            color: #000;
            font-weight: 600;
        }

        .products-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            padding: 20px 20px 20px 20px;
            padding-top: 0;
        }

        /* Search bar styles */
        .search-container {
            position: relative;
            width: 100%;
            flex-shrink: 0;
            margin: 20px 0;
        }

        .search-input {
            width: 100%;
            padding: 10px 14px 10px 16px;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            font-size: 14px;
            transition: border 0.2s ease, box-shadow 0.2s ease;
            background: #ffffff;
            box-sizing: border-box;
        }

        .search-input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }

        .search-icon {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #6c757d;
            pointer-events: none;
        }

        /* Product grid styles */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
            width: 100%;
            box-sizing: border-box;
            flex: 1;
            overflow-y: auto;
            padding: 0;
            grid-auto-flow: dense;
            align-content: start;
        }

        .product-item[style*="display: none"] {
            display: none !important;
            position: absolute;
            visibility: hidden;
        }

        .product-item {
            background: #ffffff;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            height: 240px;
            box-sizing: border-box;
            width: 100%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.06);
            position: relative;
            overflow: hidden;
        }

        .product-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: #face0b;
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .product-item:hover::before {
            transform: scaleX(1);
        }

        .product-img {
            width: 140px;
            height: 140px;
            border-radius: 10px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #f5f5f5;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            position: relative;
        }

        .product-item:hover .product-img {
            transform: scale(1.05);
        }

        .product-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .product-item p {
            margin: 0;
            font-size: 14px;
            width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            padding: 0 8px;
            font-weight: 500;
            color: #2d3748;
        }

        .product-item p:last-child {
            color: #e74c3c;
            font-weight: 700;
            font-size: 16px;
            margin-top: 4px;
        }

        .product-item:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
            border-color: #face0b;
        }

.product-item.unavailable {
    cursor: not-allowed;
    opacity: 0.7;
}

.product-item.unavailable .product-img {
    filter: grayscale(100%);
}

.product-item.unavailable .product-img::after {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.55);
}

.product-status-badge {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    color: #fff;
    padding: 8px 14px;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.8px;
    box-shadow: 0 8px 18px rgba(239, 68, 68, 0.45);
    z-index: 2;
    pointer-events: none;
}

        /* Card Header and Body Styles */
        .card-header {
            background: #333;
            color: white;
            padding: 16px 20px;
            font-weight: 700;
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-radius: 10px 10px 0 0;
        }

        .card-body {
            padding: 0;
            display: flex;
            flex-direction: column;
            overflow: hidden;
            flex: 1;
        }

        /* Cart Layout Styles */
        .cart-items-container {
            flex: 1;
            overflow-y: auto;
            padding: 12px;
            min-height: 0;
        }

        .cart-items-container::-webkit-scrollbar {
            width: 8px;
        }

        .cart-items-container::-webkit-scrollbar-track {
            background: #f1f3f5;
            border-radius: 4px;
        }

        .cart-items-container::-webkit-scrollbar-thumb {
            background: #adb5bd;
            border-radius: 4px;
        }

        .cart-items-container::-webkit-scrollbar-thumb:hover {
            background: #868e96;
        }

        .cart-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px;
            margin-bottom: 10px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }

        .cart-item:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
            border-color: #face0b;
            transform: translateY(-2px);
        }

        .cart-item-image {
            width: 90px;
            height: 90px;
            flex-shrink: 0;
            border-radius: 10px;
            overflow: hidden;
            background: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .cart-item-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .cart-item-details {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
            gap: 3px;
        }

        .cart-item-name {
            font-weight: 600;
            font-size: 15px;
            color: #2d3748;
            line-height: 1.25;
        }

        .cart-item-customization {
            font-size: 12px;
            color: #718096;
            line-height: 1.2;
        }

        .cart-item-price-quantity {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            justify-content: center;
            gap: 6px;
            flex-shrink: 0;
        }

        .cart-item-price {
            font-size: 15px;
            font-weight: 700;
            color: #e74c3c;
        }

        .cart-item-quantity-controls {
            display: flex;
            align-items: center;
            gap: 4px;
            background: #f8f9fa;
            border-radius: 6px;
            padding: 3px;
            border: 1px solid #e9ecef;
        }

        .qty-btn {
            width: 22px;
            height: 22px;
            border: none;
            background: #ffffff;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            color: #495057;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        }

        .qty-btn:hover {
            background: #face0b;
            color: #000;
            transform: scale(1.1);
            box-shadow: 0 2px 4px rgba(250, 206, 11, 0.3);
        }

        .qty-btn:active {
            transform: scale(0.95);
        }

        .qty-input {
            width: 28px;
            height: 20px;
            text-align: center;
            border: none;
            background: transparent;
            font-size: 12px;
            font-weight: 600;
            color: #2d3748;
            padding: 0;
            -moz-appearance: textfield;
        }

        .qty-input::-webkit-outer-spin-button,
        .qty-input::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .qty-input:focus {
            outline: none;
        }

        .cart-summary {
            border-top: 2px solid #e9ecef;
            padding: 6px 10px;
            background: #f8f9fa;
            flex-shrink: 0;
        }

        .cart-summary .totals {
            background: transparent;
        }

        .cart-summary .totals p {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 3px 0;
            padding: 2px 0;
            font-size: 13px;
            color: #6c757d;
        }

        .cart-summary .totals p strong {
            font-size: 15px;
            color: #495057;
        }

        .cart-summary .totals p span {
            font-weight: 600;
            color: #495057;
            font-size: 13px;
            /* Ensure all amount values in totals align to the right */
            margin-left: auto;
            text-align: right;
            min-width: 80px;
        }

        /* Ensure breakdown amounts under the cash input are right-aligned */
        #vatBreakdown p span,
        #manualDiscountAmount span,
        #pwdDiscountAmount span {
            display: inline-block;
            float: right;
            min-width: 80px;
            text-align: right;
        }

        .cart-summary .totals label {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 3px 0;
            padding: 2px 0;
            font-size: 13px;
            color: #6c757d;
            font-weight: 500;
        }

        .cart-summary .totals input[type="number"] {
            width: 110px;
            padding: 6px 8px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            text-align: right;
            font-size: 13px;
            font-weight: 600;
            background: #ffffff;
            transition: all 0.3s ease;
            -moz-appearance: textfield;
        }

        .cart-summary .totals input[type="number"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .cart-summary .totals input[type="number"]::-webkit-outer-spin-button,
        .cart-summary .totals input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        /* Reference Number Input Styles */
        #referenceNoContainer {
            margin: 8px 0;
        }

        #referenceNoContainer label {
            font-size: 13px;
            color: #1e293b;
            font-weight: 600;
            letter-spacing: 0.3px;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        #referenceNoContainer label i {
            color: #64748b;
            font-size: 14px;
        }

        #referenceNoInput {
            flex: 1;
            padding: 6px 8px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 12px;
            color: #1e293b;
            font-weight: 600;
            background: #ffffff;
            transition: all 0.3s ease;
            width: 100%;
            max-width: 140px;
            text-align: left;
            box-sizing: border-box;
        }

        #referenceNoInput:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        #referenceNoInput::placeholder {
            color: #94a3b8;
            font-weight: 400;
        }

        .discount-section {
            margin: 8px 0;
        }

        .discount-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }

        .discount-controls label {
            font-size: 13px;
            color: #64748b;
            font-weight: 600;
            letter-spacing: 0.3px;
        }

        .discount-controls input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .cart-actions {
            display: flex;
            gap: 8px;
            padding: 12px 16px;
            background: #ffffff;
            border-top: 2px solid #e9ecef;
            flex-shrink: 0;
        }

        .cart-actions button {
            flex: 1;
            padding: 10px 16px;
            margin-top: 0;
            border-radius: 6px;
            font-weight: 600;
            font-size: 13px;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .cart-actions button:first-child {
            background: #333;
            color: white;
        }

        .cart-actions button:first-child:hover {
            background: #444;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(15, 23, 42, 0.25);
        }

        .cart-actions button:last-child {
            background: linear-gradient(135deg, #face0b 0%, #f7b300 100%);
            color: #000;
        }

        .cart-actions button:last-child:hover {
            background: linear-gradient(135deg, #ffd84d 0%, #face0b 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.4);
        }

        /* Empty cart message (no icon/text, keep spacing minimal) */
        .cart-empty {
            padding: 8px 0;
        }

        /* Modern Checkout Confirmation Modal */
        #orderPreviewWindow {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(8px);
            z-index: 10000;
            overflow-y: auto;
            padding: 20px;
            box-sizing: border-box;
        }

        #orderPreviewWindow .window-content {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            max-width: 600px;
            width: 100%;
            margin: 40px auto;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            position: relative;
            animation: slideUp 0.3s ease-out;
            display: flex;
            flex-direction: column;
            max-height: 90vh;
        }

        #orderPreviewWindow .checkout-header {
            flex-shrink: 0;
        }

        #orderPreviewWindow .checkout-scroll-body {
            flex: 1 1 0;
            min-height: 0;
            overflow-y: auto;
        }

        #orderPreviewWindow .checkout-actions {
            flex-shrink: 0;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 4px 12px rgba(250, 206, 11, 0.5);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            }
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #orderPreviewWindow .close {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 24px;
            color: #666;
            transition: all 0.3s ease;
            z-index: 10;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        #orderPreviewWindow .close:hover {
            background: #e74c3c;
            color: white;
            transform: rotate(90deg);
        }

        .checkout-header {
            background: linear-gradient(135deg, #333 0%, #555 100%);
            color: white;
            padding: 30px;
            text-align: center;
            position: relative;
        }

        .checkout-header::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #face0b, #ffd700);
        }

        .checkout-header h2 {
            margin: 0 0 10px 0;
            font-size: 28px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .checkout-header .restaurant-name {
            font-size: 18px;
            margin: 5px 0;
            opacity: 0.95;
        }

        .checkout-header .restaurant-address {
            font-size: 13px;
            margin: 5px 0;
            opacity: 0.8;
        }

        .checkout-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            padding: 20px 30px;
            background: #f8f9fa;
            border-bottom: 2px solid #e9ecef;
        }

        .checkout-info-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .checkout-info-item label {
            font-size: 13px;
            color: #1e293b;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
        }

        .checkout-info-item span {
            font-size: 16px;
            color: #2d3748;
            font-weight: 600;
        }

        .checkout-items {
            padding: 16px 20px;
            overflow-y: auto;
            flex: 0 0 70%;
            box-sizing: border-box;
        }

        .checkout-items-title {
            font-size: 16px;
            font-weight: 700;
            color: #2d3748;
            margin-bottom: 12px;
            padding-bottom: 6px;
            border-bottom: 2px solid #face0b;
        }

        .checkout-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 9px 0;
            border-bottom: 1px solid #e9ecef;
        }

        .checkout-item:last-child {
            border-bottom: none;
        }

        .checkout-item-info {
            flex: 1;
        }

        .checkout-item-name {
            font-size: 14px;
            font-weight: 600;
            color: #2d3748;
            margin-bottom: 2px;
        }

        .checkout-item-details {
            font-size: 12px;
            color: #6c757d;
        }

        .checkout-item-price {
            font-size: 15px;
            font-weight: 700;
            color: #e74c3c;
            text-align: right;
            min-width: 100px;
        }

        .checkout-totals {
            background: #ffffff;
            padding: 16px 24px;
            border-top: 3px solid #face0b;
            flex: 0 0 30%;
            overflow-y: auto;
            box-sizing: border-box;
        }

        .checkout-total-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
            font-size: 15px;
        }

        .checkout-total-row label {
            font-size: 15px;
            color: #64748b;
            font-weight: 600;
        }

        .checkout-total-row span {
            color: #2d3748;
            font-weight: 600;
            font-size: 16px;
        }

        .checkout-total-row.total-final {
            border-top: 2px solid #e9ecef;
            margin-top: 6px;
            padding-top: 12px;
        }

        .checkout-total-row.total-final label {
            font-size: 20px;
            font-weight: 700;
            color: #2d3748;
        }

        .checkout-total-row.total-final span {
            font-size: 24px;
            font-weight: 700;
            color: #e74c3c;
        }

        .checkout-total-row.discount {
            color: #28a745;
        }

        .checkout-total-row.discount span {
            color: #28a745;
        }

        .checkout-actions {
            padding: 25px 30px;
            background: #f8f9fa;
            display: flex;
            gap: 15px;
            border-top: 2px solid #e9ecef;
        }

        .checkout-btn {
            flex: 1;
            padding: 16px 24px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .checkout-btn-cancel {
            background: #333;
            color: white;
        }

        .checkout-btn-cancel:hover {
            background: #444;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(15, 23, 42, 0.25);
        }

        .checkout-btn-confirm {
            background: linear-gradient(135deg, #face0b 0%, #f7b300 100%);
            color: #000;
            box-shadow: 0 6px 20px rgba(250, 206, 11, 0.35);
        }

        .checkout-btn-confirm:hover {
            background: linear-gradient(135deg, #ffd84d 0%, #face0b 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 26px rgba(250, 206, 11, 0.45);
        }

        .checkout-items::-webkit-scrollbar {
            width: 8px;
        }

        .checkout-items::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }

        .checkout-items::-webkit-scrollbar-thumb {
            background: #face0b;
            border-radius: 4px;
        }

        .checkout-items::-webkit-scrollbar-thumb:hover {
            background: #ffd700;
        }

        /* Order Type Dropdown Styles */
        #orderTypeSelect {
            transition: all 0.3s ease;
        }

        #orderTypeSelect:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .mini-order-type-select {
            width: 100%;
            padding: 6px 8px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            background: #ffffff;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-bottom: 8px;
        }

        .mini-order-type-select:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        /* Tables View Styles */
        .table-container {
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            height: 600px;
            position: relative;
            transition: all 0.3s ease;
            overflow: hidden;
        }

        .table-container:hover {
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 15px;
            border-bottom: 2px solid #e9ecef;
            margin-bottom: 15px;
            user-select: none;
        }

        .table-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
        }

        .table-title i.fa-chevron-down,
        .table-title i.fa-chevron-up {
            font-size: 14px;
            color: #6c757d;
            transition: transform 0.3s ease;
        }

        .table-close-btn {
            background: #e74c3c;
            color: white;
            border: none;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            transition: all 0.3s ease;
        }

        .table-close-btn:hover {
            background: #c0392b;
            transform: scale(1.1);
        }

        .table-bill-container {
            display: flex;
            flex-direction: column;
            height: calc(100% - 60px);
            gap: 15px;
        }

        .table-bill-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-shrink: 0;
        }

        .table-add-btn {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(250, 206, 11, 0.3);
        }

        .table-add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.4);
            background: linear-gradient(135deg, #ffd700, #face0b);
        }

        .table-add-btn:active {
            transform: translateY(0);
        }

        .table-add-btn i {
            font-size: 14px;
        }

        .mini-pos-products {
            flex: 1;
            overflow-y: auto;
            max-height: 400px;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 10px;
            background: #f8f9fa;
        }

        /* Table Menu Modal Product Grid */
        .table-menu-body .mini-pos-products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
            gap: 15px;
            padding: 15px;
            background: transparent;
            border: none;
            max-height: 500px;
        }

        .table-menu-body .product-item {
            height: 220px;
        }

        .table-menu-body .product-img {
            width: 120px;
            height: 120px;
        }

        .table-menu-body .mini-categories-container {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 15px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 8px;
        }

        .table-menu-body .mini-category-btn {
            padding: 8px 16px;
            border: 2px solid #dee2e6;
            background: white;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            color: #495057;
        }

        .table-menu-body .mini-category-btn:hover {
            border-color: #face0b;
            background: #face0b;
            color: #000;
        }

        .table-menu-body .mini-category-btn.active {
            background: linear-gradient(135deg, #face0b, #f7b300);
            border-color: #face0b;
            color: #000;
        }

        .table-menu-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            justify-content: center;
            align-items: center;
            backdrop-filter: blur(4px);
        }

        .table-menu-content {
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 1000px;
            max-height: 90vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            overflow: hidden;
            position: relative;
        }

        .table-menu-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            border-bottom: 2px solid #e9ecef;
            background: #333;
        }

        .table-menu-header h3 {
            margin: 0;
            color: #fff;
            font-size: 20px;
            font-weight: 700;
        }

        .table-menu-close {
            background: transparent;
            border: none;
            font-size: 24px;
            color: #fff;
            cursor: pointer;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s ease;
        }

        .table-menu-close:hover {
            background: rgba(255, 255, 255, 0.1);
        }

        .table-menu-body {
            padding: 20px;
            overflow-y: auto;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .mini-product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px;
            margin-bottom: 8px;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 1px solid #e9ecef;
        }

        .mini-product-item:hover {
            background: #face0b;
            color: #000;
            border-color: #face0b;
            transform: translateX(4px);
        }

        .mini-product-item:last-child {
            margin-bottom: 0;
        }

        .mini-product-name {
            font-weight: 500;
            font-size: 13px;
            color: #333;
        }

        .mini-product-price {
            font-weight: 700;
            font-size: 13px;
            color: #e74c3c;
        }

        .mini-cart {
            border: 1px solid #e9ecef;
            border-radius: 8px;
            background: #f8f9fa;
            display: flex;
            flex-direction: column;
            height: calc(100% - 50px);
            overflow: hidden;
            flex-shrink: 0;
        }

        .mini-cart-items {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            min-height: 0;
        }

        .mini-cart-items::-webkit-scrollbar {
            width: 6px;
        }

        .mini-cart-items::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .mini-cart-items::-webkit-scrollbar-thumb {
            background: #face0b;
            border-radius: 3px;
        }

        .mini-cart-items::-webkit-scrollbar-thumb:hover {
            background: #ffd700;
        }

        .mini-cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px;
            margin-bottom: 6px;
            background: white;
            border-radius: 8px;
            border: 1px solid #e9ecef;
            font-size: 11px;
            transition: all 0.2s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .mini-cart-item:hover {
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            border-color: #face0b;
            transform: translateY(-1px);
        }

        .mini-cart-item:last-child {
            margin-bottom: 0;
        }

        .mini-cart-qty {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .mini-qty-btn {
            width: 28px;
            height: 28px;
            border: none;
            background: linear-gradient(135deg, #face0b, #f7b300);
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 700;
            color: #000;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(250, 206, 11, 0.3);
        }

        .mini-qty-btn:hover {
            background: linear-gradient(135deg, #ffd700, #face0b);
            transform: scale(1.1);
            box-shadow: 0 3px 6px rgba(250, 206, 11, 0.4);
        }

        .mini-qty-btn:active {
            transform: scale(0.95);
        }

        .mini-cart-footer {
            border-top: 2px solid #e9ecef;
            padding: 10px;
            background: #f8f9fa;
            flex-shrink: 0;
        }

        .mini-cart-total {
            font-weight: 700;
            font-size: 18px;
            color: #e74c3c;
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }

        .mini-cart-actions {
            display: flex;
            gap: 10px;
        }

        .mini-cart-btn {
            flex: 1;
            padding: 10px;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            cursor: pointer;
            font-size: 13px;
            transition: all 0.3s ease;
        }

        .mini-cart-btn.clear {
            background: #333;
            color: white;
        }

        .mini-cart-btn.clear:hover {
            background: #444;
        }

        .mini-cart-btn.checkout {
            background: linear-gradient(135deg, #face0b 0%, #f7b300 100%);
            color: #000;
        }

        .mini-cart-btn.checkout:hover {
            background: linear-gradient(135deg, #ffd84d 0%, #face0b 100%);
        }

        .mini-cart-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .mini-cart-btn:disabled:hover {
            transform: none;
            box-shadow: none;
        }

        .empty-cart-message {
            text-align: center;
            padding: 20px;
            color: #adb5bd;
            font-size: 13px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100px;
        }

        .empty-products-message {
            text-align: center;
            padding: 20px;
            color: #adb5bd;
            font-size: 13px;
        }

        /* Mini POS Search and Categories */
        .mini-search-input {
            width: 100%;
            padding: 8px 35px 8px 12px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            font-size: 13px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .mini-search-input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .mini-categories-container {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-bottom: 10px;
            max-height: 80px;
            overflow-y: auto;
            padding: 5px 0;
        }

        .mini-categories-container::-webkit-scrollbar {
            width: 4px;
            height: 4px;
        }

        .mini-categories-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 2px;
        }

        .mini-categories-container::-webkit-scrollbar-thumb {
            background: #face0b;
            border-radius: 2px;
        }

        .mini-category-btn {
            padding: 6px 12px;
            border: 1px solid #e9ecef;
            border-radius: 6px;
            background: white;
            color: #495057;
            font-size: 11px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            white-space: nowrap;
        }

        .mini-category-btn:hover {
            background: #f8f9fa;
            border-color: #face0b;
            transform: translateY(-1px);
        }

        .mini-category-btn.active {
            background: #face0b;
            border-color: #face0b;
            color: #000;
            font-weight: 600;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            nav.sidebar {
                display: none;
            }

            main {
                margin-left: 0;
                flex-direction: column;
                height: auto;
            }

            .menu-section,
            .cart-section {
                flex: none;
            }

            .menu-content {
                flex-direction: column;
                height: auto;
            }

            .cart-section {
                width: 100%;
                min-width: 100%;
                max-width: 100%;
            }

            .categories-sidebar {
                width: 100%;
                min-width: 100%;
                max-height: 150px;
                border-right: none;
                border-bottom: 2px solid #e9ecef;
            }

            .categories-vertical {
                flex-direction: row;
                overflow-x: auto;
            }

            .product-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }

            .product-item {
                height: auto;
                min-height: 180px;
                padding: 8px;
            }

            .product-img {
                width: 100px;
                height: 100px;
            }
        }
        /* Search bar: same as User Management */
        .search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
            padding: 10px 14px 10px 40px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px !important;
            outline: none !important;
        }
        .search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
        }
        .search-container .input-with-icon { position: relative; }
        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
        .pos-input {
            width: 120px;
            padding: 8px 10px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            background: #ffffff;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }
        .pos-input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }
        .pos-input.align-right { text-align: right; }
        .pos-input-sm { width: 110px; }
        .pos-select {
            width: 120px;
            padding: 8px 10px;
            border: 2px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            background: #ffffff;
            cursor: pointer;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }
        .pos-select:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }
        @media (max-width: 480px) {
            .pos-input,
            .pos-select {
                min-height: 44px;
                font-size: 16px;
            }
        }
        @media (orientation: portrait) {
            main {
                flex-direction: column;
                height: auto;
            }
            .cart-section {
                width: 100%;
                min-width: 100%;
                max-width: 100%;
            }
            .product-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (orientation: landscape) {
            .product-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
        .amount-total {
            color: #e74c3c;
            font-size: 16px;
            font-weight: 700;
        }
        .amount-change {
            color: #28a745;
            font-size: 15px;
            font-weight: 700;
            display: inline-block;
            min-width: 80px;
            text-align: right;
        }
        #total { color: #e74c3c; font-size: 16px; font-weight: 700; text-align: right; }
        #change { color: #28a745; font-size: 15px; font-weight: 700; text-align: right; margin-left: auto; min-width: 80px; }
        .cart-summary .totals p span.amount-total {
            color: #e74c3c;
            font-size: 16px;
            font-weight: 700;
        }
        .cart-summary .totals p span.amount-change {
            color: #28a745;
            font-size: 15px;
            font-weight: 700;
        }
        .cart-summary .totals #totalRow {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 4px 0;
            gap: 8px;
        }
        .cart-summary .totals #totalRow #total {
            margin-left: auto !important;
            min-width: 80px;
            text-align: right !important;
        }
        .cart-summary .totals #billChangeRow {
            display: none; /* Hide change line in take-out bill */
        }
        #changeRow {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 8px;
        }
        .checkout-total-row.total-final {
            display: grid;
            grid-template-columns: 1fr auto;
            align-items: center;
            gap: 8px;
        }
        #receiptChange {
            color: #28a745;
            font-size: 16px;
            font-weight: 700;
            margin-left: auto;
            min-width: 80px;
            text-align: right;
        }
        .checkout-total-row.total-final span,
        #receiptTotal {
            color: #e74c3c;
            font-size: 20px;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="#" onclick="showPOSView(); return false;" class="<?php echo isActive('pos.php', $currentPage); ?>" id="posTab">
                <i class="fas fa-cash-register"></i>
                <span>Take Out</span>
            </a>
            <a href="#" onclick="showTablesView(); return false;" id="tablesTab">
                <i class="fas fa-table"></i>
                <span>Dine In</span>
            </a>
            <a href="product_availability.php" class="<?php echo isActive('product_availability.php', $currentPage); ?>">
                <i class="fas fa-box-open"></i>
                <span>Products</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>


    <!-- Tables View -->
    <main id="tablesView" class="hidden" style="display: none;">
        <div class="content-section" style="width: 100%;">
            <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span>TABLE MANAGEMENT</span>
                <button onclick="addTable()" style="background: linear-gradient(135deg, #face0b, #f7b300); color: #000; border: none; padding: 10px 20px; border-radius: 6px; font-weight: 700; cursor: pointer; font-size: 14px;">
                    <i class="fas fa-plus"></i> Add Table
                </button>
            </div>
            <div class="card-body" style="padding: 20px;">
                <div id="tablesContainer" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(400px, 1fr)); gap: 20px;">
                    <!-- Table containers will be dynamically added here -->
                </div>
            </div>
        </div>
    </main>

    <!-- Table Number Selection Modal -->
    <div class="table-menu-modal" id="tableNumberModal" style="display: none;">
        <div class="table-menu-content" style="max-width: 700px; width: 90%;">
            <div class="table-menu-header">
                <h3>Select Table Number</h3>
                <div style="display: flex; align-items: center; gap: 10px;">
                    <button onclick="addNewTableNumber()" style="
                        background: linear-gradient(135deg, #face0b, #f7b300);
                        color: #000;
                        border: none;
                        padding: 8px 20px;
                        border-radius: 8px;
                        font-size: 14px;
                        font-weight: 600;
                        cursor: pointer;
                        display: flex;
                        align-items: center;
                        gap: 6px;
                        transition: all 0.3s ease;
                    " onmouseover="this.style.transform='translateY(-2px)'; this.style.background='linear-gradient(135deg, #ffd84d, #face0b)';" onmouseout="this.style.transform='translateY(0)'; this.style.background='linear-gradient(135deg, #face0b, #f7b300)';">
                        <i class="fas fa-plus"></i> Add Another Table
                    </button>
                    <button class="table-menu-close" onclick="closeTableNumberModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="table-menu-body" style="padding: 30px;">
                <p style="margin-bottom: 25px; color: #6c757d; text-align: center; font-size: 16px;">Choose an available table number</p>
                <div id="tableNumberGrid" style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin-bottom: 25px;">
                    <!-- Table numbers will be dynamically added here -->
                </div>
            </div>
        </div>
    </div>

    <!-- Global Table Menu Modal -->
    <div class="table-menu-modal" id="tableMenuModal" style="display: none;">
        <div class="table-menu-content">
            <div class="table-menu-header">
                <h3 id="tableMenuTitle">Add Products</h3>
                <button class="table-menu-close" onclick="closeTableMenu()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="table-menu-body">
                <div style="margin-bottom: 10px; position: relative;">
                    <input type="text" 
                           id="tableMenuSearch" 
                           class="mini-search-input" 
                           placeholder="Search products..." 
                           autocomplete="off"
                           onkeyup="filterTableMenuProducts()"
                           oninput="filterTableMenuProducts()"
                           onfocus="filterTableMenuProducts()">
                    <i class="fas fa-search" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #6c757d; pointer-events: none; font-size: 12px;"></i>
                </div>
                <div class="mini-categories-container" id="tableMenuCategories">
                </div>
                <h4 style="margin: 10px 0; font-size: 14px; color: #333;">Products</h4>
                <div class="mini-pos-products" id="tableMenuProducts">
                </div>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main id="posView" class="hidden" style="display: flex;">
        <!-- Menu Section (Left) -->
        <div class="content-section menu-section">
            <div class="card-header">MENU</div>
            <div class="card-body">
                <div class="menu-content">
                    <div class="categories-sidebar">
                        <div class="categories-scroll-container">
                            <div class="categories-vertical">
                                <button onclick="filterProducts('all')" class="category-card active" data-category="all">
                                    <i class="fas fa-th"></i>
                                    <span>All</span>
                                </button>
                                <?php 
                                // Reset the categories result pointer
                                $categoriesResult->data_seek(0);
                                while ($category = $categoriesResult->fetch_assoc()): 
                                    $categoryIcon = getCategoryIcon($category['CategoryName']);
                                ?>
                                    <button onclick="filterProducts('<?php echo $category['CategoryID']; ?>')" class="category-card" data-category="<?php echo $category['CategoryID']; ?>">
                                        <i class="fas <?php echo htmlspecialchars($categoryIcon); ?>"></i>
                                        <span><?php echo $category['CategoryName']; ?></span>
                                    </button>
                                <?php endwhile; ?>
                            </div>
                        </div>
                    </div>
                    <div class="products-content">
                        <div class="search-container">
                            <div class="input-with-icon">
                                <i class="fas fa-search"></i>
                                <input type="text" id="productSearch" class="search-input" placeholder="Search products..." onkeyup="searchProducts()">
                            </div>
                        </div>
                        <div class="product-grid" id="productGrid">
                        <?php foreach ($products as $product): 
                            // Fix image path: prepend '../' if needed
                            $dbImagePath = $product['ImagePath'];
                            if (!empty($dbImagePath)) {
                                $imagePath = (strpos($dbImagePath, '../') === 0) ? $dbImagePath : '../' . $dbImagePath;
                            } else {
                                $imagePath = '../images/no-image.png';
                            }
                            $isAvailable = isset($product['is_available']) && (int)$product['is_available'] === 1;
                            $productClass = $isAvailable ? '' : ' unavailable';
                            $productName = htmlspecialchars($product['InventoryName'], ENT_QUOTES, 'UTF-8');
                            $imagePathAttr = htmlspecialchars($imagePath, ENT_QUOTES, 'UTF-8');
                            $priceValue = (float)$product['Price'];
                            $onClickAttr = $isAvailable 
                                ? "onclick=\"addToCart('{$productName}', {$priceValue}, '{$imagePathAttr}')\"" 
                                : '';
                        ?>
                            <div class="product-item<?php echo $productClass; ?>" data-category-id="<?php echo $product['CategoryID']; ?>" <?php echo $onClickAttr; ?>>
                                <div class="product-img">
                                    <?php if (!$isAvailable): ?>
                                        <span class="product-status-badge">Unavailable</span>
                                    <?php endif; ?>
                                    <img src="<?php echo $imagePath; ?>" alt="<?php echo $product['InventoryName']; ?>">
                                </div>
                                <p><?php echo $product['InventoryName']; ?></p>
                                <p>₱ <?php echo number_format($product['Price'], 2); ?></p>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cart Section (Right) -->
        <div class="content-section cart-section">
            <div class="card-header">BILL</div>
            <div class="card-body">
                <div class="cart-items-container" id="cartItemsContainer">
                    <!-- Cart items will be dynamically inserted here -->
                </div>
                <div class="cart-summary">
                    <div class="totals">
                        <p>Subtotal (VAT Inclusive): <span id="subtotal">₱ 0.00</span></p>
                        <div id="vatBreakdown" style="display: none; margin: 4px 0; padding: 6px 8px; background: #f8f9fa; border-radius: 6px; font-size: 12px;">
                            <p style="margin: 2px 0;">VAT Amount (12%): <span id="vatAmount">₱ 0.00</span></p>
                            <p style="margin: 2px 0;">VAT Exempt Amount: <span id="vatExemptAmount">₱ 0.00</span></p>
                        </div>
                        <div class="discount-section" style="margin: 2px 0;">
                            <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                                <label style="font-size: 12px; font-weight: 600; margin: 0; white-space: nowrap;">Manual Discount (%):</label>
                                <input type="number" id="manualDiscountInput" min="0" max="100" step="0.01" placeholder="%" oninput="var v=parseFloat(this.value); if(!isNaN(v)&&v>100) this.value=100; updateCart()" onfocus="this.select()" onclick="this.select()" class="pos-input pos-input-sm align-right">
                            </div>
                            <p id="manualDiscountAmount" style="display: none; color: #28a745; font-size: 12px; margin: 5px 0;">Manual Discount: <span>₱ 0.00</span></p>
                        </div>
                        <p id="pwdDiscountAmount" style="display: none; color: #28a745; font-size: 12px; margin: 3px 0;">PWD Discount: <span>₱ 0.00</span></p>
                        <p id="totalRow" style="margin: 4px 0;"><strong>TOTAL:</strong> <span id="total" class="amount-total">₱ 0.00</span></p>
                        <div style="margin: 6px 0;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 600;">Payment Method:</label>
                            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                                <label style="display: flex; align-items: center; cursor: pointer;">
                                    <input type="radio" name="paymentMethod" id="paymentCash" value="cash" checked onchange="updatePaymentMethod()" style="margin-right: 5px;">
                                    <i class="fas fa-money-bill-wave" style="margin-right: 5px;"></i>Cash
                                </label>
                                <label style="display: flex; align-items: center; cursor: pointer;">
                                    <input type="radio" name="paymentMethod" id="paymentGcash" value="gcash" onchange="updatePaymentMethod()" style="margin-right: 5px;">
                                    <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>GCash
                                </label>
                                <label style="display: flex; align-items: center; cursor: pointer;">
                                    <input type="radio" name="paymentMethod" id="paymentPaymaya" value="paymaya" onchange="updatePaymentMethod()" style="margin-right: 5px;">
                                    <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>Maya
                                </label>
                            </div>
                        </div>
                        <div id="cashInputContainer">
                            <label>Cash: <input type="number" id="cashInput" placeholder="Enter amount" oninput="calculateChange()" class="pos-input pos-input-sm align-right"></label>
                        </div>
                        <div id="referenceNoContainer" style="display: none;">
                            <label>Reference No: <input type="text" id="referenceNoInput" placeholder="Enter reference number" pattern="[0-9]+" maxlength="9" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="pos-input"></label>
                        </div>
                    </div>
                </div>
                <div class="cart-actions">
                    <button onclick="cart = []; cartItemIdCounter = 0; updateCart();">Clear</button>
                    <button onclick="showOrderPreview()">Pay</button>
                </div>
            </div>
        </div>
    </main>

    <!-- Order Preview Modal -->
    <div id="orderPreviewWindow">
        <div class="window-content">
            <span class="close" onclick="closeWindow()">&times;</span>
            
            <div class="checkout-header">
                <h2><i class="fas fa-shopping-cart"></i> Order Confirmation</h2>
                <div class="restaurant-name">EDGIE'S RESTAURANT AND EVENT PLACE</div>
                <div class="restaurant-address">Pasolo Road, Pasolo 1440 Valenzuela, Philippines</div>
            </div>

            <div class="checkout-scroll-body">
            <div class="checkout-info">
                <div class="checkout-info-item">
                    <label><i class="fas fa-user"></i> Cashier</label>
                    <span id="cashierName"><?php echo htmlspecialchars($userFullName); ?></span>
                </div>
                <div class="checkout-info-item">
                    <label><i class="fas fa-receipt"></i> Transaction #</label>
                    <span id="transactionNumber">-</span>
                </div>
                <div class="checkout-info-item">
                    <label><i class="fas fa-calendar"></i> Date & Time</label>
                    <span id="receiptDate">-</span>
                </div>
                <div class="checkout-info-item">
                    <label><i class="fas fa-utensils"></i> Order Type</label>
                    <span id="receiptOrderType">-</span>
                </div>
            </div>

            <div class="checkout-items">
                <div class="checkout-items-title"><i class="fas fa-list"></i> Order Items</div>
                <div id="receiptItemsBody"></div>
            </div>

            <div class="checkout-totals">
                <div class="checkout-total-row">
                    <label>Subtotal</label>
                    <span id="receiptSubtotal">₱ 0.00</span>
                </div>
                <div class="checkout-total-row discount" id="vatExemptLine" style="display: none;">
                    <label><i class="fas fa-tag"></i> VAT Exempt (PWD/Senior Citizen)</label>
                    <span>-</span>
                </div>
                <div class="checkout-total-row" id="vatLine" style="display: none;">
                    <label>VAT (12%)</label>
                    <span id="receiptVat">₱ 0.00</span>
                </div>
                <div class="checkout-total-row discount" id="discountLine" style="display: none;">
                    <label><i class="fas fa-percent"></i> Discount (20%)</label>
                    <span id="discountAmountDisplay">₱ 0.00</span>
                </div>
                <div class="checkout-total-row">
                    <label>Payment Method</label>
                    <span id="receiptPaymentMethod">CASH</span>
                </div>
                <div class="checkout-total-row">
                    <label>Amount Paid</label>
                    <span id="amountPaid">₱ 0.00</span>
                </div>
                <div class="checkout-total-row" id="changeRow">
                    <label>Change</label>
                    <span id="receiptChange">₱ 0.00</span>
                </div>
                <div class="checkout-total-row total-final">
                    <label><i class="fas fa-money-bill-wave"></i> Total Amount</label>
                    <span id="receiptTotal">₱ 0.00</span>
                </div>
            </div>
            </div>

            <div class="checkout-actions">
                <button class="checkout-btn checkout-btn-cancel" onclick="closeWindow()">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button class="checkout-btn checkout-btn-confirm" onclick="confirmOrder()">
                    <i class="fas fa-check"></i> Confirm Order
                </button>
            </div>
        </div>
    </div>

    <script>
        // Order type for counter POS is fixed as 'take-out'
        let selectedOrderType = 'take-out';

        // Toggle sidebar function
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                // Save state to localStorage
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }

        // Logout confirmation function
        function confirmLogout(event) {
            event.preventDefault();
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout Confirmation',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#face0b',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../authentication/logout.php';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../authentication/logout.php';
                }
            }
        }

        // Product filtering and cart functions
        let cart = [];

        function filterProducts(categoryId) {
            // Update active state of category cards
            const categoryCards = document.querySelectorAll('.category-card');
            categoryCards.forEach(card => {
                if (card.getAttribute('data-category') === categoryId) {
                    card.classList.add('active');
                } else {
                    card.classList.remove('active');
                }
            });

            const productItems = document.querySelectorAll('.product-item');
            productItems.forEach(item => {
                const productCategory = item.getAttribute('data-category-id');
                if (categoryId === 'all' || productCategory === categoryId) {
                    item.style.display = '';
                    item.style.visibility = '';
                    item.style.position = '';
                    item.removeAttribute('hidden');
                } else {
                    item.style.display = 'none';
                    item.style.visibility = 'hidden';
                    item.setAttribute('hidden', '');
                }
            });
            
            // Force grid to recalculate and start from top
            requestAnimationFrame(() => {
                const productGrid = document.getElementById('productGrid');
                if (productGrid) {
                    // Temporarily remove and re-add grid to force recalculation
                    const gridDisplay = productGrid.style.display;
                    productGrid.style.display = 'none';
                    void productGrid.offsetHeight; // Force reflow
                    productGrid.style.display = gridDisplay || 'grid';
                }
            });
            
            // Reapply search filter if there's a search term
            const searchInput = document.getElementById('productSearch');
            if (searchInput && searchInput.value.trim() !== '') {
                searchProducts();
            }
        }

        function searchProducts() {
            const searchTerm = document.getElementById('productSearch').value.toLowerCase().trim();
            const productItems = document.querySelectorAll('.product-item');
            
            // Get the currently active category
            const activeCategoryCard = document.querySelector('.category-card.active');
            const activeCategoryId = activeCategoryCard ? activeCategoryCard.getAttribute('data-category') : 'all';
            
            productItems.forEach(item => {
                const productName = item.querySelector('p').textContent.toLowerCase();
                const productCategory = item.getAttribute('data-category-id');
                
                // Check if item matches the current category filter
                const matchesCategory = activeCategoryId === 'all' || productCategory === activeCategoryId;
                
                // If search term is empty, show all items that match the category
                if (searchTerm === '') {
                    if (matchesCategory) {
                        item.style.display = '';
                        item.style.visibility = '';
                        item.style.position = '';
                        item.removeAttribute('hidden');
                    } else {
                        item.style.display = 'none';
                        item.style.visibility = 'hidden';
                        item.setAttribute('hidden', '');
                    }
                } else {
                    // If there's a search term, filter by both category and search term
                    if (matchesCategory && productName.includes(searchTerm)) {
                        item.style.display = '';
                        item.style.visibility = '';
                        item.style.position = '';
                        item.removeAttribute('hidden');
                    } else {
                        item.style.display = 'none';
                        item.style.visibility = 'hidden';
                        item.setAttribute('hidden', '');
                    }
                }
            });
        }

        // Generate unique ID for cart items
        let cartItemIdCounter = 0;
        
        function addToCart(productName, productPrice, productImage) {
            // Find existing item with same name and price
            const existingItem = cart.find(item => 
                item.name === productName && 
                item.price === productPrice
            );
            
            if (existingItem) {
                // Add to existing item (increment quantity)
                existingItem.quantity++;
                // Update image if not already set
                if (!existingItem.image && productImage) {
                    existingItem.image = productImage;
                }
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: 'Product Updated!',
                        text: `${productName} quantity increased to ${existingItem.quantity}`,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false,
                        position: 'top-end',
                        toast: true
                    });
                }
            } else {
                // Create new line item
                const newItem = {
                    id: cartItemIdCounter++,
                    name: productName,
                    price: productPrice,
                    quantity: 1,
                    image: productImage || '../images/no-image.png'
                };
                cart.push(newItem);
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: 'Added to Bill!',
                        text: `${productName} has been added to your bill`,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false,
                        position: 'top-end',
                        toast: true
                    });
                }
            }
            updateCart();
        }


        function updateCart() {
            const cartItemsContainer = document.getElementById('cartItemsContainer');
            const totals = document.querySelector('.totals');
            
            if (!cartItemsContainer || !totals) return;
            
            // Store the currently focused input, its value, and caret position
            const activeElement = document.activeElement;
            const activeInput = activeElement.tagName === 'INPUT' ? activeElement : null;
            const activeValue = activeInput ? activeInput.value : '';
            const activeItemId = activeInput ? activeInput.getAttribute('data-item-id') : '';
            const activeCaretPos = activeInput && typeof activeInput.selectionStart === 'number'
                ? activeInput.selectionStart
                : null;

            cartItemsContainer.innerHTML = '';
            // If cart is empty, just clear the container (no message/icon)

            let subtotal = 0;
            
            // Initialize totals
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            let subtotalVatExempt = 0;
            let subtotalVatable = 0;
            
            cart.forEach(item => {
                // Initialize hasPwdDiscount if not set
                if (item.hasPwdDiscount === undefined) {
                    item.hasPwdDiscount = false;
                }
                
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                const itemImage = item.image || '../images/no-image.png';
                // Ensure quantity is always a valid number
                const itemQuantity = parseInt(item.quantity) || 1;
                const currentQuantity = (activeItemId == item.id && activeValue !== '') ? activeValue : itemQuantity;
                
                // Calculate item-level PWD discount
                let itemPwdDiscount = 0;
                let itemAfterDiscount = itemSubtotal;
                if (item.hasPwdDiscount) {
                    itemPwdDiscount = itemSubtotal * 0.20;
                    itemAfterDiscount = itemSubtotal - itemPwdDiscount;
                    totalPwdDiscount += itemPwdDiscount;
                    subtotalVatExempt += itemAfterDiscount;
                } else {
                    // Extract VAT from VAT inclusive price
                    // Base price = price / 1.12, VAT = price - base price
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                    subtotalVatable += itemSubtotal;
                }
                
                const cartItem = document.createElement('div');
                cartItem.className = 'cart-item';
                cartItem.innerHTML = `
                    <div class="cart-item-image">
                        <img src="${itemImage}" alt="${item.name}">
                    </div>
                    <div class="cart-item-details">
                        <div class="cart-item-name">${item.name}</div>
                        <div class="cart-item-customization">Standard</div>
                        <div style="margin-top: 5px;">
                            <label style="display: flex; align-items: center; gap: 5px; font-size: 11px; cursor: pointer;">
                                <input type="checkbox" 
                                       ${item.hasPwdDiscount ? 'checked' : ''} 
                                       onchange="togglePwdDiscount(${item.id}, this.checked)"
                                       style="cursor: pointer; width: 14px; height: 14px;">
                                <span style="color: #28a745;">PWD/Senior (20%)</span>
                            </label>
                        </div>
                    </div>
                    <div class="cart-item-price-quantity">
                        <div class="cart-item-price">${formatNumber(item.price)}</div>
                        ${itemPwdDiscount > 0 ? `<div style="font-size: 11px; color: #28a745; margin-top: 2px;">Disc: ${formatNumber(itemPwdDiscount)}</div>` : ''}
                        <div class="cart-item-quantity-controls">
                            <button class="qty-btn" onclick="changeQuantity(${item.id}, -1)">-</button>
                            <input type="number" 
                                   class="qty-input"
                                   value="${parseInt(currentQuantity) || 1}" 
                                   min="1" 
                                   max="99"
                                   oninput="updateQuantity(${item.id}, this.value)" 
                                   onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                   data-item-id="${item.id}">
                            <button class="qty-btn" onclick="changeQuantity(${item.id}, 1)">+</button>
                        </div>
                        <button class="qty-btn" onclick="removeCartItem(${item.id})" style="margin-top: 4px; background: #dc3545; color: white; width: 28px; height: 28px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 12px;" title="Remove">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                `;
                cartItemsContainer.appendChild(cartItem);
            });

            // Get manual discount (percentage 0-100), compute amount
            const manualDiscountInput = document.getElementById('manualDiscountInput');
            let manualDiscountPercent = parseFloat(manualDiscountInput ? manualDiscountInput.value : 0) || 0;
            if (manualDiscountPercent > 100) {
                manualDiscountPercent = 100;
                if (manualDiscountInput) manualDiscountInput.value = 100;
            }
            if (manualDiscountPercent < 0) {
                manualDiscountPercent = 0;
                if (manualDiscountInput) manualDiscountInput.value = 0;
            }
            const totalBeforeManualDiscount = subtotal - totalPwdDiscount;
            const manualDiscount = totalBeforeManualDiscount * (manualDiscountPercent / 100);
            
            // Final total calculation
            const finalTotal = subtotal - totalPwdDiscount - manualDiscount;

            // Get current payment method selection
            const currentPaymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
            
            // If user is typing in manual discount, only update display numbers so the input is not recreated and focus/cursor stay
            const manualDiscountInputFocused = document.activeElement && document.activeElement.id === 'manualDiscountInput';
            if (manualDiscountInputFocused) {
                if (manualDiscountInput && parseFloat(manualDiscountInput.value) > 100) manualDiscountInput.value = 100;
                const subtotalEl = document.getElementById('subtotal');
                if (subtotalEl) subtotalEl.textContent = formatNumber(subtotal);
                const vatBreakdown = document.getElementById('vatBreakdown');
                if (vatBreakdown) vatBreakdown.style.display = (totalVatAmount > 0 || subtotalVatExempt > 0) ? 'block' : 'none';
                const vatAmountEl = document.getElementById('vatAmount');
                if (vatAmountEl) vatAmountEl.textContent = formatNumber(totalVatAmount);
                const vatExemptEl = document.getElementById('vatExemptAmount');
                if (vatExemptEl) vatExemptEl.textContent = formatNumber(subtotalVatExempt);
                const manualDiscountAmountEl = document.getElementById('manualDiscountAmount');
                if (manualDiscountAmountEl) {
                    manualDiscountAmountEl.style.display = manualDiscount > 0 ? 'block' : 'none';
                    const span = manualDiscountAmountEl.querySelector('span');
                    if (span) span.textContent = formatNumber(manualDiscount);
                }
                const pwdDiscountAmountEl = document.getElementById('pwdDiscountAmount');
                if (pwdDiscountAmountEl) {
                    pwdDiscountAmountEl.style.display = totalPwdDiscount > 0 ? 'block' : 'none';
                    const span = pwdDiscountAmountEl.querySelector('span');
                    if (span) span.textContent = formatNumber(totalPwdDiscount);
                }
                const totalEl = document.getElementById('total');
                if (totalEl) totalEl.textContent = formatNumber(finalTotal);
                calculateChange();
            } else {
                totals.innerHTML = `
                <p>Subtotal (VAT Inclusive): <span id="subtotal">${formatNumber(subtotal)}</span></p>
                <div id="vatBreakdown" style="display: ${totalVatAmount > 0 || subtotalVatExempt > 0 ? 'block' : 'none'}; margin: 4px 0; padding: 6px 8px; background: #f8f9fa; border-radius: 6px; font-size: 12px;">
                    <p style="margin: 2px 0;">VAT Amount (12%): <span id="vatAmount">${formatNumber(totalVatAmount)}</span></p>
                    <p style="margin: 2px 0;">VAT Exempt Amount: <span id="vatExemptAmount">${formatNumber(subtotalVatExempt)}</span></p>
                </div>
                <div class="discount-section" style="margin: 2px 0;">
                    <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                        <label style="font-size: 12px; font-weight: 600; margin: 0; white-space: nowrap;">Manual Discount (%):</label>
                        <input type="number" id="manualDiscountInput" min="0" max="100" step="0.01" placeholder="%" value="${manualDiscountPercent > 0 ? manualDiscountPercent : ''}" oninput="var v=parseFloat(this.value); if(!isNaN(v)&&v>100) this.value=100; updateCart()" onfocus="this.select()" onclick="this.select()" class="pos-input pos-input-sm align-right">
                    </div>
                ${manualDiscount > 0 ? `<p id="manualDiscountAmount" style="color: #28a745; font-size: 12px; margin: 3px 0; display: block;">Manual Discount: <span>${formatNumber(manualDiscount)}</span></p>` : '<p id="manualDiscountAmount" style="display: none;">Manual Discount: <span>₱ 0.00</span></p>'}
                </div>
                ${totalPwdDiscount > 0 ? `<p id="pwdDiscountAmount" style="color: #28a745; font-size: 12px; margin: 3px 0; display: block;">PWD Discount: <span>${formatNumber(totalPwdDiscount)}</span></p>` : '<p id="pwdDiscountAmount" style="display: none;">PWD Discount: <span>₱ 0.00</span></p>'}
                <p id="totalRow" style="margin: 4px 0;"><strong>TOTAL:</strong> <span id="total" class="amount-total">${formatNumber(finalTotal)}</span></p>
                <div style="margin: 6px 0;">
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">Payment Method:</label>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <label style="display: flex; align-items: center; cursor: pointer;">
                            <input type="radio" name="paymentMethod" id="paymentCash" value="cash" ${currentPaymentMethod === 'cash' ? 'checked' : ''} onchange="updatePaymentMethod()" style="margin-right: 5px;">
                            <i class="fas fa-money-bill-wave" style="margin-right: 5px;"></i>Cash
                        </label>
                        <label style="display: flex; align-items: center; cursor: pointer;">
                            <input type="radio" name="paymentMethod" id="paymentGcash" value="gcash" ${currentPaymentMethod === 'gcash' ? 'checked' : ''} onchange="updatePaymentMethod()" style="margin-right: 5px;">
                            <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>GCash
                        </label>
                        <label style="display: flex; align-items: center; cursor: pointer;">
                            <input type="radio" name="paymentMethod" id="paymentPaymaya" value="paymaya" ${currentPaymentMethod === 'paymaya' ? 'checked' : ''} onchange="updatePaymentMethod()" style="margin-right: 5px;">
                            <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>Maya
                        </label>
                    </div>
                </div>
                <div id="cashInputContainer">
                    <label>Cash: <input type="number" id="cashInput" placeholder="Enter amount" oninput="calculateChange()" class="pos-input pos-input-sm align-right"></label>
                </div>
                <div id="referenceNoContainer" style="display: none;">
                    <label>Reference No: <input type="text" id="referenceNoInput" placeholder="Enter reference number" pattern="[0-9]+" maxlength="9" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="pos-input"></label>
                </div>
            `;
            
                // Update payment method UI after rendering
                updatePaymentMethod();
            }

            // Restore focus to the input that was being edited (preserve caret when possible)
            if (activeInput) {
                const newInput = document.querySelector(`input[data-item-id="${activeItemId}"]`);
                if (newInput) {
                    newInput.focus();
                    const length = newInput.value.length;
                    if (typeof activeCaretPos === 'number') {
                        const pos = Math.min(activeCaretPos, length);
                        newInput.setSelectionRange(pos, pos);
                    } else {
                        newInput.setSelectionRange(length, length);
                    }
                }
            }

            // Recalculate change
            calculateChange();
        }


        function removeCartItem(itemId) {
            const itemToRemove = cart.find(item => item.id === itemId);
            if (itemToRemove) {
                cart = cart.filter(item => item.id !== itemId);
            }
            updateCart();
        }

        function updateQuantity(itemId, newQuantity) {
            const item = cart.find(item => item.id === itemId);
            if (item) {
                newQuantity = parseInt(newQuantity) || 0;
                if (newQuantity < 1) {
                    newQuantity = 1;
                }
                if (newQuantity > 99) {
                    newQuantity = 99;
                }
                item.quantity = newQuantity;
                updateCart();
            }
        }

        function changeQuantity(itemId, change) {
            const item = cart.find(item => item.id === itemId);
            if (item) {
                item.quantity += change;
                if (item.quantity <= 0) {
                    cart = cart.filter(item => item.id !== itemId);
                }
                updateCart();
            }
        }

        function togglePwdDiscount(itemId, isChecked) {
            const item = cart.find(item => item.id === itemId);
            if (item) {
                item.hasPwdDiscount = isChecked;
                updateCart();
            }
        }

        function updatePaymentMethod() {
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
            const cashInputContainer = document.getElementById('cashInputContainer');
            const cashInput = document.getElementById('cashInput');
            const referenceNoContainer = document.getElementById('referenceNoContainer');
            const referenceNoInput = document.getElementById('referenceNoInput');
            const changeElement = document.getElementById('changeAmountBill');
            const changeLabel = document.getElementById('billChangeRow');
            
            if (paymentMethod === 'cash') {
                // Show cash input and change
                if (cashInputContainer) {
                    cashInputContainer.style.display = 'block';
                }
                if (cashInput) {
                    cashInput.required = true;
                    cashInput.value = ''; // Reset to empty when cash is selected
                }
                if (referenceNoContainer) {
                    referenceNoContainer.style.display = 'none';
                }
                if (referenceNoInput) {
                    referenceNoInput.required = false;
                    referenceNoInput.value = '';
                }
                if (changeElement) {
                    changeElement.innerText = formatNumber(0);
                    changeElement.parentElement.style.display = 'block';
                }
                if (changeLabel) {
                    changeLabel.style.display = 'block';
                }
            } else {
                // GCash or Maya - show reference number input, hide cash and change
                if (cashInputContainer) {
                    cashInputContainer.style.display = 'none';
                }
                if (cashInput) {
                    const totalElement = document.getElementById('total');
                    if (totalElement) {
                        const total = parseFloat(totalElement.innerText.replace(/[^0-9.-]+/g, ''));
                        cashInput.value = total.toFixed(2);
                    }
                    cashInput.required = false;
                }
                if (referenceNoContainer) {
                    referenceNoContainer.style.display = 'block';
                }
                if (referenceNoInput) {
                    referenceNoInput.required = true;
                    // Update maxlength and pattern based on payment method
                    if (paymentMethod === 'gcash') {
                        referenceNoInput.maxLength = 9;
                        referenceNoInput.pattern = '[0-9]{9}';
                        referenceNoInput.placeholder = 'Enter reference number (9 digits)';
                    } else if (paymentMethod === 'paymaya') {
                        referenceNoInput.maxLength = 6;
                        referenceNoInput.pattern = '[0-9]{6}';
                        referenceNoInput.placeholder = 'Enter reference number (6 digits)';
                    }
                    referenceNoInput.value = ''; // Clear value when switching methods
                }
                if (changeElement) {
                    changeElement.innerText = formatNumber(0);
                    changeElement.parentElement.style.display = 'none';
                }
                if (changeLabel) {
                    changeLabel.style.display = 'none';
                }
            }
            calculateChange();
        }

        function calculateChange() {
            const cashInput = document.getElementById('cashInput');
            if (!cashInput) return;
            const cash = parseFloat(cashInput.value) || 0;
            const totalElement = document.getElementById('total');
            if (!totalElement) return;
            const total = parseFloat(totalElement.innerText.replace(/[^0-9.-]+/g, ''));
            
            const change = cash - total;
            
            const changeElement = document.getElementById('changeAmountBill');
            if (changeElement) {
                changeElement.innerText = change >= 0 ? formatNumber(change) : formatNumber(0);
            }
        }

        function formatNumber(number) {
            return '₱ ' + parseFloat(number).toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function showOrderPreview() {
            if (cart.length === 0) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: 'Empty Bill',
                        text: 'Please select an order or product first.',
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    });
                }
                return;
            }

            // Get payment method first
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
            const cashInput = document.getElementById('cashInput');
            const referenceNoInput = document.getElementById('referenceNoInput');
            let cash = parseFloat(cashInput ? cashInput.value : 0);
            let referenceNo = referenceNoInput ? referenceNoInput.value.trim() : '';
            const orderType = selectedOrderType;

            // Calculate totals with VAT inclusive and item-level PWD discount
            let subtotal = 0;
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            let subtotalVatExempt = 0;
            
            cart.forEach(item => {
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                if (item.hasPwdDiscount) {
                    const itemPwdDiscount = itemSubtotal * 0.20;
                    totalPwdDiscount += itemPwdDiscount;
                    subtotalVatExempt += (itemSubtotal - itemPwdDiscount);
                } else {
                    // Extract VAT from VAT inclusive price
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                }
            });
            
            // Get manual discount (percentage), compute amount
            const manualDiscountInput = document.getElementById('manualDiscountInput');
            let manualDiscountPercent = parseFloat(manualDiscountInput ? manualDiscountInput.value : 0) || 0;
            if (manualDiscountPercent > 100) manualDiscountPercent = 100;
            if (manualDiscountPercent < 0) manualDiscountPercent = 0;
            const totalBeforeManualDiscount = subtotal - totalPwdDiscount;
            const manualDiscount = totalBeforeManualDiscount * (manualDiscountPercent / 100);
            
            // Final total calculation
            const totalAmount = subtotal - totalPwdDiscount - manualDiscount;

            // For cashless, use total as cash for preview display if reference not entered yet
            if (paymentMethod !== 'cash' && referenceNo) {
                cash = totalAmount;
            }
            if (paymentMethod === 'cash' && (isNaN(cash) || cash < 0)) {
                cash = 0;
            }

            // Build HTML for SweetAlert order confirmation
            let itemsHtml = '';
            cart.forEach(item => {
                const itemSubtotal = item.price * item.quantity;
                itemsHtml += `
                    <div class="checkout-item" style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;font-size:13px;">
                        <div>
                            <div style="font-weight:600;">${item.name}</div>
                            <div style="color:#6c757d;font-size:12px;">Qty: ${item.quantity} × ${formatNumber(item.price)}</div>
                        </div>
                        <div style="font-weight:600;min-width:80px;text-align:right;">${formatNumber(itemSubtotal)}</div>
                    </div>
                `;
            });

            const vatLineHtml = `<div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:4px;font-size:13px;">
                <label>VAT (12%)</label>
                <span>${formatNumber(totalVatAmount)}</span>
            </div>`;

            const discountHtml = (totalPwdDiscount > 0 || manualDiscount > 0)
                ? `<div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:4px;font-size:13px;">
                        <label>Discounts</label>
                        <span>-${formatNumber(totalPwdDiscount + manualDiscount)}</span>
                   </div>`
                : '';

            const amountPaid = paymentMethod === 'cash' ? cash : totalAmount;
            const changeValue = paymentMethod === 'cash' ? Math.max(0, cash - totalAmount) : 0;

            const html = `
                <div style="text-align:left;max-height:60vh;overflow-y:auto;">
                    <div style="margin-bottom:8px;font-size:12px;color:#6c757d;">
                        <div>Order Type: <strong>${orderType === 'take-out' ? 'Take Out' : 'Dine In'}</strong></div>
                        <div>Payment Method: <strong>${paymentMethod.toUpperCase()}</strong></div>
                    </div>
                    <div style="border-top:1px solid #e9ecef;margin:8px 0;padding-top:8px;">
                        ${itemsHtml}
                    </div>
                    <div style="border-top:1px solid #e9ecef;margin:8px 0;padding-top:8px;font-size:13px;">
                        <div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:4px;">
                            <label>Subtotal (VAT Inclusive)</label>
                            <span>${formatNumber(subtotal)}</span>
                        </div>
                        ${vatLineHtml}
                        ${discountHtml}
                        <div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:6px;font-weight:600;">
                            <label>Total Amount</label>
                            <span>${formatNumber(totalAmount)}</span>
                        </div>
                        <div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:4px;">
                            <label>Amount Paid</label>
                            <span>${formatNumber(amountPaid)}</span>
                        </div>
                        <div class="checkout-total-row" style="display:flex;justify-content:space-between;margin-top:4px;">
                            <label>Change</label>
                            <span>${formatNumber(changeValue)}</span>
                        </div>
                    </div>
                </div>
            `;

            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Order Confirmation',
                    html,
                    width: 600,
                    showCancelButton: true,
                    confirmButtonText: 'Confirm Order',
                    cancelButtonText: 'Back',
                    focusConfirm: false
                }).then((result) => {
                    if (result.isConfirmed) {
                        confirmOrder();
                    }
                });
            } else {
                // Fallback: no SweetAlert, just confirm directly
                if (confirm('Confirm this order?')) {
                    confirmOrder();
                }
            }
        }

        function closeWindow() {
            document.getElementById('orderPreviewWindow').style.display = "none";
        }

        // Close modal when clicking outside of it
        document.addEventListener('DOMContentLoaded', function() {
            const orderPreviewWindow = document.getElementById('orderPreviewWindow');
            if (orderPreviewWindow) {
                orderPreviewWindow.addEventListener('click', function(e) {
                    if (e.target === orderPreviewWindow) {
                        closeWindow();
                    }
                });
            }
        });

        function confirmOrder() {
            const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked')?.value || 'cash';
            const cashInput = document.getElementById('cashInput');
            const referenceNoInput = document.getElementById('referenceNoInput');
            let cash = parseFloat(cashInput ? cashInput.value : 0);
            const referenceNo = referenceNoInput ? referenceNoInput.value.trim() : '';
            const orderType = selectedOrderType;
            const cartData = JSON.stringify(cart);
            
            // Get manual discount (percentage 0-100) to send to server
            const manualDiscountInput = document.getElementById('manualDiscountInput');
            let manualDiscountPercent = parseFloat(manualDiscountInput ? manualDiscountInput.value : 0) || 0;
            if (manualDiscountPercent > 100) manualDiscountPercent = 100;
            if (manualDiscountPercent < 0) manualDiscountPercent = 0;

            // Get total (0 when e.g. 100% manual discount - allow payment 0)
            const totalElement = document.getElementById('total');
            const totalAmount = totalElement ? parseFloat(totalElement.innerText.replace(/[^0-9.-]+/g, '')) || 0 : 0;

            // Validate payment based on method
            if (paymentMethod === 'cash') {
                if (totalAmount > 0 && (!cash || cash <= 0)) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Payment Required',
                            text: 'Please enter the amount paid.',
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
                if (totalAmount > 0 && cash < totalAmount) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Insufficient Payment',
                            text: 'Amount paid is less than the total. Please enter a sufficient amount.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
            } else {
                // GCash or Maya - payment equals total, need reference number
                if (!referenceNo) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Reference Number Required',
                            text: 'Please enter the reference number.',
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
                // Validate reference number based on payment method (GCash 9 digits, Maya 6 digits)
                if (paymentMethod === 'gcash') {
                    if (!/^\d{9}$/.test(referenceNo)) {
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Invalid Reference Number',
                                text: 'GCash reference number must be exactly 9 digits.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        return;
                    }
                } else if (paymentMethod === 'paymaya') {
                    if (!/^\d{6}$/.test(referenceNo)) {
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Invalid Reference Number',
                                text: 'Maya reference number must be exactly 6 digits.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        return;
                    }
                }
                // Set cash to total amount for cashless payments
                if (totalElement) {
                    cash = parseFloat(totalElement.innerText.replace(/[^0-9.-]+/g, ''));
                }
            }

            const xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.status === 'success') {
                            document.getElementById('transactionNumber').innerText = response.transaction_num;
                            cart = [];
                            cartItemIdCounter = 0; // Reset counter
                            updateCart();
                            
                            // Check if there are any PWD discounts
                            const hasAnyPwdDiscount = response.cart && response.cart.some(item => item.hasPwdDiscount);
                            
                            // Open receipt window (use sales_invoice_no and order_type from server)
                            const receiptWindow = openReceiptWindow(
                                response.sales_invoice_no || response.transaction_num,
                                response.total_amount,
                                response.change,
                                response.cash,
                                response.cashier,
                                response.cart,
                                hasAnyPwdDiscount,
                                response.order_type || orderType,
                                false,
                                response.payment_method || 'cash',
                                response.reference_no || null,
                                response.pwd_discount || '₱ 0.00',
                                response.manual_discount || '₱ 0.00',
                                response.vat_amount || '₱ 0.00'
                            );
                            
                            receiptWindow.onload = function() {
                                if (!receiptWindow) return;
                                // Try to maximize the receipt window before printing
                                try {
                                    receiptWindow.moveTo(0, 0);
                                    receiptWindow.resizeTo(screen.availWidth || screen.width, screen.availHeight || screen.height);
                                } catch (e) {
                                    // Some browsers may block move/resize; ignore
                                }
                                receiptWindow.focus();
                                receiptWindow.print();
                                
                                if ('onafterprint' in receiptWindow) {
                                    receiptWindow.onafterprint = function() {
                                        receiptWindow.close();
                                    };
                                } else {
                                    setTimeout(() => {
                                        receiptWindow.close();
                                    }, 1000);
                                }
                            };
                            
                            closeWindow();
                            
                            if (typeof Swal !== 'undefined') {
                                Swal.fire({
                                    title: 'Success',
                                    text: 'Order has been confirmed.',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                });
                            }
                        } else {
                            if (typeof Swal !== 'undefined') {
                                Swal.fire({
                                    title: 'Error',
                                    text: response.message || 'An error occurred while processing the order.',
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        console.error('Response text:', xhr.responseText);
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while processing the order. Please check the console for details.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    }
                }
            };
            const referenceNoParam = paymentMethod !== 'cash' ? `&reference_no=${encodeURIComponent(referenceNo)}` : '';
            xhr.send(`confirm_order=true&cart=${encodeURIComponent(cartData)}&cash=${cash}&manual_discount=${manualDiscountPercent}&order_type=${orderType}&payment_method=${paymentMethod}${referenceNoParam}`);
        }

        // Function to generate item code from product name
        function generateItemCode(productName) {
            // Convert to lowercase and remove special characters
            let code = productName.toLowerCase()
                .replace(/[^a-z0-9\s]/g, '') // Remove special characters
                .replace(/\s+/g, '') // Remove spaces
                .substring(0, 8); // Take first 8 characters
            
            // If less than 4 characters, pad with first letters
            if (code.length < 4) {
                const words = productName.toLowerCase().split(/\s+/);
                code = words.map(word => word.charAt(0)).join('').substring(0, 8);
            }
            
            return code.toUpperCase();
        }

        function openReceiptWindow(transactionNum, totalAmount, change, cash, cashier, cart, hasDiscount, orderType, isReprint = false, paymentMethod = 'cash', referenceNo = null, pwdDiscount = '₱ 0.00', manualDiscount = '₱ 0.00', vatAmount = '₱ 0.00') {
            const receiptWindow = window.open('', '_blank', 'width=300,height=auto');
            
            // Calculate totals with VAT inclusive and item-level PWD discount (same basis as reprint layout)
            let subtotal = 0;
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            let subtotalVatExempt = 0;
            
            cart.forEach(item => {
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                if (item.hasPwdDiscount) {
                    const itemPwdDiscount = itemSubtotal * 0.20;
                    totalPwdDiscount += itemPwdDiscount;
                    subtotalVatExempt += (itemSubtotal - itemPwdDiscount);
                } else {
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                }
            });
            
            // Normalize discounts/amounts for display
            const manualDiscountValue = typeof manualDiscount === 'string' ? parseFloat(manualDiscount.replace(/[^0-9.-]+/g, '')) : (manualDiscount || 0);
            const finalPwdDiscount = typeof pwdDiscount === 'string' ? parseFloat(pwdDiscount.replace(/[^0-9.-]+/g, '')) : totalPwdDiscount;
            const finalVatAmount = typeof vatAmount === 'string' ? parseFloat(vatAmount.replace(/[^0-9.-]+/g, '')) : totalVatAmount;
            const finalTotal = parseFloat(totalAmount.replace(/[^0-9.-]+/g, '')) || (subtotal - finalPwdDiscount - manualDiscountValue);
            const hasAnyDiscount = finalPwdDiscount > 0 || manualDiscountValue > 0;
            
            const numericPayment = typeof cash === 'string' ? parseFloat(cash.replace(/[^0-9.-]+/g, '')) || 0 : (cash || 0);
            const numericChange = typeof change === 'string' ? parseFloat(change.replace(/[^0-9.-]+/g, '')) || 0 : (change || 0);
            const orderTypeLabel = isReprint ? 'REPRINT' : (String(orderType || '').toLowerCase() === 'take-out' ? 'Take Out' : 'Dine In');
            
            // Same size and layout as Print Bill (58mm / 50mm) so details are readable like the bill
            receiptWindow.document.write(`
                <html>
                <head>
                    <title>Receipt</title>
                    <style>
                        @page {
                            size: 58mm auto;
                            margin: 3mm 2mm 3mm 2mm;
                        }
                        * { box-sizing: border-box; }
                        body { 
                            font-family: 'Courier New', monospace;
                            text-align: center;
                            padding: 0;
                            margin: 0;
                            background: white;
                            width: 50mm;
                            max-width: 50mm;
                            font-size: 9px;
                            overflow-wrap: break-word;
                            word-wrap: break-word;
                        }
                        .receipt-header {
                            text-align: center;
                            border-bottom: 1px dashed #000;
                            padding-bottom: 4px;
                            margin-bottom: 6px;
                            width: 100%;
                        }
                        .receipt-header h1 {
                            margin: 0;
                            font-size: 10px;
                            font-weight: bold;
                            margin-bottom: 3px;
                            line-height: 1.1;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-header p {
                            margin: 1px 0;
                            font-size: 8px;
                            line-height: 1.1;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-header .receipt-logo {
                            max-width: 40mm;
                            max-height: 15mm;
                            margin: 0 auto 4px auto;
                            display: block;
                        }
                        .receipt-items {
                            margin: 6px 0;
                            width: 100%;
                        }
                        .receipt-items table {
                            width: 100%;
                            border-collapse: collapse;
                            font-size: 8px;
                            table-layout: fixed;
                        }
                        .receipt-items th {
                            border-bottom: 1px dashed #000;
                            padding: 2px 1px;
                            text-align: left;
                            font-size: 8px;
                            font-weight: bold;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-items th:nth-child(1) { width: 15%; }
                        .receipt-items th:nth-child(2) { width: 50%; }
                        .receipt-items th:nth-child(3) { width: 35%; text-align: right; }
                        .receipt-items td {
                            padding: 2px 1px;
                            line-height: 1.1;
                            font-size: 8px;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-items td:nth-child(1) { text-align: left; }
                        .receipt-items td:nth-child(2) { text-align: left; }
                        .receipt-items td:nth-child(3) { text-align: right; }
                        .receipt-totals {
                            border-top: 1px dashed #000;
                            margin-top: 6px;
                            padding-top: 4px;
                            font-size: 8px;
                            width: 100%;
                        }
                        .receipt-totals p {
                            margin: 2px 0;
                            line-height: 1.2;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                            display: block;
                            text-align: left;
                        }
                        .receipt-totals p .label {
                            display: inline-block;
                            text-align: left;
                            max-width: 60%;
                            vertical-align: top;
                        }
                        .receipt-totals p .value {
                            display: inline-block;
                            text-align: right;
                            float: right;
                            min-width: 40%;
                            vertical-align: top;
                        }
                        .receipt-totals p strong { font-weight: bold; }
                        .receipt-footer {
                            text-align: center;
                            margin-top: 6px;
                            padding-top: 4px;
                            border-top: 1px dashed #000;
                            font-size: 8px;
                            width: 100%;
                        }
                        .receipt-footer p {
                            margin: 2px 0;
                            line-height: 1.2;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-divider {
                            border-top: 1px dashed #000;
                            margin: 4px 0;
                        }
                        .receipt-date { text-align: center; font-size: 8px; margin: 3px 0; line-height: 1.2; }
                        .order-type {
                            text-align: center;
                            font-size: 9px;
                            font-weight: bold;
                            margin: 4px 0;
                            text-transform: uppercase;
                            line-height: 1.2;
                        }
                    </style>
                </head>
                <body>
                    <div class="receipt-header">
                        <img src="../images/logo.png" alt="Logo" class="receipt-logo">
                        <h1>EDGIE'S RESTAURANT AND EVENTS</h1>
                        <p>Pasolo Road, Pasolo 1440 Valenzuela City</p>
                        <p>Tel: 0917-000-0000</p>
                        <p>VAT Reg. TIN: 000-000-000-00000</p>
                        <div class="receipt-divider"></div>
                        <p>Sales Invoice: ${transactionNum}</p>
                        <p>Cashier: ${cashier}</p>
                        <p class="receipt-date">${new Date().toLocaleString()}</p>
                        ${isReprint ? '<p style="color: #e74c3c; font-weight: bold; font-size: 9px;">*** REPRINT ***</p>' : ''}
                    </div>
                    <div class="receipt-items">
                        <table>
                            <thead>
                                <tr>
                                    <th>Qty</th>
                                    <th>Item</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody id="receiptItemsBody"></tbody>
                        </table>
                    </div>
                    <div class="receipt-totals">
                        <p><span class="label">Subtotal (VAT Inc):</span><span class="value">${formatNumber(subtotal).replace('₱ ', '')}</span></p>
                        ${hasAnyDiscount ? `
                            <p><span class="label">VAT Discount:</span><span class="value">${formatNumber(finalVatAmount).replace('₱ ', '')}</span></p>
                            <p><span class="label">PWD/Senior Disc (20%):</span><span class="value">${formatNumber(finalPwdDiscount).replace('₱ ', '')}</span></p>
                            ${manualDiscountValue > 0 ? `<p><span class="label">Manual Discount:</span><span class="value">${formatNumber(manualDiscountValue).replace('₱ ', '')}</span></p>` : ''}
                            <p><span class="label"><strong>TOTAL AMOUNT:</strong></span><span class="value"><strong>${formatNumber(finalTotal).replace('₱ ', '')}</strong></span></p>
                        ` : `
                            <p><span class="label">VAT (12%):</span><span class="value">${formatNumber(finalVatAmount).replace('₱ ', '')}</span></p>
                            <p><span class="label"><strong>TOTAL AMOUNT:</strong></span><span class="value"><strong>${formatNumber(subtotal).replace('₱ ', '')}</strong></span></p>
                        `}
                        <p><span class="label">Payment Method:</span><span class="value"><strong>${paymentMethod ? paymentMethod.toUpperCase() : 'CASH'}</strong></span></p>
                        <p><span class="label">Amount Paid:</span><span class="value">${formatNumber(numericPayment).replace('₱ ', '')}</span></p>
                        ${paymentMethod && paymentMethod.toLowerCase() !== 'cash' && referenceNo ? `<p><span class="label">Ref No:</span><span class="value"><strong>${referenceNo}</strong></span></p>` : ''}
                        ${paymentMethod && paymentMethod.toLowerCase() === 'cash' ? `<p><span class="label">Change:</span><span class="value">${formatNumber(numericChange).replace('₱ ', '')}</span></p>` : ''}
                    </div>
                    <div class="receipt-footer">
                        <div class="receipt-divider"></div>
                        <p>Customer Name: _________________</p>
                        <p>Contact No.: _________________</p>
                        <div class="receipt-divider"></div>
                        <p>Thank you for dining with us!</p>
                        <p>Please come again</p>
                        <br>
                        <p class="order-type">${orderTypeLabel}</p>
                    </div>
                </body>
                </html>
            `);
            
            const receiptItemsBody = receiptWindow.document.getElementById('receiptItemsBody');
            receiptItemsBody.innerHTML = '';
            cart.forEach(item => {
                const unitPrice = Number(item.price) || 0;
                const qty = Number(item.quantity) || 1;
                const lineTotal = unitPrice * qty;
                const priceStr = formatNumber(lineTotal).replace('₱ ', '');
                receiptItemsBody.innerHTML += `
                    <tr>
                        <td>${qty}</td>
                        <td>${item.name}</td>
                        <td>${priceStr}</td>
                    </tr>
                `;
            });
            receiptWindow.document.close();
            return receiptWindow;
        }

        // Initialize cart display on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateCart();
            // Load tables from storage
            loadTablesFromStorage();
            
            // Restore sidebar state on page load (default to collapsed)
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                // Disable transitions during state restoration
                sidebar.classList.add('no-transition');
                
                // Check localStorage for saved state
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                
                // Re-enable transitions after a short delay
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }
        });

        // Update sidebar date and time
        function updateSidebarDateTime() {
            const now = new Date();
            
            // Format date: Day, Month DD, YYYY
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', dateOptions);
            
            // Format time: HH:MM:SS AM/PM
            const timeStr = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                hour12: true 
            });
            
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            
            if (dateElement) {
                dateElement.textContent = dateStr;
            }
            if (timeElement) {
                timeElement.textContent = timeStr;
            }
        }

        // Update immediately and then every second
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        // Tables Management
        let tableCounter = 0;
        let tables = {}; // Store table data: { tableId: { cart: [], number: number, selectedCategory: 'all', searchTerm: '', orderType: 'dine-in' } }
        let nextTableNumberToShow = null; // Track the next table number to show in modal (for "Add Another Table" functionality)

        // Store products and categories data for mini POS
        const allProducts = <?php echo json_encode($products); ?>;
        const allCategories = <?php 
            $categoriesResult->data_seek(0);
            $categoriesArray = [];
            while ($cat = $categoriesResult->fetch_assoc()) {
                $categoriesArray[] = $cat;
            }
            echo json_encode($categoriesArray);
        ?>;

        // Load tables from localStorage on page load
        function loadTablesFromStorage() {
            try {
                const savedTables = localStorage.getItem('posTables');
                
                if (savedTables) {
                    tables = JSON.parse(savedTables);
                    // Calculate tableCounter from existing tables and ensure orderType is 'dine-in'
                    let maxNumber = 0;
                    for (const tableId in tables) {
                        if (tables[tableId] && tables[tableId].number > maxNumber) {
                            maxNumber = tables[tableId].number;
                        }
                        // Ensure orderType is always 'dine-in'
                        if (tables[tableId]) {
                            tables[tableId].orderType = 'dine-in';
                        }
                    }
                    tableCounter = maxNumber;
                    
                    // Save updated tables back to storage
                    saveTablesToStorage();
                    
                    // Re-render all tables when tables view is shown
                    if (document.getElementById('tablesView')) {
                        renderAllTables();
                    }
                }
            } catch (e) {
                console.error('Error loading tables from storage:', e);
            }
        }

        // Save tables to localStorage
        function saveTablesToStorage() {
            try {
                localStorage.setItem('posTables', JSON.stringify(tables));
                // Update tableCounter based on current tables
                let maxNumber = 0;
                for (const tableId in tables) {
                    if (tables[tableId] && tables[tableId].number > maxNumber) {
                        maxNumber = tables[tableId].number;
                    }
                }
                tableCounter = maxNumber;
            } catch (e) {
                console.error('Error saving tables to storage:', e);
            }
        }

        // Render all saved tables
        function renderAllTables() {
            const tablesContainer = document.getElementById('tablesContainer');
            if (!tablesContainer) return;
            
            // Clear existing tables
            tablesContainer.innerHTML = '';
            
            // Render each table
            for (const tableId in tables) {
                const table = tables[tableId];
                renderTable(tableId, table);
            }
        }

        // Render a single table
        function renderTable(tableId, table) {
            const tablesContainer = document.getElementById('tablesContainer');
            if (!tablesContainer) return;
            
            // Check if table already exists
            let tableDiv = document.getElementById(tableId);
            
            if (!tableDiv) {
                tableDiv = document.createElement('div');
                tableDiv.className = 'table-container';
                tableDiv.id = tableId;
                tablesContainer.appendChild(tableDiv);
            }
            
            tableDiv.innerHTML = `
                <div class="table-header">
                    <div class="table-title">
                        <i class="fas fa-table" style="font-size: 24px; color: #333;"></i>
                        <span>Table ${table.number}</span>
                    </div>
                    <button class="table-close-btn" onclick="removeTable('${tableId}')" title="Close Table">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="table-bill-container">
                    <div class="table-bill-header">
                        <h4 style="margin: 0; font-size: 16px; color: #333; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <i class="fas fa-receipt" style="color: #333;"></i>
                            Bill
                        </h4>
                        ${!table.showPaymentMethod ? `
                        <button class="table-add-btn" onclick="openTableMenu('${tableId}')">
                            <i class="fas fa-plus"></i> Add
                        </button>
                        ` : ''}
                    </div>
                    <div class="mini-cart" id="${tableId}_cart">
                        ${renderMiniCart(tableId)}
                    </div>
                </div>
            `;
        }

        let currentTableMenuId = null;

        function openTableMenu(tableId) {
            const table = tables[tableId];
            if (!table) return;

            currentTableMenuId = tableId;
            const menu = document.getElementById('tableMenuModal');
            const title = document.getElementById('tableMenuTitle');
            const searchInput = document.getElementById('tableMenuSearch');
            const categoriesContainer = document.getElementById('tableMenuCategories');
            const productsContainer = document.getElementById('tableMenuProducts');

            if (menu && title && searchInput && categoriesContainer && productsContainer) {
                // Update title
                title.textContent = `Add Products - Table ${table.number}`;
                
                // Set search value
                searchInput.value = table.searchTerm || '';
                
                // Render categories
                categoriesContainer.innerHTML = renderMiniCategories(tableId);
                
                // Render products
                productsContainer.innerHTML = renderMiniProducts(tableId);
                
                // Show modal
                menu.style.display = 'flex';
                
                // Close menu when clicking outside
                menu.onclick = function(e) {
                    if (e.target === menu) {
                        closeTableMenu();
                    }
                };
            }
        }

        function closeTableMenu() {
            const menu = document.getElementById('tableMenuModal');
            if (menu) {
                menu.style.display = 'none';
                currentTableMenuId = null;
            }
        }

        function filterTableMenuProducts() {
            if (currentTableMenuId) {
                const searchInput = document.getElementById('tableMenuSearch');
                const table = tables[currentTableMenuId];
                if (table && searchInput) {
                    table.searchTerm = searchInput.value.toLowerCase().trim();
                    saveTablesToStorage();
                    filterMiniProducts(currentTableMenuId);
                    // Update products in modal
                    const productsContainer = document.getElementById('tableMenuProducts');
                    if (productsContainer) {
                        productsContainer.innerHTML = renderMiniProducts(currentTableMenuId);
                    }
                }
            }
        }

        function showPOSView() {
            document.getElementById('posView').style.display = 'flex';
            document.getElementById('tablesView').style.display = 'none';
            document.getElementById('posTab').classList.add('active');
            document.getElementById('tablesTab').classList.remove('active');
        }

        function showTablesView() {
            document.getElementById('posView').style.display = 'none';
            document.getElementById('tablesView').style.display = 'block';
            document.getElementById('posTab').classList.remove('active');
            document.getElementById('tablesTab').classList.add('active');
            
            // Render all saved tables
            renderAllTables();
        }

        function addTable() {
            // Show table number selection modal
            openTableNumberModal();
        }

        function openTableNumberModal() {
            const modal = document.getElementById('tableNumberModal');
            const grid = document.getElementById('tableNumberGrid');
            
            if (!modal || !grid) return;
            
            // Get all existing table numbers
            const existingNumbers = [];
            for (const tableId in tables) {
                if (tables[tableId] && tables[tableId].number) {
                    existingNumbers.push(tables[tableId].number);
                }
            }
            
            // Find the maximum table number to display
            // Show at least 10, or highest existing, or nextTableNumberToShow if set
            let maxTableNumber = 10;
            if (existingNumbers.length > 0) {
                maxTableNumber = Math.max(10, Math.max(...existingNumbers));
            }
            
            // If we have a nextTableNumberToShow, include it in the display
            if (nextTableNumberToShow !== null && nextTableNumberToShow > maxTableNumber) {
                maxTableNumber = nextTableNumberToShow;
            }
            
            // Generate table number buttons (1 to maxTableNumber)
            let html = '';
            for (let i = 1; i <= maxTableNumber; i++) {
                const isTaken = existingNumbers.includes(i);
                html += `
                    <button 
                        class="table-number-btn ${isTaken ? 'taken' : ''}" 
                        onclick="selectTableNumber(${i})"
                        ${isTaken ? 'disabled' : ''}
                        style="
                            padding: 25px;
                            border: 2px solid ${isTaken ? '#e9ecef' : '#face0b'};
                            border-radius: 10px;
                            background: ${isTaken ? '#f8f9fa' : 'white'};
                            color: ${isTaken ? '#adb5bd' : '#333'};
                            font-size: 20px;
                            font-weight: 700;
                            cursor: ${isTaken ? 'not-allowed' : 'pointer'};
                            transition: all 0.3s ease;
                            ${!isTaken ? 'box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);' : ''}
                            display: flex;
                            flex-direction: column;
                            align-items: center;
                            justify-content: center;
                        "
                        onmouseover="${!isTaken ? "this.style.background='#face0b'; this.style.color='#000'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(0, 0, 0, 0.15)';" : ''}"
                        onmouseout="${!isTaken ? "this.style.background='white'; this.style.color='#333'; this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)';" : ''}"
                    >
                        <i class="fas fa-utensils" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                        Table ${i}
                    </button>
                `;
            }
            
            grid.innerHTML = html;
            modal.style.display = 'flex';
            
            // Close modal when clicking outside
            modal.onclick = function(e) {
                if (e.target === modal) {
                    closeTableNumberModal();
                }
            };
        }
        
        function addNewTableNumber() {
            const grid = document.getElementById('tableNumberGrid');
            if (!grid) return;
            
            // Get all existing table numbers from tables object
            const existingNumbers = [];
            for (const tableId in tables) {
                if (tables[tableId] && tables[tableId].number) {
                    existingNumbers.push(tables[tableId].number);
                }
            }
            
            // Get all table numbers currently displayed in the grid
            const displayedNumbers = [];
            const gridButtons = grid.querySelectorAll('button[onclick^="selectTableNumber"]');
            gridButtons.forEach(btn => {
                const onclickAttr = btn.getAttribute('onclick');
                const match = onclickAttr.match(/selectTableNumber\((\d+)\)/);
                if (match) {
                    displayedNumbers.push(parseInt(match[1]));
                }
            });
            
            // Find the highest number from both sources
            let highestNumber = 0;
            if (existingNumbers.length > 0) {
                highestNumber = Math.max(highestNumber, Math.max(...existingNumbers));
            }
            if (displayedNumbers.length > 0) {
                highestNumber = Math.max(highestNumber, Math.max(...displayedNumbers));
            }
            
            // If nextTableNumberToShow is set and is higher, use that
            if (nextTableNumberToShow !== null && nextTableNumberToShow > highestNumber) {
                highestNumber = nextTableNumberToShow;
            }
            
            // Calculate the next sequential number (highest + 1)
            // If no tables exist and no numbers displayed, start from 11 (since default shows 1-10)
            let nextNumber = highestNumber > 0 ? highestNumber + 1 : 11;
            
            // Set the next table number to show
            nextTableNumberToShow = nextNumber;
            
            // Check if this number already exists in the grid
            const existingButton = grid.querySelector(`button[onclick="selectTableNumber(${nextNumber})"]`);
            if (existingButton) {
                return; // Already exists, don't add again
            }
            
            // Create the new table number button directly
            const newButton = document.createElement('button');
            newButton.className = 'table-number-btn';
            newButton.setAttribute('onclick', `selectTableNumber(${nextNumber})`);
            newButton.style.cssText = `
                padding: 25px;
                border: 2px solid #face0b;
                border-radius: 10px;
                background: white;
                color: #333;
                font-size: 20px;
                font-weight: 700;
                cursor: pointer;
                transition: all 0.3s ease;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
            `;
            newButton.setAttribute('onmouseover', "this.style.background='#face0b'; this.style.color='#000'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(0, 0, 0, 0.15)';");
            newButton.setAttribute('onmouseout', "this.style.background='white'; this.style.color='#333'; this.style.transform='translateY(0)'; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)';");
            
            newButton.innerHTML = `
                <i class="fas fa-utensils" style="font-size: 24px; margin-bottom: 8px; display: block;"></i>
                Table ${nextNumber}
            `;
            
            // Append the new button to the grid immediately
            grid.appendChild(newButton);
        }

        function closeTableNumberModal() {
            const modal = document.getElementById('tableNumberModal');
            if (modal) {
                modal.style.display = 'none';
            }
        }

        function selectTableNumber(tableNumber) {
            // Check if table number is already taken
            for (const tableId in tables) {
                if (tables[tableId] && tables[tableId].number === tableNumber) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Table Already Exists',
                        text: `Table ${tableNumber} is already in use. Please select another table.`,
                        confirmButtonColor: '#face0b',
                        confirmButtonText: 'OK'
                    });
                    return;
                }
            }
            
            // Use timestamp + random to ensure unique ID
            const tableId = 'table_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            
            // Initialize table data
            tables[tableId] = {
                cart: [],
                number: tableNumber,
                selectedCategory: 'all',
                searchTerm: '',
                orderType: 'dine-in',
                hasDiscount: false,
                showPaymentMethod: false,
                paymentMethod: 'cash'
            };

            // Save to storage
            saveTablesToStorage();

            // Render the table
            renderTable(tableId, tables[tableId]);
            
            // Clear the nextTableNumberToShow since we've created the table
            nextTableNumberToShow = null;
            
            // Close the modal automatically after selecting a table
            closeTableNumberModal();
        }

        function removeTable(tableId) {
            const table = tables[tableId];
            if (!table) return;
            
            if (typeof Swal !== 'undefined') {
                let timeLeft = 10;
                let countdownInterval;
                
                const swalInstance = Swal.fire({
                    title: 'Close Table?',
                    html: `Are you sure you want to close Table ${table.number}? All bill items will be lost.<br><br><strong style="font-size: 24px; color: #d33;" id="countdown-timer">${timeLeft}</strong> seconds remaining`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef4444',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, close it',
                    cancelButtonText: 'Cancel',
                    allowOutsideClick: false,
                    allowEscapeKey: false,
                    timer: 10000,
                    timerProgressBar: true,
                    didOpen: () => {
                        const timerElement = Swal.getHtmlContainer().querySelector('#countdown-timer');
                        countdownInterval = setInterval(() => {
                            timeLeft--;
                            if (timerElement) {
                                timerElement.textContent = timeLeft;
                            }
                            if (timeLeft <= 0) {
                                clearInterval(countdownInterval);
                            }
                        }, 1000);
                    },
                    willClose: () => {
                        if (countdownInterval) {
                            clearInterval(countdownInterval);
                        }
                    }
                }).then((result) => {
                    if (countdownInterval) {
                        clearInterval(countdownInterval);
                    }
                    
                    // If timer expired (result.dismiss === Swal.DismissReason.timer), keep table open
                    if (result.dismiss === Swal.DismissReason.timer) {
                        // Timer expired - table remains open
                        return;
                    }
                    
                    // If user confirmed, close the table
                    if (result.isConfirmed) {
                        const tableElement = document.getElementById(tableId);
                        if (tableElement) {
                            tableElement.remove();
                        }
                        delete tables[tableId];
                        saveTablesToStorage();
                    }
                    // If user cancelled, table remains open (no action needed)
                });
            } else {
                if (confirm('Are you sure you want to close this table? All bill items will be lost.')) {
                    const tableElement = document.getElementById(tableId);
                    if (tableElement) {
                        tableElement.remove();
                    }
                    delete tables[tableId];
                    saveTablesToStorage();
                }
            }
        }

        function renderMiniCategories(tableId) {
            if (!allCategories || allCategories.length === 0) {
                return '';
            }
            
            const table = tables[tableId];
            const selectedCategory = table ? table.selectedCategory : 'all';
            
            let html = '<button class="mini-category-btn ' + (selectedCategory === 'all' ? 'active' : '') + '" onclick="selectMiniCategory(\'' + tableId + '\', \'all\')">All</button>';
            
            allCategories.forEach(category => {
                const categoryId = category.CategoryID;
                const categoryName = category.CategoryName || 'Unknown';
                const isActive = selectedCategory === categoryId ? 'active' : '';
                html += `<button class="mini-category-btn ${isActive}" onclick="selectMiniCategory('${tableId}', '${categoryId}')">${categoryName}</button>`;
            });
            
            return html;
        }

        function selectMiniCategory(tableId, categoryId) {
            const table = tables[tableId];
            if (!table) return;
            
            table.selectedCategory = categoryId;
            
            // Save to storage
            saveTablesToStorage();
            
            // Update category buttons (check if in modal or table)
            const categoriesContainer = document.getElementById(tableId + '_categories');
            const modalCategoriesContainer = document.getElementById('tableMenuCategories');
            
            if (categoriesContainer) {
                categoriesContainer.innerHTML = renderMiniCategories(tableId);
            }
            if (modalCategoriesContainer && currentTableMenuId === tableId) {
                modalCategoriesContainer.innerHTML = renderMiniCategories(tableId);
            }
            
            // Update products list
            filterMiniProducts(tableId);
        }

        function filterMiniProducts(tableId) {
            const table = tables[tableId];
            if (!table) return;
            
            // Get search term from either table search or modal search
            const searchInput = document.getElementById(tableId + '_search');
            const modalSearchInput = document.getElementById('tableMenuSearch');
            
            if (modalSearchInput && currentTableMenuId === tableId) {
                table.searchTerm = modalSearchInput.value.toLowerCase().trim();
            } else if (searchInput) {
                table.searchTerm = searchInput.value.toLowerCase().trim();
            }
            
            // Save to storage (debounced to avoid too many saves)
            clearTimeout(table.saveTimeout);
            table.saveTimeout = setTimeout(() => {
                saveTablesToStorage();
            }, 500);
            
            // Filter products
            let filteredProducts = allProducts;
            
            // Filter by category
            if (table.selectedCategory !== 'all') {
                filteredProducts = filteredProducts.filter(product => {
                    return product.CategoryID == table.selectedCategory;
                });
            }
            
            // Filter by search term
            if (table.searchTerm) {
                filteredProducts = filteredProducts.filter(product => {
                    const productName = (product.InventoryName || product.name || '').toLowerCase();
                    return productName.includes(table.searchTerm);
                });
            }
            
            // Update products display in table (if exists)
            const productsContainer = document.getElementById(tableId + '_products');
            if (productsContainer) {
                productsContainer.innerHTML = renderMiniProductsList(tableId, filteredProducts);
            }
            
            // Update products display in modal if open
            if (currentTableMenuId === tableId) {
                const modalProductsContainer = document.getElementById('tableMenuProducts');
                if (modalProductsContainer) {
                    modalProductsContainer.innerHTML = renderMiniProductsList(tableId, filteredProducts);
                }
            }
        }

        function renderMiniProducts(tableId) {
            const table = tables[tableId];
            if (!table) {
                return '<div class="empty-products-message">No products available</div>';
            }
            
            // Get filtered products
            let filteredProducts = allProducts;
            
            // Filter by category
            if (table.selectedCategory !== 'all') {
                filteredProducts = filteredProducts.filter(product => {
                    return product.CategoryID == table.selectedCategory;
                });
            }
            
            // Filter by search term
            if (table.searchTerm) {
                filteredProducts = filteredProducts.filter(product => {
                    const productName = (product.InventoryName || product.name || '').toLowerCase();
                    return productName.includes(table.searchTerm);
                });
            }
            
            return renderMiniProductsList(tableId, filteredProducts);
        }

        function renderMiniProductsList(tableId, products) {
            if (!products || products.length === 0) {
                return '<div class="empty-products-message" style="text-align: center; padding: 40px; color: #6c757d;">No products found</div>';
            }
            
            let html = '';
            products.forEach(product => {
                const productName = product.InventoryName || product.name || 'Unknown';
                const productPrice = product.Price || product.price || 0;
                // Fix image path: prepend '../' if needed
                let imagePath = product.ImagePath || product.imagePath || '../images/no-image.png';
                if (imagePath && !imagePath.startsWith('../')) {
                    imagePath = '../' + imagePath;
                }
                const escapedName = productName.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                const escapedImagePath = imagePath.replace(/'/g, "\\'").replace(/"/g, '&quot;');
                const isAvailable = product.is_available !== undefined && product.is_available !== null ? (parseInt(product.is_available) === 1) : true;
                const productClass = isAvailable ? '' : ' unavailable';
                const onClickAttr = isAvailable 
                    ? `onclick="addToMiniCart('${tableId}', '${escapedName}', ${productPrice}, '${escapedImagePath}')"`
                    : '';
                
                html += `
                    <div class="product-item${productClass}" ${onClickAttr}>
                        <div class="product-img">
                            ${!isAvailable ? '<span class="product-status-badge">Unavailable</span>' : ''}
                            <img src="${escapedImagePath}" alt="${productName}">
                        </div>
                        <p>${productName}</p>
                        <p>₱ ${parseFloat(productPrice).toFixed(2)}</p>
                    </div>
                `;
            });
            return html;
        }

        function renderMiniCart(tableId) {
            const table = tables[tableId];
            if (!table || !table.cart || table.cart.length === 0) {
                return `
                    <div class="mini-cart-items">
                        <div class="empty-cart-message">Bill is empty</div>
                    </div>
                    <div class="mini-cart-footer">
                        <div class="mini-cart-total">
                            <span>Total:</span>
                            <span>₱ 0.00</span>
                        </div>
                        <div class="mini-cart-actions">
                            <button class="mini-cart-btn clear" onclick="clearMiniCart('${tableId}')" disabled>Clear</button>
                            <button class="mini-cart-btn checkout" onclick="printTableBill('${tableId}')" disabled>Print Bill</button>
                        </div>
                    </div>
                `;
            }

            // If payment method should be shown, show payment method + back-to-bill button
            if (table.showPaymentMethod) {
                // Calculate total for display
                let subtotal = 0;
                table.cart.forEach(item => {
                    subtotal += item.price * item.quantity;
                });
                const hasTransactionDiscount = table.hasDiscount || false;
                const totalDiscount = hasTransactionDiscount ? subtotal * 0.20 : 0;
                const total = subtotal - totalDiscount;

                return `
                    <div class="mini-cart-items" style="display: flex; align-items: center; justify-content: center; height: 100%;">
                        <div style="width: 100%; max-width: 400px; padding: 20px;">
                            <div style="text-align: center; margin-bottom: 20px;">
                                <h3 style="margin: 0 0 10px 0; font-size: 18px; color: #333;">Select Payment Method</h3>
                                <div style="font-size: 14px; color: #6c757d; margin-bottom: 20px;">
                                    <strong style="color: #000;">Total:</strong>
                                    <strong style="color: #e74c3c; margin-left: 4px;">₱ ${total.toFixed(2)}</strong>
                                </div>
                            </div>
                            <div style="padding: 20px; background: #fff; border-radius: 8px; border: 2px solid #e9ecef;">
                                <label style="display: block; margin-bottom: 12px; font-weight: 600; font-size: 14px; text-align: center;">Payment Method:</label>
                                <div style="display: flex; gap: 10px; flex-wrap: wrap; justify-content: center; margin-bottom: 20px;">
                                    <label style="display: flex; align-items: center; cursor: pointer; font-size: 13px; padding: 10px 15px; border: 2px solid ${table.paymentMethod === 'cash' ? '#face0b' : '#dee2e6'}; border-radius: 8px; background: ${table.paymentMethod === 'cash' ? '#fffef5' : 'white'}; transition: all 0.3s ease;">
                                        <input type="radio" name="tablePaymentMethod_${tableId}" value="cash" ${table.paymentMethod === 'cash' ? 'checked' : ''} onchange="tables['${tableId}'].paymentMethod = 'cash'; const cartEl = document.getElementById('${tableId}_cart'); if (cartEl) cartEl.innerHTML = renderMiniCart('${tableId}'); calculateTableChange('${tableId}'); saveTablesToStorage();" style="margin-right: 8px;">
                                        <i class="fas fa-money-bill-wave" style="margin-right: 5px;"></i>Cash
                                    </label>
                                    <label style="display: flex; align-items: center; cursor: pointer; font-size: 13px; padding: 10px 15px; border: 2px solid ${table.paymentMethod === 'gcash' ? '#face0b' : '#dee2e6'}; border-radius: 8px; background: ${table.paymentMethod === 'gcash' ? '#fffef5' : 'white'}; transition: all 0.3s ease;">
                                        <input type="radio" name="tablePaymentMethod_${tableId}" value="gcash" ${table.paymentMethod === 'gcash' ? 'checked' : ''} onchange="tables['${tableId}'].paymentMethod = 'gcash'; const cartEl = document.getElementById('${tableId}_cart'); if (cartEl) cartEl.innerHTML = renderMiniCart('${tableId}'); saveTablesToStorage();" style="margin-right: 8px;">
                                        <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>GCash
                                    </label>
                                    <label style="display: flex; align-items: center; cursor: pointer; font-size: 13px; padding: 10px 15px; border: 2px solid ${table.paymentMethod === 'paymaya' ? '#face0b' : '#dee2e6'}; border-radius: 8px; background: ${table.paymentMethod === 'paymaya' ? '#fffef5' : 'white'}; transition: all 0.3s ease;">
                                        <input type="radio" name="tablePaymentMethod_${tableId}" value="paymaya" ${table.paymentMethod === 'paymaya' ? 'checked' : ''} onchange="tables['${tableId}'].paymentMethod = 'paymaya'; const cartEl = document.getElementById('${tableId}_cart'); if (cartEl) cartEl.innerHTML = renderMiniCart('${tableId}'); saveTablesToStorage();" style="margin-right: 8px;">
                                        <i class="fas fa-mobile-alt" style="margin-right: 5px;"></i>Maya
                                    </label>
                                </div>
                                ${table.paymentMethod === 'cash' ? `
                                <div style="margin-top: 15px; text-align: center;">
                                    <label style="font-size: 13px; font-weight: 500; display: block; margin-bottom: 8px;">Cash Amount:</label>
                                    <input type="number" id="${tableId}_cashInput" placeholder="Enter amount" oninput="calculateTableChange('${tableId}')" style="width: 100%; max-width: 200px; padding: 10px; border: 2px solid #dee2e6; border-radius: 6px; font-size: 14px; text-align: center; margin: 0 auto; display: block;">
                                </div>
                                <div style="margin-top: 10px; text-align: center; font-size: 14px; font-weight: 600;">
                                    Change: <span id="${tableId}_change" style="color: #28a745;">₱ 0.00</span>
                                </div>
                                ` : `
                                <div style="margin-top: 15px; text-align: center;">
                                    <label style="font-size: 13px; font-weight: 500; display: block; margin-bottom: 8px;">Reference Number:</label>
                                    <input type="text" id="${tableId}_referenceNoInput" placeholder="${table.paymentMethod === 'gcash' ? 'Enter reference number (9 digits)' : 'Enter reference number (6 digits)'}" pattern="${table.paymentMethod === 'gcash' ? '[0-9]{9}' : '[0-9]{6}'}" maxlength="${table.paymentMethod === 'gcash' ? '9' : '6'}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; max-width: 250px; padding: 10px; border: 2px solid #dee2e6; border-radius: 6px; font-size: 14px; text-align: center; margin: 0 auto; display: block;">
                                </div>
                                `}
                                <div style="margin-top: 20px; display: flex; justify-content: center; gap: 10px;">
                                    <button class="mini-cart-btn clear" onclick="tables['${tableId}'].showPaymentMethod = false; const cartEl = document.getElementById('${tableId}_cart'); if (cartEl) cartEl.innerHTML = renderMiniCart('${tableId}'); saveTablesToStorage();" style="padding: 10px 16px; font-size: 13px; font-weight: 600;">Back to Bill</button>
                                    <button class="mini-cart-btn checkout" onclick="checkoutMiniCart('${tableId}')" style="padding: 12px 18px; font-size: 14px; font-weight: 600;">Pay</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mini-cart-footer" style="display: none;"></div>
                `;
            }

            let itemsHtml = '';
            let subtotal = 0;
            
            table.cart.forEach(item => {
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                // Ensure item has an ID (for backward compatibility with old cart items)
                if (item.id === undefined) {
                    if (!tableCartItemIdCounter[tableId]) {
                        tableCartItemIdCounter[tableId] = 0;
                    }
                    item.id = tableCartItemIdCounter[tableId]++;
                }
                const itemId = item.id;
                itemsHtml += `
                    <div class="mini-cart-item">
                        <div style="flex: 1;">
                            <div style="font-weight: 600; margin-bottom: 4px;">${item.name}</div>
                            <div style="color: #6c757d; font-size: 11px;">₱ ${parseFloat(item.price).toFixed(2)} × ${item.quantity}</div>
                            <div style="margin-top: 3px;">
                                <label style="display: flex; align-items: center; gap: 5px; font-size: 11px; cursor: pointer;">
                                    <input type="checkbox"
                                           ${item.hasPwdDiscount ? 'checked' : ''}
                                           onchange="toggleTablePwdDiscount('${tableId}', '${itemId}', this.checked)"
                                           style="cursor: pointer; width: 14px; height: 14px;">
                                    <span style="color: #28a745;">PWD/Senior (20%)</span>
                                </label>
                            </div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 6px;">
                            <div class="mini-cart-qty">
                                <button class="mini-qty-btn" onclick="changeMiniCartQty('${tableId}', '${itemId}', -1)">-</button>
                                <span style="min-width: 30px; text-align: center; font-weight: 600;">${item.quantity}</span>
                                <button class="mini-qty-btn" onclick="changeMiniCartQty('${tableId}', '${itemId}', 1)">+</button>
                            </div>
                            <button onclick="removeMiniCartItem('${tableId}', '${itemId}')" style="background: #dc3545; color: white; border: none; border-radius: 4px; width: 28px; height: 28px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 12px; cursor: pointer; flex-shrink: 0;" title="Remove">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `;
            });
            
            // Manual discount for table (percentage 0-100) – similar to take-out
            const manualDiscountPercentTable = Math.min(100, Math.max(0, table.manualDiscount || 0));
            const totalBeforeManualDiscountTable = subtotal;
            const manualDiscountAmountTable = totalBeforeManualDiscountTable * (manualDiscountPercentTable / 100);
            const discountedSubtotal = subtotal - manualDiscountAmountTable;
            
            // VAT is 12% of the discounted subtotal (VAT-inclusive model simplified for tables)
            const vatAmount = discountedSubtotal * 0.12;
            const total = discountedSubtotal + vatAmount;

            // Structure: scrollable items container + fixed footer
            const html = `
                <div class="mini-cart-items">
                    ${itemsHtml}
                </div>
                <div class="mini-cart-footer">
                    <div style="margin: 8px 0; padding: 8px; background: #f8f9fa; border-radius: 6px;">
                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
                            <span style="font-size: 11px; color: #6c757d; font-weight: 500;">Manual Discount (%):</span>
                            <input type="text"
                                   inputmode="decimal"
                                   placeholder="%"
                                   value="${manualDiscountPercentTable > 0 ? manualDiscountPercentTable : ''}"
                                   oninput="updateTableManualDiscount('${tableId}', this)"
                                   class="pos-input pos-input-sm align-right"
                                   style="width: 60px; padding: 4px 6px;">
                        </div>
                        <div id="${tableId}_manualDiscountInfo" style="font-size: 11px; color: #28a745; text-align: right; margin-top: 4px; ${manualDiscountAmountTable > 0 ? '' : 'display: none;'}">
                            Manual Discount: ₱ ${manualDiscountAmountTable.toFixed(2)}
                        </div>
                    </div>
                    <div class="mini-cart-total">
                        <span style="font-weight: 700; color: #000;">Total:</span>
                        <span id="${tableId}_miniTotal">₱ ${total.toFixed(2)}</span>
                    </div>
                    <div class="mini-cart-actions">
                        <button class="mini-cart-btn clear" onclick="clearMiniCart('${tableId}')">Clear</button>
                        <button class="mini-cart-btn checkout" onclick="printTableBill('${tableId}')">Print Bill</button>
                    </div>
                </div>
            `;

            return html;
        }

        // Track cart item IDs for tables
        let tableCartItemIdCounter = {};
        
        function addToMiniCart(tableId, productName, productPrice, productImage) {
            const table = tables[tableId];
            if (!table) return;
            
            // Initialize counter for this table if needed
            if (!tableCartItemIdCounter[tableId]) {
                tableCartItemIdCounter[tableId] = 0;
            }

            // Find existing item with same name and price
            const existingItem = table.cart.find(item => 
                item.name === productName && 
                item.price === productPrice
            );
            
            if (existingItem) {
                existingItem.quantity++;
            } else {
                table.cart.push({
                    id: tableCartItemIdCounter[tableId]++,
                    name: productName,
                    price: productPrice,
                    quantity: 1,
                    image: productImage || '../images/no-image.png'
                });
            }

            // Update cart display
            const cartElement = document.getElementById(tableId + '_cart');
            if (cartElement) {
                cartElement.innerHTML = renderMiniCart(tableId);
            }

            // Save to storage
            saveTablesToStorage();

            // Close the menu after adding product
            closeTableMenu();

            // Show notification
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Added!',
                    text: `${productName} added to Table ${table.number}`,
                    icon: 'success',
                    timer: 1000,
                    showConfirmButton: false,
                    position: 'top-end',
                    toast: true
                });
            }
        }


        function removeMiniCartItem(tableId, itemId) {
            const table = tables[tableId];
            if (!table) return;
            
            // Convert itemId to number if it's a string
            const id = typeof itemId === 'string' ? parseInt(itemId) : itemId;
            table.cart = table.cart.filter(item => item.id != id);
            
            // Update cart display
            const cartElement = document.getElementById(tableId + '_cart');
            if (cartElement) {
                cartElement.innerHTML = renderMiniCart(tableId);
            }
            
            // Save to storage
            saveTablesToStorage();
        }

        function changeMiniCartQty(tableId, itemId, change) {
            const table = tables[tableId];
            if (!table) return;

            // Convert itemId to number if it's a string
            const id = typeof itemId === 'string' ? parseInt(itemId) : itemId;
            const item = table.cart.find(item => item.id == id);
            if (item) {
                item.quantity += change;
                if (item.quantity <= 0) {
                    table.cart = table.cart.filter(item => item.id != id);
                } else if (item.quantity > 99) {
                    item.quantity = 99;
                }
            }

            // Update cart display
            const cartElement = document.getElementById(tableId + '_cart');
            if (cartElement) {
                cartElement.innerHTML = renderMiniCart(tableId);
            }
            
            // Save to storage
            saveTablesToStorage();
        }

        function toggleTablePwdDiscount(tableId, itemId, isChecked) {
            const table = tables[tableId];
            if (!table) return;

            const id = typeof itemId === 'string' ? parseInt(itemId) : itemId;
            const item = table.cart.find(item => item.id == id);
            if (item) {
                item.hasPwdDiscount = isChecked;
            }

            const cartElement = document.getElementById(tableId + '_cart');
            if (cartElement) {
                cartElement.innerHTML = renderMiniCart(tableId);
            }
            saveTablesToStorage();
        }

        function updateTableManualDiscount(tableId, inputEl) {
            // Allow only digits and decimal point
            inputEl.value = inputEl.value.replace(/[^0-9.]/g, '');
            let v = parseFloat(inputEl.value);
            if (!isNaN(v) && v > 100) {
                v = 100;
                inputEl.value = '100';
            }
            if (isNaN(v)) {
                v = 0;
            }

            const table = tables[tableId];
            if (!table) return;
            table.manualDiscount = v;

            // Recalculate totals locally without re-rendering the whole mini-cart
            let subtotal = 0;
            table.cart.forEach(item => {
                subtotal += (item.price || 0) * (item.quantity || 0);
            });

            const manualDiscountPercentTable = Math.min(100, Math.max(0, table.manualDiscount || 0));
            const totalBeforeManualDiscountTable = subtotal;
            const manualDiscountAmountTable = totalBeforeManualDiscountTable * (manualDiscountPercentTable / 100);
            const discountedSubtotal = subtotal - manualDiscountAmountTable;
            const vatAmount = discountedSubtotal * 0.12;
            const total = discountedSubtotal + vatAmount;

            const infoEl = document.getElementById(tableId + '_manualDiscountInfo');
            if (infoEl) {
                if (manualDiscountAmountTable > 0) {
                    infoEl.style.display = '';
                    infoEl.textContent = 'Manual Discount: ₱ ' + manualDiscountAmountTable.toFixed(2);
                } else {
                    infoEl.style.display = 'none';
                }
            }

            const totalEl = document.getElementById(tableId + '_miniTotal');
            if (totalEl) {
                totalEl.textContent = '₱ ' + total.toFixed(2);
            }

            saveTablesToStorage();
        }

        function clearMiniCart(tableId) {
            const table = tables[tableId];
            if (!table) return;

            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Clear Cart?',
                    text: 'Are you sure you want to clear all items from this table\'s cart?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef4444',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, clear it',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        table.cart = [];
                        table.hasDiscount = false;
                        table.showPaymentMethod = false;
                        table.paymentMethod = 'cash';
                        if (tableCartItemIdCounter[tableId]) {
                            tableCartItemIdCounter[tableId] = 0;
                        }
                        const cartElement = document.getElementById(tableId + '_cart');
                        if (cartElement) {
                            cartElement.innerHTML = renderMiniCart(tableId);
                        }
                        saveTablesToStorage();
                    }
                });
            } else {
                if (confirm('Clear all items from this table\'s cart?')) {
                    table.cart = [];
                    table.hasDiscount = false;
                    table.showPaymentMethod = false;
                    table.paymentMethod = 'cash';
                    if (tableCartItemIdCounter[tableId]) {
                        tableCartItemIdCounter[tableId] = 0;
                    }
                    const cartElement = document.getElementById(tableId + '_cart');
                    if (cartElement) {
                        cartElement.innerHTML = renderMiniCart(tableId);
                    }
                    saveTablesToStorage();
                }
            }
        }

        function printTableBill(tableId) {
            const table = tables[tableId];
            if (!table || !table.cart || table.cart.length === 0) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: 'Empty Cart',
                        text: 'Please add items to the cart first.',
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    });
                }
                return;
            }

            // Calculate totals with VAT inclusive and item-level PWD discount
            let subtotal = 0;
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            let subtotalVatExempt = 0;
            
            table.cart.forEach(item => {
                // Initialize hasPwdDiscount if not set
                if (item.hasPwdDiscount === undefined) {
                    item.hasPwdDiscount = false;
                }
                
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                if (item.hasPwdDiscount) {
                    const itemPwdDiscount = itemSubtotal * 0.20;
                    totalPwdDiscount += itemPwdDiscount;
                    subtotalVatExempt += (itemSubtotal - itemPwdDiscount);
                } else {
                    // Extract VAT from VAT inclusive price
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                }
            });
            
            // Get manual discount from table (percentage 0-100), compute amount
            const manualDiscountPercent = Math.min(100, Math.max(0, table.manualDiscount || 0));
            const totalBeforeManualDiscount = subtotal - totalPwdDiscount;
            const finalManualDiscount = totalBeforeManualDiscount * (manualDiscountPercent / 100);
            
            // Final total calculation
            const finalTotal = subtotal - totalPwdDiscount - finalManualDiscount;

            // Create bill window for printing, using same layout as take-out receipt but marked as NOT FINAL INVOICE
            const billWindow = window.open('', '_blank', 'width=300,height=auto');
            
            billWindow.document.write(`
                <html>
                <head>
                    <title>Bill - Table ${table.number}</title>
                    <style>
                        @page {
                            size: 58mm auto;
                            margin: 3mm 2mm 3mm 2mm;
                        }
                        * { box-sizing: border-box; }
                        body { 
                            font-family: 'Courier New', monospace;
                            text-align: center;
                            padding: 0;
                            margin: 0;
                            background: white;
                            width: 50mm;
                            max-width: 50mm;
                            font-size: 9px;
                            overflow-wrap: break-word;
                            word-wrap: break-word;
                        }
                        .receipt-header {
                            text-align: center;
                            border-bottom: 1px dashed #000;
                            padding-bottom: 4px;
                            margin-bottom: 6px;
                            width: 100%;
                        }
                        .receipt-header h1 {
                            margin: 0;
                            font-size: 10px;
                            font-weight: bold;
                            margin-bottom: 3px;
                            line-height: 1.1;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-header p {
                            margin: 1px 0;
                            font-size: 8px;
                            line-height: 1.1;
                            word-wrap: break-word;
                            overflow-wrap: break-word;
                        }
                        .receipt-items {
                            margin: 6px 0;
                            width: 100%;
                        }
                        .receipt-items table {
                            width: 100%;
                            border-collapse: collapse;
                            font-size: 8px;
                            table-layout: fixed;
                        }
                        .receipt-items th {
                            border-bottom: 1px dashed #000;
                            padding: 2px 1px;
                            text-align: left;
                            font-size: 8px;
                            font-weight: bold;
                        }
                        .receipt-items th:nth-child(1) { width: 15%; }
                        .receipt-items th:nth-child(2) { width: 55%; }
                        .receipt-items th:nth-child(3) { width: 30%; text-align: right; }
                        .receipt-items td {
                            padding: 2px 1px;
                            line-height: 1.1;
                            font-size: 8px;
                        }
                        .receipt-items td:nth-child(1) { text-align: left; }
                        .receipt-items td:nth-child(2) { text-align: left; }
                        .receipt-items td:nth-child(3) { text-align: right; }
                        .receipt-totals {
                            border-top: 1px dashed #000;
                            margin-top: 6px;
                            padding-top: 4px;
                            font-size: 8px;
                            width: 100%;
                        }
                        .receipt-totals p {
                            margin: 2px 0;
                            line-height: 1.2;
                            display: block;
                            text-align: left;
                        }
                        .receipt-totals p .label {
                            display: inline-block;
                            text-align: left;
                            max-width: 60%;
                            vertical-align: top;
                        }
                        .receipt-totals p .value {
                            display: inline-block;
                            text-align: right;
                            float: right;
                            min-width: 40%;
                            vertical-align: top;
                        }
                        .receipt-totals p strong { font-weight: bold; }
                        .receipt-footer {
                            text-align: center;
                            margin-top: 6px;
                            padding-top: 4px;
                            border-top: 1px dashed #000;
                            font-size: 8px;
                            width: 100%;
                        }
                        .receipt-footer p {
                            margin: 2px 0;
                            line-height: 1.2;
                        }
                        .receipt-divider {
                            border-top: 1px dashed #000;
                            margin: 4px 0;
                        }
                        .receipt-date {
                            text-align: center;
                            font-size: 8px;
                            margin: 3px 0;
                            line-height: 1.2;
                        }
                        .order-type {
                            text-align: center;
                            font-size: 9px;
                            font-weight: bold;
                            margin: 4px 0;
                            text-transform: uppercase;
                            line-height: 1.2;
                        }
                    </style>
                </head>
                <body>
                    <div class="receipt-header">
                        <h1>EDGIE'S RESTAURANT AND EVENTS</h1>
                        <p>Pasolo Road, Pasolo 1440 Valenzuela City</p>
                        <p>Tel: 0917-000-0000</p>
                        <p>VAT Reg. TIN: 000-000-000-00000</p>
                        <div class="receipt-divider"></div>
                        <p style="font-weight: bold; color: #dc3545; font-size: 9px; margin: 4px 0;">*** NOT FINAL INVOICE ***</p>
                        <p>Table: ${table.number}</p>
                        <p class="receipt-date">${new Date().toLocaleString()}</p>
                    </div>
                    <div class="receipt-items">
                        <table>
                            <thead>
                                <tr>
                                    <th>Qty</th>
                                    <th>Item</th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody id="billItemsBody"></tbody>
                        </table>
                    </div>
                    <div class="receipt-totals">
                        <p><span class="label">Subtotal (VAT Inc):</span><span class="value">${formatNumber(subtotal).replace('₱ ', '')}</span></p>
                        ${totalVatAmount > 0 ? `<p><span class="label">VAT Amount (12%):</span><span class="value">${formatNumber(totalVatAmount).replace('₱ ', '')}</span></p>` : ''}
                        ${subtotalVatExempt > 0 ? `<p><span class="label">VAT Exempt Amount:</span><span class="value">${formatNumber(subtotalVatExempt).replace('₱ ', '')}</span></p>` : ''}
                        ${totalPwdDiscount > 0 ? `<p><span class="label">PWD/Senior Disc (20%):</span><span class="value">${formatNumber(totalPwdDiscount).replace('₱ ', '')}</span></p>` : ''}
                        ${finalManualDiscount > 0 ? `<p><span class="label">Manual Discount:</span><span class="value">${formatNumber(finalManualDiscount).replace('₱ ', '')}</span></p>` : ''}
                        <p><span class="label"><strong>TOTAL AMOUNT:</strong></span><span class="value"><strong>${formatNumber(finalTotal).replace('₱ ', '')}</strong></span></p>
                    </div>
                    <div class="receipt-footer">
                        <div class="receipt-divider"></div>
                        <p class="order-type">${table.orderType ? table.orderType.toUpperCase().replace('-', ' ') : 'DINE IN'}</p>
                    </div>
                </body>
                </html>
            `);
            
            const billItemsBody = billWindow.document.getElementById('billItemsBody');
            table.cart.forEach(item => {
                const itemSubtotal = item.price * item.quantity;
                billItemsBody.innerHTML += `
                    <tr>
                        <td>${item.quantity}</td>
                        <td>${item.name}</td>
                        <td>${formatNumber(itemSubtotal).replace('₱ ', '')}</td>
                    </tr>
                `;
            });
            billWindow.document.close();
            
            // Print the bill (try to open full screen similar to final receipts)
            billWindow.onload = function() {
                if (!billWindow) return;
                try {
                    billWindow.moveTo(0, 0);
                    billWindow.resizeTo(screen.availWidth || screen.width, screen.availHeight || screen.height);
                } catch (e) {}
                billWindow.focus();
                billWindow.print();
                setTimeout(() => {
                    billWindow.close();
                }, 1000);
            };
            
            // Show payment method selection after printing
            if (!table.showPaymentMethod) {
                table.showPaymentMethod = true;
                table.paymentMethod = table.paymentMethod || 'cash';
                saveTablesToStorage();
                
                // Re-render the entire table to hide the "Add" button and show payment method
                renderTable(tableId, table);
            }
        }

        function calculateTableChange(tableId) {
            const table = tables[tableId];
            if (!table) return;
            
            const cashInput = document.getElementById(tableId + '_cashInput');
            const changeElement = document.getElementById(tableId + '_change');
            
            if (!cashInput || !changeElement) return;
            
            const cash = parseFloat(cashInput.value) || 0;
            
            // Calculate total
            let subtotal = 0;
            table.cart.forEach(item => {
                subtotal += item.price * item.quantity;
            });
            const hasTransactionDiscount = table.hasDiscount || false;
            const totalDiscount = hasTransactionDiscount ? subtotal * 0.20 : 0;
            const total = subtotal - totalDiscount;
            
            const change = cash - total;
            changeElement.innerText = formatNumber(change >= 0 ? change : 0);
        }

        function checkoutMiniCart(tableId) {
            const table = tables[tableId];
            if (!table || !table.cart || table.cart.length === 0) {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: 'Empty Cart',
                        text: 'Please add items to the cart first.',
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    });
                }
                return;
            }

            // Calculate totals with VAT inclusive and item-level PWD discount
            let subtotal = 0;
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            
            table.cart.forEach(item => {
                // Initialize hasPwdDiscount if not set
                if (item.hasPwdDiscount === undefined) {
                    item.hasPwdDiscount = false;
                }
                
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                if (item.hasPwdDiscount) {
                    const itemPwdDiscount = itemSubtotal * 0.20;
                    totalPwdDiscount += itemPwdDiscount;
                } else {
                    // Extract VAT from VAT inclusive price
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                }
            });
            
            // Get manual discount from table (percentage), compute amount
            const manualDiscountPercent = Math.min(100, Math.max(0, table.manualDiscount || 0));
            const totalBeforeManualDiscount = subtotal - totalPwdDiscount;
            const finalManualDiscount = totalBeforeManualDiscount * (manualDiscountPercent / 100);
            
            // Final total calculation
            const total = subtotal - totalPwdDiscount - finalManualDiscount;

            // Get payment method and payment details from table
            const paymentMethod = table.paymentMethod || 'cash';
            let cash = 0;
            let referenceNo = '';
            
            if (paymentMethod === 'cash') {
                const cashInput = document.getElementById(tableId + '_cashInput');
                cash = parseFloat(cashInput ? cashInput.value : 0);
                
                if (total > 0 && (!cash || cash <= 0)) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Payment Required',
                            text: 'Please enter the cash amount.',
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
                
                if (total > 0 && cash < total) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Insufficient Amount',
                            text: 'Please enter an amount that is enough to cover the total.',
                            icon: 'error',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
            } else {
                // GCash or Maya
                const referenceNoInput = document.getElementById(tableId + '_referenceNoInput');
                referenceNo = referenceNoInput ? referenceNoInput.value.trim() : '';
                
                if (!referenceNo) {
                    if (typeof Swal !== 'undefined') {
                        Swal.fire({
                            title: 'Reference Number Required',
                            text: 'Please enter the reference number.',
                            icon: 'warning',
                            confirmButtonText: 'OK'
                        });
                    }
                    return;
                }
                // Validate reference number based on payment method
                if (paymentMethod === 'gcash') {
                    // GCash requires exactly 9 digits
                    if (!/^\d{9}$/.test(referenceNo)) {
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Invalid Reference Number',
                                text: 'GCash reference number must be exactly 9 digits.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        return;
                    }
                } else if (paymentMethod === 'paymaya') {
                    // Maya requires exactly 6 digits
                    if (!/^\d{6}$/.test(referenceNo)) {
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Invalid Reference Number',
                                text: 'Maya reference number must be exactly 6 digits.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                        return;
                    }
                }
                cash = total; // For cashless payments, cash equals total
            }
            
            // Process the checkout
            processMiniCartCheckout(tableId, cash, paymentMethod, referenceNo);
        }

        function processMiniCartCheckout(tableId, cash, paymentMethod = 'cash', referenceNo = '') {
            const table = tables[tableId];
            if (!table) return;

            // Get order type from table
            const tableOrderType = table.orderType || 'dine-in';

            // Use the main cart and checkout functionality
            // Temporarily set the main cart to this table's cart
            const originalCart = [...cart];
            cart = JSON.parse(JSON.stringify(table.cart)); // Deep copy
            
            // Set cash input
            const cashInput = document.getElementById('cashInput');
            if (cashInput) {
                cashInput.value = cash;
            }

            // Calculate totals with VAT inclusive and item-level PWD discount
            let subtotal = 0;
            let totalVatAmount = 0;
            let totalPwdDiscount = 0;
            
            cart.forEach(item => {
                // Initialize hasPwdDiscount if not set
                if (item.hasPwdDiscount === undefined) {
                    item.hasPwdDiscount = false;
                }
                
                const itemSubtotal = item.price * item.quantity;
                subtotal += itemSubtotal;
                
                if (item.hasPwdDiscount) {
                    const itemPwdDiscount = itemSubtotal * 0.20;
                    totalPwdDiscount += itemPwdDiscount;
                } else {
                    // Extract VAT from VAT inclusive price
                    const itemBasePrice = itemSubtotal / 1.12;
                    const itemVatAmount = itemSubtotal - itemBasePrice;
                    totalVatAmount += itemVatAmount;
                }
            });
            
            // Get manual discount (from table as percentage), compute amount
            const manualDiscountPercent = Math.min(100, Math.max(0, table.manualDiscount || 0));
            const totalBeforeManualDiscount = subtotal - totalPwdDiscount;
            const finalManualDiscount = totalBeforeManualDiscount * (manualDiscountPercent / 100);
            
            // Final total calculation
            const total = subtotal - totalPwdDiscount - finalManualDiscount;
            const change = cash - total;
            
            // Check if there are any PWD discounts
            const hasAnyPwdDiscount = cart.some(item => item.hasPwdDiscount);

            // Process order using existing functionality
            const cartData = JSON.stringify(cart);
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.status === 'success') {
                            // Clear table cart and reset payment method
                            table.cart = [];
                            table.showPaymentMethod = false;
                            table.paymentMethod = 'cash';
                            if (tableCartItemIdCounter[tableId]) {
                                tableCartItemIdCounter[tableId] = 0;
                            }
                            const cartElement = document.getElementById(tableId + '_cart');
                            if (cartElement) {
                                cartElement.innerHTML = renderMiniCart(tableId);
                            }

                            // Save to storage
                            saveTablesToStorage();

                            // Restore original cart
                            cart = originalCart;
                            updateCart();

                            // Open receipt window (sales invoice # and order type from server)
                            const receiptWindow = openReceiptWindow(
                                response.sales_invoice_no || response.transaction_num,
                                response.total_amount,
                                response.change,
                                response.cash,
                                response.cashier,
                                response.cart,
                                hasAnyPwdDiscount,
                                response.order_type || tableOrderType,
                                false,
                                response.payment_method || 'cash',
                                response.reference_no || null,
                                response.pwd_discount || '₱ 0.00',
                                response.manual_discount || '₱ 0.00',
                                response.vat_amount || '₱ 0.00'
                            );
                            
                            receiptWindow.onload = function() {
                                if (!receiptWindow) return;
                                try {
                                    receiptWindow.moveTo(0, 0);
                                    receiptWindow.resizeTo(screen.availWidth || screen.width, screen.availHeight || screen.height);
                                } catch (e) {}
                                receiptWindow.focus();
                                receiptWindow.print();
                                
                                if ('onafterprint' in receiptWindow) {
                                    receiptWindow.onafterprint = function() {
                                        receiptWindow.close();
                                    };
                                } else {
                                    setTimeout(() => {
                                        receiptWindow.close();
                                    }, 1000);
                                }
                            };

                            if (typeof Swal !== 'undefined') {
                                Swal.fire({
                                    title: 'Success!',
                                    text: `Table ${table.number} order confirmed!`,
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then(() => {
                                    // Automatically close the table after successful payment
                                    const tableElement = document.getElementById(tableId);
                                    if (tableElement) {
                                        tableElement.remove();
                                    }
                                    delete tables[tableId];
                                    delete tableCartItemIdCounter[tableId];
                                    saveTablesToStorage();
                                });
                            } else {
                                // If Swal is not available, close table immediately
                                const tableElement = document.getElementById(tableId);
                                if (tableElement) {
                                    tableElement.remove();
                                }
                                delete tables[tableId];
                                delete tableCartItemIdCounter[tableId];
                                saveTablesToStorage();
                            }
                        } else {
                            if (typeof Swal !== 'undefined') {
                                Swal.fire({
                                    title: 'Error',
                                    text: response.message || 'An error occurred while processing the order.',
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        console.error('Response text:', xhr.responseText);
                        if (typeof Swal !== 'undefined') {
                            Swal.fire({
                                title: 'Error',
                                text: 'An error occurred while processing the order. Please check the console for details.',
                                icon: 'error',
                                confirmButtonText: 'OK'
                            });
                        }
                    }
                }
            };
            const referenceNoParam = paymentMethod !== 'cash' ? `&reference_no=${encodeURIComponent(referenceNo)}` : '';
            xhr.send(`confirm_order=true&cart=${encodeURIComponent(cartData)}&cash=${cash}&manual_discount=${manualDiscountPercent}&order_type=${tableOrderType}&payment_method=${paymentMethod}${referenceNoParam}`);
        }
    </script>
<script src="js/prevent_back_button.js"></script>
</body>
</html>
