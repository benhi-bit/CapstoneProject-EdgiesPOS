<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    exit('Unauthorized');
}

require_once __DIR__ . '/../config/connection.php';

// Get parameters from POST request
// Default to a wide range so that initial load shows all transactions
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : '2000-01-01';
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-d');
$search = isset($_POST['search']) ? trim($_POST['search']) : '';
$sortColumn = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'transaction_date';
$sortDirection = isset($_POST['sort_direction']) ? $_POST['sort_direction'] : 'DESC';

// Ensure dates include time components for proper range comparison
// This ensures that when clicking "Today's Orders", all transactions for the entire day are included
$startDate = date('Y-m-d 00:00:00', strtotime($startDate));
$endDate = date('Y-m-d 23:59:59', strtotime($endDate));

// Build query - join with loginaccount to get cashier's full name
$transactionsQuery = "
    SELECT 
        t.transaction_num, 
        t.transaction_date, 
        t.total_amount,
        t.payment,
        t.change_amount,
        t.details,
        t.processed_by,
        la.FullName AS cashier_name
    FROM 
        transactions t
    LEFT JOIN loginaccount la ON la.Username = t.processed_by
    WHERE 
        t.transaction_date BETWEEN ? AND ?
";

if ($search !== '') {
    $transactionsQuery .= " AND transaction_num LIKE ? ";
}

$transactionsQuery .= " ORDER BY " . $sortColumn . " " . $sortDirection;

$transactionsStmt = $conn->prepare($transactionsQuery);

if ($search !== '') {
    $likeSearch = '%' . $search . '%';
    $transactionsStmt->bind_param("sss", $startDate, $endDate, $likeSearch);
} else {
    $transactionsStmt->bind_param("ss", $startDate, $endDate);
}

$transactionsStmt->execute();
$transactionsResult = $transactionsStmt->get_result();

if ($transactionsResult->num_rows > 0) {
    while ($transaction = $transactionsResult->fetch_assoc()) {
        $formattedDate = date('Y-m-d h:i A', strtotime($transaction['transaction_date']));
        $total = $transaction['total_amount'];
        $formattedTotal = '₱' . number_format($total, 2);
        $formattedPayment = '₱' . number_format($transaction['payment'], 2);
        $formattedChange = '₱' . number_format($transaction['change_amount'], 2);
        $detailsPayload = base64_encode($transaction['details']);
        $transactionNumber = str_pad($transaction['transaction_num'], 8, '0', STR_PAD_LEFT);
        $transactionDateIso = date('Y-m-d H:i:s', strtotime($transaction['transaction_date']));
        // Get cashier's full name if available, otherwise fall back to username
        $cashierName = !empty($transaction['cashier_name']) ? $transaction['cashier_name'] : ($transaction['processed_by'] ?: 'N/A');
        $safeCashier = htmlspecialchars($cashierName, ENT_QUOTES, 'UTF-8');
        ?>
        <tr>
            <td><?php echo $transactionNumber; ?></td>
            <td><?php echo $formattedDate; ?></td>
            <td><?php echo $formattedTotal; ?></td>
            <td><?php echo $formattedPayment; ?></td>
            <td><?php echo $formattedChange; ?></td>
            <td>
                <button onclick="showDetails('<?php echo htmlspecialchars($detailsPayload, ENT_QUOTES, 'UTF-8'); ?>', '<?php echo $transactionNumber; ?>', '<?php echo $transactionDateIso; ?>', '<?php echo htmlspecialchars($transaction['total_amount'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($transaction['payment'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($transaction['change_amount'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo $safeCashier; ?>')"><i class="fas fa-eye"></i> View Details</button>
                <button onclick="reprintReceipt('<?php echo $transactionNumber; ?>', '<?php echo htmlspecialchars($transaction['total_amount'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($transaction['payment'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($transaction['change_amount'], ENT_QUOTES, 'UTF-8'); ?>', '<?php echo htmlspecialchars($detailsPayload, ENT_QUOTES, 'UTF-8'); ?>', '<?php echo $safeCashier; ?>')"><i class="fas fa-print"></i> Reprint</button>
            </td>
        </tr>
        <?php
    }
} else {
    echo '<tr><td colspan="6">No transactions found for the selected criteria.</td></tr>';
}

$transactionsStmt->close();
$conn->close();
?> 