<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

require_once __DIR__ . '/../config/connection.php';

// Function to send SSE data
function sendSSEData($data) {
    echo "data: " . json_encode($data) . "\n\n";
    ob_flush();
    flush();
}

while (true) {
    // Get latest transaction count (total orders)
    $transactionQuery = $conn->query("SELECT COUNT(*) as count FROM transactions");
    $transactionCount = $transactionQuery->fetch_assoc()['count'];

    // Get latest category count
    $categoryQuery = $conn->query("SELECT COUNT(*) as count FROM categories");
    $categoryCount = $categoryQuery->fetch_assoc()['count'];

    // Get total sales (overall)
    $totalSalesQuery = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM transactions");
    $totalSales = $totalSalesQuery->fetch_assoc()['total'];

    // Get today's sales
    $todaySalesQuery = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM transactions WHERE DATE(transaction_date) = CURDATE()");
    $todaySales = $todaySalesQuery->fetch_assoc()['total'];

    // Get today's orders count
    $todayOrdersQuery = $conn->query("SELECT COUNT(*) as count FROM transactions WHERE DATE(transaction_date) = CURDATE()");
    $todayOrders = $todayOrdersQuery->fetch_assoc()['count'];

    // Get today's sold products
    $todaySoldQuery = $conn->query("
        SELECT 
            SUBSTRING_INDEX(SUBSTRING_INDEX(details, '(', 1), ',', -1) as product_name,
            SUM(CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(details, ')', 1), '(', -1) AS UNSIGNED)) as total_quantity,
            SUM(total_amount) as total_sales
        FROM transactions 
        WHERE DATE(transaction_date) = CURDATE()
        GROUP BY product_name
        HAVING total_quantity > 0
        ORDER BY total_quantity DESC
    ");

    $todaySoldProducts = [];
    while ($row = $todaySoldQuery->fetch_assoc()) {
        $todaySoldProducts[] = $row;
    }

    // Get sales data for the current month
    $startDate = date('Y-m-01');
    $endDate = date('Y-m-t');
    $salesDataQuery = $conn->query("
        WITH RECURSIVE dates AS (
            SELECT '$startDate' as date
            UNION ALL
            SELECT DATE_ADD(date, INTERVAL 1 DAY)
            FROM dates
            WHERE date < '$endDate'
        )
        SELECT 
            dates.date AS OrderDate,
            COALESCE(SUM(transactions.total_amount), 0) AS TotalSales
        FROM dates
        LEFT JOIN transactions ON DATE(transactions.transaction_date) = dates.date
        GROUP BY dates.date
        ORDER BY dates.date
    ");

    $salesData = [];
    while ($row = $salesDataQuery->fetch_assoc()) {
        $salesData[] = [
            'date' => $row['OrderDate'],
            'sales' => $row['TotalSales']
        ];
    }

    // Get monthly sales data for the current year
    $currentYear = date('Y');
    $monthlySalesQuery = $conn->query("
        SELECT 
            MONTH(transaction_date) as month,
            SUM(total_amount) as total_sales
        FROM transactions 
        WHERE YEAR(transaction_date) = $currentYear
        GROUP BY MONTH(transaction_date)
        ORDER BY month
    ");

    $monthlySales = array_fill(1, 12, 0); // Initialize all months with 0
    while ($row = $monthlySalesQuery->fetch_assoc()) {
        $monthlySales[$row['month']] = $row['total_sales'];
    }

    $data = [
        'transaction_count' => $transactionCount,
        'category_count' => $categoryCount,
        'total_sales' => $totalSales,
        'today_sales' => $todaySales,
        'today_orders' => $todayOrders,
        'today_sold_products' => $todaySoldProducts,
        'sales_data' => $salesData,
        'monthly_sales' => array_values($monthlySales)
    ];

    sendSSEData($data);

    // Sleep for a few seconds before next update
    sleep(2);
} 