<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('HTTP/1.1 403 Forbidden');
    exit('Unauthorized');
}

require_once __DIR__ . '/../config/connection.php';

$searchTerm = isset($_GET['search_term']) ? $_GET['search_term'] : '';
$categoryFilter = isset($_GET['category_filter']) ? $_GET['category_filter'] : '';
$sortColumn = isset($_GET['sort_column']) ? $_GET['sort_column'] : 'date_created';
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

$query = "SELECT i.InventoryID, i.InventoryName, i.Price, i.Quantity, c.CategoryName, i.CategoryID, i.ImagePath, i.date_created, i.is_available 
          FROM inventory i 
          JOIN categories c ON i.CategoryID = c.CategoryID";

$conditions = [];
$params = [];
$types = '';

if (!empty($searchTerm)) {
    $conditions[] = "(i.InventoryName LIKE ? OR i.InventoryID LIKE ?)";
    $searchParam = "%$searchTerm%";
    array_push($params, $searchParam, $searchParam);
    $types .= 'ss';
}

if (!empty($categoryFilter)) {
    $conditions[] = "i.CategoryID = ?";
    array_push($params, $categoryFilter);
    $types .= 'i';
}

if (!empty($conditions)) {
    $query .= " WHERE " . implode(' AND ', $conditions);
}

// Validate sort column to prevent SQL injection
$allowedColumns = ['InventoryID', 'InventoryName', 'Price', 'CategoryName', 'date_created', 'is_available'];
$sortColumn = in_array($sortColumn, $allowedColumns) ? $sortColumn : 'date_created';
$sortOrder = strtoupper($sortOrder) === 'ASC' ? 'ASC' : 'DESC';

// Add table alias for sorting
$sortColumnWithAlias = $sortColumn === 'CategoryName' ? 'c.' . $sortColumn : 'i.' . $sortColumn;
$query .= " ORDER BY " . $sortColumnWithAlias . " " . $sortOrder;

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $row['date_created'] = !empty($row['date_created']) ? date('Y-m-d h:i A', strtotime($row['date_created'])) : 'N/A';
    $products[] = $row;
}

header('Content-Type: application/json');
echo json_encode($products);

$stmt->close();
$conn->close();
?>