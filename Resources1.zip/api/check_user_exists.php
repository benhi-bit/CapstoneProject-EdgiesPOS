<?php
session_start();
require_once __DIR__ . '/../config/connection.php';

// Set header to return JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['Username'])) {
    echo json_encode(['exists' => false]);
    exit();
}

// Prepare and execute query to check if user exists
$stmt = $conn->prepare("SELECT UserID FROM loginaccount WHERE Username = ?");
$stmt->bind_param("s", $_SESSION['Username']);
$stmt->execute();
$result = $stmt->get_result();

// Return whether user exists or not
echo json_encode(['exists' => ($result->num_rows > 0)]);

$stmt->close();
$conn->close();
?> 