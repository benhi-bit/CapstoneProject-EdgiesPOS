<?php
session_start();
require_once __DIR__ . '/../config/connection.php';

header('Content-Type: application/json');

// Get the last check timestamp from session or set to current time if not exists
$lastCheck = isset($_SESSION['last_log_check']) ? $_SESSION['last_log_check'] : date('Y-m-d H:i:s');

// Update the last check timestamp
$_SESSION['last_log_check'] = date('Y-m-d H:i:s');

// Query for new logs since last check with correct column names
$stmt = $conn->prepare("
    SELECT 
        action_type as action,
        description,
        user_fullname as user,
        log_timestamp as timestamp
    FROM system_logs 
    WHERE log_timestamp > ? 
    ORDER BY log_timestamp DESC 
    LIMIT 10
");
$stmt->bind_param("s", $lastCheck);
$stmt->execute();
$result = $stmt->get_result();

$newLogs = array();
while ($row = $result->fetch_assoc()) {
    $newLogs[] = array(
        'action' => $row['action'],
        'description' => $row['description'],
        'user' => $row['user'],
        'timestamp' => $row['timestamp']
    );
}

echo json_encode(array(
    'success' => true,
    'logs' => $newLogs
));

$stmt->close();
$conn->close();
?> 