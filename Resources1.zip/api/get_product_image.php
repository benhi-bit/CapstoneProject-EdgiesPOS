<?php
require_once __DIR__ . '/../config/connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    $stmt = $conn->prepare("SELECT ImagePath FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    // Fix image path for admin directory: prepend '../' if needed
    $imagePath = $row['ImagePath'];
    if (!empty($imagePath) && strpos($imagePath, '../') !== 0) {
        $imagePath = '../' . $imagePath;
    }
    
    header('Content-Type: application/json');
    echo json_encode(['imagePath' => $imagePath]);
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No product ID provided']);
}
?> 