<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['Username']) || ($_SESSION['Role'] ?? '') !== 'Admin') {
    echo json_encode(['next_run_at' => null, 'last_run_at' => null, 'is_due' => false]);
    exit();
}

$schedulePath = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'backup_schedule.json';
$out = ['next_run_at' => null, 'last_run_at' => null, 'last_status' => null, 'is_due' => false];

if (is_file($schedulePath)) {
    $schedule = json_decode(@file_get_contents($schedulePath), true);
    if (is_array($schedule) && !empty($schedule['run_at'])) {
        $out['next_run_at'] = $schedule['run_at'];
        $out['last_run_at'] = $schedule['last_run_at'] ?? null;
        $out['last_status'] = $schedule['last_status'] ?? null;
        $runAt = DateTime::createFromFormat('Y-m-d\TH:i', $schedule['run_at']);
        if ($runAt) {
            $now = new DateTime('now');
            $lastRunAt = null;
            if (!empty($schedule['last_run_at'])) {
                $lastRunAt = DateTime::createFromFormat('Y-m-d\TH:i', (string)$schedule['last_run_at']);
            }
            $out['is_due'] = ($now >= $runAt && (!$lastRunAt || $lastRunAt < $runAt));
        }
    }
}

echo json_encode($out);
