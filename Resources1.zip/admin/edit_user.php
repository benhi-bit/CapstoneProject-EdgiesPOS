<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include the database connection
require_once __DIR__ . '/../lib/log_helper.php'; // Include logging functionality

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'] ?? 'Administrator';

// Set header to return JSON
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = $_POST['userID'];
    $role = 'Cashier';
    $fullName = trim($_POST['fullName'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $newPassword = isset($_POST['password']) ? trim($_POST['password']) : '';
    $confirmPassword = isset($_POST['confirmPassword']) ? trim($_POST['confirmPassword']) : '';

    // Validate full name
    if (!preg_match('/^[A-Za-zÀ-ž\s.\'\-]{2,50}$/', $fullName)) {
        echo json_encode(['success' => false, 'message' => 'Full name must be 2–50 characters (letters, spaces, and basic punctuation only).']);
        exit();
    }

    // Validate username
    if (!preg_match('/^[A-Za-z0-9_]{4,20}$/', $username)) {
        echo json_encode(['success' => false, 'message' => 'Username must be 4–20 characters (letters, numbers, and underscore only).']);
        exit();
    }

    // Validate email
    if (!empty($email) && !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
        echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
        exit();
    }

    // Get old user details for logging
    $oldUserStmt = $conn->prepare("SELECT Username, FullName, Email FROM loginaccount WHERE UserID = ?");
    $oldUserStmt->bind_param("i", $userId);
    $oldUserStmt->execute();
    $oldUser = $oldUserStmt->get_result()->fetch_assoc();
    $oldUserStmt->close();
    
    // Check if user exists
    if (!$oldUser) {
        echo json_encode([
            'success' => false,
            'message' => 'User not found.'
        ]);
        exit();
    }

    // Check if username already exists (excluding current user)
    $checkStmt = $conn->prepare("SELECT Username FROM loginaccount WHERE Username = ? AND UserID != ?");
    $checkStmt->bind_param("si", $username, $userId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Username already exists. Please choose a different username.'
        ]);
        exit();
    }
    $checkStmt->close();

    // Check if email already exists (excluding current user)
    $emailCheckStmt = $conn->prepare("SELECT Email FROM loginaccount WHERE Email = ? AND UserID != ?");
    $emailCheckStmt->bind_param("si", $email, $userId);
    $emailCheckStmt->execute();
    $emailResult = $emailCheckStmt->get_result();

    if ($emailResult->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Email already exists. Please use a different email address.'
        ]);
        exit();
    }
    $emailCheckStmt->close();

    // If a new password is provided, validate and include it in the update
    $updateWithPassword = false;
    if ($newPassword !== '' || $confirmPassword !== '') {
        if ($newPassword === '' || $confirmPassword === '') {
            echo json_encode([
                'success' => false,
                'message' => 'Please enter and confirm the new password.'
            ]);
            exit();
        }

        // Basic server-side policy: at least 6 chars, 1 uppercase, 1 number
        $pattern = '/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/';
        if (!preg_match($pattern, $newPassword)) {
            echo json_encode([
                'success' => false,
                'message' => 'Password must be at least 6 characters long and contain at least one uppercase letter and one number.'
            ]);
            exit();
        }

        if ($newPassword !== $confirmPassword) {
            echo json_encode([
                'success' => false,
                'message' => 'Passwords do not match. Please re-enter.'
            ]);
            exit();
        }

        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateWithPassword = true;
    }

    // Prepare and bind
    if ($updateWithPassword) {
        $stmt = $conn->prepare("UPDATE loginaccount SET Role = ?, FullName = ?, Username = ?, Email = ?, Password = ? WHERE UserID = ?");
        $stmt->bind_param("sssssi", $role, $fullName, $username, $email, $hashedPassword, $userId);
    } else {
        $stmt = $conn->prepare("UPDATE loginaccount SET Role = ?, FullName = ?, Username = ?, Email = ? WHERE UserID = ?");
        $stmt->bind_param("ssssi", $role, $fullName, $username, $email, $userId);
    }

    if ($stmt->execute()) {
        // Log the changes
        $changes = [];
        if ($oldUser['Username'] !== $username) $changes[] = "username updated";
        if ($oldUser['FullName'] !== $fullName) $changes[] = "full name updated";
        if ($oldUser['Email'] !== $email) $changes[] = "email updated";

        if ($updateWithPassword) {
            $changes[] = "password changed";
        }

        if (!empty($changes)) {
            $description = "User account updated (" . implode(", ", $changes) . "): " . $oldUser['Username'];
            addSystemLog($conn, "User Updated", $description, $userFullName);
        }

        echo json_encode([
            'success' => true,
            'message' => 'User updated successfully!'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Error updating user: ' . $stmt->error
        ]);
    }

    $stmt->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method'
    ]);
}

$conn->close();
?> 