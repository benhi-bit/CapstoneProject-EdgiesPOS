<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Cashier') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Get the order ID from the URL
$orderId = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

// Fetch order details
$orderQuery = "SELECT o.OrderID, o.Username, o.Total, o.Cash, o.T_Change, o.OrderDate, oi.ProductName, oi.Quantity, oi.Price 
               FROM orders o 
               JOIN order_items oi ON o.OrderID = oi.OrderID 
               WHERE o.OrderID = ?";
$orderStmt = $conn->prepare($orderQuery);
$orderStmt->bind_param("i", $orderId);
$orderStmt->execute();
$orderResult = $orderStmt->get_result();
$orderDetails = $orderResult->fetch_all(MYSQLI_ASSOC);
$orderStmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }
        header {
            background: #333;
            color: white;
            padding: 15px;
            text-align: center;
        }
        main {
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #face0b;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .button {
            padding: 10px 15px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .button:hover {
            background-color: #face0b;
        }
    </style>
</head>
<body>
<header>
    <h1>Order Details</h1>
</header>
<main>
    <h2>Order ID: <?php echo $orderId; ?></h2>
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($orderDetails): ?>
                <?php foreach ($orderDetails as $detail): ?>
                    <tr>
                        <td><?php echo $detail['ProductName']; ?></td>
                        <td><?php echo $detail['Quantity']; ?></td>
                        <td>₱ <?php echo number_format($detail['Price'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No details found for this order.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <a href="sales_report.php" class="button">Back to Sales Report</a>
</main>
</body>
</html>

<?php
$conn->close();
?>