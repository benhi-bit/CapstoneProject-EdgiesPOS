<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

$runAt = $_POST['run_at'] ?? '';
$runAt = trim($runAt);

// Expect a local datetime like "2026-01-21T10:00" from <input type="datetime-local">
if ($runAt === '') {
    echo json_encode(['success' => false, 'message' => 'Please select a date and time']);
    exit();
}

// Basic validation
if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $runAt)) {
    echo json_encode(['success' => false, 'message' => 'Invalid date/time format']);
    exit();
}

// Parse and ensure it's a valid datetime
$dt = DateTime::createFromFormat('Y-m-d\TH:i', $runAt);
if (!$dt) {
    echo json_encode(['success' => false, 'message' => 'Invalid date/time']);
    exit();
}

// Store the chosen run time as-is (if it's in the past, backup will run on next poll)
// Persist in config JSON
$configPath = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'backup_schedule.json';
$payload = ['run_at' => $dt->format('Y-m-d\TH:i')];

$ok = file_put_contents($configPath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
if ($ok === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to save schedule']);
    exit();
}

// Derive weekday + time for Task Scheduler (weekly)
$weekday = strtoupper($dt->format('D')); // MON, TUE, ...
$time = $dt->format('H:i');

echo json_encode([
    'success' => true,
    'message' => 'Automatic backup schedule updated.',
    'run_at' => $payload['run_at'],
    'task_scheduler' => [
        'weekday' => $weekday,
        'time' => $time
    ]
]);

