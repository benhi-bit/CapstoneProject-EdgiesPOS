<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php'; // Include your database connection
require_once __DIR__ . '/../lib/ensure_transactions_table.php';
ensureTransactionsTable($conn);
require_once __DIR__ . '/../lib/log_helper.php'; // Include logging functionality

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');

// Initialize date range variables (check both GET and POST)
// Default to showing all entries (no date filter)
$startDateInput = isset($_POST['start_date'])
    ? $_POST['start_date']
    : (isset($_GET['start_date']) ? $_GET['start_date'] : '');

$endDateInput = isset($_POST['end_date'])
    ? $_POST['end_date']
    : (isset($_GET['end_date']) ? $_GET['end_date'] : '');

// Store the original date values for display in the form inputs
$startDateDisplay = $startDateInput;
$endDateDisplay = $endDateInput;

// If dates are provided, format them; otherwise set to null for "all entries"
if ($startDateInput && $endDateInput) {
    // Ensure dates include time components for proper range comparison
    $startDate = date('Y-m-d 00:00:00', strtotime($startDateInput));
    $endDate = date('Y-m-d 23:59:59', strtotime($endDateInput));
    $useDateFilter = true;
} else {
    // Show all entries - no date filter
    $startDate = null;
    $endDate = null;
    $useDateFilter = false;
}

// Initialize search variable
$search = isset($_POST['search']) ? trim($_POST['search']) : '';

// Initialize sort variables
$sortColumnInput = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'transaction_date';
$sortDirection = isset($_POST['sort_direction']) ? $_POST['sort_direction'] : 'DESC';

// Build base query
$transactionsQuery = "
    SELECT 
        t.transaction_num, 
        t.transaction_date, 
        t.total_amount,
        t.payment,
        t.change_amount,
        t.details,
        t.processed_by,
        t.payment_method,
        t.reference_no,
        la.FullName AS cashier_name
    FROM 
        transactions t
    LEFT JOIN loginaccount la ON la.Username = t.processed_by
    WHERE 1=1
";

// Add date filter only if dates are provided
if ($useDateFilter) {
    $transactionsQuery .= " AND t.transaction_date BETWEEN ? AND ? ";
}

if ($search !== '') {
    $transactionsQuery .= " AND t.transaction_num LIKE ? ";
}

$allowedSortColumns = [
    'transaction_num' => 't.transaction_num',
    'transaction_date' => 't.transaction_date',
    'total_amount' => 't.total_amount',
    'payment' => 't.payment',
    'change_amount' => 't.change_amount',
];
$sortColumn = isset($allowedSortColumns[$sortColumnInput]) ? $allowedSortColumns[$sortColumnInput] : 't.transaction_date';

// Add sorting to the query
$transactionsQuery .= " ORDER BY " . $sortColumn . " " . $sortDirection;

$transactionsStmt = $conn->prepare($transactionsQuery);

// Bind parameters based on whether date filter and search are used
if ($useDateFilter && $search !== '') {
    $likeSearch = '%' . $search . '%';
    $transactionsStmt->bind_param("sss", $startDate, $endDate, $likeSearch);
} else if ($useDateFilter) {
    $transactionsStmt->bind_param("ss", $startDate, $endDate);
} else if ($search !== '') {
    $likeSearch = '%' . $search . '%';
    $transactionsStmt->bind_param("s", $likeSearch);
}
// If neither date filter nor search, no parameters needed - show all entries

if (!$transactionsStmt->execute()) {
    die("Failed to execute query: " . $transactionsStmt->error);
}
$transactionsResult = $transactionsStmt->get_result();
$totalTransactions = $transactionsResult ? $transactionsResult->num_rows : 0;
$transactionsStmt->close();

$productPrices = [];
$productPriceQuery = "SELECT InventoryName, Price FROM inventory";
if ($productPriceResult = $conn->query($productPriceQuery)) {
    while ($priceRow = $productPriceResult->fetch_assoc()) {
        $nameKey = strtolower(trim($priceRow['InventoryName']));
        if ($nameKey !== '') {
            $productPrices[$nameKey] = (float)$priceRow['Price'];
        }
    }
    $productPriceResult->free();
}

// Handle reprint logging
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log_reprint'])) {
    $transactionNum = $_POST['transaction_num'];
    $description = sprintf(
        "Receipt reprinted for Transaction #%s",
        $transactionNum
    );
    addSystemLog($conn, "Receipt Reprint", $description, $userFullName);
    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Transaction History</title>
  <link rel="stylesheet" href="../assets/css/transaction.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    html, body {
        margin: 0;
        padding: 0;
    }
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
html, body {
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    background-color: #f5f5f5;
    color: #1e293b;
}
/* Sidebar Styles */
nav.sidebar {
    width: 70px;
    background-color: #333;
    height: 100vh;
    position: fixed;
    top: 0 !important;
    left: 0;
    overflow-x: hidden;
    overflow-y: auto;
    z-index: 999;
    display: flex;
    flex-direction: column;
    transition: width 0.3s ease;
    margin-top: 0 !important;
    padding-top: 0 !important;
}

/* Disable transitions on page load */
nav.sidebar.no-transition,
nav.sidebar.no-transition * {
    transition: none !important;
}

nav.sidebar.sidebar-expanded {
    width: 200px;
}

/* Navigation items container - scrollable */
.sidebar-nav-items {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding-top: 20px;
    padding-bottom: 10px;
    min-height: 0; /* Important for flex scrolling */
    margin-top: 0;
    padding-left: 0;
    padding-right: 0;
}

nav.sidebar.sidebar-expanded .sidebar-nav-items {
    overflow-y: auto;
}

/* Custom scrollbar styling */
.sidebar-nav-items::-webkit-scrollbar {
    width: 6px;
}

.sidebar-nav-items::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.2);
}

.sidebar-nav-items::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 3px;
}

.sidebar-nav-items::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.5);
}

.sidebar-logo {
    padding: 20px;
    text-align: center;
    flex-shrink: 0; /* Prevent logo from shrinking */
    margin-bottom: 0;
    cursor: pointer;
}

.sidebar-logo img {
    max-width: 100%;
    height: auto;
    max-height: 40px;
    object-fit: contain;
    margin-bottom: 5px;
    transition: max-height 0.3s ease, margin-bottom 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-logo img {
    max-height: 80px;
    margin-bottom: 10px;
}

.sidebar-logo .restaurant-name {
    color: white;
    font-size: 14px;
    font-weight: 600;
    line-height: 1.4;
    margin-top: 10px;
    transition: all 0.3s ease;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    text-align: center;
}

nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
    opacity: 1;
    max-height: 100px;
}

/* Sidebar Footer - Cashier Info at Bottom */
.sidebar-footer {
    flex-shrink: 0; /* Prevent footer from shrinking */
    padding: 20px 15px;
    background-color: rgba(0, 0, 0, 0.3);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    text-align: center;
    margin-top: auto; /* Push to bottom */
    transition: all 0.3s ease;
}

.sidebar-footer .cashier-name {
    color: white;
    font-size: 16px;
    font-weight: 500;
    line-height: 1.4;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.sidebar-footer .cashier-name i {
    font-size: 14px;
}

.sidebar-footer .cashier-name span {
    opacity: 0;
    width: 0;
    overflow: hidden;
    transition: all 0.3s ease;
    display: inline-block;
}

nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
    opacity: 1;
    width: auto;
}

.sidebar-footer .sidebar-datetime {
    color: white;
    font-size: 14px;
    line-height: 1.6;
    text-align: center;
    transition: all 0.3s ease;
}

.sidebar-footer .sidebar-datetime #sidebar-date {
    font-weight: 500;
    margin-bottom: 5px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
    opacity: 1;
    max-height: 30px;
}

.sidebar-footer .sidebar-datetime #sidebar-time {
    font-weight: 600;
    color: #face0b;
    font-size: 16px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
    opacity: 1;
    max-height: 30px;
}

nav.sidebar a {
    color: white;
    padding: 14px 0;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    text-align: left;
    padding-left: 20px;
}

nav.sidebar.sidebar-expanded a {
    padding: 14px 20px;
    text-align: left;
    justify-content: flex-start;
}

nav.sidebar a:hover {
    background-color: #ddd;
    color: black;
}

nav.sidebar a.active {
    background-color: #face0b;
    color: black;
}

nav.sidebar a i {
    margin-right: 0;
    width: 20px;
    text-align: center;
    display: inline-block;
}

nav.sidebar.sidebar-expanded a i {
    margin-right: 10px;
}

nav.sidebar a span {
    transition: all 0.3s ease;
    opacity: 0;
    width: 0;
    overflow: hidden;
    display: inline-block;
}

nav.sidebar.sidebar-expanded a span {
    opacity: 1;
    width: auto;
    white-space: normal;
    word-wrap: break-word;
    overflow-wrap: break-word;
    line-height: 1.3;
    max-width: 140px;
    display: inline-block;
}

/* Allow specific long navigation items to wrap to 2 lines */
nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
nav.sidebar.sidebar-expanded a[href*="user_management"] span {
    max-width: 130px;
}

/* Main Content Area */
main {
    margin-left: 90px;
    margin-top: 0;
    padding: 20px;
    flex-grow: 1;
    transition: margin-left 0.3s ease, width 0.3s ease;
    width: calc(100% - 90px);
    box-sizing: border-box;
    position: relative;
    overflow-x: hidden;
}

/* Disable main content transitions on page load */
nav.sidebar.no-transition ~ main {
    transition: none !important;
}

nav.sidebar.sidebar-expanded ~ main {
    margin-left: 220px;
    width: calc(100% - 220px);
}
/* Table styles - using manage_product.php style */
/* Modal styles */
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    align-items: center;
    justify-content: center;
    transition: opacity 0.3s ease;
    opacity: 0;
    pointer-events: none;
}

.modal.show {
    display: flex;
    opacity: 1;
    pointer-events: auto;
    animation: modalFadeIn 0.3s;
}

@keyframes modalFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.modal-content {
    background-color: white;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    border-radius: 15px;
    position: relative;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
    transition: transform 0.2s, box-shadow 0.2s;
}

.modal-content.modal-modern {
  padding: 0;
  border: none;
  overflow: hidden;
  background: #f5f5f5;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
  max-width: 720px;
}

.modal-header {
  background: #333;
  color: #fff;
  padding: 28px 32px;
  display: flex;
  align-items: center;
  gap: 18px;
  position: relative;
}

.modal-header .modal-icon {
  width: 54px;
  height: 54px;
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.14);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.modal-header h2 {
  margin: 0;
  font-size: 26px;
  color: #fff;
}

.modal-header p {
  margin: 4px 0 0;
  color: rgba(255, 255, 255, 0.88);
  font-size: 14px;
  line-height: 1.5;
}

.modal-body {
  padding: 30px;
  display: flex;
  flex-direction: column;
  gap: 24px;
  max-height: calc(90vh - 160px);
  overflow-y: auto;
}

.modal-body::-webkit-scrollbar {
  width: 8px;
}

.modal-body::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.05);
  border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb {
  background: rgba(51, 51, 51, 0.3);
  border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb:hover {
  background: rgba(51, 51, 51, 0.5);
}

.section-card {
  background: #fff;
  border-radius: 18px;
  padding: 20px 22px 24px;
  border: 1px solid rgba(15, 23, 42, 0.08);
  box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
}

.section-header {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 18px;
}

.section-header .section-icon {
  width: 40px;
  height: 40px;
  border-radius: 12px;
  background: rgba(250, 206, 11, 0.2);
  color: #b58500;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
}

.section-header h3 {
  margin: 0;
  font-size: 18px;
  color: #0f172a;
}

.section-header p {
  display: none;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  padding: 20px 30px;
  border-top: 1px solid rgba(0, 0, 0, 0.1);
  background: #fff;
}

.modal-actions .btn-secondary,
.modal-actions .btn-primary {
  padding: 8px 16px;
  border-radius: 999px;
  font-weight: 600;
  font-size: 13px;
  border: none;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  margin: 0 4px;
}

.modal-actions .btn-secondary {
  background: rgba(0, 0, 0, 0.1);
  color: #333;
}

.modal-actions .btn-secondary:hover {
  background: rgba(0, 0, 0, 0.2);
  transform: translateY(-1px);
}

.modal-actions .btn-primary {
  background: linear-gradient(135deg, #face0b, #f7b300);
  color: #000;
  box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

.modal-actions .btn-primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

/* Modal form elements */
.modal-content.modal-modern .form-group {
  margin-bottom: 20px;
}

.modal-content.modal-modern .form-group label {
  font-size: 13px;
  letter-spacing: 0.3px;
  color: #1e293b;
  text-transform: uppercase;
  font-weight: 600;
  margin-bottom: 8px;
  display: block;
}

.modal-content.modal-modern .form-group label i {
  font-size: 14px;
  color: #64748b;
}

.modal-content.modal-modern .input-with-icon {
  position: relative;
  display: flex;
  align-items: center;
}

.modal-content.modal-modern .input-with-icon i {
  position: absolute;
  left: 14px;
  color: #64748b;
  font-size: 14px;
  z-index: 1;
  pointer-events: none;
}

.modal-content.modal-modern .input-with-icon input[type="date"],
.modal-content.modal-modern .input-with-icon input[type="text"],
.modal-content.modal-modern .input-with-icon input[type="number"],
.modal-content.modal-modern .input-with-icon select {
  width: 100%;
  border-radius: 10px;
  border: 2px solid #e2e8f0;
  padding: 14px 16px 14px 40px;
  transition: border 0.2s ease, box-shadow 0.2s ease;
  background: white;
  color: #1e293b;
  font-size: 15px;
  box-sizing: border-box;
}

.modal-content.modal-modern .input-with-icon input[type="date"]::-webkit-calendar-picker-indicator {
  cursor: pointer;
  opacity: 0;
  position: absolute;
  right: 0;
  width: 100%;
  height: 100%;
}

.modal-content.modal-modern .input-with-icon input[type="date"] {
  position: relative;
}

.modal-content.modal-modern .input-with-icon input:focus,
.modal-content.modal-modern .input-with-icon select:focus {
  border-color: #face0b;
  box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25);
  outline: none;
}

/* Action buttons in table - Matching manage_product.php style */
#transactionsTable button[onclick^="showDetails"],
#transactionsTable button.action-btn.view-btn {
    background: linear-gradient(135deg, #6b7280, #4b5563);
    color: #fff;
    padding: 8px 16px;
    margin: 0 4px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    box-shadow: 0 8px 18px rgba(107, 114, 128, 0.35);
}

#transactionsTable button[onclick^="showDetails"]:hover,
#transactionsTable button.action-btn.view-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(107, 114, 128, 0.45);
}

#transactionsTable button[onclick^="reprintReceipt"],
#transactionsTable button.action-btn.print-btn {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    padding: 8px 16px;
    margin: 0 4px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

#transactionsTable button[onclick^="reprintReceipt"]:hover,
#transactionsTable button.action-btn.print-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

#transactionsTable button i {
    font-size: 14px;
    color: inherit;
}

.receipt-modal-body .transaction-info {
  color: #333;
  font-size: 14px;
  line-height: 1.8;
}

.receipt-modal-body .transaction-info p {
  margin: 10px 0;
  color: #333;
}

.receipt-modal-body .transaction-info strong {
  color: #333;
  font-weight: 600;
}

.receipt-modal-body .transaction-info span {
  color: #333;
  font-weight: 500;
}

.receipt-modal-body .order-items table {
  width: 100%;
  border-collapse: collapse;
  margin: 10px 0 0;
}

.receipt-modal-body .order-items th,
.receipt-modal-body .order-items td {
  padding: 12px;
  text-align: left;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  font-size: 14px;
}

.receipt-modal-body .order-items th {
  background-color: #f8f9fa;
  font-weight: 600;
  color: #333;
  text-transform: uppercase;
  font-size: 12px;
  letter-spacing: 0.5px;
}

.receipt-modal-body .order-items td {
  color: #333;
}

.receipt-modal-body .order-items tbody tr:last-child td {
  border-bottom: none;
}

.order-summary-card .order-summary {
  text-align: right;
}

.order-summary-card .order-summary p {
  margin: 8px 0;
  font-size: 14px;
  color: #333;
}

.order-summary-card .order-summary strong {
  color: #333;
  font-weight: 600;
}

.order-summary-card .order-summary span {
  color: #333;
  font-weight: 500;
  margin-left: 8px;
}
@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateY(-50px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

.close {
    color: #fff;
    font-size: 28px;
    font-weight: bold;
    position: absolute;
    top: 20px;
    right: 24px;
    cursor: pointer;
    transition: color 0.3s;
    z-index: 10;
    background: none;
    border: none;
    padding: 0;
    line-height: 1;
}

.close:hover,
.close:focus {
    color: rgba(255, 255, 255, 0.7);
}

/* Modal Input and Form Elements */
.modal-content input[type="text"],
.modal-content input[type="number"],
.modal-content select {
    width: 95%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 15px;
    border: 1px solid #ccc;
    font-size: 16px;
}

.modal-content button[type="submit"] {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #333;
    color: white;
    border: none;
    border-radius: 15px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.modal-content button[type="submit"]:hover {
    background-color: #555;
}

/* Responsive design for smaller screens */
@media screen and (max-width: 768px) {
    main {
        margin-left: 0;
        width: 100%;
    }
    
    
    nav.sidebar {
        display: none;
    }

    .table-container {
        max-height: calc(100vh - 200px);
        overflow-x: auto;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
    }

    #transactionsTable {
        min-width: 800px;
    }

    #transactionsTable th,
    #transactionsTable td {
        padding: 12px 10px;
        font-size: 13px;
    }

    #transactionsTable th {
        font-size: 12px;
        padding: 10px 8px;
    }

    .modal-content {
        width: 80%; /* Adjust modal width for smaller screens */
    }

    .modal-content input[type="text"],
    .modal-content input[type="number"],
    .modal-content select {
        font-size: 14px; /* Adjust input size for smaller screens */
    }

    .modal-content button[type="submit"] {
        font-size: 14px; /* Adjust button size for smaller screens */
    }

    /* Search bar mobile styles */
    .transactions-filter-form {
        flex-direction: column;
        align-items: stretch;
        gap: 8px;
    }

    .search-container {
        width: 100%;
    }

    .search-container .input-with-icon {
        width: 100%;
    }

    .date-range-group {
        min-width: auto;
        width: 100%;
    }
}


/* Buttons */
button {
    padding: 10px 20px;
    font-size: 14px;
    cursor: pointer;
    background-color: #face0b;
    color: black;
    border: none;
    border-radius: 15px;
    transition: background-color 0.3s ease;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}

button:hover {
    background-color: #f7b300;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(250, 206, 11, 0.4);
}

/* Add product button (moved to the right) */
#addProductButton {
    background-color: #333;
    margin-bottom: 20px;
    color:white;
    float: right; /* Move to the right */
}

/* Delete button specific styles (red color) */
button[type="submit"][name="delete_product"] {
    background-color: red; /* Red background for delete button */
    color: white; /* White text color */
}

button[type="submit"][name="delete_product"]:hover {
    background-color: darkred; /* Darker red when hovered */
}

/* Background color classes for quantity */
.red-background {
    background-color: #FF7276;
    color: black;
}

.orange-background {
    background-color: #90ee90;
}

.yellow-background {
    background-color: #ffff64;
}

/* Responsive design for smaller screens */
@media screen and (max-width: 768px) {
    nav.sidebar {
        width: 100%;
        position: relative;
    }

    main {
        margin-left: 0;
    }

    table th, table td {
        padding: 8px;
    }

    .modal-content {
        width: 80%;
    }
}

.date-selector {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.date-selector label {
    white-space: nowrap;
    margin: 0;
}

.date-selector input[type="date"] {
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 15px;
    font-size: 14px;
}
.user-profile {
    display: flex;
    align-items: center;
    color: white;
    font-size: 1.1em;
    font-weight: bold;
    margin-right: 5%;
}

.user-profile .fullname {
    color: #face0b;
}

/* Add styles for the sort indicators (up/down arrows) */
th {
    cursor: pointer;
    position: relative;
    padding-right: 20px; /* Make space for the arrow */
}
.sort-indicator {
    position: absolute;
    right: 5px;
}
.asc::after {
    content: '\2191'; /* Up arrow */
}
.desc::after {
    content: '\2193'; /* Down arrow */
}
.sorted::after {
    content: '\2195'; /* Toggle indicator */
}
.date-selector input[type="date"] {
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 15px;
    font-size: 14px;
    width: auto;
}

.date-selector select {
    padding: 10px;
    border-radius: 25px;
    border: 1px solid #ccc;
    background-color: white;
    font-size: 14px;
}

.date-selector .button {
    padding: 10px 15px; /* Padding for the button */
    background-color: #333; /* Button background color */
    color: white; /* Button text color */
    border: none; /* Remove border */
    border-radius: 25px; /* Increased border-radius for rounder corners */
    cursor: pointer; /* Pointer cursor on hover */
    font-size: 16px; /* Font size */
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

.date-selector .button:hover {
    background-color: #555; /* Darker shade on hover */
}

        


        .receipt {
            font-family: Arial, sans-serif;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 15px;
            width: 100%;
            max-width: 500px;
            margin: auto;
        }
        .receipt h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .receipt p {
            margin: 5px 0;
        }
        .receipt .total {
            font-weight: bold;
            font-size: 18px;
            margin-top: 10px;
        }

    #searchForm button {
      padding: 10px 20px;
      background-color: #333;
      color: white;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      font-size: 16px;
      transition: background-color 0.3s ease;
    }

    #searchForm button:hover {
      background-color: #555;
    }

    .receipt-header {
      text-align: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 1px solid #ddd;
    }

    .receipt-content {
      padding: 20px;
    }

    .transaction-info {
      margin-bottom: 20px;
    }

    .transaction-info p {
      margin: 5px 0;
    }

    .order-items table {
      width: 100%;
      border-collapse: collapse;
      margin: 20px 0;
    }

    .order-items th,
    .order-items td {
      padding: 10px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }

    .order-items th {
      background-color: #f5f5f5;
      font-weight: bold;
    }

    .order-summary {
      text-align: right;
      margin-top: 20px;
      padding-top: 10px;
      border-top: 1px solid #ddd;
    }


    h1, h2 {
        font-size: 24px;
        margin-bottom: 15px;
    }

    h3 {
        font-size: 18px;
        margin-bottom: 10px;
    }

    .order-summary p {
      margin: 8px 0;
      font-size: 16px;
    }

    .order-summary p:last-child {
      color: #2ecc71;
      font-weight: bold;
      font-size: 18px;
    }

    /* Sort button styles */
    .sort-btn {
        background: none;
        border: none;
        cursor: pointer;
        padding: 4px 8px;
        color: #ffffff;
        border-radius: 0;
        display: inline-flex;
        align-items: center;
        vertical-align: middle;
        margin-left: 8px;
        transition: color 0.2s ease;
        box-shadow: none;
    }

    .sort-btn:hover {
        background: none;
        color: #ffffff;
        transform: none;
        box-shadow: none;
    }

    .sort-btn.active {
        background: none;
        color: #ffffff;
        box-shadow: none;
    }

    th {
        position: relative;
        white-space: nowrap;
        padding: 12px 15px;
    }

    .column-header {
        display: inline-flex;
        align-items: center;
        gap: 5px;
    }

    button i {
        margin-right: 5px;
        vertical-align: middle;
    }

    button {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        padding: 10px 20px;
        font-size: 14px;
        cursor: pointer;
        background-color: #face0b;
        color: black;
        border: none;
        border-radius: 15px;
        transition: background-color 0.3s ease;
    }

    /* Shared header, table, and modal styling */
    .products-header {
        background: white;
        padding: 18px 24px;
        border-radius: 22px;
        margin: 0 0 24px 0;
        color: #333;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(0, 0, 0, 0.1);
    }

    .products-header-main {
        display: flex;
        justify-content: space-between;
        gap: 14px;
        align-items: center;
        flex-wrap: wrap;
    }

    .header-title {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .header-title-icon {
        width: 60px;
        height: 60px;
        border-radius: 14px;
        background: rgba(250, 206, 11, 0.15);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 26px;
        color: #face0b;
    }

    .header-title h2 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: #1e293b;
        letter-spacing: -0.5px;
    }

    .header-actions {
        display: flex;
        align-items: center;
        gap: 16px;
        flex-wrap: wrap;
    }

    .header-metrics {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .metric-card {
        display: none;
    }

    .products-toolbar {
        background: transparent;
        padding: 0;
        margin-top: 16px;
        box-shadow: none;
    }

    .transactions-filter-form {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        align-items: center;
        margin: 0;
    }

    /* Search bar styles without icon and green border */
    .search-container {
        position: relative;
    }

    .search-container .input-with-icon {
        width: 300px;
        flex-shrink: 0;
    }

    .search-container .input-with-icon {
        position: relative;
    }

    .search-container .input-with-icon i {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #64748b;
        font-size: 14px;
        z-index: 1;
        pointer-events: none;
    }

    .search-container .input-with-icon input {
        padding: 10px 14px 10px 40px;
        border: 1px solid #e2e8f0;
        border-radius: 15px;
        font-size: 14px;
        color: #1e293b;
        transition: border 0.2s ease, box-shadow 0.2s ease;
        background: white;
        width: 100%;
        box-sizing: border-box;
    }

    .search-container .input-with-icon input:focus {
        outline: none;
        border-color: #face0b;
        box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
    }

    .search-container input[type="text"]::placeholder {
        color: #94a3b8;
    }

    .date-range-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-width: 160px;
    }

    .date-range-group label {
        color: #1e293b;
        font-size: 13px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }

    .date-range-group input {
        padding: 12px 14px;
        border-radius: 10px;
        border: 2px solid #e2e8f0;
        background: white;
        color: #1e293b;
        font-size: 15px;
        transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    .date-range-group input:focus {
        border-color: #face0b;
        outline: none;
        box-shadow: 0 0 5px rgba(250, 206, 11, 0.3);
    }

    .ghost-btn {
        background: linear-gradient(135deg, #face0b, #f7b300);
        color: #000;
        padding: 10px 20px;
        margin: 0 4px;
        border: none;
        border-radius: 999px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
        box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
    }

    .ghost-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
    }
    
    .ghost-btn i {
        font-size: 14px;
        color: inherit;
    }

    .table-container {
        max-height: calc(100vh - 260px);
        overflow-y: auto;
        padding-right: 8px;
        position: relative;
        margin-top: 20px;
        border-radius: 12px;
    }

    .table-container::-webkit-scrollbar {
        width: 8px;
    }

    .table-container::-webkit-scrollbar-thumb {
        background: rgba(15, 23, 42, 0.25);
        border-radius: 10px;
    }

    #transactionsTable {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0 12px;
        margin-top: 0;
        background: transparent;
    }

    #transactionsTable thead {
        position: sticky;
        top: 0;
        z-index: 20;
        background: #333;
        transform: translateZ(0);
        isolation: isolate;
    }

    #transactionsTable thead tr {
        background: #333;
    }

    #transactionsTable th {
        background-color: #333 !important;
        color: #ffffff;
        padding: 16px 20px;
        text-align: left;
        font-size: 14px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        cursor: pointer;
        border: none;
        position: relative;
        white-space: nowrap;
        transition: background-color 0.3s ease;
        box-shadow: 0 4px 0 0 #333;
        border-bottom: 4px solid #333;
    }

    #transactionsTable th:first-child {
        border-top-left-radius: 12px;
        border-bottom-left-radius: 0;
    }

    #transactionsTable th:last-child {
        border-top-right-radius: 12px;
        border-bottom-right-radius: 0;
    }

    #transactionsTable th:hover {
        background-color: #444;
    }

    #transactionsTable tbody {
        position: relative;
        z-index: 1;
    }

    #transactionsTable tbody tr {
        background: #ffffff;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        transition: all 0.3s ease;
        margin-bottom: 12px;
    }

    #transactionsTable tbody tr:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        background: #ffffff;
    }

    #transactionsTable td {
        padding: 18px 20px;
        text-align: left;
        font-size: 15px;
        color: #1e293b;
        border: none;
        vertical-align: middle;
    }

    #transactionsTable tbody tr td:first-child {
        border-top-left-radius: 12px;
        border-bottom-left-radius: 12px;
    }

    #transactionsTable tbody tr td:last-child {
        border-top-right-radius: 12px;
        border-bottom-right-radius: 12px;
    }

    #transactionsTable button[onclick^="showDetails"],
    #transactionsTable button[onclick^="reprintReceipt"],
    #transactionsTable button.action-btn {
        padding: 8px 12px;
        font-size: 11px;
        margin: 2px;
    }
    
    #transactionsTable button i {
        font-size: 12px;
    }
    
    .ghost-btn {
        padding: 10px 16px;
        font-size: 12px;
    }

    .modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        align-items: center;
        justify-content: center;
        transition: opacity 0.3s ease;
        opacity: 0;
        pointer-events: none;
    }

    .modal.show {
        display: flex;
        opacity: 1;
        pointer-events: auto;
        animation: modalFadeIn 0.3s;
    }

    .modal-content.modal-modern {
        padding: 0;
        border: none;
        overflow: hidden;
        background: #f5f5f5;
        box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
        max-width: 720px;
    }

    .modal-header {
        background: #333;
        color: #fff;
        padding: 28px 32px;
        display: flex;
        align-items: center;
        gap: 18px;
    }

    .modal-body {
        padding: 30px;
        display: flex;
        flex-direction: column;
        gap: 24px;
        max-height: calc(90vh - 160px);
        overflow-y: auto;
    }

    .modal-actions .btn-primary {
        background: #face0b;
        color: #1a1a1a;
        padding: 12px 22px;
        border-radius: 15px;
        font-weight: 600;
        border: none;
        cursor: pointer;
        transition: transform 0.15s ease, box-shadow 0.15s ease;
        box-shadow: 0 12px 24px rgba(250, 206, 11, 0.45);
    }

    .modal-actions .btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 14px 24px rgba(250, 206, 11, 0.45);
    }
/* Search bar: same as User Management */
.search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
    padding: 10px 14px 10px 40px !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 15px !important;
    font-size: 14px !important;
    outline: none !important;
}
.search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
    border-color: #face0b !important;
    box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
}
.search-container { position: relative; }
.search-container .input-with-icon { position: relative; }
.search-container .input-with-icon i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 14px;
}
/* All buttons: no shadow */
button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
    box-shadow: none !important;
}
</style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>
<main>
  <div class="products-header">
    <div class="products-header-main">
      <div class="header-title">
        <div class="header-title-icon">
          <i class="fas fa-receipt"></i>
        </div>
        <h2>Transaction History</h2>
      </div>
      <div class="header-actions">
        <form method="POST" class="transactions-filter-form" id="searchForm">
          <input type="hidden" name="sort_column" id="sortColumn" value="<?php echo htmlspecialchars($sortColumnInput); ?>">
          <input type="hidden" name="sort_direction" id="sortDirection" value="<?php echo htmlspecialchars($sortDirection); ?>">
          
          <div class="search-container">
            <div class="input-with-icon">
              <i class="fas fa-search"></i>
              <input type="text" name="search" id="search_term" placeholder="Search by transaction number" value="<?php echo htmlspecialchars($search); ?>" onchange="this.form.submit()">
            </div>
          </div>
          
          <div class="date-range-group">
            <label for="start_date">Start Date</label>
            <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDateDisplay); ?>" onchange="this.form.submit()" />
          </div>
          <div class="date-range-group">
            <label for="end_date">End Date</label>
            <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDateDisplay); ?>" onchange="this.form.submit()" />
          </div>
        </form>
        <button type="button" onclick="generateReport()" class="ghost-btn"><i class="fas fa-file-alt"></i> Generate Sales Report</button>
        <button type="button" onclick="generatePresetReport('daily')" class="ghost-btn">Daily</button>
        <button type="button" onclick="generatePresetReport('weekly')" class="ghost-btn">Weekly</button>
        <button type="button" onclick="generatePresetReport('monthly')" class="ghost-btn">Monthly</button>
      </div>
    </div>
  </div>

  <div class="table-container">
  <table id="transactionsTable">
    <thead>
      <tr>
        <th>
          <div class="column-header">
            Transaction Number
            <button onclick="sortTable('transaction_num')" class="sort-btn" data-column="transaction_num">
              <i class="fas fa-sort"></i>
            </button>
          </div>
        </th>
        <th>
          <div class="column-header">
            Transaction Date
            <button onclick="sortTable('transaction_date')" class="sort-btn" data-column="transaction_date">
              <i class="fas fa-sort"></i>
            </button>
          </div>
        </th>
        <th>
          <div class="column-header">
            Total Amount
            <button onclick="sortTable('total_amount')" class="sort-btn" data-column="total_amount">
              <i class="fas fa-sort"></i>
            </button>
          </div>
        </th>
        <th>
          <div class="column-header">
            Payment
            <button onclick="sortTable('payment')" class="sort-btn" data-column="payment">
              <i class="fas fa-sort"></i>
            </button>
          </div>
        </th>
        <th>
          <div class="column-header">
            Change
            <button onclick="sortTable('change_amount')" class="sort-btn" data-column="change_amount">
              <i class="fas fa-sort"></i>
            </button>
          </div>
        </th>
        <th>Payment Method</th>
        <th>Reference No</th>
        <th>Details</th>
      </tr>
    </thead>
    <tbody>
      <?php if ($transactionsResult->num_rows > 0): ?>
        <?php while ($transaction = $transactionsResult->fetch_assoc()): ?>
          <?php
          $formattedDate = date('Y-m-d h:i A', strtotime($transaction['transaction_date']));
          $details = json_decode($transaction['details'], true);
          $detailsPayload = base64_encode($transaction['details']);
          $encodedDetails = htmlspecialchars($detailsPayload, ENT_QUOTES, 'UTF-8');
          $cashierName = $transaction['cashier_name'] ?? $transaction['processed_by'] ?? 'N/A';
          $escapedCashier = htmlspecialchars($cashierName, ENT_QUOTES, 'UTF-8');
          $total = $transaction['total_amount'];
          $formattedTotal = '₱' . number_format($total, 2);
          $formattedPayment = '₱' . number_format($transaction['payment'], 2);
          $formattedChange = '₱' . number_format($transaction['change_amount'], 2);
          $paymentMethod = $transaction['payment_method'] ?? 'cash';
          $referenceNo = $transaction['reference_no'] ?? '';
          $escapedPaymentMethod = htmlspecialchars(strtoupper($paymentMethod), ENT_QUOTES, 'UTF-8');
          $escapedReferenceNo = htmlspecialchars($referenceNo, ENT_QUOTES, 'UTF-8');
          ?>
          <tr>
            <td><?php echo str_pad($transaction['transaction_num'], 8, '0', STR_PAD_LEFT); ?></td>
            <td><?php echo $formattedDate; ?></td>
            <td><?php echo $formattedTotal; ?></td>
            <td><?php echo $formattedPayment; ?></td>
            <td><?php echo $formattedChange; ?></td>
            <td><?php echo $escapedPaymentMethod; ?></td>
            <td><?php echo $escapedReferenceNo ? $escapedReferenceNo : '-'; ?></td>
            <td>
              <button class="action-btn view-btn" onclick="showDetails('<?php echo $encodedDetails; ?>', '<?php echo str_pad($transaction['transaction_num'], 8, '0', STR_PAD_LEFT); ?>', '<?php echo date('Y-m-d H:i:s', strtotime($transaction['transaction_date'])); ?>', '<?php echo $transaction['total_amount']; ?>', '<?php echo $transaction['payment']; ?>', '<?php echo $transaction['change_amount']; ?>', '<?php echo $escapedCashier; ?>', '<?php echo $escapedPaymentMethod; ?>', '<?php echo $escapedReferenceNo; ?>')"><i class="fas fa-eye"></i> View Details</button>
              <button class="action-btn print-btn" onclick="reprintReceipt('<?php echo str_pad($transaction['transaction_num'], 8, '0', STR_PAD_LEFT); ?>', '<?php echo $transaction['total_amount']; ?>', '<?php echo $transaction['payment']; ?>', '<?php echo $transaction['change_amount']; ?>', '<?php echo $encodedDetails; ?>', '<?php echo $escapedCashier; ?>', '<?php echo $escapedPaymentMethod; ?>', '<?php echo $escapedReferenceNo; ?>')"><i class="fas fa-print"></i> Reprint</button>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr>
          <td colspan="8">No transactions found for the selected date range.</td>
        </tr>
      <?php endif; ?>
    </tbody>
  </table>
  </div>
</main>

<!-- Modal Structure -->
<div id="receiptModal" class="modal">
  <div class="modal-content modal-modern">
    <span class="close" onclick="closeModal()">&times;</span>
    <div class="modal-header">
      <div class="modal-icon">
        <i class="fas fa-receipt"></i>
      </div>
      <div>
        <h2>Transaction Details</h2>
        <p>View complete transaction information and itemized receipt</p>
      </div>
    </div>
    <div class="modal-body receipt-modal-body">
      <div class="section-card">
        <div class="section-header">
          <div class="section-icon">
            <i class="fas fa-info-circle"></i>
          </div>
          <div>
            <h3>Summary</h3>
          </div>
        </div>
        <div class="transaction-info">
          <p><strong>Transaction Number:</strong> <span id="modalTransactionNum"></span></p>
          <p><strong>Date:</strong> <span id="modalTransactionDate"></span></p>
          <p><strong>Cashier:</strong> <span id="modalCashier"></span></p>
        </div>
      </div>
      <div class="section-card">
        <div class="section-header">
          <div class="section-icon">
            <i class="fas fa-list"></i>
          </div>
          <div>
            <h3>Ordered Items</h3>
          </div>
        </div>
        <div class="order-items">
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody id="modalItemsBody"></tbody>
          </table>
        </div>
      </div>
      <div class="section-card order-summary-card">
        <div class="section-header">
          <div class="section-icon">
            <i class="fas fa-wallet"></i>
          </div>
          <div>
            <h3>Payment Summary</h3>
          </div>
        </div>
        <div class="order-summary">
          <p><strong>Total Amount:</strong> <span id="modalTotalAmount"></span></p>
          <p><strong>Amount Paid:</strong> <span id="modalAmountPaid"></span></p>
          <p><strong>Change:</strong> <span id="modalChange"></span></p>
          <p><strong>Payment Method:</strong> <span id="modalPaymentMethod"></span></p>
          <p id="modalReferenceNoRow" style="display: none;"><strong>Reference No:</strong> <span id="modalReferenceNo"></span></p>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  const productPriceMap = <?php echo json_encode($productPrices, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

  function formatCurrency(value) {
    const numeric = Number(value);
    const safeValue = Number.isFinite(numeric) ? numeric : 0;
    return '₱ ' + safeValue.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function formatNumber(number) {
    return formatCurrency(number);
  }

  function getInventoryPrice(name) {
    if (!name) {
      return 0;
    }
    const key = name.trim().toLowerCase();
    if (!key) {
      return 0;
    }
    const value = Object.prototype.hasOwnProperty.call(productPriceMap, key)
      ? Number(productPriceMap[key])
      : 0;
    return Number.isFinite(value) ? value : 0;
  }

  function parseTransactionDetails(detailsBase64) {
    let decoded = '';
    try {
      decoded = atob(detailsBase64);
    } catch (error) {
      console.error('Failed to decode transaction details.', error);
      return { items: [], cashier: 'N/A', raw: '' };
    }

    let items = [];
    let cashier = null;

    const normalizeItems = parsedItems => parsedItems
      .map(entry => {
        const name = typeof entry.name === 'string' && entry.name.trim() !== '' ? entry.name.trim() : 'Unknown item';
        const quantity = Number(entry.quantity) || 0;
        let price = Number(entry.price) || 0;
        if (!price && typeof entry.total !== 'undefined') {
          const entryTotal = Number(entry.total) || 0;
          price = quantity > 0 ? entryTotal / quantity : 0;
        }
        if (!price) {
          price = getInventoryPrice(name);
        }
        return quantity > 0 ? { name, quantity, price } : null;
      })
      .filter(Boolean);

    try {
      const parsed = JSON.parse(decoded);
      if (Array.isArray(parsed)) {
        items = normalizeItems(parsed);
      } else if (parsed && Array.isArray(parsed.items)) {
        items = normalizeItems(parsed.items);
        cashier = typeof parsed.cashier === 'string' ? parsed.cashier.trim() : null;
      }
    } catch (jsonError) {
      // Continue to fallback parsing if JSON parsing fails
    }

    if (!items.length) {
      const segments = decoded
        .split(',')
        .map(segment => segment.trim())
        .filter(segment => segment.length > 0);

      if (segments.length) {
        const lastSegment = segments[segments.length - 1] || '';
        const lowerLast = lastSegment.toLowerCase();

        // Case 1: Explicit "cashier: Name"
        if (/cashier\s*:/.test(lowerLast)) {
          cashier = lastSegment.replace(/cashier\s*:/i, '').trim();
          segments.pop();
        } else {
          // Case 2: Legacy format where the last segment is just the cashier full name
          // and does NOT look like an item (no "(qty)" pattern)
          const itemRegex = /(.*?)\(\s*(\d+)\s*(?:x\s*([\d.]+))?\s*\)/i;
          if (!itemRegex.test(lastSegment) && lastSegment.length > 0) {
            cashier = lastSegment.trim();
          segments.pop();
          }
        }
      }

      items = segments
        .map(segment => {
          const regex = /(.*?)\(\s*(\d+)\s*(?:x\s*([\d.]+))?\s*\)/i;
          const match = segment.match(regex);
          if (!match) {
            return null;
          }
          const name = match[1].trim();
          const quantity = Number(match[2]) || 0;
          let price = Number(match[3]) || 0;
          if (!price) {
            price = getInventoryPrice(name);
          }
          return quantity > 0 ? { name, quantity, price } : null;
        })
        .filter(Boolean);
    }

    return {
      items,
      cashier: cashier && cashier.trim() !== '' ? cashier : 'N/A',
      raw: decoded
    };
  }

  function toggleSidebar() {
    const sidebar = document.querySelector('nav.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('sidebar-expanded');
        // Save state to localStorage
        const isExpanded = sidebar.classList.contains('sidebar-expanded');
        localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
    }
  }
  
  // Restore sidebar state on page load (without transition)
  document.addEventListener('DOMContentLoaded', function() {
      const sidebar = document.querySelector('nav.sidebar');
      if (sidebar) {
          // Disable transitions during state restoration
          sidebar.classList.add('no-transition');
          
          const savedState = localStorage.getItem('sidebarExpanded');
          if (savedState === 'true') {
              sidebar.classList.add('sidebar-expanded');
          } else {
              // Default to collapsed (no saved state or explicitly false)
              sidebar.classList.remove('sidebar-expanded');
          }
          
          // Re-enable transitions after a short delay
          setTimeout(function() {
              sidebar.classList.remove('no-transition');
          }, 50);
      }
  });

  function confirmLogout(event) {
    event.preventDefault();
    Swal.fire({
        title: 'Logout Confirmation',
        text: "Are you sure you want to logout?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#face0b',
        cancelButtonColor: '#333',
        confirmButtonText: 'Yes, logout',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../authentication/logout.php';
        }
    });
  }

  function showDetails(detailsBase64, transactionNum, transactionDate, totalAmount, payment, changeAmount, cashierName, paymentMethod = 'cash', referenceNo = '') {
    const parsedDetails = parseTransactionDetails(detailsBase64);
    const items = parsedDetails.items;
    const cashier = (cashierName && cashierName.trim() !== '' && cashierName !== 'N/A') ? cashierName : parsedDetails.cashier;

    document.getElementById('modalTransactionNum').textContent = transactionNum;
    document.getElementById('modalTransactionDate').textContent = transactionDate;
    document.getElementById('modalCashier').textContent = cashier;
    document.getElementById('modalTotalAmount').textContent = formatCurrency(totalAmount);
    document.getElementById('modalAmountPaid').textContent = formatCurrency(payment);
    document.getElementById('modalChange').textContent = formatCurrency(changeAmount);
    document.getElementById('modalPaymentMethod').textContent = paymentMethod ? paymentMethod.toUpperCase() : 'CASH';
    
    const referenceNoRow = document.getElementById('modalReferenceNoRow');
    const referenceNoSpan = document.getElementById('modalReferenceNo');
    if (paymentMethod && paymentMethod.toLowerCase() !== 'cash' && referenceNo) {
      referenceNoSpan.textContent = referenceNo;
      referenceNoRow.style.display = 'block';
    } else {
      referenceNoRow.style.display = 'none';
    }

    const itemsBody = document.getElementById('modalItemsBody');
    itemsBody.innerHTML = '';

    items.forEach(item => {
      const unitPrice = Number(item.price) || 0;
      const subtotal = unitPrice * item.quantity;
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td>${formatCurrency(unitPrice)}</td>
        <td>${formatCurrency(subtotal)}</td>
      `;
      itemsBody.appendChild(row);
    });

    const modal = document.getElementById('receiptModal');
    modal.style.display = "flex";
    modal.classList.add('show');
  }

  function closeModal() {
    const modal = document.getElementById('receiptModal');
    modal.style.display = "none";
    modal.classList.remove('show');
  }

  window.onclick = function(event) {
    const modal = document.getElementById('receiptModal');
    if (event.target === modal) {
      closeModal();
    }
  }


  let searchTimeout;
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      clearTimeout(searchTimeout);
      searchTimeout = setTimeout(() => {
        const formData = new FormData(document.getElementById('searchForm'));

        formData.append('sort_column', document.getElementById('sortColumn').value);
        formData.append('sort_direction', document.getElementById('sortDirection').value);

        fetch('../api/fetch_transactions.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.text())
        .then(html => {
          document.querySelector('tbody').innerHTML = html;
        })
        .catch(error => console.error('Error:', error));
      }, 300);
    });
  }

  let currentSort = {
    column: '<?php echo $sortColumnInput; ?>',
    order: '<?php echo $sortDirection; ?>'
  };

  function updateSortIcon(column) {
    document.querySelectorAll('.sort-btn').forEach(btn => {
      btn.classList.remove('active');
      btn.querySelector('i').className = 'fas fa-sort';
    });

    const currentBtn = document.querySelector(`button[data-column="${column}"]`);
    if (currentBtn) {
      currentBtn.classList.add('active');
      const icon = currentBtn.querySelector('i');
      icon.className = currentSort.order === 'ASC' ? 'fas fa-sort-up' : 'fas fa-sort-down';
    }
  }

  function sortTable(column) {
    if (currentSort.column === column) {
      currentSort.order = currentSort.order === 'ASC' ? 'DESC' : 'ASC';
    } else {
      currentSort.column = column;
      currentSort.order = 'ASC';
    }

    updateSortIcon(column);
    document.getElementById('sortColumn').value = column;
    document.getElementById('sortDirection').value = currentSort.order;
    document.getElementById('searchForm').submit();
  }

  document.addEventListener('DOMContentLoaded', function() {
    updateSortIcon(currentSort.column);
  });

  // Function to generate item code from product name
  function generateItemCode(productName) {
      // Convert to lowercase and remove special characters
      let code = productName.toLowerCase()
          .replace(/[^a-z0-9\s]/g, '') // Remove special characters
          .replace(/\s+/g, '') // Remove spaces
          .substring(0, 8); // Take first 8 characters
      
      // If less than 4 characters, pad with first letters
      if (code.length < 4) {
          const words = productName.toLowerCase().split(/\s+/);
          code = words.map(word => word.charAt(0)).join('').substring(0, 8);
      }
      
      return code.toUpperCase();
  }

  function reprintReceipt(transactionNum, totalAmount, payment, changeAmount, detailsBase64, cashierName, paymentMethod = 'cash', referenceNo = '') {
    fetch('transaction_history.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `log_reprint=true&transaction_num=${transactionNum}`
    });

    const parsedDetails = parseTransactionDetails(detailsBase64);
    const items = parsedDetails.items;
    const cashier = (cashierName && cashierName.trim() !== '' && cashierName !== 'N/A') ? cashierName : parsedDetails.cashier;

    const numericTotal = Number(totalAmount) || 0;
    const numericPayment = Number(payment) || 0;
    const numericChange = Number(changeAmount) || 0;
    const itemsSubtotal = items.reduce((sum, item) => {
      const unitPrice = Number(item.price) || 0;
      return sum + unitPrice * (Number(item.quantity) || 0);
    }, 0);

    const effectiveSubtotal = numericTotal || itemsSubtotal;
    const hasDiscount = numericTotal > 0 && itemsSubtotal > 0 && numericTotal < itemsSubtotal;
    const pwdDiscount = hasDiscount ? effectiveSubtotal * 0.20 : 0;
    const discountedSubtotal = hasDiscount ? (effectiveSubtotal - pwdDiscount) : effectiveSubtotal;
    // VAT is 12% of the subtotal (added on top, not extracted)
    // If transaction has discount, entire transaction is VAT exempt
    const vatAmount = hasDiscount ? 0 : (discountedSubtotal * 0.12);
    const finalTotal = discountedSubtotal + vatAmount;

    const receiptWindow = window.open('', '_blank', 'width=300,height=auto');
    receiptWindow.document.write(`
        <html>
        <head>
            <title>Receipt Reprint</title>
            <style>
                @page {
                    size: 58mm auto;
                    margin: 3mm 2mm 3mm 2mm;
                }
                * {
                    box-sizing: border-box;
                }
                body { 
                    font-family: 'Courier New', monospace;
                    text-align: center;
                    padding: 0;
                    margin: 0;
                    background: white;
                    width: 50mm;
                    max-width: 50mm;
                    font-size: 9px;
                    overflow-wrap: break-word;
                    word-wrap: break-word;
                }
                .receipt-header {
                    text-align: center;
                    border-bottom: 1px dashed #000;
                    padding-bottom: 4px;
                    margin-bottom: 6px;
                    width: 100%;
                }
                .receipt-header h1 {
                    margin: 0;
                    font-size: 10px;
                    font-weight: bold;
                    margin-bottom: 3px;
                    line-height: 1.1;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                .receipt-header p {
                    margin: 1px 0;
                    font-size: 8px;
                    line-height: 1.1;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                .receipt-items {
                    margin: 6px 0;
                    width: 100%;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    font-size: 8px;
                    table-layout: fixed;
                }
                th {
                    border-bottom: 1px dashed #000;
                    padding: 2px 1px;
                    text-align: left;
                    font-size: 8px;
                    font-weight: bold;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                th:nth-child(1) { width: 35%; }
                th:nth-child(2) { width: 12%; }
                th:nth-child(3) { width: 26%; }
                th:nth-child(4) { width: 27%; }
                td {
                    padding: 2px 1px;
                    line-height: 1.1;
                    font-size: 8px;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                td:nth-child(1) { width: 35%; }
                td:nth-child(2) { width: 12%; text-align: center; }
                td:nth-child(3) { width: 26%; text-align: right; }
                td:nth-child(4) { width: 27%; text-align: right; }
                .receipt-totals {
                    border-top: 1px dashed #000;
                    margin-top: 6px;
                    padding-top: 4px;
                    font-size: 8px;
                    width: 100%;
                }
                .receipt-totals p {
                    margin: 2px 0;
                    line-height: 1.2;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                    display: block;
                    text-align: left;
                }
                .receipt-totals p .label {
                    display: inline-block;
                    text-align: left;
                    max-width: 60%;
                    vertical-align: top;
                }
                .receipt-totals p .value {
                    display: inline-block;
                    text-align: right;
                    float: right;
                    min-width: 40%;
                    vertical-align: top;
                }
                .receipt-totals p strong {
                    font-weight: bold;
                }
                .receipt-footer {
                    text-align: center;
                    margin-top: 6px;
                    padding-top: 4px;
                    border-top: 1px dashed #000;
                    font-size: 8px;
                    width: 100%;
                }
                .receipt-footer p {
                    margin: 2px 0;
                    line-height: 1.2;
                    word-wrap: break-word;
                    overflow-wrap: break-word;
                }
                .receipt-divider {
                    border-top: 1px dashed #000;
                    margin: 4px 0;
                }
                .receipt-date {
                    text-align: center;
                    font-size: 8px;
                    margin: 3px 0;
                    line-height: 1.2;
                }
                .receipt-thank-you {
                    text-align: center;
                    font-size: 8px;
                    margin: 4px 0;
                    font-style: italic;
                    line-height: 1.2;
                }
                .order-type {
                    text-align: center;
                    font-size: 9px;
                    font-weight: bold;
                    margin: 4px 0;
                    text-transform: uppercase;
                    line-height: 1.2;
                }
            </style>
        </head>
        <body>
            <div class="receipt-header">
                <h1>EDGIE'S RESTAURANT AND EVENT PLACE</h1>
                <p>Pasolo Road, Pasolo 1440 Valenzuela, Philippines</p>
                <div class="receipt-divider"></div>
                <p>Transaction #: ${transactionNum}</p>
                <p>Cashier: ${cashier}</p>
                <p class="receipt-date">${new Date().toLocaleString()}</p>
                <p style="color: #e74c3c; font-weight: bold;">*** REPRINT ***</p>
            </div>
            <div class="receipt-items">
                <table>
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody id="receiptItemsBody"></tbody>
                </table>
            </div>
            <div class="receipt-totals">
                <p><span class="label">Subtotal (VAT Inc):</span><span class="value">${formatNumber(effectiveSubtotal).replace('₱ ', '')}</span></p>
                ${hasDiscount ? `
                    <p><span class="label">VAT Discount:</span><span class="value">${formatNumber(vatAmount).replace('₱ ', '')}</span></p>
                    <p><span class="label">PWD/Senior Disc (20%):</span><span class="value">${formatNumber(pwdDiscount).replace('₱ ', '')}</span></p>
                    <p><span class="label"><strong>TOTAL AMOUNT DUE:</strong></span><span class="value"><strong>${formatNumber(finalTotal).replace('₱ ', '')}</strong></span></p>
                ` : `
                    <p><span class="label">VAT (12%):</span><span class="value">${formatNumber(vatAmount).replace('₱ ', '')}</span></p>
                    <p><span class="label"><strong>TOTAL AMOUNT DUE:</strong></span><span class="value"><strong>${formatNumber(effectiveSubtotal).replace('₱ ', '')}</strong></span></p>
                `}
                <p><span class="label">Payment Method:</span><span class="value"><strong>${paymentMethod ? paymentMethod.toUpperCase() : 'CASH'}</strong></span></p>
                <p><span class="label">Amount Paid:</span><span class="value">${formatNumber(numericPayment).replace('₱ ', '')}</span></p>
                ${paymentMethod && paymentMethod.toLowerCase() !== 'cash' && referenceNo ? `<p><span class="label">Ref No:</span><span class="value"><strong>${referenceNo}</strong></span></p>` : ''}
                ${paymentMethod && paymentMethod.toLowerCase() === 'cash' ? `<p><span class="label">Change:</span><span class="value">${formatNumber(numericChange).replace('₱ ', '')}</span></p>` : ''}
            </div>
            <div class="receipt-footer">
                <div class="receipt-divider"></div>
                <p>Customer Name: _________________</p>
                <p>Contact No.: _________________</p>
                <div class="receipt-divider"></div>
                <p>Thank you for dining with us!</p>
                <p>Please come again</p>
                <br>
                <p class="order-type">REPRINT</p>
            </div>
        </body>
        </html>
    `);
    
    const receiptItemsBody = receiptWindow.document.getElementById('receiptItemsBody');
    receiptItemsBody.innerHTML = '';
    items.forEach(item => {
        const unitPrice = Number(item.price) || 0;
        const itemTotal = unitPrice * (Number(item.quantity) || 0);
        const itemCode = generateItemCode(item.name);
        receiptItemsBody.innerHTML += `
            <tr>
                <td>${itemCode}</td>
                <td>${item.quantity}</td>
                <td>${formatNumber(unitPrice).replace('₱ ', '')}</td>
                <td>${formatNumber(itemTotal).replace('₱ ', '')}</td>
            </tr>
        `;
    });
    
    receiptWindow.document.close();
    receiptWindow.onload = function() {
        receiptWindow.print();
    };
  }

    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        
        // Format date: Day, Month DD, YYYY
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        
        // Format time: HH:MM:SS AM/PM
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }

    // Update immediately and then every second
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);
    
    // Generate Sales Report functions
    function generateReport() {
        // Set default values in modal (default to current month)
        const modalStartDate = document.getElementById('modal_report_start_date');
        const modalEndDate = document.getElementById('modal_report_end_date');
        
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        
        modalStartDate.value = firstDay.toISOString().split('T')[0];
        modalEndDate.value = lastDay.toISOString().split('T')[0];
        
        // Show the modal
        document.getElementById('generateReportModal').classList.add('show');
    }
    
    function closeReportModal() {
        document.getElementById('generateReportModal').classList.remove('show');
    }
    
    function proceedGenerateReport() {
        const startDate = document.getElementById('modal_report_start_date').value;
        const endDate = document.getElementById('modal_report_end_date').value;
        const search = document.getElementById('search_term') ? document.getElementById('search_term').value : '';
        
        // Validate dates
        if (!startDate || !endDate) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Please select both start and end dates.'
            });
            return;
        }
        
        if (startDate > endDate) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Start date cannot be later than end date.'
            });
            return;
        }
        
        // Close modal and redirect to generate report
        closeReportModal();
        window.location.href = `generate_report.php?start_date=${startDate}&end_date=${endDate}&search=${encodeURIComponent(search)}`;
    }

    function formatLocalDate(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    function generatePresetReport(preset) {
        const startInput = document.getElementById('start_date');
        const endInput = document.getElementById('end_date');
        const referenceValue = (startInput && startInput.value) ? startInput.value : ((endInput && endInput.value) ? endInput.value : '');
        const referenceDate = referenceValue ? new Date(referenceValue + 'T00:00:00') : new Date();

        let startDate;
        let endDate;

        if (preset === 'daily') {
            startDate = new Date(referenceDate);
            endDate = new Date(referenceDate);
        } else if (preset === 'weekly') {
            // Week is Monday-Sunday based on the selected date (or today if none selected)
            const day = referenceDate.getDay(); // 0=Sun..6=Sat
            const diffToMonday = (day === 0) ? -6 : (1 - day);
            startDate = new Date(referenceDate);
            startDate.setDate(referenceDate.getDate() + diffToMonday);
            endDate = new Date(startDate);
            endDate.setDate(startDate.getDate() + 6);
        } else if (preset === 'monthly') {
            startDate = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), 1);
            endDate = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 1, 0);
        } else {
            return;
        }

        const s = formatLocalDate(startDate);
        const e = formatLocalDate(endDate);
        const search = document.getElementById('search_term') ? document.getElementById('search_term').value : '';
        window.location.href = `generate_report.php?start_date=${s}&end_date=${e}&search=${encodeURIComponent(search)}`;
    }
    
    // Close modal when clicking outside of it
    window.onclick = function(event) {
        const modal = document.getElementById('generateReportModal');
        if (event.target == modal) {
            closeReportModal();
        }
    }
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeReportModal();
        }
    });
</script>

<!-- Generate Report Modal -->
<div id="generateReportModal" class="modal">
    <div class="modal-content modal-modern">
        <div class="modal-header">
            <div class="modal-icon">
                <i class="fas fa-file-alt"></i>
            </div>
            <div>
                <h2>Generate Sales Report</h2>
                <p>Select the date range for the sales report</p>
            </div>
            <span class="close" onclick="closeReportModal()">&times;</span>
        </div>
        <div class="modal-body">
            <div class="section-card">
                <div class="form-group">
                    <label for="modal_report_start_date">Start Date</label>
                    <div class="input-with-icon">
                        <i class="fas fa-calendar-alt"></i>
                        <input type="date" id="modal_report_start_date" name="modal_report_start_date" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="modal_report_end_date">End Date</label>
                    <div class="input-with-icon">
                        <i class="fas fa-calendar-alt"></i>
                        <input type="date" id="modal_report_end_date" name="modal_report_end_date" required>
                    </div>
                </div>
                <div class="modal-actions">
                    <button type="button" onclick="closeReportModal()" class="btn-secondary">Cancel</button>
                    <button type="button" onclick="proceedGenerateReport()" class="btn-primary">
                        <i class="fas fa-download"></i> Generate Report
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>

<?php
$conn->close();
?>
