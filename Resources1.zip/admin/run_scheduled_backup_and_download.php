<?php
session_start();
if (!isset($_SESSION['Username']) || ($_SESSION['Role'] ?? '') !== 'Admin') {
    http_response_code(403);
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/backup_helper.php';

$baseDir = realpath(__DIR__ . '/..');
if ($baseDir === false) {
    http_response_code(500);
    exit();
}
$backupDir = $baseDir . DIRECTORY_SEPARATOR . 'backup';
$schedulePath = $baseDir . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'backup_schedule.json';
$dbname = 'edgies_pos';

$runNow = isset($_GET['run_now']) && $_GET['run_now'] === '1';

if ($runNow) {
    $result = runBackupNow($conn, $dbname, $backupDir, $schedulePath);
} else {
    ensureBackupDir($backupDir);
    $result = runScheduledBackupIfDue($conn, $dbname, $backupDir, $schedulePath);
}
$conn->close();

if (!$result['ran'] || $result['path'] === null || !is_file($result['path'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'No backup due at this time.']);
    exit();
}

$filename = basename($result['path']);
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . (string)filesize($result['path']));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
readfile($result['path']);
exit();
