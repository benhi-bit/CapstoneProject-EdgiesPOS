<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php';
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT UserID, FullName, Username, Email FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userQuery->close();

// Determine display name
if (!empty($userData) && !empty($userData['FullName']) && trim($userData['FullName']) !== '') {
    $userFullName = trim($userData['FullName']);
} elseif (!empty($userData) && !empty($userData['Username'])) {
    $userFullName = $userData['Username'];
} else {
    $userFullName = 'Administrator';
}

$userId = $userData['UserID'] ?? null;
$currentFullName = $userData['FullName'] ?? '';
$currentUsername = $userData['Username'] ?? '';
$currentEmail = $userData['Email'] ?? '';

$message = null;
$messageType = 'success';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['update_profile'])) {
        $fullName = trim($_POST['fullName']);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        
        // Validate inputs
        if (empty($fullName) || empty($username) || empty($email)) {
            $message = 'All fields are required.';
            $messageType = 'error';
        } elseif (!preg_match('/^[A-Za-zÀ-ž\s.\'\-]{2,50}$/', $fullName)) {
            $message = 'Full name must be 2–50 characters (letters, spaces, basic punctuation only).';
            $messageType = 'error';
        } elseif (!preg_match('/^[A-Za-z0-9_]{4,20}$/', $username)) {
            $message = 'Username must be 4–20 characters (letters, numbers, underscore only).';
            $messageType = 'error';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
            $message = 'Invalid email address.';
            $messageType = 'error';
        } else {
            // Check if username already exists (excluding current user)
            $checkStmt = $conn->prepare("SELECT UserID FROM loginaccount WHERE Username = ? AND UserID != ?");
            $checkStmt->bind_param("si", $username, $userId);
            $checkStmt->execute();
            $checkResult = $checkStmt->get_result();
            $checkStmt->close();
            
            if ($checkResult->num_rows > 0) {
                $message = 'Username already exists. Please choose a different username.';
                $messageType = 'error';
            } else {
                // Check if email already exists (excluding current user)
                $emailCheckStmt = $conn->prepare("SELECT UserID FROM loginaccount WHERE Email = ? AND UserID != ?");
                $emailCheckStmt->bind_param("si", $email, $userId);
                $emailCheckStmt->execute();
                $emailResult = $emailCheckStmt->get_result();
                $emailCheckStmt->close();
                
                if ($emailResult->num_rows > 0) {
                    $message = 'Email already exists. Please use a different email address.';
                    $messageType = 'error';
                } else {
                    // Update profile
                    $updateStmt = $conn->prepare("UPDATE loginaccount SET FullName = ?, Username = ?, Email = ? WHERE UserID = ?");
                    $updateStmt->bind_param("sssi", $fullName, $username, $email, $userId);
                    
                    if ($updateStmt->execute()) {
                        // Update session username if it changed
                        if ($username !== $_SESSION['Username']) {
                            $_SESSION['Username'] = $username;
                        }
                        
                        // Log the change
                        $description = "Admin profile updated: " . $username;
                        addSystemLog($conn, "Profile Updated", $description, $userFullName);
                        
                        $message = 'Profile updated successfully!';
                        $messageType = 'success';
                        
                        // Refresh user data
                        $userQuery = $conn->prepare("SELECT UserID, FullName, Username, Email FROM loginaccount WHERE Username = ?");
                        $userQuery->bind_param("s", $username);
                        $userQuery->execute();
                        $userData = $userQuery->get_result()->fetch_assoc();
                        $userQuery->close();
                        
                        $currentFullName = $userData['FullName'] ?? '';
                        $currentUsername = $userData['Username'] ?? '';
                        $currentEmail = $userData['Email'] ?? '';
                        $userFullName = !empty($currentFullName) ? $currentFullName : $currentUsername;
                    } else {
                        $message = 'Error updating profile: ' . $updateStmt->error;
                        $messageType = 'error';
                    }
                    $updateStmt->close();
                }
            }
        }
    } elseif (isset($_POST['change_password'])) {
        $currentPassword = $_POST['currentPassword'];
        $newPassword = trim($_POST['newPassword']);
        $confirmPassword = trim($_POST['confirmPassword']);
        
        // Validate inputs
        if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
            $message = 'All password fields are required.';
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'New passwords do not match.';
            $messageType = 'error';
        } else {
            // Verify current password
            $verifyStmt = $conn->prepare("SELECT Password FROM loginaccount WHERE UserID = ?");
            $verifyStmt->bind_param("i", $userId);
            $verifyStmt->execute();
            $verifyResult = $verifyStmt->get_result();
            $verifyData = $verifyResult->fetch_assoc();
            $verifyStmt->close();
            
            if (!password_verify($currentPassword, $verifyData['Password'])) {
                $message = 'Current password is incorrect.';
                $messageType = 'error';
            } else {
                // Validate password pattern: at least 6 characters, 1 uppercase letter, 1 number
                $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/';
                if (!preg_match($passwordPattern, $newPassword)) {
                    $message = 'Password must be at least 6 characters long and contain at least one uppercase letter and one number.';
                    $messageType = 'error';
                } else {
                    // Update password
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $updateStmt = $conn->prepare("UPDATE loginaccount SET Password = ? WHERE UserID = ?");
                    $updateStmt->bind_param("si", $hashedPassword, $userId);
                    
                    if ($updateStmt->execute()) {
                        // Log the change
                        $description = "Admin password changed: " . $currentUsername;
                        addSystemLog($conn, "Password Changed", $description, $userFullName);
                        
                        $message = 'Password changed successfully!';
                        $messageType = 'success';
                    } else {
                        $message = 'Error changing password: ' . $updateStmt->error;
                        $messageType = 'error';
                    }
                    $updateStmt->close();
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Settings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, [class*="btn-"], input[type="submit"], input[type="button"] {
            box-shadow: none !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines when expanded */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }

        .settings-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 24px;
        }

        /* Products Header Styles */
        .products-header {
            background: white;
            padding: 20px 28px;
            border-radius: 18px;
            margin: 0 0 24px 0;
            color: #333;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.08);
        }

        .products-header-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header-title-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            background: rgba(250, 206, 11, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #face0b;
        }

        .header-title h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            letter-spacing: -0.5px;
        }

        .settings-card {
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 24px;
            border: 1px solid rgba(0, 0, 0, 0.08);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .settings-card-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(15, 23, 42, 0.08);
        }

        .settings-card-header .icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: rgba(250, 206, 11, 0.2);
            color: #b58500;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .settings-card-header h3 {
            margin: 0;
            font-size: 20px;
            color: #0f172a;
        }

        .settings-card-header p {
            margin: 4px 0 0 0;
            color: #64748b;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #0f172a;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
            box-sizing: border-box;
        }

        .form-group input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 4px rgba(250, 206, 11, 0.15);
        }

        .password-input-wrapper {
            position: relative;
        }

        .password-input-wrapper input {
            padding-right: 45px;
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #64748b;
            cursor: pointer;
            padding: 5px;
            font-size: 16px;
        }

        .toggle-password:hover {
            color: #1e293b;
        }

        .password-requirements {
            margin-top: 10px;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
        }

        .password-requirements small {
            display: block;
            color: #64748b;
            font-size: 12px;
            margin-bottom: 8px;
        }

        .requirement-list {
            list-style: none;
            padding: 0;
            margin: 8px 0 0 0;
        }

        .requirement-list li {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            color: #64748b;
            margin-bottom: 6px;
        }

        .requirement-list li i {
            font-size: 8px;
            color: #cbd5e1;
        }

        .requirement-list li.valid {
            color: #10b981;
        }

        .requirement-list li.valid i {
            color: #10b981;
            font-size: 12px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            border: none;
            padding: 12px 24px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        .btn-primary:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }

        .alert {
            padding: 14px 18px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
        }

        .alert-success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        @media (max-width: 768px) {
            nav.sidebar {
                width: 0;
            }

            nav.sidebar.sidebar-expanded {
                width: 200px;
            }

            main {
                margin-left: 0;
            }

            nav.sidebar.sidebar-expanded ~ main {
                margin-left: 0;
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName ?? 'Administrator'); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

    <main>
        <div class="products-header">
            <div class="products-header-main">
                <div class="header-title">
                    <div class="header-title-icon">
                        <i class="fas fa-user-cog"></i>
                    </div>
                    <h2>Account Settings</h2>
                </div>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <div class="settings-grid">
            <!-- Profile Settings -->
            <div class="settings-card">
                <div class="settings-card-header">
                        <div class="icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <h3>Profile Information</h3>
                            <p>Update your personal information</p>
                        </div>
                    </div>
                    <form method="POST" action="">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-group">
                            <label for="fullName">Full Name</label>
                            <input type="text" id="fullName" name="fullName" value="<?php echo htmlspecialchars($currentFullName); ?>" required pattern="^[A-Za-zÀ-ž\s.'\-]{2,50}$" title="2–50 characters, letters, spaces, basic punctuation only">
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($currentUsername); ?>" required pattern="^[A-Za-z0-9_]{4,20}$" title="4–20 characters, letters, numbers, underscore only">
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($currentEmail); ?>" required pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="Enter a valid email address">
                        </div>
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i> Update Profile
                        </button>
                    </form>
            </div>
            
            <!-- Password Settings -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="icon">
                        <i class="fas fa-lock"></i>
                    </div>
                    <div>
                        <h3>Change Password</h3>
                        <p>Update your account password</p>
                    </div>
                </div>
                <form method="POST" action="" id="passwordForm">
                    <input type="hidden" name="change_password" value="1">
                    <div class="form-group">
                        <label for="currentPassword">Current Password</label>
                        <div class="password-input-wrapper">
                            <input type="password" id="currentPassword" name="currentPassword" required>
                            <button type="button" class="toggle-password" onclick="togglePassword('currentPassword')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="newPassword">New Password</label>
                        <div class="password-input-wrapper">
                            <input type="password" id="newPassword" name="newPassword" required onkeyup="validatePassword()" pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                            <button type="button" class="toggle-password" onclick="togglePassword('newPassword')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-requirements">
                            <small>Password requirements:</small>
                            <ul class="requirement-list">
                                <li id="req-length"><i class="fas fa-circle"></i> At least 6 characters</li>
                                <li id="req-uppercase"><i class="fas fa-circle"></i> One uppercase letter</li>
                                <li id="req-number"><i class="fas fa-circle"></i> One number</li>
                            </ul>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="confirmPassword">Confirm New Password</label>
                        <div class="password-input-wrapper">
                            <input type="password" id="confirmPassword" name="confirmPassword" required onkeyup="checkPasswordMatch()">
                            <button type="button" class="toggle-password" onclick="togglePassword('confirmPassword')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <small id="password-match-indicator" style="color: #64748b; font-size: 12px; margin-top: 6px; display: block;">Enter the same password again</small>
                    </div>
                    <button type="submit" class="btn-primary" id="changePasswordBtn">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </form>
            </div>
        </div>
    </main>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.add('no-transition');
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                setTimeout(() => {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }

            updateSidebarDateTime();
            setInterval(updateSidebarDateTime, 1000);
        });

        function updateSidebarDateTime() {
            const now = new Date();
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', dateOptions);
            const timeStr = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                hour12: true 
            });
            
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            
            if (dateElement) dateElement.textContent = dateStr;
            if (timeElement) timeElement.textContent = timeStr;
        }

        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.parentElement.querySelector('.toggle-password');
            const icon = button.querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        function validatePassword() {
            const password = document.getElementById('newPassword').value;
            const lengthReq = document.getElementById('req-length');
            const upperReq = document.getElementById('req-uppercase');
            const numberReq = document.getElementById('req-number');

            // Check length
            if (password.length >= 6) {
                lengthReq.classList.add('valid');
            } else {
                lengthReq.classList.remove('valid');
            }

            // Check uppercase
            if (/[A-Z]/.test(password)) {
                upperReq.classList.add('valid');
            } else {
                upperReq.classList.remove('valid');
            }

            // Check number
            if (/\d/.test(password)) {
                numberReq.classList.add('valid');
            } else {
                numberReq.classList.remove('valid');
            }
        }

        function checkPasswordMatch() {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            const indicator = document.getElementById('password-match-indicator');

            if (confirmPassword === '') {
                indicator.textContent = 'Enter the same password again';
                indicator.style.color = '#64748b';
            } else if (newPassword === confirmPassword) {
                indicator.textContent = 'Passwords match';
                indicator.style.color = '#10b981';
            } else {
                indicator.textContent = 'Passwords do not match';
                indicator.style.color = '#ef4444';
            }
        }

        function confirmLogout(e) {
            e.preventDefault();
            Swal.fire({
                title: 'Logout Confirmation',
                text: "Are you sure you want to logout?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        }

        // Show success/error messages with SweetAlert
        <?php if ($message): ?>
        Swal.fire({
            icon: '<?php echo $messageType === 'success' ? 'success' : 'error'; ?>',
            title: '<?php echo $messageType === 'success' ? 'Success' : 'Error'; ?>',
            text: '<?php echo addslashes($message); ?>',
            confirmButtonColor: '<?php echo $messageType === 'success' ? '#face0b' : '#d33'; ?>'
        });
        <?php endif; ?>
    </script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>

<?php $conn->close(); ?>
