<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'];
$userQuery->close();

// Initialize date range variables
$startDateInput = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-01'); // Default to the first day of the current month
$endDateInput = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-t'); // Default to the last day of the current month

// Store for display in form
$startDateDisplay = $startDateInput;
$endDateDisplay = $endDateInput;

// Ensure the end date includes the entire day for database query
$startDate = date('Y-m-d 00:00:00', strtotime($startDateInput));
$endDate = date('Y-m-d 23:59:59', strtotime($endDateInput));

// Fetch transaction data based on the selected date range
$transactionQuery = "
    SELECT 
        t.serial_num AS SerialNumber, 
        t.transaction_date AS TransactionDate, 
        t.total_amount AS TotalSales
    FROM 
        transactions t 
    WHERE 
        t.transaction_date BETWEEN ? AND ? 
    ORDER BY 
        t.transaction_date DESC
";
$transactionStmt = $conn->prepare($transactionQuery);
$transactionStmt->bind_param("ss", $startDate, $endDate);
$transactionStmt->execute();
$transactionResult = $transactionStmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, [class*="btn-"], input[type="submit"], input[type="button"] {
            box-shadow: none !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
            color: #1e293b;
        }

/* Sidebar Styles */
nav.sidebar {
    width: 70px;
    background-color: #333;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    overflow-x: hidden;
    overflow-y: auto;
    z-index: 999;
    display: flex;
    flex-direction: column;
    transition: width 0.3s ease;
}

/* Disable transitions on page load */
nav.sidebar.no-transition,
nav.sidebar.no-transition * {
    transition: none !important;
}

nav.sidebar.sidebar-expanded {
    width: 200px;
}

/* Navigation items container - scrollable */
.sidebar-nav-items {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding-top: 20px;
    padding-bottom: 10px;
    min-height: 0; /* Important for flex scrolling */
}

nav.sidebar.sidebar-expanded .sidebar-nav-items {
    overflow-y: auto;
}

/* Custom scrollbar styling */
.sidebar-nav-items::-webkit-scrollbar {
    width: 6px;
}

.sidebar-nav-items::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.2);
}

.sidebar-nav-items::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 3px;
}

.sidebar-nav-items::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.5);
}

.sidebar-logo {
    padding: 20px;
    text-align: center;
    flex-shrink: 0; /* Prevent logo from shrinking */
    margin-bottom: 0;
    cursor: pointer;
}

.sidebar-logo img {
    max-width: 100%;
    height: auto;
    max-height: 40px;
    object-fit: contain;
    margin-bottom: 5px;
    transition: max-height 0.3s ease, margin-bottom 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-logo img {
    max-height: 80px;
    margin-bottom: 10px;
}

.sidebar-logo .restaurant-name {
    color: white;
    font-size: 14px;
    font-weight: 600;
    line-height: 1.4;
    margin-top: 10px;
    transition: all 0.3s ease;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    text-align: center;
    text-align: center;
}

nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
    opacity: 1;
    max-height: 100px;
}

/* Sidebar Footer - Admin Info at Bottom */
.sidebar-footer {
    flex-shrink: 0; /* Prevent footer from shrinking */
    padding: 20px 15px;
    background-color: rgba(0, 0, 0, 0.3);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    text-align: center;
    margin-top: auto; /* Push to bottom */
    transition: all 0.3s ease;
}

.sidebar-footer .cashier-name {
    color: white;
    font-size: 16px;
    font-weight: 500;
    line-height: 1.4;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.sidebar-footer .cashier-name i {
    font-size: 14px;
}

.sidebar-footer .cashier-name span {
    opacity: 0;
    width: 0;
    overflow: hidden;
    transition: all 0.3s ease;
    display: inline-block;
}

nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
    opacity: 1;
    width: auto;
}

.sidebar-footer .sidebar-datetime {
    color: white;
    font-size: 14px;
    line-height: 1.6;
    text-align: center;
    transition: all 0.3s ease;
}

.sidebar-footer .sidebar-datetime #sidebar-date {
    font-weight: 500;
    margin-bottom: 5px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
    opacity: 1;
    max-height: 30px;
}

.sidebar-footer .sidebar-datetime #sidebar-time {
    font-weight: 600;
    color: #face0b;
    font-size: 16px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
    opacity: 1;
    max-height: 30px;
}

nav.sidebar a {
    color: white;
    padding: 14px 0;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    text-align: left;
    padding-left: 20px;
}

nav.sidebar.sidebar-expanded a {
    padding: 14px 20px;
    text-align: left;
    justify-content: flex-start;
}

nav.sidebar a:hover {
    background-color: #ddd;
    color: black;
}

nav.sidebar a.active {
    background-color: #face0b;
    color: black;
}

nav.sidebar a i {
    margin-right: 0;
    width: 20px;
    text-align: center;
    display: inline-block;
}

nav.sidebar.sidebar-expanded a i {
    margin-right: 10px;
}

nav.sidebar a span {
    transition: all 0.3s ease;
    opacity: 0;
    width: 0;
    overflow: hidden;
    display: inline-block;
}

nav.sidebar.sidebar-expanded a span {
    opacity: 1;
    width: auto;
    white-space: normal;
    word-wrap: break-word;
    overflow-wrap: break-word;
    line-height: 1.3;
    max-width: 140px;
    display: inline-block;
}

/* Allow specific long navigation items to wrap to 2 lines */
nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
nav.sidebar.sidebar-expanded a[href*="user_management"] span {
    max-width: 130px;
}

/* Main Content Area */
main {
    margin-left: 90px;
    margin-top: 0;
    padding: 20px;
    flex-grow: 1;
    transition: margin-left 0.3s ease, width 0.3s ease;
    width: calc(100% - 90px);
    box-sizing: border-box;
    position: relative;
    overflow-x: hidden;
}

nav.sidebar.sidebar-expanded ~ main {
    margin-left: 220px;
    width: calc(100% - 220px);
}

/* Disable main content transitions on page load */
nav.sidebar.no-transition ~ main {
    transition: none !important;
}

/* Table styles */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 20px;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background-color: #face0b;
    color: #000;
    font-weight: 600;
}

tbody tr:nth-child(odd) {
    background-color: #f2f2f2;
}

tbody tr:nth-child(even) {
    background-color: #ffffff;
}

tr:hover {
    background-color: #f1f1f1;
}

.button {
    padding: 10px 20px;
    background-color: #333;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    font-size: 14px;
    transition: all 0.3s;
}

.button:hover {
    background-color: #face0b;
    color: #000;
}

.date-selector {
    margin-bottom: 20px;
    display: flex;
    gap: 10px;
    align-items: center;
    flex-wrap: wrap;
}

.date-selector label {
    font-weight: 500;
    color: #333;
}

.date-selector input[type="date"] {
    padding: 8px;
    border: 2px solid #e2e8f0;
    border-radius: 5px;
    font-size: 14px;
}

.date-selector input[type="date"]:focus {
    outline: none;
    border-color: #face0b;
}

.date-selector button[type="submit"] {
    padding: 10px 20px;
    background-color: #333;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    transition: all 0.3s;
}

.date-selector button[type="submit"]:hover {
    background-color: #face0b;
    color: #000;
}

main h2 {
    color: #333;
    margin-bottom: 20px;
    font-size: 28px;
}

table a {
    color: #333;
    text-decoration: none;
    font-weight: 500;
}

table a:hover {
    color: #face0b;
    text-decoration: underline;
}

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: #ffffff;
            margin: 10% auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #face0b;
        }

        .modal-header h3 {
            margin: 0;
            color: #333;
            font-size: 24px;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }

        .close:hover {
            color: #333;
        }

        .modal-body {
            margin-bottom: 20px;
        }

        .modal-form-group {
            margin-bottom: 20px;
        }

        .modal-form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }

        .modal-form-group input[type="date"] {
            width: 100%;
            padding: 10px;
            border: 2px solid #e2e8f0;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .modal-form-group input[type="date"]:focus {
            outline: none;
            border-color: #face0b;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 25px;
        }

        .modal-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .modal-btn-primary {
            background-color: #face0b;
            color: #000;
        }

        .modal-btn-primary:hover {
            background-color: #e6c009;
            transform: translateY(-1px);
        }

        .modal-btn-secondary {
            background-color: #333;
            color: #fff;
        }

        .modal-btn-secondary:hover {
            background-color: #444;
        }

    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="sales_report.php" class="<?php echo isActive('sales_report.php', $currentPage); ?>">
                <i class="fas fa-chart-line"></i>
                <span>Sales Report</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Admin Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>
<main>
    <h2>Sales Report</h2>
    
    <!-- Date Selector Form -->
    <form method="POST" class="date-selector">
        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDateDisplay); ?>">
        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDateDisplay); ?>">
        <button type="submit">Filter</button>
        <button type="button" onclick="generateReport()" class="button">Generate Sales Report</button>
        <button type="button" onclick="generatePresetReport('daily')" class="button">Daily</button>
        <button type="button" onclick="generatePresetReport('weekly')" class="button">Weekly</button>
        <button type="button" onclick="generatePresetReport('monthly')" class="button">Monthly</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Serial Number</th> <!-- Updated header -->
                <th>Transaction Date</th>
                <th>Total Sales</th>
            </tr>
        </thead>
        <tbody>
    <?php while ($row = $transactionResult->fetch_assoc()): ?>
        <tr>
            <td>
                <a href="receipt.php?serial_num=<?php echo urlencode($row['SerialNumber']); ?>">
                    <?php echo htmlspecialchars($row['SerialNumber']); ?>
                </a>
            </td>
            <td><?php echo htmlspecialchars($row['TransactionDate']); ?></td>
            <td><?php echo htmlspecialchars($row['TotalSales']); ?></td>
        </tr>
    <?php endwhile; ?>
</tbody>
    </table>
</main>

<!-- Generate Report Modal -->
<div id="generateReportModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-file-alt"></i> Generate Sales Report</h3>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>
        <div class="modal-body">
            <p style="margin-bottom: 20px; color: #666;">Select the date range for the sales report:</p>
            <div class="modal-form-group">
                <label for="modal_start_date">Start Date:</label>
                <input type="date" id="modal_start_date" name="modal_start_date" required>
            </div>
            <div class="modal-form-group">
                <label for="modal_end_date">End Date:</label>
                <input type="date" id="modal_end_date" name="modal_end_date" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="modal-btn modal-btn-secondary" onclick="closeModal()">Cancel</button>
                <button type="button" class="modal-btn modal-btn-primary" onclick="proceedGenerateReport()">
                    <i class="fas fa-download"></i> Generate Report
                </button>
            </div>
        </div>
    </div>
</div>

<script>
    function confirmLogout(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Logout Confirmation',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#face0b',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../authentication/logout.php';
            }
        });
    }
    
    function generateReport() {
        // Get current date values from the filter form
        const currentStartDate = document.getElementById('start_date').value;
        const currentEndDate = document.getElementById('end_date').value;
        
        // Set default values in modal (use current filter dates or default to current month)
        const modalStartDate = document.getElementById('modal_start_date');
        const modalEndDate = document.getElementById('modal_end_date');
        
        modalStartDate.value = currentStartDate || '<?php echo $startDateDisplay; ?>';
        modalEndDate.value = currentEndDate || '<?php echo $endDateDisplay; ?>';
        
        // Show the modal
        document.getElementById('generateReportModal').style.display = 'block';
    }
    
    function closeModal() {
        document.getElementById('generateReportModal').style.display = 'none';
    }
    
    function proceedGenerateReport() {
        const startDate = document.getElementById('modal_start_date').value;
        const endDate = document.getElementById('modal_end_date').value;
        
        // Validate dates
        if (!startDate || !endDate) {
            alert('Please select both start and end dates.');
            return;
        }
        
        if (startDate > endDate) {
            alert('Start date cannot be later than end date.');
            return;
        }
        
        // Close modal and redirect to generate report
        closeModal();
        window.location.href = `generate_report.php?start_date=${startDate}&end_date=${endDate}`;
    }

    function formatLocalDate(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }

    function generatePresetReport(preset) {
        const startInput = document.getElementById('start_date');
        const endInput = document.getElementById('end_date');
        const referenceValue = (startInput && startInput.value) ? startInput.value : ((endInput && endInput.value) ? endInput.value : '');
        const referenceDate = referenceValue ? new Date(referenceValue + 'T00:00:00') : new Date();

        let startDate;
        let endDate;

        if (preset === 'daily') {
            startDate = new Date(referenceDate);
            endDate = new Date(referenceDate);
        } else if (preset === 'weekly') {
            // Week is Monday-Sunday based on the selected date (or today if none selected)
            const day = referenceDate.getDay(); // 0=Sun..6=Sat
            const diffToMonday = (day === 0) ? -6 : (1 - day);
            startDate = new Date(referenceDate);
            startDate.setDate(referenceDate.getDate() + diffToMonday);
            endDate = new Date(startDate);
            endDate.setDate(startDate.getDate() + 6);
        } else if (preset === 'monthly') {
            startDate = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), 1);
            endDate = new Date(referenceDate.getFullYear(), referenceDate.getMonth() + 1, 0);
        } else {
            // fallback: use current filter values if present
            const s = startInput ? startInput.value : '';
            const e = endInput ? endInput.value : '';
            if (!s || !e) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Please select a date first.'
                });
                return;
            }
            window.location.href = `generate_report.php?start_date=${s}&end_date=${e}`;
            return;
        }

        const s = formatLocalDate(startDate);
        const e = formatLocalDate(endDate);
        window.location.href = `generate_report.php?start_date=${s}&end_date=${e}`;
    }
    
    // Close modal when clicking outside of it
    window.onclick = function(event) {
        const modal = document.getElementById('generateReportModal');
        if (event.target == modal) {
            closeModal();
        }
    }
    
    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeModal();
        }
    });
    
    // Toggle sidebar function
    function toggleSidebar() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('sidebar-expanded');
            // Save state to localStorage
            const isExpanded = sidebar.classList.contains('sidebar-expanded');
            localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
        }
    }
    
    // Restore sidebar state on page load (without transition)
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            // Disable transitions during state restoration
            sidebar.classList.add('no-transition');
            
            const savedState = localStorage.getItem('sidebarExpanded');
            if (savedState === 'true') {
                sidebar.classList.add('sidebar-expanded');
            } else {
                // Default to collapsed (no saved state or explicitly false)
                sidebar.classList.remove('sidebar-expanded');
            }
            
            // Re-enable transitions after a short delay
            setTimeout(function() {
                sidebar.classList.remove('no-transition');
            }, 50);
        }
    });
    
    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        const dateOptions = { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        };
        const timeOptions = { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true
        };
        
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        const timeStr = now.toLocaleTimeString('en-US', timeOptions);
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }
    
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);
</script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>