<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once __DIR__ . '/../config/connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['log_id'])) {
    $logId = (int)$_POST['log_id'];
    
    // Delete the log
    $stmt = $conn->prepare("DELETE FROM system_logs WHERE log_id = ?");
    $stmt->bind_param("i", $logId);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete log']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}
?> 