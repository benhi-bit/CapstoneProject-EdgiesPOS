<?php
session_start();
if (!isset($_SESSION['Username']) || ($_SESSION['Role'] ?? '') !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/backup_helper.php';

$backupDir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'backup';
ensureBackupDir($backupDir);

$backupFiles = glob($backupDir . DIRECTORY_SEPARATOR . '*.sql');
if (!$backupFiles || count($backupFiles) === 0) {
    http_response_code(404);
    echo "No backup files found.\n";
    exit();
}

usort($backupFiles, function ($a, $b) {
    return filemtime($b) <=> filemtime($a);
});

$latest = $backupFiles[0];
$filename = basename($latest);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($latest));
header('Pragma: no-cache');
header('Expires: 0');

readfile($latest);
exit();
?>

