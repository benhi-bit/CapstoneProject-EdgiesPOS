<?php
if ($result->num_rows > 0) {
    $order = $result->fetch_assoc();
    $formattedDate = date('Y-m-d h:i A', strtotime($order['OrderDate']));
    $formattedTotal = '₱' . number_format($order['TotalAmount'], 2);
?>
    <div class="order-details">
        <h3>Order #<?php echo $orderId; ?></h3>
        <p>Date: <?php echo $formattedDate; ?></p>
        <p>Cashier: <?php echo htmlspecialchars($order['Cashier']); ?></p>
        <p>Total Amount: <?php echo $formattedTotal; ?></p>
    </div>
<?php } ?>
