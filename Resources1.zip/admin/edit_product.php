<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Fetch the product details if an ID is provided
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $stmt->close();
}

// Handle form submission for updating the product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $inventoryName = $_POST['inventory_name'];
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];
    $categoryId = $_POST['category_id'];

    $stmt = $conn->prepare("UPDATE inventory SET InventoryName = ?, Price = ?, Quantity = ?, CategoryID = ? WHERE InventoryID = ?");
    $stmt->bind_param("sdiii", $inventoryName, $price, $quantity, $categoryId, $id);
    $stmt->execute();
    $stmt->close();

    header("Location: inventory.php"); // Redirect back to inventory page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
    </style>
</head>
<body>
    <h2>Edit Product</h2>
    <form method="POST" action="">
        <label for="inventory_name">Product Name:</label>
        <input type="text" id="inventory_name" name="inventory_name" value="<?php echo $product['InventoryName']; ?>" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,100}$" title="2–100 characters, letters, numbers, spaces, basic punctuation">
        
        <label for="price">Price:</label>
        <input type="text" id="price" name="price" value="<?php echo $product['Price']; ?>" required placeholder="₱0.00" pattern="^\d+(\.\d{1,2})?$" title="Positive number with up to 2 decimal places" inputmode="decimal">
        
        <label for="quantity">Quantity:</label>
        <input type="number" id="quantity" name="quantity" value="<?php echo $product['Quantity']; ?>" min="0" required pattern="^\d+$" title="Positive whole number">
        
        <label for="category_id">Category:</label>
        <select id="category_id" name="category_id" required>
            <option value="">--Select a Category--</option>
            <?php
            // Fetch categories for the dropdown
            $categoryResult = $conn->query("SELECT * FROM categories");
            while ($category = $categoryResult->fetch_assoc()) {
                $selected = ($category['CategoryID'] == $product['CategoryID']) ? 'selected' : '';
                echo "<option value='{$category['CategoryID']}' $selected>{$category['CategoryName']}</option>";
            }
            ?>
        </select>
        
        <button type="submit" name="update_product">Update Product</button>
    </form>
</body>
</html>

<?php
$conn->close(); // Close the database connection
?>