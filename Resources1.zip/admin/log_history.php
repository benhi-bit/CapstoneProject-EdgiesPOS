<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');

// Initialize variables for filtering and sorting
$search = isset($_POST['search']) ? trim($_POST['search']) : '';
$entries = isset($_POST['entries']) ? $_POST['entries'] : 'all';
$entries = ($entries === 'all') ? PHP_INT_MAX : (int)$entries;
$sortColumn = isset($_POST['sort_column']) ? $_POST['sort_column'] : 'log_timestamp';
$sortDirection = isset($_POST['sort_direction']) ? $_POST['sort_direction'] : 'DESC';
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : '';
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : '';
$actionTypeFilter = isset($_POST['action_type']) ? trim($_POST['action_type']) : '';
$roleFilter = isset($_POST['role']) ? trim($_POST['role']) : '';
$userFilter = isset($_POST['user_fullname']) ? trim($_POST['user_fullname']) : '';

// Build the query
$query = "SELECT l.*, la.Role AS user_role, t.total_amount, t.payment, t.change_amount, t.details as transaction_details 
          FROM system_logs l 
          LEFT JOIN loginaccount la ON la.FullName = l.user_fullname
          LEFT JOIN transactions t ON SUBSTRING_INDEX(SUBSTRING_INDEX(l.description, '#', -1), ' ', 1) = t.transaction_num";
$params = [];
$types = "";
$whereConditions = [];

// Exclude cashier drawer open/close logs from Log History (matches any action/description containing "drawer")
$whereConditions[] = "(LOWER(l.action_type) NOT LIKE '%drawer%' AND LOWER(l.description) NOT LIKE '%drawer%')";

if (!empty($search)) {
    $whereConditions[] = "(l.action_type LIKE ? OR l.description LIKE ? OR l.user_fullname LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam]);
    $types .= "sss";
}

// Action type filtering
if ($actionTypeFilter !== '' && $actionTypeFilter !== 'all') {
    $whereConditions[] = "l.action_type = ?";
    $params[] = $actionTypeFilter;
    $types .= "s";
}

// Role filtering (from joined loginaccount)
if ($roleFilter !== '' && $roleFilter !== 'all') {
    $whereConditions[] = "la.Role = ?";
    $params[] = $roleFilter;
    $types .= "s";
}

// User filtering
if ($userFilter !== '' && $userFilter !== 'all') {
    $whereConditions[] = "l.user_fullname = ?";
    $params[] = $userFilter;
    $types .= "s";
}

// Add date range filtering
if (!empty($startDate)) {
    $whereConditions[] = "DATE(l.log_timestamp) >= ?";
    $params[] = $startDate;
    $types .= "s";
}

if (!empty($endDate)) {
    $whereConditions[] = "DATE(l.log_timestamp) <= ?";
    $params[] = $endDate;
    $types .= "s";
}

// Combine all WHERE conditions
if (!empty($whereConditions)) {
    $query .= " WHERE " . implode(' AND ', $whereConditions);
}

// Add sorting
$allowedColumns = ['log_timestamp', 'action_type', 'user_fullname', 'user_role'];
$sortColumn = in_array($sortColumn, $allowedColumns) ? $sortColumn : 'log_timestamp';
$sortDirection = in_array(strtoupper($sortDirection), ['ASC', 'DESC']) ? $sortDirection : 'DESC';

// Map sort column to proper table/alias reference
$sortColumnMap = [
    'log_timestamp' => 'l.log_timestamp',
    'action_type' => 'l.action_type',
    'user_fullname' => 'l.user_fullname',
    'user_role' => 'user_role' // This is an alias, so use it directly
];
$sortColumnRef = isset($sortColumnMap[$sortColumn]) ? $sortColumnMap[$sortColumn] : 'l.log_timestamp';
$query .= " ORDER BY $sortColumnRef $sortDirection";

// Add limit
if ($entries !== PHP_INT_MAX) {
    $query .= " LIMIT ?";
    $params[] = $entries;
    $types .= "i";
}

// Prepare and execute the query
$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$actionTypes = [];
$actionTypeStmt = $conn->prepare("SELECT DISTINCT action_type FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') ORDER BY action_type ASC");
if ($actionTypeStmt && $actionTypeStmt->execute()) {
    $actionTypeRes = $actionTypeStmt->get_result();
    while ($row = $actionTypeRes->fetch_assoc()) {
        $actionTypes[] = $row['action_type'];
    }
}
if ($actionTypeStmt) {
    $actionTypeStmt->close();
}

$roles = [];
$rolesRes = $conn->query("SELECT DISTINCT Role FROM loginaccount WHERE Role IS NOT NULL AND Role <> '' ORDER BY Role ASC");
if ($rolesRes) {
    while ($row = $rolesRes->fetch_assoc()) {
        $roles[] = $row['Role'];
    }
    $rolesRes->free();
}

$users = [];
$usersStmt = $conn->prepare("SELECT DISTINCT user_fullname FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') ORDER BY user_fullname ASC");
if ($usersStmt && $usersStmt->execute()) {
    $usersRes = $usersStmt->get_result();
    while ($row = $usersRes->fetch_assoc()) {
        $users[] = $row['user_fullname'];
    }
}
if ($usersStmt) {
    $usersStmt->close();
}

$productPrices = [];
$productPriceQuery = "SELECT InventoryName, Price FROM inventory";
if ($productPriceResult = $conn->query($productPriceQuery)) {
    while ($priceRow = $productPriceResult->fetch_assoc()) {
        $nameKey = strtolower(trim($priceRow['InventoryName']));
        if ($nameKey !== '') {
            $productPrices[$nameKey] = (float)$priceRow['Price'];
        }
    }
    $productPriceResult->free();
}

// Get total number of logs for statistics
$totalLogsQuery = "SELECT COUNT(*) as total FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%')";
$totalLogs = $conn->query($totalLogsQuery)->fetch_assoc()['total'];

// Get today's logs count
$todayLogsQuery = "SELECT COUNT(*) as today FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND DATE(log_timestamp) = CURDATE()";
$todayLogs = $conn->query($todayLogsQuery)->fetch_assoc()['today'];

// Get this week's logs count
$weekLogsQuery = "SELECT COUNT(*) as week FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND YEARWEEK(log_timestamp) = YEARWEEK(NOW())";
$weekLogs = $conn->query($weekLogsQuery)->fetch_assoc()['week'];

// Get this month's logs count
$monthLogsQuery = "SELECT COUNT(*) as month FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND MONTH(log_timestamp) = MONTH(NOW()) AND YEAR(log_timestamp) = YEAR(NOW())";
$monthLogs = $conn->query($monthLogsQuery)->fetch_assoc()['month'];

// Handle AJAX requests for new logs and stats
if (isset($_GET['action'])) {
    header('Content-Type: application/json');
    
    if ($_GET['action'] === 'fetch_logs' && isset($_GET['lastLogId'])) {
        $lastLogId = intval($_GET['lastLogId']);
        
        $query = "SELECT l.*, la.Role AS user_role, t.total_amount, t.payment, t.change_amount, t.details as transaction_details 
                  FROM system_logs l 
                  LEFT JOIN loginaccount la ON la.FullName = l.user_fullname
                  LEFT JOIN transactions t ON SUBSTRING_INDEX(SUBSTRING_INDEX(l.description, '#', -1), ' ', 1) = t.transaction_num
                  WHERE l.log_id > ?
                  AND (LOWER(l.action_type) NOT LIKE '%drawer%' AND LOWER(l.description) NOT LIKE '%drawer%')
                  ORDER BY l.log_timestamp DESC";

        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $lastLogId);
        $stmt->execute();
        $result = $stmt->get_result();

$newLogs = [];
        while ($row = $result->fetch_assoc()) {
            $transactionNumber = null;
            if (!empty($row['description']) && preg_match('/Transaction\s*#(\d+)/i', $row['description'], $matches)) {
                $transactionNumber = str_pad($matches[1], 8, '0', STR_PAD_LEFT);
            }

            $newLogs[] = [
        'log_id' => $row['log_id'],
        'action_type' => $row['action_type'],
        'description' => $row['description'],
        'user_fullname' => $row['user_fullname'],
        'user_role' => $row['user_role'],
        'log_timestamp' => date('Y-m-d h:i A', strtotime($row['log_timestamp'])),
        'transaction_details_base64' => $row['transaction_details'] ? base64_encode($row['transaction_details']) : '',
                'transaction_num' => $transactionNumber,
        'total_amount' => $row['total_amount'],
        'payment' => $row['payment'],
        'change_amount' => $row['change_amount']
    ];
        }
        
        echo json_encode(['logs' => $newLogs]);
        exit();
    }
    
    if ($_GET['action'] === 'get_stats') {
        // Get total number of logs
        $totalLogsQuery = "SELECT COUNT(*) as total FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%')";
        $totalLogs = $conn->query($totalLogsQuery)->fetch_assoc()['total'];

        // Get today's logs count
        $todayLogsQuery = "SELECT COUNT(*) as today FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND DATE(log_timestamp) = CURDATE()";
        $todayLogs = $conn->query($todayLogsQuery)->fetch_assoc()['today'];

        // Get this week's logs count
        $weekLogsQuery = "SELECT COUNT(*) as week FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND YEARWEEK(log_timestamp) = YEARWEEK(NOW())";
        $weekLogs = $conn->query($weekLogsQuery)->fetch_assoc()['week'];

        // Get this month's logs count
        $monthLogsQuery = "SELECT COUNT(*) as month FROM system_logs WHERE (LOWER(action_type) NOT LIKE '%drawer%' AND LOWER(description) NOT LIKE '%drawer%') AND MONTH(log_timestamp) = MONTH(NOW()) AND YEAR(log_timestamp) = YEAR(NOW())";
        $monthLogs = $conn->query($monthLogsQuery)->fetch_assoc()['month'];

        echo json_encode([
            'today' => $todayLogs,
            'week' => $weekLogs,
            'month' => $monthLogs,
            'total' => $totalLogs
        ]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log History</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }


        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .dashboard-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .dashboard-card.active {
            background-color: #face0b;
            color: black;
        }

        .dashboard-card.active .number {
            color: black;
        }

        .dashboard-card h3 {
            margin: 0;
            color: #333;
        }

        .dashboard-card .number {
            font-size: 2em;
            font-weight: bold;
            color: #face0b;
            margin: 10px 0;
        }

        .search-section {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .search-form {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }

        .search-container {
            position: relative;
            display: inline-block;
            flex: 1;
            min-width: 200px;
        }

        .search-container i,
        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            pointer-events: none;
            z-index: 1;
        }

        .search-container input[type="text"],
        .search-form input[type="text"] {
            padding: 10px 14px 10px 35px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            width: 100%;
            background: white;
            color: #333;
            box-sizing: border-box;
        }

        .search-container input[type="text"]:focus,
        .search-form input[type="text"]:focus {
            outline: none;
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }

        .search-form select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 15px;
        }

        .search-form label {
            font-weight: bold;
            color: #333;
            font-size: 14px;
            white-space: nowrap;
        }

        .search-form input[type="date"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 15px;
            font-size: 14px;
            cursor: pointer;
        }

        .search-form input[type="date"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 5px rgba(250, 206, 11, 0.3);
        }

        .search-form button[type="submit"],
        .search-form button[type="button"] {
            padding: 8px 16px;
            background: linear-gradient(135deg, #333, #444);
            color: white;
            border: none;
            border-radius: 999px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            white-space: nowrap;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.25);
        }

        .search-form button[type="submit"] i,
        .search-form button[type="button"] i {
            font-size: 13px;
        }

        .search-form button[type="submit"]:hover {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        .search-form button[type="button"]:hover {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
        }

        .table-container {
            max-height: calc(100vh - 260px);
            overflow-y: auto;
            margin-top: 20px;
            border-radius: 12px;
        }

        #logsTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            margin-top: 0;
            background: transparent;
        }

        #logsTable thead {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #333;
            transform: translateZ(0);
            isolation: isolate;
        }

        #logsTable thead tr {
            background: #333;
        }

        #logsTable th {
            background-color: #333 !important;
            color: #ffffff;
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            cursor: pointer;
            border: none;
            position: relative;
            white-space: nowrap;
            transition: background-color 0.3s ease;
            box-shadow: 0 4px 0 0 #333;
            border-bottom: 4px solid #333;
        }

        #logsTable th:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 0;
        }

        #logsTable th:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 0;
        }

        #logsTable th:hover {
            background-color: #444;
        }

        #logsTable tbody {
            position: relative;
            z-index: 1;
        }

        #logsTable tbody tr {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            margin-bottom: 12px;
        }

        #logsTable tbody tr:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
            background: #ffffff;
        }

        #logsTable td {
            padding: 18px 20px;
            text-align: left;
            font-size: 15px;
            color: #1e293b;
            border: none;
            vertical-align: middle;
        }

        #logsTable tbody tr td:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 12px;
        }

        #logsTable tbody tr td:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        .sort-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 0 5px;
            color: #666;
        }

        .sort-btn:hover {
            color: #333;
        }

        .sort-btn.active {
            color: #000;
        }

        @media screen and (max-width: 768px) {
            main {
                margin-left: 0;
                width: 100%;
            }
            
            
            nav.sidebar {
                display: none;
            }

            .dashboard-container {
                grid-template-columns: 1fr;
            }

            #logsTable {
                min-width: 600px;
            }

            #logsTable th,
            #logsTable td {
                padding: 12px 10px;
                font-size: 13px;
            }

            #logsTable th {
                font-size: 12px;
                padding: 10px 8px;
            }

            /* Make table scrollable on mobile */
            main {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
            transition: opacity 0.3s ease;
            opacity: 0;
            pointer-events: none;
        }

        .modal.show {
            display: flex;
            opacity: 1;
            pointer-events: auto;
            animation: modalFadeIn 0.3s;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: #ffffff;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            border-radius: 15px;
            position: relative;
            box-shadow: 0 8px 32px rgba(0,0,0,0.18);
            animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .modal-content.modal-modern {
            padding: 0;
            border: none;
            overflow: hidden;
            background: #f5f5f5;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
            max-width: 720px;
        }

        .modal-header {
            background: #333;
            color: #fff;
            padding: 28px 32px;
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .modal-header .modal-icon {
            width: 54px;
            height: 54px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.14);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 26px;
            color: #fff;
        }

        .modal-header p {
            margin: 4px 0 0;
            color: rgba(255, 255, 255, 0.88);
            font-size: 15px;
        }

        .modal-body {
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 24px;
            max-height: calc(90vh - 160px);
            overflow-y: auto;
        }

        .modal-body::-webkit-scrollbar {
            width: 8px;
        }

        .modal-body::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb {
            background: rgba(51, 51, 51, 0.3);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb:hover {
            background: rgba(51, 51, 51, 0.5);
        }

        .section-card {
            background: #fff;
            border-radius: 18px;
            padding: 20px 22px 24px;
            border: 1px solid rgba(15, 23, 42, 0.08);
            box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 18px;
        }

        .section-header .section-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(250, 206, 11, 0.2);
            color: #b58500;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .section-header h3 {
            margin: 0;
            font-size: 18px;
            color: #0f172a;
        }

        .section-header p {
            display: none;
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .modal-actions .btn-secondary,
        .modal-actions .btn-primary {
            padding: 8px 16px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .modal-actions .btn-secondary {
            background: rgba(0, 0, 0, 0.1);
            color: #333;
        }

        .modal-actions .btn-secondary:hover {
            background: rgba(0, 0, 0, 0.2);
            transform: translateY(-1px);
        }

        .modal-actions .btn-primary {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        .modal-actions .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        .receipt-modal-body .transaction-info {
            color: #333;
            font-size: 14px;
            line-height: 1.8;
        }

        .receipt-modal-body .transaction-info p {
            margin: 10px 0;
            color: #333;
        }

        .receipt-modal-body .transaction-info strong {
            color: #333;
            font-weight: 600;
        }

        .receipt-modal-body .transaction-info span {
            color: #333;
            font-weight: 500;
        }

        .receipt-modal-body .order-items table {
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0 0;
        }

        .receipt-modal-body .order-items th,
        .receipt-modal-body .order-items td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            font-size: 14px;
        }

        .receipt-modal-body .order-items th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        .receipt-modal-body .order-items td {
            color: #333;
        }

        .receipt-modal-body .order-items tbody tr:last-child td {
            border-bottom: none;
        }

        .order-summary-card .order-summary {
            text-align: right;
        }

        .order-summary-card .order-summary p {
            margin: 8px 0;
            font-size: 14px;
            color: #333;
        }

        .order-summary-card .order-summary strong {
            color: #333;
            font-weight: 600;
        }

        .order-summary-card .order-summary span {
            color: #333;
            font-weight: 500;
            margin-left: 8px;
        }

        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .close {
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 12px;
            right: 18px;
            cursor: pointer;
            transition: color 0.3s;
            z-index: 10;
        }

        .close:hover,
        .close:focus {
            color: rgba(255, 255, 255, 0.7);
        }

        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ddd;
        }

        .receipt-content {
            padding: 20px;
        }

        .transaction-info {
            margin-bottom: 20px;
        }

        .transaction-info p {
            margin: 5px 0;
        }

        .order-items table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        .order-items th,
        .order-items td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .order-items th {
            background-color: white;
            font-weight: bold;
        }

        .order-summary {
            text-align: right;
            margin-top: 20px;
            padding-top: 10px;
            border-top: 1px solid #ddd;
        }

        h1, h2 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        .order-summary p {
            margin: 8px 0;
            font-size: 16px;
        }

        .order-summary p:last-child {
            color: #2ecc71;
            font-weight: bold;
            font-size: 18px;
        }

        button {
            padding: 8px 12px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #face0b;
        }

        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: flex-start;
            align-items: center;
        }

        .view-btn, .delete-btn {
            padding: 8px 16px;
            border: none;
            border-radius: 999px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            font-size: 13px;
            font-weight: 600;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
        }

        .view-btn {
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            box-shadow: 0 8px 18px rgba(52, 152, 219, 0.35);
        }

        .view-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(52, 152, 219, 0.45);
        }

        .delete-btn {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            color: white;
            box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
        }

        .delete-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
        }

        td .fas {
            font-size: 14px;
        }

        td .view-btn {
            margin-left: 10px;
            padding: 4px 8px;
            font-size: 12px;
            vertical-align: middle;
            display: inline-flex;
            align-items: center;
        }

        td .view-btn i {
            font-size: 12px;
            margin-right: 4px;
        }

        /* Receipt Modal Styles */
        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: flex-start;
            align-items: center;
        }
        /* Search bar: same as User Management */
        .search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
            padding: 10px 14px 10px 40px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px !important;
            outline: none !important;
        }
        .search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
        }
        .search-container { position: relative; }
        .search-container .input-with-icon { position: relative; }
        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

    <main>
        <h2>System Log History</h2>

        <div class="dashboard-container">
            <div class="dashboard-card" onclick="filterByDate('today')" id="card-today" title="Click to filter today's logs">
                <h3>Today's Logs</h3>
                <div class="number"><?php echo $todayLogs; ?></div>
            </div>
            <div class="dashboard-card" onclick="filterByDate('week')" id="card-week" title="Click to filter this week's logs">
                <h3>This Week's Logs</h3>
                <div class="number"><?php echo $weekLogs; ?></div>
            </div>
            <div class="dashboard-card" onclick="filterByDate('month')" id="card-month" title="Click to filter this month's logs">
                <h3>This Month's Logs</h3>
                <div class="number"><?php echo $monthLogs; ?></div>
            </div>
            <div class="dashboard-card" onclick="filterByDate('all')" id="card-all" title="Click to show all logs">
                <h3>Total Logs</h3>
                <div class="number"><?php echo $totalLogs; ?></div>
            </div>
        </div>

        <div class="search-section">
            <form method="POST" class="search-form" id="searchForm">
                <input type="hidden" name="sort_column" id="sortColumn" value="<?php echo htmlspecialchars($sortColumn); ?>">
                <input type="hidden" name="sort_direction" id="sortDirection" value="<?php echo htmlspecialchars($sortDirection); ?>">
                
                <div class="search-container">
                    <div class="input-with-icon">
                        <i class="fas fa-search"></i>
                        <input type="text" name="search" placeholder="Search logs..." value="<?php echo htmlspecialchars($search); ?>" id="searchInput">
                    </div>
                </div>
                
                <label for="start_date">Start Date:</label>
                <input type="date" name="start_date" id="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                
                <label for="end_date">End Date:</label>
                <input type="date" name="end_date" id="end_date" value="<?php echo htmlspecialchars($endDate); ?>">

                <select name="action_type" id="actionTypeSelect" onchange="this.form.submit()">
                    <option value="all" <?php echo ($actionTypeFilter === '' || $actionTypeFilter === 'all') ? 'selected' : ''; ?>>All actions</option>
                    <?php foreach ($actionTypes as $type): ?>
                        <option value="<?php echo htmlspecialchars($type, ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($actionTypeFilter === $type) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($type, ENT_QUOTES, 'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="role" id="roleSelect" onchange="this.form.submit()">
                    <option value="all" <?php echo ($roleFilter === '' || $roleFilter === 'all') ? 'selected' : ''; ?>>All roles</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo htmlspecialchars($role, ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($roleFilter === $role) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($role, ENT_QUOTES, 'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="user_fullname" id="userSelect" onchange="this.form.submit()">
                    <option value="all" <?php echo ($userFilter === '' || $userFilter === 'all') ? 'selected' : ''; ?>>All users</option>
                    <?php foreach ($users as $userName): ?>
                        <option value="<?php echo htmlspecialchars($userName, ENT_QUOTES, 'UTF-8'); ?>" <?php echo ($userFilter === $userName) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($userName, ENT_QUOTES, 'UTF-8'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <select name="entries" id="entriesSelect" onchange="this.form.submit()">
                    <option value="10" <?php echo $entries == 10 ? 'selected' : ''; ?>>10 entries</option>
                    <option value="25" <?php echo $entries == 25 ? 'selected' : ''; ?>>25 entries</option>
                    <option value="50" <?php echo $entries == 50 ? 'selected' : ''; ?>>50 entries</option>
                    <option value="100" <?php echo $entries == 100 ? 'selected' : ''; ?>>100 entries</option>
                    <option value="all" <?php echo $entries === PHP_INT_MAX ? 'selected' : ''; ?>>All logs</option>
                </select>
                
                <button type="submit"><i class="fas fa-filter"></i> Filter</button>
                <button type="button" onclick="clearFilters()"><i class="fas fa-times"></i> Clear</button>
            </form>
        </div>

        <div class="table-container">
        <table id="logsTable">
            <thead>
                <tr>
                    <th>
                        <div class="column-header">
                            Action Type
                            <button onclick="sortTable('action_type')" class="sort-btn" data-column="action_type">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                    <th>Description</th>
                    <th>
                        <div class="column-header">
                            User
                            <button onclick="sortTable('user_fullname')" class="sort-btn" data-column="user_fullname">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                    <th>
                        <div class="column-header">
                            Role
                            <button onclick="sortTable('user_role')" class="sort-btn" data-column="user_role">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                    <th>
                        <div class="column-header">
                            Timestamp
                            <button onclick="sortTable('log_timestamp')" class="sort-btn" data-column="log_timestamp">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <?php
                        $logTimestamp = date('Y-m-d h:i A', strtotime($row['log_timestamp']));
                        $transactionNumber = null;
                        if (!empty($row['description']) && preg_match('/Transaction\s*#(\d+)/i', $row['description'], $matches)) {
                            $transactionNumber = str_pad($matches[1], 8, '0', STR_PAD_LEFT);
                        }
                    ?>
                    <tr data-log-id="<?php echo (int)$row['log_id']; ?>">
                        <td><?php echo htmlspecialchars($row['action_type']); ?></td>
                        <td>
                            <?php echo htmlspecialchars($row['description']); ?>
                            <?php if ($row['action_type'] === 'POS Transaction' && !empty($row['transaction_details'])): ?>
                                <?php
                                    $detailsBase64 = base64_encode($row['transaction_details']);
                                    $totalAmount = isset($row['total_amount']) ? (float)$row['total_amount'] : 0;
                                    $payment = isset($row['payment']) ? (float)$row['payment'] : 0;
                                    $changeAmount = isset($row['change_amount']) ? (float)$row['change_amount'] : 0;
                                ?>
                                <button type="button"
                                        class="view-btn"
                                        data-details="<?php echo htmlspecialchars($detailsBase64, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-transaction="<?php echo htmlspecialchars($transactionNumber ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?>"
                                        data-date="<?php echo htmlspecialchars($logTimestamp, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-total="<?php echo htmlspecialchars($totalAmount, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-payment="<?php echo htmlspecialchars($payment, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-change="<?php echo htmlspecialchars($changeAmount, ENT_QUOTES, 'UTF-8'); ?>"
                                        data-cashier="<?php echo htmlspecialchars($row['user_fullname'] ?? 'N/A', ENT_QUOTES, 'UTF-8'); ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                        <td><?php echo htmlspecialchars($row['user_role'] ?? 'N/A'); ?></td>
                        <td><?php echo $logTimestamp; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </main>

    <!-- Transaction Details Modal -->
    <div id="receiptModal" class="modal">
        <div class="modal-content modal-modern">
            <span class="close" onclick="closeModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <h2>Transaction Details</h2>
                    <p>View complete transaction information and itemized receipt</p>
                </div>
            </div>
            <div class="modal-body receipt-modal-body">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-info-circle"></i>
                        </div>
                        <div>
                            <h3>Summary</h3>
                        </div>
                    </div>
                    <div class="transaction-info">
                        <p><strong>Transaction Number:</strong> <span id="modalTransactionNum"></span></p>
                        <p><strong>Date:</strong> <span id="modalTransactionDate"></span></p>
                        <p><strong>Cashier:</strong> <span id="modalCashier"></span></p>
                    </div>
                </div>
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-list"></i>
                        </div>
                        <div>
                            <h3>Ordered Items</h3>
                        </div>
                    </div>
                    <div class="order-items">
                        <table>
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody id="modalItemsBody"></tbody>
                        </table>
                    </div>
                </div>
                <div class="section-card order-summary-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div>
                            <h3>Payment Summary</h3>
                        </div>
                    </div>
                    <div class="order-summary">
                        <p><strong>Total Amount:</strong> <span id="modalTotalAmount"></span></p>
                        <p><strong>Amount Paid:</strong> <span id="modalAmountPaid"></span></p>
                        <p><strong>Change:</strong> <span id="modalChange"></span></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        const productPriceMap = <?php echo json_encode($productPrices, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;

        function formatCurrency(value) {
            const numeric = Number(value);
            const safeValue = Number.isFinite(numeric) ? numeric : 0;
            return '₱ ' + safeValue.toLocaleString('en-US', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function getInventoryPrice(name) {
            if (!name) {
                return 0;
            }
            const key = name.trim().toLowerCase();
            if (!key) {
                return 0;
            }
            const value = Object.prototype.hasOwnProperty.call(productPriceMap, key)
                ? Number(productPriceMap[key])
                : 0;
            return Number.isFinite(value) ? value : 0;
        }

        function parseTransactionDetails(detailsBase64) {
            let decoded = '';
            try {
                const binary = atob(detailsBase64 || '');
                const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
                const decoder = new TextDecoder();
                decoded = decoder.decode(bytes);
            } catch (error) {
                try {
                    decoded = atob(detailsBase64 || '');
                } catch (fallbackError) {
                    decoded = detailsBase64 || '';
                }
            }

            let items = [];
            let cashier = null;

            const normalizeItems = parsedItems => parsedItems
                .map(entry => {
                    const name = typeof entry.name === 'string' && entry.name.trim() !== '' ? entry.name.trim() : 'Unknown item';
                    const quantity = Number(entry.quantity) || 0;
                    let price = Number(entry.price) || 0;
                    if (!price && typeof entry.total !== 'undefined') {
                        const entryTotal = Number(entry.total) || 0;
                        price = quantity > 0 ? entryTotal / quantity : 0;
                    }
                    if (!price) {
                        price = getInventoryPrice(name);
                    }
                    return quantity > 0 ? { name, quantity, price } : null;
                })
                .filter(Boolean);

            try {
                const parsed = JSON.parse(decoded);
                if (Array.isArray(parsed)) {
                    items = normalizeItems(parsed);
                } else if (parsed && Array.isArray(parsed.items)) {
                    items = normalizeItems(parsed.items);
                    cashier = typeof parsed.cashier === 'string' ? parsed.cashier.trim() : null;
                }
            } catch (jsonError) {
                // Continue to fallback parsing
            }

            if (!items.length) {
                const segments = decoded
                    .split(',')
                    .map(segment => segment.trim())
                    .filter(segment => segment.length > 0);

                if (segments.length) {
                    const lastSegment = segments[segments.length - 1];
                    if (/cashier\s*:/.test((lastSegment || '').toLowerCase())) {
                        cashier = lastSegment.replace(/cashier\s*:/i, '').trim();
                        segments.pop();
                    } else if (!cashier) {
                        cashier = lastSegment;
                        segments.pop();
                    }
                }

                items = segments
                    .map(segment => {
                        const regex = /(.*?)\(\s*(\d+)\s*(?:x\s*([\d.]+))?\s*\)/i;
                        const match = segment.match(regex);
                        if (!match) {
                            return null;
                        }
                        const name = match[1].trim();
                        const quantity = Number(match[2]) || 0;
                        let price = Number(match[3]) || 0;
                        if (!price) {
                            price = getInventoryPrice(name);
                        }
                        return quantity > 0 ? { name, quantity, price } : null;
                    })
                    .filter(Boolean);
            }

            return {
                items,
                cashier: cashier && cashier.trim() !== '' ? cashier : 'N/A',
                raw: decoded
            };
        }

        function handleViewDetails(button) {
            const detailsBase64 = button.getAttribute('data-details') || '';
            const transactionNum = button.getAttribute('data-transaction') || 'N/A';
            const transactionDate = button.getAttribute('data-date') || '';
            const totalAmount = Number(button.getAttribute('data-total')) || 0;
            const payment = Number(button.getAttribute('data-payment')) || 0;
            const changeAmount = Number(button.getAttribute('data-change')) || 0;
            const cashierName = button.getAttribute('data-cashier') || 'N/A';
            showTransactionDetails(detailsBase64, transactionNum, transactionDate, totalAmount, payment, changeAmount, cashierName);
        }

        document.addEventListener('click', function(event) {
            const viewButton = event.target.closest('.view-btn');
            if (viewButton) {
                event.preventDefault();
                handleViewDetails(viewButton);
            }
        });

        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                // Save state to localStorage
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }
        
        // Restore sidebar state on page load (without transition)
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                // Disable transitions during state restoration
                sidebar.classList.add('no-transition');
                
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                
                // Re-enable transitions after a short delay
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }
        });

        function confirmLogout(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Logout Confirmation',
                text: "Are you sure you want to logout?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        }

        // Update sidebar date and time
        function updateSidebarDateTime() {
            const now = new Date();
            
            // Format date: Day, Month DD, YYYY
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', dateOptions);
            
            // Format time: HH:MM:SS AM/PM
            const timeStr = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                hour12: true 
            });
            
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            
            if (dateElement) {
                dateElement.textContent = dateStr;
            }
            if (timeElement) {
                timeElement.textContent = timeStr;
            }
        }

        // Update immediately and then every second
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        let currentSort = {
            column: '<?php echo $sortColumn; ?>',
            order: '<?php echo $sortDirection; ?>'
        };

        function updateSortIcon(column) {
            document.querySelectorAll('.sort-btn').forEach(btn => {
                btn.classList.remove('active');
                btn.querySelector('i').className = 'fas fa-sort';
            });
            
            const currentBtn = document.querySelector(`button[data-column="${column}"]`);
            if (currentBtn) {
                currentBtn.classList.add('active');
                const icon = currentBtn.querySelector('i');
                icon.className = currentSort.order === 'ASC' ? 'fas fa-sort-up' : 'fas fa-sort-down';
            }
        }

        function sortTable(column) {
            if (currentSort.column === column) {
                currentSort.order = currentSort.order === 'ASC' ? 'DESC' : 'ASC';
            } else {
                currentSort.column = column;
                currentSort.order = 'ASC';
            }
            
            document.getElementById('sortColumn').value = column;
            document.getElementById('sortDirection').value = currentSort.order;
            document.getElementById('searchForm').submit();
        }

        function clearFilters() {
            document.getElementById('searchForm').querySelector('input[name="search"]').value = '';
            document.getElementById('start_date').value = '';
            document.getElementById('end_date').value = '';
            const actionTypeSelect = document.getElementById('actionTypeSelect');
            if (actionTypeSelect) actionTypeSelect.value = 'all';
            const roleSelect = document.getElementById('roleSelect');
            if (roleSelect) roleSelect.value = 'all';
            const userSelect = document.getElementById('userSelect');
            if (userSelect) userSelect.value = 'all';
            document.getElementById('searchForm').querySelector('select[name="entries"]').value = '10';
            document.getElementById('sortColumn').value = 'log_timestamp';
            document.getElementById('sortDirection').value = 'DESC';
            removeActiveCard();
            document.getElementById('searchForm').submit();
        }

        function formatLocalDate(date) {
            const y = date.getFullYear();
            const m = String(date.getMonth() + 1).padStart(2, '0');
            const d = String(date.getDate()).padStart(2, '0');
            return `${y}-${m}-${d}`;
        }

        function filterByDate(period) {
            const startDateInput = document.getElementById('start_date');
            const endDateInput = document.getElementById('end_date');
            const today = new Date();
            
            // Remove active class from all cards
            removeActiveCard();
            
            // Set active class on clicked card
            const cardId = 'card-' + period;
            const card = document.getElementById(cardId);
            if (card) {
                card.classList.add('active');
            }
            
            // Clear search input
            document.getElementById('searchInput').value = '';
            
            // Preserve current sort settings (don't reset them)
            // The sortColumn and sortDirection hidden inputs already have the current values
            
            // Set date range based on period
            switch(period) {
                case 'today':
                    const todayStr = formatLocalDate(today);
                    startDateInput.value = todayStr;
                    endDateInput.value = todayStr;
                    break;
                case 'week':
                    const weekStart = new Date(today);
                    weekStart.setDate(today.getDate() - today.getDay()); // Start of week (Sunday)
                    const weekEnd = new Date(weekStart);
                    weekEnd.setDate(weekStart.getDate() + 6); // End of week (Saturday)
                    startDateInput.value = formatLocalDate(weekStart);
                    endDateInput.value = formatLocalDate(weekEnd);
                    break;
                case 'month':
                    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
                    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
                    startDateInput.value = formatLocalDate(monthStart);
                    endDateInput.value = formatLocalDate(monthEnd);
                    break;
                case 'all':
                    startDateInput.value = '';
                    endDateInput.value = '';
                    break;
            }
            
            // Submit the form (sort settings are preserved in hidden inputs)
            document.getElementById('searchForm').submit();
        }

        function removeActiveCard() {
            document.querySelectorAll('.dashboard-card').forEach(card => {
                card.classList.remove('active');
            });
        }

        // Set active card on page load based on current filters
        document.addEventListener('DOMContentLoaded', function() {
            // Update sort icon
            updateSortIcon(currentSort.column);
            
            // Set active card based on current date filters
            const startDate = document.getElementById('start_date').value;
            const endDate = document.getElementById('end_date').value;
            const today = formatLocalDate(new Date());
            
            if (startDate && endDate) {
                if (startDate === today && endDate === today) {
                    document.getElementById('card-today').classList.add('active');
                } else {
                    // Check if it's this week
                    const weekStart = new Date();
                    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
                    const weekEnd = new Date(weekStart);
                    weekEnd.setDate(weekStart.getDate() + 6);
                    const weekStartStr = formatLocalDate(weekStart);
                    const weekEndStr = formatLocalDate(weekEnd);
                    
                    if (startDate === weekStartStr && endDate === weekEndStr) {
                        document.getElementById('card-week').classList.add('active');
                    } else {
                        // Check if it's this month
                        const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
                        const monthEnd = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
                        const monthStartStr = formatLocalDate(monthStart);
                        const monthEndStr = formatLocalDate(monthEnd);
                        
                        if (startDate === monthStartStr && endDate === monthEndStr) {
                            document.getElementById('card-month').classList.add('active');
                        }
                    }
                }
            } else if (!startDate && !endDate) {
                document.getElementById('card-all').classList.add('active');
            }
        });

        function showTransactionDetails(detailsBase64, transactionNum, transactionDate, totalAmount, payment, changeAmount, cashierName) {
            const parsedDetails = parseTransactionDetails(detailsBase64);
            const items = parsedDetails.items;
            const cashier = (cashierName && cashierName.trim() !== '' && cashierName !== 'N/A') ? cashierName : parsedDetails.cashier;

            document.getElementById('modalTransactionNum').textContent = transactionNum;
            document.getElementById('modalTransactionDate').textContent = transactionDate;
            document.getElementById('modalCashier').textContent = cashier;
            document.getElementById('modalTotalAmount').textContent = formatCurrency(totalAmount);
            document.getElementById('modalAmountPaid').textContent = formatCurrency(payment);
            document.getElementById('modalChange').textContent = formatCurrency(changeAmount);

            const itemsBody = document.getElementById('modalItemsBody');
            itemsBody.innerHTML = '';

            items.forEach(item => {
                const unitPrice = Number(item.price) || 0;
                const subtotal = unitPrice * item.quantity;
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.name}</td>
                    <td>${item.quantity}</td>
                    <td>${formatCurrency(unitPrice)}</td>
                    <td>${formatCurrency(subtotal)}</td>
                `;
                itemsBody.appendChild(row);
            });

            const modal = document.getElementById('receiptModal');
            modal.style.display = "flex";
            modal.classList.add('show');
        }

        function closeModal() {
            const modal = document.getElementById('receiptModal');
            modal.style.display = "none";
            modal.classList.remove('show');
        }

        window.addEventListener('click', function(event) {
            const modal = document.getElementById('receiptModal');
            if (event.target === modal) {
                closeModal();
            }
        });

    </script>
<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html> 
