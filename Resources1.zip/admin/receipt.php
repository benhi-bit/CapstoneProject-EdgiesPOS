<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include your database connection

// Get the serial number from the query parameter
$serialNumber = isset($_GET['serial_num']) ? $_GET['serial_num'] : null;

if ($serialNumber) {
    // Fetch the receipt data based on the serial number
    $receiptQuery = "
        SELECT 
            t.serial_num AS SerialNumber, 
            t.transaction_date AS TransactionDate, 
            t.total_amount AS TotalSales,
            t.details AS TransactionDetails -- Assuming you have a details column
        FROM 
            transactions t 
        WHERE 
            t.serial_num = ?
    ";
    $receiptStmt = $conn->prepare($receiptQuery);
    $receiptStmt->bind_param("s", $serialNumber);
    $receiptStmt->execute();
    $receiptResult = $receiptStmt->get_result();

    if ($receiptResult->num_rows > 0) {
        $receiptData = $receiptResult->fetch_assoc();
    } else {
        echo "No receipt found for this serial number.";
        exit();
    }
} else {
    echo "Invalid serial number.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receipt for Serial Number: <?php echo htmlspecialchars($receiptData['SerialNumber']); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Add your styles here */
    </style>
</head>
<body>
    <h2>Receipt Details</h2>
    <p><strong>Serial Number:</strong> <?php echo htmlspecialchars($receiptData['SerialNumber']); ?></p>
    <p><strong>Transaction Date:</strong> <?php echo htmlspecialchars($receiptData['TransactionDate']); ?></p>
    <p><strong>Total Sales:</strong> <?php echo htmlspecialchars($receiptData['TotalSales']); ?></p>
    <p><strong>Details:</strong> <?php echo htmlspecialchars($receiptData['TransactionDetails']); ?></p>
    <a href="sales_report.php">Back to Sales Report</a>
</body>
</html>