<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php'; // Include the database connection
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/recovery_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userQuery->close();

// Determine display name - prioritize FullName, fallback to Username, then Administrator
if (!empty($userData) && !empty($userData['FullName']) && trim($userData['FullName']) !== '') {
    $userFullName = trim($userData['FullName']);
} elseif (!empty($userData) && !empty($userData['Username'])) {
    $userFullName = $userData['Username'];
} else {
    $userFullName = 'Administrator';
}

ensureRecoveryTableExists($conn);

// Initialize sort variables
$sortColumn = isset($_GET['sort']) ? $_GET['sort'] : 'Date_Created';
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// Validate sort parameters to prevent SQL injection
$allowedFields = ['Role', 'FullName', 'Username', 'Date_Created'];
$allowedOrders = ['ASC', 'DESC'];

if (!in_array($sortColumn, $allowedFields)) {
    $sortColumn = 'Date_Created';
}
if (!in_array(strtoupper($sortOrder), $allowedOrders)) {
    $sortOrder = 'DESC';
}

// Fetch data from the loginaccount table with error handling and sorting - Only show Cashier accounts
$sql = "SELECT UserID, Role, FullName, Username, Email, Date_Created FROM loginaccount WHERE Username != ? AND Role = 'Cashier' ORDER BY $sortColumn $sortOrder";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $_SESSION['Username']);

if ($stmt->execute()) {
    $result = $stmt->get_result();
} else {
    die("Error executing query: " . $conn->error);
}

// Check for success message
$successMessage = isset($_GET['success']) ? "User added successfully!" : "";

// Handle form submission for adding a new user
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Check if username or email already exists
    $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM loginaccount WHERE Username = ? OR Email = ?");
    $checkStmt->bind_param("ss", $username, $email);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();

    if ($row['count'] > 0) {
        $_SESSION['error_message'] = 'Username or email already exists.';
    } else {
        $stmt = $conn->prepare("INSERT INTO loginaccount (Username, Password, FullName, Email, Role) VALUES (?, ?, ?, ?, 'Cashier')");
        $stmt->bind_param("ssss", $username, $password, $fullname, $email);
        
        if ($stmt->execute()) {
            // Add log for new user creation
            addSystemLog($conn, "User Created", "New user account created: " . $username, $userFullName);
            $_SESSION['success_message'] = 'User added successfully!';
        } else {
            $_SESSION['error_message'] = 'Error adding user: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle user removal
if (isset($_POST['remove_user'])) {
    $userId = (int)$_POST['user_id'];
    
    // Get user details before removal
    $stmt = $conn->prepare("SELECT * FROM loginaccount WHERE UserID = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $removedUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$removedUser) {
        $_SESSION['error_message'] = 'User not found.';
    } else {
        storeRecoveryItem(
            $conn,
            'user',
            'loginaccount',
            $removedUser['UserID'],
            $removedUser['Username'],
            $removedUser,
            $userFullName
        );

        $stmt = $conn->prepare("DELETE FROM loginaccount WHERE UserID = ?");
        $stmt->bind_param("i", $userId);
        
        if ($stmt->execute()) {
            addSystemLog($conn, "User Removed", "User account removed: " . $removedUser['Username'], $userFullName);
            $_SESSION['success_message'] = 'User removed successfully!';
        } else {
            $_SESSION['error_message'] = 'Error removing user: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle user editing - REMOVED: Now handled via AJAX in edit_user.php
// The old form submission handler has been removed to prevent duplicate submissions
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Add SweetAlert2 CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
    </style>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            background-color: #f5f5f5;
            color: #1e293b;
        }

/* Add SweetAlert2 z-index override to appear above modals */
.swal2-container {
    z-index: 10000 !important;
}

.swal2-container.swal-above-modal {
    z-index: 10000 !important;
}

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines when expanded */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }

        /* Products Header Styles */
        .products-header {
            background: white;
            padding: 20px 28px;
            border-radius: 18px;
            margin: 0 0 24px 0;
            color: #333;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .products-header-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header-title-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            background: rgba(250, 206, 11, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #face0b;
        }

        .header-title h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            letter-spacing: -0.5px;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-container {
            position: relative;
        }

        .search-container .input-with-icon {
            width: 300px;
            position: relative;
        }

        .search-container .input-with-icon input {
            padding: 10px 14px 10px 40px;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            font-size: 14px;
            transition: border 0.2s ease, box-shadow 0.2s ease;
            background: white;
            width: 100%;
            box-sizing: border-box;
        }

        .search-container .input-with-icon input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }

        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }

        @media screen and (max-width: 768px) {
            main {
                margin-left: 0;
                width: 100%;
            }
            
            
            nav.sidebar {
                display: none;
            }

            .products-header {
                padding: 16px 20px;
            }

            .products-header-main {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
            }

            .header-title {
                justify-content: center;
            }

            .header-actions {
                flex-direction: column;
                width: 100%;
            }

            .search-container {
                width: 100%;
            }

            .search-container .input-with-icon {
                width: 100%;
            }

            #addUserBtn {
                width: 100%;
                justify-content: center;
            }

            .table-container {
                max-height: calc(100vh - 200px);
                overflow-x: auto;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch;
            }

            #usersTable {
                min-width: 600px;
            }

            #usersTable th,
            #usersTable td {
                padding: 12px 10px;
                font-size: 13px;
            }

            #usersTable th {
                font-size: 12px;
                padding: 10px 8px;
            }
        }

.table-container {
    max-height: calc(100vh - 260px);
    overflow-y: auto;
    padding-right: 8px;
    position: relative;
    margin-top: 20px;
    border-radius: 12px;
}

.table-container::-webkit-scrollbar {
    width: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: rgba(15, 23, 42, 0.05);
    border-radius: 10px;
}

.table-container::-webkit-scrollbar-thumb {
    background: rgba(15, 23, 42, 0.25);
    border-radius: 10px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: rgba(15, 23, 42, 0.4);
}

#usersTable {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 12px;
    margin-top: 0;
    margin-bottom: 20px;
    background: transparent;
}

#usersTable thead {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #333;
    transform: translateZ(0);
    isolation: isolate;
}

#usersTable thead tr {
    background: #333;
}

#usersTable th {
    background-color: #333 !important;
    color: #ffffff;
    padding: 16px 20px;
    text-align: left;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border: none;
    position: relative;
    white-space: nowrap;
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 0 0 #333;
    border-bottom: 4px solid #333;
}

#usersTable th:first-child {
    border-top-left-radius: 12px;
    border-bottom-left-radius: 0;
}

#usersTable th:last-child {
    border-top-right-radius: 12px;
    border-bottom-right-radius: 0;
}

#usersTable th:hover {
    background-color: #444;
}

#usersTable tbody {
    position: relative;
    z-index: 1;
}

#usersTable tbody tr {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    margin-bottom: 12px;
}

#usersTable tbody tr:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
    background: #ffffff;
}

#usersTable td {
    padding: 18px 20px;
    text-align: left;
    font-size: 15px;
    color: #1e293b;
    border: none;
    vertical-align: middle;
}

#usersTable tbody tr td:first-child {
    border-top-left-radius: 12px;
    border-bottom-left-radius: 12px;
}

#usersTable tbody tr td:last-child {
    border-top-right-radius: 12px;
    border-bottom-right-radius: 12px;
}

.button {
    padding: 8px 16px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 600;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
}

.button i {
    font-size: 13px;
}

.button:hover {
    transform: translateY(-1px);
}

/* Edit button style: neutral gray to differ from yellow Add */
.editBtn {
    background: #64748b;
    color: #ffffff;
}

.editBtn:hover {
    background: #4b5563;
}

/* Remove button style */
.removeBtn {
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    color: #fff;
    box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
}

.removeBtn:hover {
    box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
}

/* Modal styles */
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    justify-content: center;
    align-items: center;
    transition: opacity 0.3s ease;
    opacity: 0;
    pointer-events: none;
}
.modal.show {
    display: flex;
    opacity: 1;
    pointer-events: auto;
    animation: modalFadeIn 0.3s;
}

@keyframes modalFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Modal content styles */
.modal-content {
    background-color: #ffffff;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    border-radius: 15px;
    position: relative;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
    transition: transform 0.2s, box-shadow 0.2s;
}

.modal-content.add-user-modal {
    padding: 0;
    border: none;
    overflow: hidden;
    background: #f5f5f5;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
    max-width: 720px;
}

.modal-header {
    background: #333;
    color: #fff;
    padding: 28px 32px;
    display: flex;
    align-items: center;
    gap: 18px;
}

.modal-header .modal-icon {
    width: 54px;
    height: 54px;
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.14);
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
}

.modal-header h2 {
    margin: 0;
    font-size: 26px;
    color: #fff;
}

.modal-header p {
    margin: 4px 0 0;
    color: rgba(255, 255, 255, 0.88);
    font-size: 14px;
    line-height: 1.5;
}

.modal-body {
    padding: 30px;
    display: flex;
    flex-direction: column;
    gap: 24px;
    max-height: calc(90vh - 160px);
    overflow-y: auto;
}

.modal-body::-webkit-scrollbar {
    width: 8px;
}

.modal-body::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb {
    background: rgba(51, 51, 51, 0.3);
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb:hover {
    background: rgba(51, 51, 51, 0.5);
}

.section-card {
    background: #fff;
    border-radius: 18px;
    padding: 20px 22px 24px;
    border: 1px solid rgba(15, 23, 42, 0.08);
    box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
}

.section-header {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px;
}

.section-header .section-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: rgba(250, 206, 11, 0.2);
    color: #b58500;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.section-header h3 {
    margin: 0;
    font-size: 18px;
    color: #0f172a;
}

.section-header p {
    display: none;
    color: #64748b;
    font-size: 14px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
}

.form-grid .form-group {
    margin-bottom: 0;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
    margin-top: 10px;
}

.modal-actions .btn-secondary,
.modal-actions .btn-primary {
    padding: 8px 16px;
    border-radius: 999px;
    font-weight: 600;
    font-size: 13px;
    border: none;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}

.modal-actions .btn-secondary {
    background: #333;
    color: #fff;
    box-shadow: 0 8px 18px rgba(15, 23, 42, 0.18);
}

.modal-actions .btn-secondary:hover {
    background: #444;
    transform: translateY(-1px);
}

.modal-actions .btn-primary {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

.modal-actions .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

.modal-actions .btn-primary:disabled {
    opacity: 0.7;
    cursor: not-allowed;
    box-shadow: none;
}

.modal-content.add-user-modal .form-group label {
    font-size: 13px;
    letter-spacing: 0.3px;
    color: #1e293b;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 8px;
    display: block;
}

.modal-content.add-user-modal .input-with-icon input,
.modal-content.add-user-modal select {
    border-radius: 10px;
    border: 2px solid #e2e8f0;
    padding: 14px 16px 14px 40px;
    font-size: 15px;
    color: #1e293b;
    transition: border 0.2s ease, box-shadow 0.2s ease;
    background: white;
    box-sizing: border-box;
}

.modal-content.add-user-modal select {
    padding-left: 14px;
    cursor: pointer;
}

.modal-content.add-user-modal .input-with-icon i:not(.fa-eye):not(.fa-eye-slash) {
    color: #64748b;
    font-size: 14px;
}

.modal-content.add-user-modal .input-with-icon input:focus,
.modal-content.add-user-modal select:focus {
    border-color: #face0b;
    box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25);
    outline: none;
}

.modal-content.add-user-modal .input-with-icon input::placeholder {
    color: #94a3b8;
}

.modal-content.add-user-modal small {
    color: #64748b !important;
    font-size: 12px;
    margin-top: 6px;
    display: block;
    line-height: 1.5;
}

.modal-content.add-user-modal .form-group {
    margin-bottom: 20px;
}

.modal-content.add-user-modal .form-group.full-width {
    grid-column: 1 / -1;
}

.modal-content.add-user-modal .form-group label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    letter-spacing: 0.3px;
    color: #1e293b;
    text-transform: uppercase;
    font-weight: 600;
    margin-bottom: 10px;
}

.modal-content.add-user-modal .form-group label i {
    font-size: 14px;
    color: #64748b;
}

.modal-content.add-user-modal .form-group label .required {
    color: #ef4444;
    font-weight: 700;
}

.modal-content.add-user-modal .form-group input[type="text"],
.modal-content.add-user-modal .form-group input[type="email"],
.modal-content.add-user-modal .form-group input[type="password"] {
    width: 100%;
    border-radius: 10px;
    border: 2px solid #e2e8f0;
    padding: 14px 16px;
    transition: all 0.3s ease;
    background: white;
    color: #1e293b;
    font-size: 15px;
    box-sizing: border-box;
}

.modal-content.add-user-modal .form-group input:focus {
    border-color: #face0b;
    box-shadow: 0 0 0 4px rgba(250, 206, 11, 0.15);
    outline: none;
}

.modal-content.add-user-modal .form-group input::placeholder {
    color: #94a3b8;
    font-size: 14px;
}

.modal-content.add-user-modal .form-group .form-hint {
    color: #64748b;
    font-size: 12px;
    margin-top: 6px;
    display: block;
    line-height: 1.5;
}

.modal-content.add-user-modal .role-display {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    background: #f1f5f9;
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    color: #475569;
    font-size: 15px;
    font-weight: 500;
}

.modal-content.add-user-modal .role-display i {
    color: #64748b;
}

.modal-content.add-user-modal .password-grid {
    grid-template-columns: 1fr 1fr;
}

@media screen and (max-width: 768px) {
    .modal-content.add-user-modal .password-grid {
        grid-template-columns: 1fr;
    }
}

.modal-content.add-user-modal .password-input {
    position: relative;
}

.modal-content.add-user-modal .password-input input {
    padding-right: 45px;
}

.modal-content.add-user-modal .password-input .toggle-password {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #64748b;
    padding: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: color 0.2s ease;
    z-index: 10;
}

.modal-content.add-user-modal .password-input .toggle-password:hover {
    color: #1e293b;
}

.modal-content.add-user-modal .password-input .toggle-password i {
    font-size: 16px;
}

.modal-content.add-user-modal .password-requirements {
    margin-top: 10px;
    padding: 12px;
    background: #f8fafc;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
}

.modal-content.add-user-modal .requirement-list {
    list-style: none;
    padding: 0;
    margin: 8px 0 0 0;
}

.modal-content.add-user-modal .requirement-list li {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    color: #64748b;
    margin-bottom: 6px;
}

.modal-content.add-user-modal .requirement-list li:last-child {
    margin-bottom: 0;
}

.modal-content.add-user-modal .requirement-list li i {
    font-size: 8px;
    color: #cbd5e1;
    transition: all 0.3s ease;
    margin-right: 4px;
}

.modal-content.add-user-modal .requirement-list li.valid i {
    color: #10b981;
    font-size: 12px;
}

.modal-content.add-user-modal .requirement-list li.valid {
    color: #10b981;
    font-weight: 500;
}

.modal-content.add-user-modal .select-wrapper {
    position: relative;
}

.modal-content.add-user-modal .select-wrapper select {
    width: 100%;
    border-radius: 10px;
    border: 2px solid #e2e8f0;
    padding: 14px 40px 14px 16px;
    transition: all 0.3s ease;
    background: white;
    color: #1e293b;
    font-size: 15px;
    cursor: pointer;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    box-sizing: border-box;
}

.modal-content.add-user-modal .select-wrapper select:focus {
    border-color: #face0b;
    box-shadow: 0 0 0 4px rgba(250, 206, 11, 0.15);
    outline: none;
}

.modal-content.add-user-modal .select-wrapper .select-arrow {
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    pointer-events: none;
    font-size: 12px;
}

.modal-content.add-user-modal .section-header p {
    display: block;
    color: #64748b;
    font-size: 13px;
    margin-top: 4px;
    font-weight: 400;
    text-transform: none;
}

.modal-content.add-user-modal #password-match-indicator.match {
    color: #10b981;
    font-weight: 500;
}

.modal-content.add-user-modal #password-match-indicator.mismatch {
    color: #ef4444;
    font-weight: 500;
}

.modal-content.add-user-modal .section-card {
    background: #fff;
    border-radius: 18px;
    padding: 20px 22px 24px;
    border: 1px solid rgba(15, 23, 42, 0.08);
    box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
}

.modal-content.add-user-modal .section-header h3 {
    color: #0f172a;
    font-size: 18px;
    font-weight: 600;
}

.close,
.closeEdit {
    color: #fff;
    font-size: 28px;
    font-weight: bold;
    position: absolute;
    top: 12px;
    right: 18px;
    cursor: pointer;
    transition: color 0.3s;
    z-index: 10;
}
.close:hover,
.close:focus,
.closeEdit:hover,
.closeEdit:focus {
    color: rgba(255, 255, 255, 0.7);
}

h1, h2 {
    font-size: 24px;
    margin-bottom: 15px;
}

h3 {
    font-size: 18px;
    margin-bottom: 10px;
}

.modal-content h2 {
    font-size: 24px;
    margin-bottom: 20px;
    color: white vn;
}

.form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 15px;
}

.form-column {
    flex: 1;
    min-width: 0; /* Prevents flex items from overflowing */
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #1e293b;
    font-size: 13px;
    letter-spacing: 0.3px;
    text-transform: uppercase;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 12px;
    border: 1px solid rgba(0, 0, 0, 0.15);
    border-radius: 10px;
    box-sizing: border-box;
    font-size: 14px;
    color: #333;
    background-color: white;
    transition: border 0.2s ease, box-shadow 0.2s ease;
}

.form-group input:focus,
.form-group select:focus {
    border-color: #face0b;
    box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25);
    outline: none;
}

.form-group input::placeholder {
    color: #94a3b8;
}

.password-field {
    position: relative;
}

.password-field .toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
}

.form-submit {
    text-align: right;
    margin-top: 20px;
}

.form-submit input[type="submit"] {
    padding: 10px 20px;
    background-color: #face0b;
    color: black;
    border: none;
    border-radius: 15px;
    cursor: pointer;
    font-size: 16px;
}

.form-submit input[type="submit"]:hover {
    background-color: #f7b300;
}

@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateY(-50px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

@media (max-width: 600px) {
    .modal-content {
        width: 98vw;
        max-width: 98vw;
        padding: 16px 6px 12px 6px;
    }
    .modal-content h2 {
        font-size: 20px;
    }
    .modal-content input,
    .modal-content select {
        font-size: 15px;
    }
}

body.no-scroll {
    overflow: hidden !important;
}


/* Dropdown container */
.dropdown {
    position: relative; /* Position relative for absolute positioning of dropdown content */
}

/* Dropdown button */
.dropbtn {
    color: white;
    padding: 14px 20px;
    text-decoration: none;
    display: block; /* Make it block element */
}

/* Dropdown content (hidden by default) */
.dropdown-content {
    display: none; /* Hidden by default */
    position: relative; /* Change to relative to push down other items */
    background-color: #444; /* Dark background color for emphasis */
    min-width: 200px; /* Minimum width */
    z-index: 1; /* Sit on top */
    border-radius: 15px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for better visibility */
}

/* Links inside the dropdown */
.dropdown-content a {
    color: white; /* Text color */
    padding: 12px 16px; /* Padding */
    text-decoration: none; /* No underline */
    display: flex; /* Use flexbox for alignment */
    align-items: center; /* Center items vertically */
}

/* Style for icons */
.dropdown-content a i {
    margin-right: 10px; /* Space between icon and text */
}

/* Show the dropdown content on hover */
.dropdown:hover .dropdown-content {
    display: block; /* Show the dropdown */
}

/* Change background color on hover */
.dropdown-content a:hover {
    background-color: #555; /* Light background on hover */
    color: white; /* Keep text color white on hover */
}

#addUserBtn {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    padding: 8px 16px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

#addUserBtn:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

/* Success Message Box Styles */
.success-box {
    display: none;
    position: fixed;
    top: 20px;
    right: 20px;
    background-color: #4CAF50;
    color: white;
    padding: 15px 25px;
    border-radius: 15px;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    z-index: 2000;
    animation: slideInRight 0.5s ease-out;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes fadeOut {
    from {
        opacity: 1;
    }
    to {
        opacity: 0;
    }
}

/* Sort button styles */
.sort-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px 8px;
    color: #ffffff;
    border-radius: 0;
    display: inline-flex;
    align-items: center;
    vertical-align: middle;
    margin-left: 8px;
    transition: color 0.2s ease;
    box-shadow: none;
}

.sort-btn:hover {
    background: none;
    color: #ffffff;
    transform: none;
    box-shadow: none;
}

.sort-btn.active {
    background: none;
    color: #ffffff;
    box-shadow: none;
}

th {
    position: relative;
    white-space: nowrap;
    padding: 12px 15px;
}

.column-header {
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

/* Add these styles for the search container */
/* Unified with header search bar above: 15px radius, #e2e8f0 border */
.search-container {
    position: relative;
    display: inline-block;
}

.search-container i,
.search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    pointer-events: none;
    font-size: 14px;
}

.search-container input[type="text"] {
    padding: 10px 14px 10px 40px !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 15px !important;
    font-size: 14px;
    transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.search-container input[type="text"]:focus {
    outline: none;
    border-color: #face0b !important;
    box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
}

.input-with-icon {
    position: relative;
}

.input-with-icon i:not(.fa-eye):not(.fa-eye-slash) {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 14px;
    pointer-events: none;
}

.input-with-icon input {
    padding-left: 30px;
    width: 100%;
    box-sizing: border-box;
}

.input-with-icon input[type="password"] {
    padding-right: 35px;
}

.toggle-password {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #666;
    padding: 0;
}

.toggle-password:hover {
    color: #333;
}

.previous-email {
    display: block;
    margin-top: 5px;
    color: #666;
    font-size: 12px;
}

    </style>    
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName ?? 'Administrator'); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>
    <main>
        <div class="products-header">
            <div class="products-header-main">
                <div class="header-title">
                    <div class="header-title-icon">
                        <i class="fas fa-users-cog"></i>
                    </div>
                    <h2>User Management</h2>
                </div>
                <div class="header-actions">
                    <div class="search-container">
                        <div class="input-with-icon">
                            <i class="fas fa-search"></i>
                            <input type="text" id="searchInput" placeholder="Search users..." onkeyup="filterUsers()">
                        </div>
                    </div>
                    <button id="addUserBtn" class="button"><i class="fas fa-user-plus"></i> Add User</button>
                </div>
            </div>
        </div>

            <div class="table-container">
            <table id="usersTable">
                <thead>
                    <tr>
                        <th>
                            <div class="column-header">
                                Role
                                <button onclick="sortTable('Role')" class="sort-btn" data-column="Role">
                                    <i class="fas fa-sort"></i>
                                </button>
                            </div>
                        </th>
                        <th>
                            <div class="column-header">
                                Full Name
                                <button onclick="sortTable('FullName')" class="sort-btn" data-column="FullName">
                                    <i class="fas fa-sort"></i>
                                </button>
                            </div>
                        </th>
                        <th>
                            <div class="column-header">
                                Username
                                <button onclick="sortTable('Username')" class="sort-btn" data-column="Username">
                                    <i class="fas fa-sort"></i>
                                </button>
                            </div>
                        </th>
                        <th>
                            <div class="column-header">
                                Email
                                <button onclick="sortTable('Email')" class="sort-btn" data-column="Email">
                                    <i class="fas fa-sort"></i>
                                </button>
                            </div>
                        </th>
                        <th>
                            <div class="column-header">
                                Date Created
                                <button onclick="sortTable('Date_Created')" class="sort-btn" data-column="Date_Created">
                                    <i class="fas fa-sort"></i>
                                </button>
                            </div>
                        </th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $dateCreated = !empty($row['Date_Created']) ? date('Y-m-d h:i A', strtotime($row['Date_Created'])) : 'N/A';
                        $roleEscaped = htmlspecialchars($row["Role"], ENT_QUOTES, 'UTF-8');
                        $fullNameEscaped = htmlspecialchars($row["FullName"], ENT_QUOTES, 'UTF-8');
                        $usernameEscaped = htmlspecialchars($row["Username"], ENT_QUOTES, 'UTF-8');
                        $emailEscaped = htmlspecialchars($row["Email"], ENT_QUOTES, 'UTF-8');

                        echo "<tr>
                                <td>" . $roleEscaped . "</td>
                                <td>" . $fullNameEscaped . "</td>
                                <td>" . $usernameEscaped . "</td>
                                <td>" . $emailEscaped . "</td>
                                <td>" . $dateCreated . "</td>
                                <td>
                                    <button class='editBtn button'
                                        data-id='" . (int)$row["UserID"] . "'
                                        data-role='" . $roleEscaped . "'
                                        data-fullname='" . $fullNameEscaped . "'
                                        data-username='" . $usernameEscaped . "'
                                        data-email='" . $emailEscaped . "'><i class='fas fa-edit'></i> Edit</button>
                                    <button class='removeBtn button' data-id='" . $row["UserID"] . "'><i class='fas fa-trash-alt'></i> Remove</button>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No users found</td></tr>";
                }
                ?>
            </table>
            </div>

            <!-- The Modal for Adding User -->
            <div id="userModal" class="modal">
                <div class="modal-content add-user-modal">
                    <span class="close">&times;</span>
                    <div class="modal-header">
                        <div class="modal-icon">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <div>
                            <h2>Add New User</h2>
                            <p>Create a new user account with role and security settings</p>
                        </div>
                    </div>
                    <form id="addUserForm" method="POST" action="add_user.php" class="modal-body" novalidate>
                        <!-- Account Information Section -->
                        <div class="section-card">
                            <div class="section-header">
                                <div class="section-icon">
                                    <i class="fas fa-id-badge"></i>
                                </div>
                                <div>
                                    <h3>Account Information</h3>
                                    <p>Enter the basic details for the new user account</p>
                                </div>
                            </div>
                            <div class="form-grid">
                                <div class="form-group full-width">
                                    <label for="fullName">
                                        <i class="fas fa-user"></i> Full Name <span class="required">*</span>
                                    </label>
                                    <input type="text" id="fullName" name="fullName" placeholder="Enter full name" required pattern="^[A-Za-zÀ-ž\s.'\-]{2,50}$" title="2–50 characters, letters, spaces, and basic punctuation only">
                                    <small class="form-hint">Enter the user's complete name (letters and spaces only)</small>
                                </div>
                                <div class="form-group">
                                    <label for="username">
                                        <i class="fas fa-at"></i> Username <span class="required">*</span>
                                    </label>
                                    <input type="text" id="username" name="username" placeholder="Enter username" required pattern="^[A-Za-z0-9_]{4,20}$" title="4–20 characters, letters, numbers, and underscore only">
                                    <small class="form-hint">Unique username for login</small>
                                </div>
                                <div class="form-group">
                                    <label for="email">
                                        <i class="fas fa-envelope"></i> Email Address <span class="required">*</span>
                                    </label>
                                    <input type="email" id="email" name="email" placeholder="user@example.com" required pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="Enter a valid email address (e.g. user@example.com)">
                                    <small class="form-hint">Valid email address</small>
                                </div>
                                <div class="form-group">
                                    <label for="role">
                                        <i class="fas fa-user-tag"></i> Role <span class="required">*</span>
                                    </label>
                                    <div class="select-wrapper">
                                        <select id="role" name="role" required>
                                            <option value="Cashier" selected>Cashier</option>
                                            <option value="Admin">Admin</option>
                                        </select>
                                        <i class="fas fa-chevron-down select-arrow"></i>
                                    </div>
                                    <small class="form-hint">Select the user's role</small>
                                </div>
                            </div>
                        </div>

                        <!-- Password Section -->
                        <div class="section-card">
                            <div class="section-header">
                                <div class="section-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <h3>Password & Security</h3>
                                    <p>Set a secure password for account access</p>
                                </div>
                            </div>
                            <div class="form-grid password-grid">
                                <div class="form-group">
                                    <label for="password">
                                        <i class="fas fa-key"></i> Password <span class="required">*</span>
                                    </label>
                                    <div class="input-with-icon password-input">
                                        <input type="password" id="password" name="password" placeholder="Enter password" required pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                                        <button type="button" class="toggle-password" onclick="togglePassword('password')" tabindex="-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <div class="password-requirements">
                                        <small class="form-hint">Password requirements:</small>
                                        <ul class="requirement-list">
                                            <li id="req-length"><i class="fas fa-circle"></i> At least 6 characters</li>
                                            <li id="req-uppercase"><i class="fas fa-circle"></i> One uppercase letter</li>
                                            <li id="req-number"><i class="fas fa-circle"></i> One number</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="confirmPassword">
                                        <i class="fas fa-key"></i> Confirm Password <span class="required">*</span>
                                    </label>
                                    <div class="input-with-icon password-input">
                                        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Re-enter password" required pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                                        <button type="button" class="toggle-password" onclick="togglePassword('confirmPassword')" tabindex="-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <small class="form-hint" id="password-match-indicator">Enter the same password again</small>
                                </div>
                            </div>
                        </div>

                        <!-- Recovery Section -->
                        <div class="section-card">
                            <div class="section-header">
                                <div class="section-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <div>
                                    <h3>Account Recovery</h3>
                                    <p>Set up security questions for password recovery</p>
                                </div>
                            </div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="recoveryQuestion">
                                        <i class="fas fa-question-circle"></i> Recovery Question <span class="required">*</span>
                                    </label>
                                    <div class="select-wrapper">
                                    <select id="recoveryQuestion" name="recoveryQuestion" required>
                                            <option value="">Select a recovery question</option>
                                        <option value="What is your pet's name?">What is your pet's name?</option>
                                        <option value="What is your mother's maiden name?">What is your mother's maiden name?</option>
                                        <option value="What was your first school?">What was your first school?</option>
                                        <option value="What is your favorite movie?">What is your favorite movie?</option>
                                        <option value="What is your favorite color?">What is your favorite color?</option>
                                        <option value="What is your favorite food?">What is your favorite food?</option>
                                        <option value="What is your favorite book?">What is your favorite book?</option>
                                        <option value="What is your favorite sport?">What is your favorite sport?</option>
                                        <option value="What is your favorite place?">What is your favorite place?</option>
                                        <option value="What is your favorite song?">What is your favorite song?</option>
                                    </select>
                                        <i class="fas fa-chevron-down select-arrow"></i>
                                    </div>
                                    <small class="form-hint">Choose a question you can remember</small>
                                </div>
                                <div class="form-group">
                                    <label for="recoveryAnswer">
                                        <i class="fas fa-answer"></i> Recovery Answer <span class="required">*</span>
                                    </label>
                                    <input type="text" id="recoveryAnswer" name="recoveryAnswer" placeholder="Enter your answer" required pattern="^.{2,100}$" title="2–100 characters">
                                    <small class="form-hint">Answer to your selected question</small>
                                </div>
                            </div>
                            <!-- Action Buttons (inside container) -->
                            <div class="modal-actions">
                                <button type="submit" class="btn-primary" id="submitBtn">
                                    <i class="fas fa-user-plus"></i> Create User
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- The Modal for Editing User -->
            <div id="editUserModal" class="modal">
                <div class="modal-content add-user-modal">
                    <span class="closeEdit">&times;</span>
                    <div class="modal-header">
                        <div class="modal-icon">
                            <i class="fas fa-user-edit"></i>
                        </div>
                        <div>
                            <h2>Edit User</h2>
                            <p>Update user account information and security settings</p>
                        </div>
                    </div>
                    <form id="editUserForm" method="POST" class="modal-body" novalidate>
                        <input type="hidden" id="editUserID" name="userID">
                        <div class="section-card">
                            <div class="section-header">
                                <div class="section-icon">
                                    <i class="fas fa-id-card-alt"></i>
                                </div>
                                <div>
                                    <h3>Account Details</h3>
                                    <p>Update the user account information</p>
                                </div>
                            </div>
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="editRole">
                                        <i class="fas fa-user-tag"></i> Role
                                    </label>
                                    <div class="role-display">
                                        <i class="fas fa-user-tag"></i>
                                        <span>Cashier</span>
                                    </div>
                                    <input type="hidden" id="editRole" name="role" value="Cashier">
                                    <small class="form-hint">User role cannot be changed</small>
                                </div>
                                <div class="form-group">
                                    <label for="editFullName">
                                        <i class="fas fa-user"></i> Full Name <span class="required">*</span>
                                    </label>
                                    <input type="text" id="editFullName" name="fullName" placeholder="Enter full name" required pattern="^[A-Za-zÀ-ž\s.'\-]{2,50}$" title="2–50 characters, letters, spaces, and basic punctuation only">
                                    <small class="form-hint">Enter the user's complete name (letters and spaces only)</small>
                                    </div>
                                <div class="form-group">
                                    <label for="editUsername">
                                        <i class="fas fa-at"></i> Username <span class="required">*</span>
                                    </label>
                                    <input type="text" id="editUsername" name="username" placeholder="Enter username" required pattern="^[A-Za-z0-9_]{4,20}$" title="4–20 characters, letters, numbers, and underscore only">
                                    <small class="form-hint">Unique username for login</small>
                                </div>
                                <div class="form-group">
                                    <label for="editEmail">
                                        <i class="fas fa-envelope"></i> Email Address <span class="required">*</span>
                                    </label>
                                    <input type="email" id="editEmail" name="email" placeholder="user@example.com" required pattern="^[^\s@]+@[^\s@]+\.[^\s@]+$" title="Enter a valid email address (e.g. user@example.com)">
                                    <small class="form-hint">Valid email address</small>
                                    </div>
                                </div>
                                    </div>

                        <!-- Password Section -->
                        <div class="section-card">
                            <div class="section-header">
                                <div class="section-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <h3>Password & Security</h3>
                                    <p>Update password (leave blank to keep current password)</p>
                                </div>
                            </div>
                            <div class="form-grid password-grid">
                                <div class="form-group">
                                    <label for="editPassword">
                                        <i class="fas fa-key"></i> New Password <small style="font-weight:400;">(optional)</small>
                                    </label>
                                    <div class="input-with-icon password-input">
                                        <input type="password" id="editPassword" name="password" placeholder="Enter new password" pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                                        <button type="button" class="toggle-password" onclick="togglePassword('editPassword')" tabindex="-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <div class="password-requirements">
                                        <small class="form-hint">Password requirements (if changing):</small>
                                        <ul class="requirement-list">
                                            <li id="edit-req-length"><i class="fas fa-circle"></i> At least 6 characters</li>
                                            <li id="edit-req-uppercase"><i class="fas fa-circle"></i> One uppercase letter</li>
                                            <li id="edit-req-number"><i class="fas fa-circle"></i> One number</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="editConfirmPassword">
                                        <i class="fas fa-key"></i> Confirm New Password
                                    </label>
                                    <div class="input-with-icon password-input">
                                        <input type="password" id="editConfirmPassword" name="confirmPassword" placeholder="Re-enter new password" pattern="^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$" title="At least 6 characters, one uppercase letter, and one number">
                                        <button type="button" class="toggle-password" onclick="togglePassword('editConfirmPassword')" tabindex="-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </div>
                                    <small class="form-hint" id="edit-password-match-indicator">Enter the same password again if changing</small>
                                </div>
                            </div>
                            <!-- Action Buttons (inside container) -->
                            <div class="modal-actions">
                                <button type="submit" class="btn-primary" id="editSubmitBtn">
                                    <i class="fas fa-save"></i> Save Changes
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Sorting functionality
        let currentSort = {
            column: '<?php echo $sortColumn; ?>',
            order: '<?php echo $sortOrder; ?>'
        };

        function updateSortIcon(column) {
            // Remove active class from all sort buttons
            document.querySelectorAll('.sort-btn').forEach(btn => {
                btn.classList.remove('active');
                btn.querySelector('i').className = 'fas fa-sort';
            });
            
            // Add active class to current sort button
            const currentBtn = document.querySelector(`button[data-column="${column}"]`);
            if (currentBtn) {
                currentBtn.classList.add('active');
                const icon = currentBtn.querySelector('i');
                icon.className = currentSort.order === 'ASC' ? 'fas fa-sort-up' : 'fas fa-sort-down';
            }
        }

        function sortTable(column) {
            if (currentSort.column === column) {
                // Toggle sort order if clicking the same column
                currentSort.order = currentSort.order === 'ASC' ? 'DESC' : 'ASC';
            } else {
                // Set new column and default to ascending
                currentSort.column = column;
                currentSort.order = 'ASC';
            }
            
            updateSortIcon(column);
            
            // Redirect with new sort parameters
            window.location.href = `user_management.php?sort=${column}&sort_order=${currentSort.order}`;
        }

        // Initialize sort icons on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateSortIcon(currentSort.column);
        });

        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                // Save state to localStorage
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }
        
        // Restore sidebar state on page load (without transition)
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                // Disable transitions during state restoration
                sidebar.classList.add('no-transition');
                
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                
                // Re-enable transitions after a short delay
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }
        });

        function confirmLogout(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Logout Confirmation',
                text: "Are you sure you want to logout?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        }

        // Update sidebar date and time
        function updateSidebarDateTime() {
            const now = new Date();
            
            // Format date: Day, Month DD, YYYY
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', dateOptions);
            
            // Format time: HH:MM:SS AM/PM
            const timeStr = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                hour12: true 
            });
            
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            
            if (dateElement) {
                dateElement.textContent = dateStr;
            }
            if (timeElement) {
                timeElement.textContent = timeStr;
            }
        }

        // Update immediately and then every second
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        // Search functionality
        function filterUsers() {
            const searchInput = document.getElementById('searchInput');
            const filter = searchInput.value.toLowerCase();
            const table = document.getElementById('usersTable');
            const tbody = table.getElementsByTagName('tbody')[0];
            const rows = tbody.getElementsByTagName('tr');

            // Loop through all table rows
            for (let i = 0; i < rows.length; i++) {
                const roleCell = rows[i].getElementsByTagName('td')[0];
                const fullNameCell = rows[i].getElementsByTagName('td')[1];
                const usernameCell = rows[i].getElementsByTagName('td')[2];
                const emailCell = rows[i].getElementsByTagName('td')[3];
                const dateCell = rows[i].getElementsByTagName('td')[4];
                
                let text = '';
                if (roleCell) text += roleCell.textContent || roleCell.innerText;
                if (fullNameCell) text += ' ' + (fullNameCell.textContent || fullNameCell.innerText);
                if (usernameCell) text += ' ' + (usernameCell.textContent || usernameCell.innerText);
                if (emailCell) text += ' ' + (emailCell.textContent || emailCell.innerText);
                if (dateCell) text += ' ' + (dateCell.textContent || dateCell.innerText);
                
                // Check if the search term matches any cell content
                if (text.toLowerCase().indexOf(filter) > -1) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }
        }
    </script>
    <script src="js/account_check.js"></script>
    <script src="js/user_management.js"></script>
    <script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>
