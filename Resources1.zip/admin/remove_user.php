<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/recovery_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'] ?? 'Administrator';
$userQuery->close();

ensureRecoveryTableExists($conn);

if (isset($_GET['id'])) {
    $userId = intval($_GET['id']);

    // Get user details before removal
    $userDetailsStmt = $conn->prepare("SELECT * FROM loginaccount WHERE UserID = ?");
    $userDetailsStmt->bind_param("i", $userId);
    $userDetailsStmt->execute();
    $userDetails = $userDetailsStmt->get_result()->fetch_assoc();
    $userDetailsStmt->close();

    if (!$userDetails) {
        echo json_encode(['success' => false, 'message' => 'User not found.']);
        exit();
    }

    storeRecoveryItem(
        $conn,
        'user',
        'loginaccount',
        $userDetails['UserID'],
        $userDetails['Username'],
        $userDetails,
        $userFullName
    );

    $stmt = $conn->prepare("DELETE FROM loginaccount WHERE UserID = ?");
    $stmt->bind_param("i", $userId);

    if ($stmt->execute()) {
        $description = "User account removed: " . $userDetails['Username'];
        addSystemLog($conn, "User Removed", $description, $userFullName);
        echo json_encode(['success' => true, 'message' => 'Account removed successfully!']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error removing user: ' . $conn->error]);
    }

    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'No user ID provided']);
}

$conn->close();

