<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/backup_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'] ?? 'Administrator';
$userQuery->close();

// Database name used for labeling/filename. Connection comes from connection.php.
$dbname = "edgies_pos";

// Set filename (starts with date)
$filename = makeBackupFilename($dbname);

// Headers for file download - let user choose where to save
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Generate SQL dump
$output = generateDatabaseBackupSql($conn, $dbname);

// Log the backup operation (download only, not saved to server)
addSystemLog($conn, "Database Backup", "Database backup downloaded: {$filename}", $userFullName);

// Output the file for download - user decides where to save
echo $output;

// Close connection
$conn->close();
exit();
?>
