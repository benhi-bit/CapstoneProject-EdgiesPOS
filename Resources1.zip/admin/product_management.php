<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php';
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/recovery_helper.php';

// Ensure is_available column exists
$availabilityColumnCheck = $conn->query("SHOW COLUMNS FROM inventory LIKE 'is_available'");
if ($availabilityColumnCheck && $availabilityColumnCheck->num_rows === 0) {
    $conn->query("ALTER TABLE inventory ADD COLUMN is_available TINYINT(1) NOT NULL DEFAULT 1");
}
if ($availabilityColumnCheck) {
    $availabilityColumnCheck->close();
}

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');
$userQuery->close();

ensureRecoveryTableExists($conn);

// ========== CATEGORY HANDLERS ==========
// Handle form submission for adding a new category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $categoryName = trim($_POST['category_name'] ?? '');
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,50}$/', $categoryName)) {
        $_SESSION['error_message'] = "Category name must be 2–50 characters (letters, numbers, spaces, basic punctuation).";
        header('Location: product_management.php'); exit();
    }
    $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM categories WHERE CategoryName = ?");
    $checkStmt->bind_param("s", $categoryName);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();

    if ($row['count'] > 0) {
        $_SESSION['error_message'] = "A category with this name already exists!";
    } else {
        $stmt = $conn->prepare("INSERT INTO categories (CategoryName, date_created) VALUES (?, NOW())");
        $stmt->bind_param("s", $categoryName);
        if ($stmt->execute()) {
            addSystemLog($conn, "Category Created", "New category created: " . $categoryName, $userFullName);
            $_SESSION['success_message'] = "Category added successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle category removal
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_category'])) {
    $categoryId = (int)$_POST['category_id'];
    $stmt = $conn->prepare("SELECT * FROM categories WHERE CategoryID = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $categoryData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$categoryData) {
        $_SESSION['error_message'] = "Category not found.";
    } else {
        storeRecoveryItem($conn, 'category', 'categories', $categoryData['CategoryID'], $categoryData['CategoryName'], $categoryData, $userFullName);
        $stmt = $conn->prepare("DELETE FROM categories WHERE CategoryID = ?");
        $stmt->bind_param("i", $categoryId);
        if ($stmt->execute()) {
            addSystemLog($conn, "Category Removed", "Category removed: " . $categoryData['CategoryName'], $userFullName);
            $_SESSION['success_message'] = "Category removed successfully!";
        } else {
            $_SESSION['error_message'] = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle category editing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_category'])) {
    $categoryId = $_POST['category_id'];
    $categoryName = trim($_POST['category_name'] ?? '');
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,50}$/', $categoryName)) {
        $_SESSION['error_message'] = "Category name must be 2–50 characters (letters, numbers, spaces, basic punctuation).";
        header('Location: product_management.php'); exit();
    }
    $stmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $oldCategory = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $stmt = $conn->prepare("UPDATE categories SET CategoryName = ? WHERE CategoryID = ?");
    $stmt->bind_param("si", $categoryName, $categoryId);
    if ($stmt->execute()) {
        addSystemLog($conn, "Category Updated", "Category name updated from '" . $oldCategory['CategoryName'] . "' to '" . $categoryName . "'", $userFullName);
        $_SESSION['success_message'] = "Category updated successfully!";
    } else {
        $_SESSION['error_message'] = "Error: " . $stmt->error;
    }
    $stmt->close();
}

// ========== PRODUCT HANDLERS ==========
// Handle form submission for adding a new product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $inventoryName = trim($_POST['inventory_name'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $categoryId = $_POST['category_id'];

    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,100}$/', $inventoryName)) {
        $_SESSION['error_message'] = 'Product name must be 2–100 characters (letters, numbers, spaces, basic punctuation).';
        header('Location: product_management.php'); exit();
    }
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $price) || floatval($price) <= 0) {
        $_SESSION['error_message'] = 'Price must be a positive number (up to 2 decimal places).';
        header('Location: product_management.php'); exit();
    }

    $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM inventory WHERE InventoryName = ?");
    $checkStmt->bind_param("s", $inventoryName);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();

    if ($row['count'] > 0) {
        $_SESSION['error_message'] = 'A product with this name already exists.';
    } else {
        $imagePath = null;
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
            $targetDir = "../images/";
            $fileName = time() . '_' . basename($_FILES['product_image']['name']);
            $targetPath = $targetDir . $fileName;
            $check = getimagesize($_FILES['product_image']['tmp_name']);
            if($check !== false) {
                $allowedTypes = array('jpg', 'jpeg', 'png');
                $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
                if(in_array($imageFileType, $allowedTypes)) {
                    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetPath)) {
                        $imagePath = $targetPath;
                    } else {
                        $_SESSION['error_message'] = 'Sorry, there was an error uploading your file.';
                    }
                } else {
                    $_SESSION['error_message'] = 'Sorry, only JPG, JPEG, PNG files are allowed.';
                }
            } else {
                $_SESSION['error_message'] = 'File is not an image.';
            }
        }

        $stmt = $conn->prepare("INSERT INTO inventory (CategoryID, InventoryName, Price, ImagePath) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isds", $categoryId, $inventoryName, $price, $imagePath);
        if ($stmt->execute()) {
            $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
            $catStmt->bind_param("i", $categoryId);
            $catStmt->execute();
            $categoryData = $catStmt->get_result()->fetch_assoc();
            $catStmt->close();
            $description = sprintf("New product added: %s (Price: ₱%.2f, Category: %s)", $inventoryName, $price, $categoryData['CategoryName']);
            addSystemLog($conn, "Product Created", $description, $userFullName);
            $_SESSION['success_message'] = 'Product added successfully!';
        } else {
            $_SESSION['error_message'] = 'Error adding product: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle editing of a product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_product'])) {
    $id = $_POST['inventory_id'];
    $inventoryName = trim($_POST['inventory_name'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $categoryId = $_POST['category_id'];

    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,100}$/', $inventoryName)) {
        $_SESSION['error_message'] = 'Product name must be 2–100 characters (letters, numbers, spaces, basic punctuation).';
        header('Location: product_management.php'); exit();
    }
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $price) || floatval($price) <= 0) {
        $_SESSION['error_message'] = 'Price must be a positive number (up to 2 decimal places).';
        header('Location: product_management.php'); exit();
    }

    $stmt = $conn->prepare("SELECT i.InventoryName, i.Price, i.CategoryID, c.CategoryName FROM inventory i JOIN categories c ON i.CategoryID = c.CategoryID WHERE i.InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $oldProduct = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $imagePath = null;
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $targetDir = "../images/";
        $fileName = time() . '_' . basename($_FILES['product_image']['name']);
        $targetPath = $targetDir . $fileName;
        $check = getimagesize($_FILES['product_image']['tmp_name']);
        if($check !== false) {
            $allowedTypes = array('jpg', 'jpeg', 'png');
            $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
            if(in_array($imageFileType, $allowedTypes)) {
                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                } else {
                    $_SESSION['error_message'] = 'Sorry, there was an error uploading your file.';
                }
            } else {
                $_SESSION['error_message'] = 'Sorry, only JPG, JPEG, PNG files are allowed.';
            }
        } else {
            $_SESSION['error_message'] = 'File is not an image.';
        }
    }

    if ($imagePath === null) {
        $stmt = $conn->prepare("SELECT ImagePath FROM inventory WHERE InventoryID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $imagePath = $row['ImagePath'];
        $stmt->close();
    }

    $stmt = $conn->prepare("UPDATE inventory SET CategoryID = ?, InventoryName = ?, Price = ?, ImagePath = ? WHERE InventoryID = ?");
    $stmt->bind_param("isdsi", $categoryId, $inventoryName, $price, $imagePath, $id);
    if ($stmt->execute()) {
        $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
        $catStmt->bind_param("i", $categoryId);
        $catStmt->execute();
        $newCategory = $catStmt->get_result()->fetch_assoc();
        $catStmt->close();
        $changes = [];
        if ($oldProduct['InventoryName'] !== $inventoryName) {
            $changes[] = "name updated from '{$oldProduct['InventoryName']}' to '{$inventoryName}'";
        }
        if ($oldProduct['Price'] != $price) {
            $changes[] = sprintf("price updated from ₱%.2f to ₱%.2f", $oldProduct['Price'], $price);
        }
        if ($oldProduct['CategoryID'] != $categoryId) {
            $changes[] = "category updated from '{$oldProduct['CategoryName']}' to '{$newCategory['CategoryName']}'";
        }
        if ($imagePath !== $row['ImagePath']) {
            $changes[] = "image updated";
        }
        if (!empty($changes)) {
            $description = sprintf("Product updated (%s): %s", implode(", ", $changes), $oldProduct['InventoryName']);
            addSystemLog($conn, "Product Updated", $description, $userFullName);
        }
        $_SESSION['success_message'] = 'Product updated successfully!';
    } else {
        $_SESSION['error_message'] = 'Error updating product: ' . $stmt->error;
    }
    $stmt->close();
}

// Handle removal of a product
if (isset($_POST['remove_product'])) {
    $id = (int)$_POST['inventory_id'];
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $productRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$productRow) {
        $_SESSION['error_message'] = 'Product not found.';
    } else {
        $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
        $catStmt->bind_param("i", $productRow['CategoryID']);
        $catStmt->execute();
        $categoryData = $catStmt->get_result()->fetch_assoc();
        $catStmt->close();
        storeRecoveryItem($conn, 'product', 'inventory', $productRow['InventoryID'], $productRow['InventoryName'], $productRow, $userFullName);
        $stmt = $conn->prepare("DELETE FROM inventory WHERE InventoryID = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $description = sprintf("Product removed: %s (Price: ₱%.2f, Category: %s)", $productRow['InventoryName'], $productRow['Price'], $categoryData['CategoryName'] ?? 'N/A');
            addSystemLog($conn, "Product Removed", $description, $userFullName);
            $_SESSION['success_message'] = 'Product removed successfully!';
        } else {
            $_SESSION['error_message'] = 'Error removing product: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle availability toggle
if (isset($_POST['toggle_status'])) {
    $id = (int)$_POST['inventory_id'];
    $stmt = $conn->prepare("SELECT InventoryName, is_available FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $productData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($productData) {
        $newStatus = $productData['is_available'] ? 0 : 1;
        $updateStmt = $conn->prepare("UPDATE inventory SET is_available = ? WHERE InventoryID = ?");
        $updateStmt->bind_param("ii", $newStatus, $id);
        if ($updateStmt->execute()) {
            $statusLabel = $newStatus ? 'Available' : 'Unavailable';
            $description = sprintf("Product status updated: %s is now %s", $productData['InventoryName'], $statusLabel);
            addSystemLog($conn, "Product Status Updated", $description, $userFullName);
            $_SESSION['success_message'] = 'Product status updated successfully!';
        } else {
            $_SESSION['error_message'] = 'Error updating product status: ' . $updateStmt->error;
        }
        $updateStmt->close();
    }
}

// Get selected category from GET parameter
$selectedCategoryId = isset($_GET['category']) ? (int)$_GET['category'] : null;

// Fetch all categories
$categoryResult = $conn->query("SELECT *, DATE_FORMAT(date_created, '%Y-%m-%d %h:%i %p') as formatted_date FROM categories ORDER BY CategoryName ASC");
$categories = [];
while ($category = $categoryResult->fetch_assoc()) {
    $categories[] = $category;
}

// Fetch products for selected category (or all if none selected)
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';
$sortColumn = isset($_GET['sort_column']) ? $_GET['sort_column'] : 'date_created';
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

$query = "SELECT i.InventoryID, i.InventoryName, i.Price, i.Quantity, c.CategoryName, i.CategoryID, i.ImagePath, i.date_created, i.is_available 
          FROM inventory i 
          JOIN categories c ON i.CategoryID = c.CategoryID";

$conditions = [];
if ($selectedCategoryId) {
    $conditions[] = "i.CategoryID = ?";
}
if (!empty($searchTerm)) {
    $conditions[] = "(i.InventoryName LIKE ? OR i.InventoryID LIKE ?)";
}

if (count($conditions) > 0) {
    $query .= " WHERE " . implode(' AND ', $conditions);
}

$allowedColumns = ['InventoryID', 'InventoryName', 'Price', 'CategoryName', 'date_created', 'is_available'];
$sortColumn = in_array($sortColumn, $allowedColumns) ? $sortColumn : 'date_created';
$sortOrder = strtoupper($sortOrder) === 'ASC' ? 'ASC' : 'DESC';
$sortColumnWithAlias = $sortColumn === 'CategoryName' ? 'c.' . $sortColumn : 'i.' . $sortColumn;
$query .= " ORDER BY " . $sortColumnWithAlias . " " . $sortOrder;

$stmt = $conn->prepare($query);
if ($selectedCategoryId && !empty($searchTerm)) {
    $searchWildcard = '%' . $searchTerm . '%';
    $stmt->bind_param("iss", $selectedCategoryId, $searchWildcard, $searchWildcard);
} elseif ($selectedCategoryId) {
    $stmt->bind_param("i", $selectedCategoryId);
} elseif (!empty($searchTerm)) {
    $searchWildcard = '%' . $searchTerm . '%';
    $stmt->bind_param("ss", $searchWildcard, $searchWildcard);
}

$stmt->execute();
$productsResult = $stmt->get_result();

// Fetch all categories for dropdowns
$allCategoriesResult = $conn->query("SELECT * FROM categories ORDER BY CategoryName ASC");
$allCategories = [];
while ($cat = $allCategoriesResult->fetch_assoc()) {
    $allCategories[] = $cat;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* SweetAlert overrides */
        .swal2-input, .swal2-textarea, .swal2-select, .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        .swal2-validation-message { display: none !important; }
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Admin Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines when expanded */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        /* Split Layout */
        .management-container {
            display: flex;
            gap: 20px;
            height: calc(100vh - 100px);
        }

        .categories-panel {
            width: 350px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .products-panel {
            flex: 1;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }

        .panel-header {
            padding: 20px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .panel-header h2 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
        }

        .panel-header h2 i {
            color: #face0b !important;
            margin-right: 8px;
        }

        .panel-body {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
        }

        .products-panel .panel-body {
            display: flex;
            flex-direction: column;
            overflow: hidden;
            padding: 20px;
        }

        .products-panel .panel-body:not(:has(.table-scroll-wrapper)) {
            overflow-y: auto;
        }

        .products-panel .panel-body #productsContainer {
            flex: 1;
            min-height: 0;
            display: flex;
            flex-direction: column;
        }

        .table-scroll-wrapper {
            flex: 1;
            min-height: 0;
            overflow-y: auto;
            margin: 0 -20px;
            padding: 0 20px;
            background: #fff;
            border-radius: 12px;
        }

        /* Category List */
        .category-item {
            padding: 15px;
            margin-bottom: 10px;
            background: #f8f9fa;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.2s ease;
            border: 2px solid transparent;
        }

        .category-item:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }

        .category-item.active {
            background: #fff3cd;
            border-color: #face0b;
        }

        .category-item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        .category-name {
            font-weight: 600;
            font-size: 16px;
            color: #1e293b;
        }

        .category-actions {
            display: flex;
            gap: 5px;
        }

        .category-actions button {
            padding: 4px 8px;
            font-size: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-edit-category {
            background: #face0b;
            color: #000;
        }

        .btn-remove-category {
            background: #ef4444;
            color: white;
        }

        .category-date {
            font-size: 12px;
            color: #64748b;
        }

        /* Products Table */
        .products-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 10px;
        }

        .products-table thead {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #333;
            transform: translateZ(0);
            isolation: isolate;
        }

        .products-table thead tr {
            background: #333;
        }

        .products-table th {
            background-color: #333 !important;
            color: #ffffff;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 4px 0 0 #333;
            border-bottom: 4px solid #333;
        }

        .products-table th:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 0;
        }

        .products-table th:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 0;
        }

        .products-table tbody {
            position: relative;
            z-index: 1;
        }

        .products-table tbody tr {
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .products-table td {
            padding: 12px;
            font-size: 14px;
        }

        .product-image-cell {
            width: 80px;
            height: 80px;
            padding: 8px;
        }

        .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 8px;
        }

        .status-toggle-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
        }

        .status-available {
            background: #22c55e;
            color: white;
        }

        .status-unavailable {
            background: #ef4444;
            color: white;
        }

        /* Buttons (match User Management modal palette) */
        .btn-primary {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            padding: 8px 16px;
            border: none;
            border-radius: 999px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        /* Edit buttons use a neutral slate color to differ from yellow Add buttons */
        .btn-edit,
        button[onclick*="openEditProductModal"],
        button[onclick*="openEditCategoryModal"] {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            font-weight: 600;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 4px 8px rgba(250, 206, 11, 0.3);
        }

        .btn-edit:hover,
        button[onclick*="openEditProductModal"]:hover,
        button[onclick*="openEditCategoryModal"]:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 12px rgba(250, 206, 11, 0.4);
        }

        /* Modal styles - match User Management */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            transition: opacity 0.3s ease;
            opacity: 0;
            pointer-events: none;
        }
        .modal.show {
            display: flex;
            opacity: 1;
            pointer-events: auto;
            animation: modalFadeIn 0.3s;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: #ffffff;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 50%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
            border-radius: 15px;
            position: relative;
            box-shadow: 0 8px 32px rgba(0,0,0,0.18);
            animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-content:not(.add-user-modal) .modal-header {
            background: #333;
            color: #fff;
            padding: 20px 24px;
            border-radius: 12px 12px 0 0;
            margin: -20px -20px 0 -20px;
            display: flex;
            align-items: center;
            gap: 14px;
        }

        .modal-content:not(.add-user-modal) .modal-header h2 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
        }

        .modal-content:not(.add-user-modal) .modal-header h2 i {
            margin-right: 8px;
            color: #face0b;
        }

        .modal-body {
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 24px;
            max-height: calc(90vh - 160px);
            overflow-y: auto;
        }

        .modal-body::-webkit-scrollbar {
            width: 8px;
        }

        .modal-body::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb {
            background: rgba(51, 51, 51, 0.3);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb:hover {
            background: rgba(51, 51, 51, 0.5);
        }

        /* Modal "add-user-modal" system (match User Management look & typography) */
        .modal-content.add-user-modal {
            padding: 0;
            border: none;
            overflow: hidden;
            background: #f5f5f5;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
            max-width: 720px;
        }

        /* Exact header sizing like User Management */
        .modal-content.add-user-modal .modal-header {
            background: #333;
            color: #fff;
            padding: 28px 32px;
            display: flex;
            align-items: center;
            gap: 18px;
            margin: 0; /* override generic header negative margin */
            border-radius: 0;
        }

        .modal-content.add-user-modal .modal-header h2 {
            margin: 0;
            font-size: 26px;
            color: #fff;
        }

        .modal-header .modal-icon {
            width: 54px;
            height: 54px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.14);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            flex-shrink: 0;
        }

        .modal-header p {
            margin: 4px 0 0;
            color: rgba(255, 255, 255, 0.88);
            font-size: 14px;
            line-height: 1.5;
        }

        .section-card {
            background: #fff;
            border-radius: 18px;
            padding: 20px 22px 24px;
            border: 1px solid rgba(15, 23, 42, 0.08);
            box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 18px;
        }

        .section-header .section-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(250, 206, 11, 0.2);
            color: #b58500;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .section-header h3 {
            margin: 0;
            font-size: 18px;
            color: #0f172a;
            font-weight: 600;
        }

        .section-header p {
            display: none;
            color: #64748b;
            font-size: 14px;
        }

        .modal-content.add-user-modal .section-header p {
            display: block;
            color: #64748b;
            font-size: 13px;
            margin-top: 4px;
            font-weight: 400;
            text-transform: none;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 16px;
        }

        .form-grid .form-group {
            margin-bottom: 0;
        }

        .modal-content.add-user-modal .form-group.full-width {
            grid-column: 1 / -1;
        }

        .modal-content.add-user-modal .form-group label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .modal-content.add-user-modal .form-group label i {
            font-size: 14px;
            color: #64748b;
        }

        .modal-content.add-user-modal .form-group label .required {
            color: #ef4444;
            font-weight: 700;
        }

        .modal-content.add-user-modal .form-group input[type="text"],
        .modal-content.add-user-modal .form-group input[type="number"],
        .modal-content.add-user-modal .form-group input[type="file"],
        .modal-content.add-user-modal .form-group select {
            width: 100%;
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 14px 16px;
            transition: all 0.3s ease;
            background: white;
            color: #1e293b;
            font-size: 15px;
            box-sizing: border-box;
        }

        .modal-content.add-user-modal .form-group input:focus,
        .modal-content.add-user-modal .form-group select:focus {
            border-color: #face0b;
            box-shadow: 0 0 0 4px rgba(250, 206, 11, 0.15);
            outline: none;
        }

        .modal-content.add-user-modal .form-group input::placeholder {
            color: #94a3b8;
            font-size: 14px;
        }

        .modal-content.add-user-modal .form-group .form-hint {
            color: #64748b;
            font-size: 12px;
            margin-top: 6px;
            display: block;
            line-height: 1.5;
        }

        .modal-content.add-user-modal .select-wrapper {
            position: relative;
        }

        .modal-content.add-user-modal .select-wrapper select {
            padding: 14px 40px 14px 16px;
            cursor: pointer;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }

        .modal-content.add-user-modal .select-wrapper .select-arrow {
            position: absolute;
            right: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            pointer-events: none;
            font-size: 12px;
        }

        .close {
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 12px;
            right: 18px;
            cursor: pointer;
            transition: color 0.3s;
            z-index: 10;
        }

        .close:hover,
        .close:focus {
            color: rgba(255, 255, 255, 0.7);
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding: 14px 26px 18px;
            border-top: 1px solid rgba(15, 23, 42, 0.08);
            background: #ffffff;
        }

        .modal-actions .btn-secondary,
        .modal-actions .btn-primary,
        .modal-actions .btn-edit {
            padding: 8px 18px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
        }

        .modal-actions .btn-secondary {
            background: rgba(15, 23, 42, 0.06);
            color: #1f2937;
            box-shadow: 0 2px 6px rgba(15, 23, 42, 0.08);
        }

        .modal-actions .btn-secondary:hover {
            background: rgba(15, 23, 42, 0.12);
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(15, 23, 42, 0.15);
        }

        .modal-actions .btn-primary:hover,
        .modal-actions .btn-edit:hover {
            transform: translateY(-1px);
        }

        .close {
            position: absolute;
            top: 16px;
            right: 20px;
            color: #ffffff;
            font-size: 26px;
            font-weight: 700;
            cursor: pointer;
            text-shadow: 0 2px 6px rgba(0, 0, 0, 0.6);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #1e293b;
            font-size: 13px;
            letter-spacing: 0.3px;
            text-transform: uppercase;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            box-sizing: border-box;
        }

        .search-box {
            padding: 10px 14px 10px 40px;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            font-size: 14px;
            transition: border 0.2s ease, box-shadow 0.2s ease;
            background: white;
            width: 100%;
            box-sizing: border-box;
        }

        /* Remove shadows from all buttons in this form */
        button {
            box-shadow: none !important;
        }

        /* Page header to match Backup & Restore / other forms */
        .products-header {
            background: #ffffff;
            padding: 18px 24px;
            border-radius: 22px;
            margin: 0 0 24px 0;
            color: #333;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(0, 0, 0, 0.1);
        }

        .products-header-main {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            align-items: center;
            flex-wrap: wrap;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-title-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            background: rgba(250, 206, 11, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #face0b;
        }

        .header-title h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            letter-spacing: -0.5px;
        }

        .empty-state {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .empty-state i {
            font-size: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        /* Search bar: same as User Management */
        .search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
            padding: 10px 14px 10px 40px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px !important;
            outline: none !important;
        }
        .search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
        }
        .search-container { position: relative; }
        .search-container .input-with-icon { position: relative; }
        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

    <main>
        <div class="products-header">
            <div class="products-header-main">
                <div class="header-title">
                    <div class="header-title-icon">
                        <i class="fas fa-box"></i>
                    </div>
                    <h2>Product Management</h2>
                </div>
            </div>
        </div>

        <div class="management-container">
            <!-- Left Panel: Categories -->
            <div class="categories-panel">
                <div class="panel-header">
                    <h2><i class="fas fa-list-alt"></i> Categories</h2>
                    <button class="btn-primary" onclick="openAddCategoryModal()">
                        <i class="fas fa-plus"></i> Add
                    </button>
                </div>
                <div class="panel-body">
                    <div class="search-container" style="margin-bottom: 12px;">
                        <div class="input-with-icon" style="width: 100%; max-width: 300px;">
                            <i class="fas fa-search"></i>
                            <input type="text" class="search-box" id="categorySearch" placeholder="Search categories..." onkeyup="filterCategories()">
                        </div>
                    </div>
                    <div id="categoriesList">
                        <?php foreach ($categories as $category): ?>
                            <div class="category-item <?php echo ($selectedCategoryId == $category['CategoryID']) ? 'active' : ''; ?>" 
                                 onclick="selectCategory(<?php echo $category['CategoryID']; ?>)">
                                <div class="category-item-header">
                                    <span class="category-name"><?php echo htmlspecialchars($category['CategoryName']); ?></span>
                                    <div class="category-actions" onclick="event.stopPropagation();">
                                        <button class="btn-edit-category" onclick="openEditCategoryModal(<?php echo $category['CategoryID']; ?>, '<?php echo htmlspecialchars($category['CategoryName'], ENT_QUOTES); ?>')">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn-remove-category" onclick="confirmRemoveCategory(<?php echo $category['CategoryID']; ?>, '<?php echo htmlspecialchars($category['CategoryName']); ?>')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="category-date"><?php echo htmlspecialchars($category['formatted_date']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right Panel: Products -->
            <div class="products-panel">
                <div class="panel-header">
                    <h2>
                        <i class="fas fa-box"></i> Products
                        <?php if ($selectedCategoryId): ?>
                            <span style="font-size: 14px; font-weight: normal; color: #64748b;">
                                - <?php echo htmlspecialchars($categories[array_search($selectedCategoryId, array_column($categories, 'CategoryID'))]['CategoryName'] ?? 'Unknown'); ?>
                            </span>
                        <?php endif; ?>
                    </h2>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <div class="search-container">
                            <div class="input-with-icon" style="width: 200px;">
                                <i class="fas fa-search"></i>
                                <input type="text" class="search-box" id="productSearch" placeholder="Search products..." style="width: 100%; margin: 0;" onkeyup="searchProducts()">
                            </div>
                        </div>
                        <button class="btn-primary" onclick="openAddProductModal()">
                            <i class="fas fa-plus"></i> Add Product
                        </button>
                    </div>
                </div>
                <div class="panel-body">
                    <div id="productsContainer">
                        <?php if ($productsResult->num_rows > 0): ?>
                            <div class="table-scroll-wrapper">
                            <table class="products-table">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Category</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($product = $productsResult->fetch_assoc()): 
                                        $imagePath = !empty($product['ImagePath']) ? 
                                            (strpos($product['ImagePath'], '../') === 0 ? $product['ImagePath'] : '../' . $product['ImagePath']) : 
                                            '../images/no-image.png';
                                        $isAvailable = (int)$product['is_available'] === 1;
                                        $statusLabel = $isAvailable ? 'Available' : 'Unavailable';
                                        $statusClass = $isAvailable ? 'status-available' : 'status-unavailable';
                                    ?>
                                        <tr>
                                            <td class="product-image-cell">
                                                <img src="<?php echo $imagePath; ?>" alt="<?php echo htmlspecialchars($product['InventoryName']); ?>" class="product-image">
                                            </td>
                                            <td><?php echo htmlspecialchars($product['InventoryName']); ?></td>
                                            <td>₱<?php echo number_format($product['Price'], 2); ?></td>
                                            <td><?php echo htmlspecialchars($product['CategoryName']); ?></td>
                                            <td>
                                                <form method="POST" style="display: inline;">
                                                    <input type="hidden" name="inventory_id" value="<?php echo $product['InventoryID']; ?>">
                                                    <button type="submit" name="toggle_status" class="status-toggle-btn <?php echo $statusClass; ?>">
                                                        <?php echo $statusLabel; ?>
                                                    </button>
                                                </form>
                                            </td>
                                            <td>
                                                <button class="btn-edit" onclick="openEditProductModal(<?php echo $product['InventoryID']; ?>, '<?php echo htmlspecialchars($product['InventoryName'], ENT_QUOTES); ?>', <?php echo $product['Price']; ?>, <?php echo $product['CategoryID']; ?>)">
                                                    <i class="fas fa-edit"></i> Edit
                                                </button>
                                                <button style="background: #ef4444; color: white; padding: 6px 12px; border: none; border-radius: 20px; cursor: pointer;" onclick="confirmRemoveProduct(<?php echo $product['InventoryID']; ?>, '<?php echo htmlspecialchars($product['InventoryName'], ENT_QUOTES); ?>')">
                                                    <i class="fas fa-trash"></i> Remove
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="fas fa-box-open"></i>
                                <p>No products found<?php echo $selectedCategoryId ? ' in this category' : ''; ?>.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Category Modals -->
    <div id="addCategoryModal" class="modal">
        <div class="modal-content add-user-modal">
            <span class="close" onclick="closeAddCategoryModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-tags"></i>
                </div>
                <div>
                    <h2>Add Category</h2>
                    <p>Create a new product category for organizing items</p>
                </div>
            </div>
            <form method="POST" class="modal-body">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-tag"></i>
                        </div>
                        <div>
                            <h3>Category Details</h3>
                            <p>Enter a unique category name</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-tag"></i> Category Name <span class="required">*</span>
                            </label>
                            <input type="text" name="category_name" placeholder="e.g., Beverages, Food, Desserts" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,50}$" title="2–50 characters, letters, numbers, spaces, basic punctuation">
                            <small class="form-hint">This name will be used to group products in the POS.</small>
                        </div>
                    </div>
                    <div class="modal-actions">
                        <button type="submit" name="add_category" class="btn-primary">
                            <i class="fas fa-plus"></i> Create Category
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div id="editCategoryModal" class="modal">
        <div class="modal-content add-user-modal">
            <span class="close" onclick="closeEditCategoryModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-edit"></i>
                </div>
                <div>
                    <h2>Edit Category</h2>
                    <p>Update category name and save changes</p>
                </div>
            </div>
            <form method="POST" class="modal-body">
                <input type="hidden" id="edit_category_id" name="category_id">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-tag"></i>
                        </div>
                        <div>
                            <h3>Category Details</h3>
                            <p>Edit the category name</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-tag"></i> Category Name <span class="required">*</span>
                            </label>
                            <input type="text" id="edit_category_name" name="category_name" placeholder="Enter category name" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,50}$" title="2–50 characters, letters, numbers, spaces, basic punctuation">
                            <small class="form-hint">Make sure the name stays unique and descriptive.</small>
                        </div>
                    </div>
                    <div class="modal-actions">
                        <button type="submit" name="edit_category" class="btn-primary">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Product Modals -->
    <div id="addProductModal" class="modal">
        <div class="modal-content add-user-modal">
            <span class="close" onclick="closeAddProductModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-box-open"></i>
                </div>
                <div>
                    <h2>Add Product</h2>
                    <p>Create a new product and assign it to a category</p>
                </div>
            </div>
            <form method="POST" enctype="multipart/form-data" class="modal-body">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-box"></i>
                        </div>
                        <div>
                            <h3>Product Details</h3>
                            <p>Enter product name, price, category, and optional image</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-box"></i> Product Name <span class="required">*</span>
                            </label>
                            <input type="text" name="inventory_name" placeholder="Enter product name" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,100}$" title="2–100 characters, letters, numbers, spaces, basic punctuation">
                            <small class="form-hint">Use a clear, unique product name.</small>
                        </div>

                        <div class="form-group">
                            <label>
                                <i class="fas fa-tag"></i> Category <span class="required">*</span>
                            </label>
                            <div class="select-wrapper">
                                <select name="category_id" required>
                                    <option value="">Select a category</option>
                                    <?php foreach ($allCategories as $cat): ?>
                                        <option value="<?php echo $cat['CategoryID']; ?>" <?php echo ($selectedCategoryId == $cat['CategoryID']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($cat['CategoryName']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <i class="fas fa-chevron-down select-arrow"></i>
                            </div>
                            <small class="form-hint">Choose where the product should appear.</small>
                        </div>

                        <div class="form-group">
                            <label>
                                <i class="fas fa-coins"></i> Price <span class="required">*</span>
                            </label>
                            <input type="number" step="0.01" min="0.01" name="price" placeholder="0.00" required title="Positive number with up to 2 decimal places">
                            <small class="form-hint">Set the selling price in PHP.</small>
                        </div>

                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-image"></i> Product Image <small style="font-weight:400; text-transform:none;">(optional)</small>
                            </label>
                            <input type="file" name="product_image" accept="image/*">
                            <small class="form-hint">PNG/JPG recommended. Leave empty to use the default image.</small>
                        </div>
                    </div>

                    <!-- Action Buttons (inside Product Details container) -->
                    <div class="modal-actions">
                        <button type="submit" name="add_product" class="btn-primary">
                            <i class="fas fa-plus"></i> Create Product
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div id="editProductModal" class="modal">
        <div class="modal-content add-user-modal">
            <span class="close" onclick="closeEditProductModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-pen"></i>
                </div>
                <div>
                    <h2>Edit Product</h2>
                    <p>Update product details and save changes</p>
                </div>
            </div>
            <form method="POST" enctype="multipart/form-data" class="modal-body">
                <input type="hidden" id="edit_inventory_id" name="inventory_id">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-box"></i>
                        </div>
                        <div>
                            <h3>Product Details</h3>
                            <p>Edit name, category, price, and optional image</p>
                        </div>
                    </div>
                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-box"></i> Product Name <span class="required">*</span>
                            </label>
                            <input type="text" id="edit_inventory_name" name="inventory_name" placeholder="Enter product name" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,100}$" title="2–100 characters, letters, numbers, spaces, basic punctuation">
                            <small class="form-hint">Update the product name displayed in the POS.</small>
                        </div>

                        <div class="form-group">
                            <label>
                                <i class="fas fa-tag"></i> Category <span class="required">*</span>
                            </label>
                            <div class="select-wrapper">
                                <select id="edit_category_id" name="category_id" required>
                                    <option value="">Select a category</option>
                                    <?php foreach ($allCategories as $cat): ?>
                                        <option value="<?php echo $cat['CategoryID']; ?>">
                                            <?php echo htmlspecialchars($cat['CategoryName']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <i class="fas fa-chevron-down select-arrow"></i>
                            </div>
                            <small class="form-hint">Choose the category where this product belongs.</small>
                        </div>

                        <div class="form-group">
                            <label>
                                <i class="fas fa-coins"></i> Price <span class="required">*</span>
                            </label>
                            <input type="number" step="0.01" min="0.01" id="edit_price" name="price" placeholder="0.00" required title="Positive number with up to 2 decimal places">
                            <small class="form-hint">Update the selling price in PHP.</small>
                        </div>

                        <div class="form-group full-width">
                            <label>
                                <i class="fas fa-image"></i> Product Image <small style="font-weight:400; text-transform:none;">(optional)</small>
                            </label>
                            <input type="file" name="product_image" accept="image/*">
                            <small class="form-hint">Leave empty to keep the current product image.</small>
                        </div>
                    </div>

                    <!-- Action Buttons (inside Product Details container) -->
                    <div class="modal-actions">
                        <button type="submit" name="edit_product" class="btn-primary">
                            <i class="fas fa-save"></i> Save Changes
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        <?php if (isset($_SESSION['success_message'])): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo $_SESSION['success_message']; ?>',
                confirmButtonColor: '#face0b'
            });
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo $_SESSION['error_message']; ?>',
                confirmButtonColor: '#ef4444'
            });
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        // Sidebar toggle functionality with persistence
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                // Save state to localStorage
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }

        // Restore sidebar state on page load (without transition)
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                // Disable transitions during state restoration
                sidebar.classList.add('no-transition');
                
                // Check localStorage for saved state
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                
                // Re-enable transitions after a short delay
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }
        });

        function selectCategory(categoryId) {
            window.location.href = 'product_management.php?category=' + categoryId;
        }

        function filterCategories() {
            const search = document.getElementById('categorySearch').value.toLowerCase();
            const items = document.querySelectorAll('.category-item');
            items.forEach(item => {
                const name = item.querySelector('.category-name').textContent.toLowerCase();
                item.style.display = name.includes(search) ? 'block' : 'none';
            });
        }

        function searchProducts() {
            const search = document.getElementById('productSearch').value.toLowerCase();
            const rows = document.querySelectorAll('.products-table tbody tr');
            rows.forEach(row => {
                const name = row.cells[1].textContent.toLowerCase();
                row.style.display = name.includes(search) ? '' : 'none';
            });
        }

        function openAddCategoryModal() {
            document.getElementById('addCategoryModal').classList.add('show');
        }

        function closeAddCategoryModal() {
            document.getElementById('addCategoryModal').classList.remove('show');
        }

        function openEditCategoryModal(id, name) {
            document.getElementById('edit_category_id').value = id;
            document.getElementById('edit_category_name').value = name;
            document.getElementById('editCategoryModal').classList.add('show');
        }

        function closeEditCategoryModal() {
            document.getElementById('editCategoryModal').classList.remove('show');
        }

        function confirmRemoveCategory(id, name) {
            Swal.fire({
                title: 'Remove category?',
                text: `Do you want to remove "${name}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, remove it'
            }).then((result) => {
                if (result.isConfirmed) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="category_id" value="${id}">
                        <input type="hidden" name="remove_category" value="1">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        function openAddProductModal() {
            document.getElementById('addProductModal').classList.add('show');
        }

        function closeAddProductModal() {
            document.getElementById('addProductModal').classList.remove('show');
        }

        function openEditProductModal(id, name, price, categoryId) {
            document.getElementById('edit_inventory_id').value = id;
            document.getElementById('edit_inventory_name').value = name;
            document.getElementById('edit_price').value = price;
            document.getElementById('edit_category_id').value = categoryId;
            document.getElementById('editProductModal').classList.add('show');
        }

        function closeEditProductModal() {
            document.getElementById('editProductModal').classList.remove('show');
        }

        function confirmRemoveProduct(id, name) {
            Swal.fire({
                title: 'Remove product?',
                text: `Do you want to remove "${name}"?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, remove it'
            }).then((result) => {
                if (result.isConfirmed) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.innerHTML = `
                        <input type="hidden" name="inventory_id" value="${id}">
                        <input type="hidden" name="remove_product" value="1">
                    `;
                    document.body.appendChild(form);
                    form.submit();
                }
            });
        }

        function confirmLogout(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        }

        // Close modals on outside click
        window.onclick = function(event) {
            const modals = ['addCategoryModal', 'editCategoryModal', 'addProductModal', 'editProductModal'];
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
                if (event.target == modal) {
                    modal.classList.remove('show');
                }
            });
        }

        // Update sidebar date and time
        function updateSidebarDateTime() {
            const now = new Date();
            const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });
            const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            if (dateElement) dateElement.textContent = dateStr;
            if (timeElement) timeElement.textContent = timeStr;
        }
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);
    </script>
    <script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>
