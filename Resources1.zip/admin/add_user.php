<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

require_once __DIR__ . '/../config/connection.php'; // Include the database connection
require_once __DIR__ . '/../lib/log_helper.php'; // Include logging functionality

function isAjaxRequest() {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        return true;
    }
    if (!empty($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
        return true;
    }
    return false;
}

$isAjax = isAjaxRequest();

// Get the current logged-in user's username from session
$currentSessionUsername = $_SESSION['Username'] ?? '';

// Get user's full name - use BINARY for case-sensitive matching to ensure we get the correct user
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE BINARY Username = ?");
$userQuery->bind_param("s", $currentSessionUsername);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userQuery->close();

// Determine display name - prioritize FullName, fallback to Username, then Administrator
if (!empty($userData) && !empty($userData['FullName']) && trim($userData['FullName']) !== '') {
    $userFullName = trim($userData['FullName']);
} elseif (!empty($userData) && !empty($userData['Username'])) {
    $userFullName = $userData['Username'];
} else {
    $userFullName = 'Administrator';
}

if ($isAjax) {
    header('Content-Type: application/json');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get role from POST, validate it, default to Cashier if invalid
    $role = isset($_POST['role']) ? $_POST['role'] : 'Cashier';
    // Validate role - only allow Admin or Cashier
    if ($role !== 'Admin' && $role !== 'Cashier') {
        $role = 'Cashier';
    }
    $fullName = trim($_POST['fullName'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $recoveryQuestion = $_POST['recoveryQuestion'] ?? '';
    $recoveryAnswer = trim($_POST['recoveryAnswer'] ?? '');
    $dateCreated = date('Y-m-d H:i:s');

    // Validate full name: 2-50 chars, letters/spaces/basic punctuation
    if (!preg_match('/^[A-Za-zÀ-ž\s.\'\-]{2,50}$/', $fullName)) {
        $msg = 'Full name must be 2–50 characters (letters, spaces, and basic punctuation only).';
        if ($isAjax) { echo json_encode(['success' => false, 'message' => $msg]); } else { header('Location: user_management.php?error=' . urlencode($msg)); }
        exit();
    }

    // Validate username: 4-20 chars, letters/numbers/underscore
    if (!preg_match('/^[A-Za-z0-9_]{4,20}$/', $username)) {
        $msg = 'Username must be 4–20 characters (letters, numbers, and underscore only).';
        if ($isAjax) { echo json_encode(['success' => false, 'message' => $msg]); } else { header('Location: user_management.php?error=' . urlencode($msg)); }
        exit();
    }

    // Validate email
    if (!empty($email) && !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
        $msg = 'Please enter a valid email address.';
        if ($isAjax) { echo json_encode(['success' => false, 'message' => $msg]); } else { header('Location: user_management.php?error=' . urlencode($msg)); }
        exit();
    }

    // Validate recovery answer: 2-100 chars
    if (!empty($recoveryAnswer) && !preg_match('/^.{2,100}$/', $recoveryAnswer)) {
        $msg = 'Recovery answer must be 2–100 characters.';
        if ($isAjax) { echo json_encode(['success' => false, 'message' => $msg]); } else { header('Location: user_management.php?error=' . urlencode($msg)); }
        exit();
    }

    // Validate password
    if (empty($password)) {
        $msg = 'Password is required.';
        if ($isAjax) {
            echo json_encode(['success' => false, 'message' => $msg]);
        } else {
            header('Location: user_management.php?error=' . urlencode($msg));
        }
        exit();
    }

    // Validate password pattern: at least 6 characters, 1 uppercase letter, 1 number
    $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/';
    if (!preg_match($passwordPattern, $password)) {
        $msg = 'Password must be at least 6 characters long and contain at least one uppercase letter and one number.';
        if ($isAjax) {
            echo json_encode(['success' => false, 'message' => $msg]);
        } else {
            header('Location: user_management.php?error=' . urlencode($msg));
        }
        exit();
    }

    // Validate password confirmation
    if ($password !== $confirmPassword) {
        $msg = 'Passwords do not match. Please re-enter.';
        if ($isAjax) {
            echo json_encode(['success' => false, 'message' => $msg]);
        } else {
            header('Location: user_management.php?error=' . urlencode($msg));
        }
        exit();
    }

    // Hash the password after validation
    $password = password_hash($password, PASSWORD_DEFAULT);

    // Check if username, full name, or email already exists
    $checkStmt = $conn->prepare("SELECT Username, FullName, Email FROM loginaccount WHERE Username = ? OR FullName = ? OR (Email = ? AND Email != '')");
    $checkStmt->bind_param("sss", $username, $fullName, $email);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($row['Username'] === $username) {
            $msg = 'Username already exists. Please choose a different username.';
            if ($isAjax) {
                echo json_encode(['success' => false, 'message' => $msg]);
            } else {
                header('Location: user_management.php?error=' . urlencode($msg));
            }
        } else if ($row['FullName'] === $fullName) {
            $msg = 'Full name already exists. Please use a different full name.';
            if ($isAjax) {
                echo json_encode(['success' => false, 'message' => $msg]);
            } else {
                header('Location: user_management.php?error=' . urlencode($msg));
            }
        } else if ($row['Email'] === $email && $email !== '') {
            $msg = 'Email already exists. Please use a different email address.';
            if ($isAjax) {
                echo json_encode(['success' => false, 'message' => $msg]);
            } else {
                header('Location: user_management.php?error=' . urlencode($msg));
            }
        }
        exit();
    }
    $checkStmt->close();

    // Prepare and bind - include Email in the INSERT
    $stmt = $conn->prepare("INSERT INTO loginaccount (Role, FullName, Username, Email, Password, RecoveryQuestion, RecoveryAnswer, Date_Created) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $role, $fullName, $username, $email, $password, $recoveryQuestion, $recoveryAnswer, $dateCreated);

    if ($stmt->execute()) {
        // Log the user creation
        $description = "New user account created: " . $username;
        addSystemLog($conn, "User Created", $description, $userFullName);

        $msg = 'User added successfully!';
        if ($isAjax) {
            echo json_encode(['success' => true, 'message' => $msg]);
        } else {
            header('Location: user_management.php?success=' . urlencode($msg));
        }
    } else {
        $msg = 'Error adding user: ' . $stmt->error;
        if ($isAjax) {
            echo json_encode(['success' => false, 'message' => $msg]);
        } else {
            header('Location: user_management.php?error=' . urlencode($msg));
        }
    }

    $stmt->close();
} else {
    $msg = 'Invalid request method';
    if ($isAjax) {
        echo json_encode(['success' => false, 'message' => $msg]);
    } else {
        header('Location: user_management.php?error=' . urlencode($msg));
    }
}

$conn->close();
?>