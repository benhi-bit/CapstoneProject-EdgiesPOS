<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = $userData['FullName'] ?? 'Administrator';
$userQuery->close();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

if (!isset($_FILES['backup_file']) || $_FILES['backup_file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error occurred']);
    exit();
}

$file = $_FILES['backup_file'];
$fileName = $file['name'];
$fileTmpName = $file['tmp_name'];
$fileSize = $file['size'];
$fileError = $file['error'];

// Validate file type
$fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
if ($fileExt !== 'sql') {
    echo json_encode(['success' => false, 'message' => 'Invalid file type. Please upload a .sql file']);
    exit();
}

// Validate file size (max 50MB)
if ($fileSize > 50 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'File size exceeds 50MB limit']);
    exit();
}

// Read the SQL file
$sqlContent = file_get_contents($fileTmpName);
if ($sqlContent === false) {
    echo json_encode(['success' => false, 'message' => 'Failed to read backup file']);
    exit();
}

// Disable foreign key checks temporarily
$conn->query("SET FOREIGN_KEY_CHECKS = 0");

// Split SQL file into individual queries
// Remove comments and split by semicolon
$sqlContent = preg_replace('/--.*$/m', '', $sqlContent);
$sqlContent = preg_replace('/\/\*.*?\*\//s', '', $sqlContent);
$queries = array_filter(array_map('trim', explode(';', $sqlContent)));

$successCount = 0;
$errorCount = 0;
$errors = [];

foreach ($queries as $query) {
    $query = trim($query);
    if (empty($query) || strlen($query) < 10) {
        continue;
    }
    
    // Skip SET statements that might cause issues
    if (preg_match('/^(SET|COMMIT|START TRANSACTION)/i', $query)) {
        continue;
    }
    
    if ($conn->query($query)) {
        $successCount++;
    } else {
        $errorCount++;
        $errors[] = $conn->error;
        // Don't stop on error, continue with other queries
    }
}

// Re-enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

if ($errorCount > 0 && $successCount === 0) {
    // All queries failed
    echo json_encode([
        'success' => false,
        'message' => 'Database restore failed. ' . implode('; ', array_slice($errors, 0, 3))
    ]);
} else if ($errorCount > 0) {
    // Some queries failed
    addSystemLog($conn, "Database Restore", "Database restored with {$successCount} successful queries and {$errorCount} errors. File: {$fileName}", $userFullName);
    echo json_encode([
        'success' => true,
        'message' => "Database restored with {$successCount} successful queries. {$errorCount} queries had errors.",
        'warnings' => array_slice($errors, 0, 5)
    ]);
} else {
    // All queries succeeded
    addSystemLog($conn, "Database Restore", "Database successfully restored from file: {$fileName}", $userFullName);
    echo json_encode([
        'success' => true,
        'message' => "Database successfully restored from backup file: {$fileName}"
    ]);
}

$conn->close();
?>
