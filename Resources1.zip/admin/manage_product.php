<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php'; // Include your database connection
require_once __DIR__ . '/../lib/log_helper.php'; // Include logging functionality
require_once __DIR__ . '/../lib/recovery_helper.php';

// Ensure is_available column exists for availability toggling
$availabilityColumnCheck = $conn->query("SHOW COLUMNS FROM inventory LIKE 'is_available'");
if ($availabilityColumnCheck && $availabilityColumnCheck->num_rows === 0) {
    $conn->query("ALTER TABLE inventory ADD COLUMN is_available TINYINT(1) NOT NULL DEFAULT 1");
}
if ($availabilityColumnCheck) {
    $availabilityColumnCheck->close();
}

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');
$userQuery->close();

ensureRecoveryTableExists($conn);

// Handle form submission for adding a new product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $inventoryName = trim($_POST['inventory_name'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $categoryId = $_POST['category_id'];

    // Validate product name: 2-100 chars, letters/numbers/spaces/basic punctuation
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,100}$/', $inventoryName)) {
        $_SESSION['error_message'] = 'Product name must be 2–100 characters (letters, numbers, spaces, basic punctuation).';
        header('Location: manage_product.php'); exit();
    }
    // Validate price: positive number with up to 2 decimal places
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $price) || floatval($price) <= 0) {
        $_SESSION['error_message'] = 'Price must be a positive number (up to 2 decimal places).';
        header('Location: manage_product.php'); exit();
    }

    // Check if product name already exists
        $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM inventory WHERE InventoryName = ?");
    $checkStmt->bind_param("s", $inventoryName);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();

    if ($row['count'] > 0) {
        $_SESSION['error_message'] = 'A product with this name already exists.';
    } else {
        // Handle image upload
        $imagePath = null;
        if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
            $targetDir = "../images/";
            $fileName = time() . '_' . basename($_FILES['product_image']['name']);
            $targetPath = $targetDir . $fileName;
            
            // Check if image file is a actual image or fake image
            $check = getimagesize($_FILES['product_image']['tmp_name']);
            if($check !== false) {
                // Allow certain file formats
                $allowedTypes = array('jpg', 'jpeg', 'png');
                $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
                
                if(in_array($imageFileType, $allowedTypes)) {
                    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetPath)) {
                        $imagePath = $targetPath;
                    } else {
                        $_SESSION['error_message'] = 'Sorry, there was an error uploading your file.';
                    }
                } else {
                    $_SESSION['error_message'] = 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.';
                }
            } else {
                $_SESSION['error_message'] = 'File is not an image.';
            }
        }

        // Product name is unique, proceed with insertion
        $stmt = $conn->prepare("INSERT INTO inventory (CategoryID, InventoryName, Price, ImagePath) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isds", $categoryId, $inventoryName, $price, $imagePath);
        
        if ($stmt->execute()) {
            // Get category name for logging
            $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
            $catStmt->bind_param("i", $categoryId);
            $catStmt->execute();
            $categoryData = $catStmt->get_result()->fetch_assoc();
            $catStmt->close();

            // Add log for new product creation
            $description = sprintf(
                "New product added: %s (Price: ₱%.2f, Category: %s)",
                $inventoryName,
                $price,
                $categoryData['CategoryName']
            );
            addSystemLog($conn, "Product Created", $description, $userFullName);
            
            $_SESSION['success_message'] = 'Product added successfully!';
        } else {
            $_SESSION['error_message'] = 'Error adding product: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle editing of a product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_product'])) {
    $id = $_POST['inventory_id'];
    $inventoryName = trim($_POST['inventory_name'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $categoryId = $_POST['category_id'];

    // Validate product name
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,100}$/', $inventoryName)) {
        $_SESSION['error_message'] = 'Product name must be 2–100 characters (letters, numbers, spaces, basic punctuation).';
        header('Location: manage_product.php'); exit();
    }
    // Validate price
    if (!preg_match('/^\d+(\.\d{1,2})?$/', $price) || floatval($price) <= 0) {
        $_SESSION['error_message'] = 'Price must be a positive number (up to 2 decimal places).';
        header('Location: manage_product.php'); exit();
    }

    // Get old product details for logging
    $stmt = $conn->prepare("SELECT i.InventoryName, i.Price, i.CategoryID, c.CategoryName FROM inventory i JOIN categories c ON i.CategoryID = c.CategoryID WHERE i.InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $oldProduct = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    // Handle image upload
    $imagePath = null;
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
        $targetDir = "../images/";
        $fileName = time() . '_' . basename($_FILES['product_image']['name']);
        $targetPath = $targetDir . $fileName;
        
        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['product_image']['tmp_name']);
        if($check !== false) {
            // Allow certain file formats
            $allowedTypes = array('jpg', 'jpeg', 'png');
            $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));
            
            if(in_array($imageFileType, $allowedTypes)) {
                if (move_uploaded_file($_FILES['product_image']['tmp_name'], $targetPath)) {
                    $imagePath = $targetPath;
                } else {
                    $_SESSION['error_message'] = 'Sorry, there was an error uploading your file.';
                }
            } else {
                $_SESSION['error_message'] = 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.';
            }
        } else {
            $_SESSION['error_message'] = 'File is not an image.';
        }
    }

    // If no new image was uploaded, keep the existing image path
    if ($imagePath === null) {
        $stmt = $conn->prepare("SELECT ImagePath FROM inventory WHERE InventoryID = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $imagePath = $row['ImagePath'];
        $stmt->close();
    }

    $stmt = $conn->prepare("UPDATE inventory SET CategoryID = ?, InventoryName = ?, Price = ?, ImagePath = ? WHERE InventoryID = ?");
    $stmt->bind_param("isdsi", $categoryId, $inventoryName, $price, $imagePath, $id);
    
    if ($stmt->execute()) {
        // Get new category name for logging
        $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
        $catStmt->bind_param("i", $categoryId);
        $catStmt->execute();
        $newCategory = $catStmt->get_result()->fetch_assoc();
        $catStmt->close();

        // Build changes array for logging
        $changes = [];
        if ($oldProduct['InventoryName'] !== $inventoryName) {
            $changes[] = "name updated from '{$oldProduct['InventoryName']}' to '{$inventoryName}'";
        }
        if ($oldProduct['Price'] != $price) {
            $changes[] = sprintf("price updated from ₱%.2f to ₱%.2f", $oldProduct['Price'], $price);
        }
        if ($oldProduct['CategoryID'] != $categoryId) {
            $changes[] = "category updated from '{$oldProduct['CategoryName']}' to '{$newCategory['CategoryName']}'";
        }
        if ($imagePath !== $row['ImagePath']) {
            $changes[] = "image updated";
        }

        // Add log for product update
        if (!empty($changes)) {
            $description = sprintf(
                "Product updated (%s): %s",
                implode(", ", $changes),
                $oldProduct['InventoryName']
            );
            addSystemLog($conn, "Product Updated", $description, $userFullName);
        }

        $_SESSION['success_message'] = 'Product updated successfully!';
    } else {
        $_SESSION['error_message'] = 'Error updating product: ' . $stmt->error;
    }
    $stmt->close();
}

// Handle removal of a product
if (isset($_POST['remove_product'])) {
    $id = (int)$_POST['inventory_id'];

    // Get full product details before removal
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $productRow = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$productRow) {
        $_SESSION['error_message'] = 'Product not found.';
    } else {
        // Fetch category name for logging
        $catStmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
        $catStmt->bind_param("i", $productRow['CategoryID']);
        $catStmt->execute();
        $categoryData = $catStmt->get_result()->fetch_assoc();
        $catStmt->close();

        storeRecoveryItem(
            $conn,
            'product',
            'inventory',
            $productRow['InventoryID'],
            $productRow['InventoryName'],
            $productRow,
            $userFullName
        );

        // Prepare the delete statement
        $stmt = $conn->prepare("DELETE FROM inventory WHERE InventoryID = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $description = sprintf(
                "Product removed: %s (Price: ₱%.2f, Category: %s)",
                $productRow['InventoryName'],
                $productRow['Price'],
                $categoryData['CategoryName'] ?? 'N/A'
            );
            addSystemLog($conn, "Product Removed", $description, $userFullName);
            $_SESSION['success_message'] = 'Product removed successfully!';
        } else {
            $_SESSION['error_message'] = 'Error removing product: ' . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle availability toggle
if (isset($_POST['toggle_status'])) {
    $id = (int)$_POST['inventory_id'];

    $stmt = $conn->prepare("SELECT InventoryName, is_available FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $productData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($productData) {
        $newStatus = $productData['is_available'] ? 0 : 1;
        $updateStmt = $conn->prepare("UPDATE inventory SET is_available = ? WHERE InventoryID = ?");
        $updateStmt->bind_param("ii", $newStatus, $id);

        if ($updateStmt->execute()) {
            $statusLabel = $newStatus ? 'Available' : 'Unavailable';
            $description = sprintf(
                "Product status updated: %s is now %s",
                $productData['InventoryName'],
                $statusLabel
            );
            addSystemLog($conn, "Product Status Updated", $description, $userFullName);
            $_SESSION['success_message'] = 'Product status updated successfully!';
        } else {
            $_SESSION['error_message'] = 'Error updating product status: ' . $updateStmt->error;
        }
        $updateStmt->close();
    }
}

$searchTerm = '';
$categoryFilter = '';
$sortColumn = isset($_GET['sort_column']) ? $_GET['sort_column'] : 'date_created'; // Change default sort column
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC'; // Change default sort order

// Check if a search term is provided
if (isset($_POST['search_term'])) {
    $searchTerm = $_POST['search_term'];
}
// Handle search term and category filter
if (isset($_POST['search_term'])) {
    $searchTerm = $_POST['search_term'];
}

if (isset($_POST['category_filter'])) {
    $categoryFilter = $_POST['category_filter'];
}
// Check if a category filter is selected
if (isset($_POST['category_filter'])) {
    $categoryFilter = $_POST['category_filter'];
}

// Prepare the SQL query with search and category filter
$query = "SELECT i.InventoryID, i.InventoryName, i.Price, i.Quantity, c.CategoryName, i.CategoryID, i.ImagePath, i.date_created, i.is_available 
          FROM inventory i 
          JOIN categories c ON i.CategoryID = c.CategoryID";

// Initialize conditions array
$conditions = [];

// If the search term is not empty, add it to the conditions
if (!empty($searchTerm)) {
    $conditions[] = "(i.InventoryID LIKE ? OR i.InventoryName LIKE ?)";
}

// If a category filter is selected, add it to the conditions
if (!empty($categoryFilter)) {
    $conditions[] = "i.CategoryID = ?";
}

// If there are conditions, append them to the query
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(' AND ', $conditions);
}

// Add sorting
$query .= " ORDER BY $sortColumn $sortOrder";

// Prepare the statement
$stmt = $conn->prepare($query);

// Bind parameters for search
if (!empty($searchTerm)) {
    $searchWildcard = '%' . $searchTerm . '%';
    if (count($conditions) === 1) {
        $stmt->bind_param("ss", $searchWildcard, $searchWildcard);
    } elseif (count($conditions) === 2) {
        $stmt->bind_param("ssi", $searchWildcard, $searchWildcard, $categoryFilter);
    }
} elseif (!empty($categoryFilter)) {
    $stmt->bind_param("i", $categoryFilter);
}

// Execute the statement
$stmt->execute();
$result = $stmt->get_result();

// Fetch product details for editing if an edit is requested
$productToEdit = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE InventoryID = ?");
    $stmt->bind_param("i", $id);
    $productToEdit = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Fetch categories for the dropdown
$categoryResult = $conn->query("SELECT * FROM categories");
$categories = [];
while ($category = $categoryResult->fetch_assoc()) {
    $categories[] = $category;
}
$categoryCount = count($categories);

$totalQuery = "SELECT COUNT(*) AS total FROM inventory";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Product</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/cashier_inventory.css">
    <!-- Add SweetAlert2 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <!-- Add SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
    </style>
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    background-color: white;
}
/* Sidebar Styles */
nav.sidebar {
    width: 70px;
    background-color: #333;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    overflow-x: hidden;
    overflow-y: auto;
    z-index: 999;
    display: flex;
    flex-direction: column;
    transition: width 0.3s ease;
}

/* Disable transitions on page load */
nav.sidebar.no-transition,
nav.sidebar.no-transition * {
    transition: none !important;
}

nav.sidebar.sidebar-expanded {
    width: 200px;
}

/* Navigation items container - scrollable */
.sidebar-nav-items {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding-top: 20px;
    padding-bottom: 10px;
    min-height: 0; /* Important for flex scrolling */
}

nav.sidebar.sidebar-expanded .sidebar-nav-items {
    overflow-y: auto;
}

/* Custom scrollbar styling */
.sidebar-nav-items::-webkit-scrollbar {
    width: 6px;
}

.sidebar-nav-items::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.2);
}

.sidebar-nav-items::-webkit-scrollbar-thumb {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 3px;
}

.sidebar-nav-items::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, 0.5);
}

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

.sidebar-logo img {
    max-width: 100%;
    height: auto;
    max-height: 40px;
    object-fit: contain;
    margin-bottom: 5px;
    transition: max-height 0.3s ease, margin-bottom 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-logo img {
    max-height: 80px;
    margin-bottom: 10px;
}

.sidebar-logo .restaurant-name {
    color: white;
    font-size: 14px;
    font-weight: 600;
    line-height: 1.4;
    margin-top: 10px;
    transition: all 0.3s ease;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    text-align: center;
}

nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
    opacity: 1;
    max-height: 100px;
}

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

.sidebar-footer .cashier-name {
    color: white;
    font-size: 16px;
    font-weight: 500;
    line-height: 1.4;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.3s ease;
}

.sidebar-footer .cashier-name i {
    font-size: 14px;
}

.sidebar-footer .cashier-name span {
    opacity: 0;
    width: 0;
    overflow: hidden;
    transition: all 0.3s ease;
    display: inline-block;
}

nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
    opacity: 1;
    width: auto;
}

.sidebar-footer .sidebar-datetime {
    color: white;
    font-size: 14px;
    line-height: 1.6;
    text-align: center;
    transition: all 0.3s ease;
}

.sidebar-footer .sidebar-datetime #sidebar-date {
    font-weight: 500;
    margin-bottom: 5px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

.sidebar-footer .sidebar-datetime #sidebar-time {
    font-weight: 600;
    color: #face0b;
    font-size: 16px;
    opacity: 0;
    max-height: 0;
    overflow: hidden;
    transition: all 0.3s ease;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
    opacity: 1;
    max-height: 30px;
}

nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
    opacity: 1;
    max-height: 30px;
}

nav.sidebar a {
    color: white;
    padding: 14px 0;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    text-align: left;
    padding-left: 20px;
}

nav.sidebar a:hover {
    background-color: #ddd;
    color: black;
}

nav.sidebar a.active {
    background-color: #face0b;
    color: black;
}

nav.sidebar a i {
    margin-right: 0;
    width: 20px;
    text-align: center;
    display: inline-block;
}

nav.sidebar a span {
    transition: all 0.3s ease;
    opacity: 0;
    width: 0;
    overflow: hidden;
    display: inline-block;
}

nav.sidebar.sidebar-expanded a i {
    margin-right: 10px;
}

nav.sidebar.sidebar-expanded a span {
    opacity: 1;
    width: auto;
    white-space: normal;
    word-wrap: break-word;
    overflow-wrap: break-word;
    line-height: 1.3;
    max-width: 140px;
    display: inline-block;
}

/* Allow specific long navigation items to wrap to 2 lines when expanded */
nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
nav.sidebar.sidebar-expanded a[href*="user_management"] span {
    max-width: 130px;
}

/* Main Content Area */
main {
    margin-left: 90px;
    margin-top: 0;
    padding: 20px;
    flex-grow: 1;
    transition: margin-left 0.3s ease, width 0.3s ease;
    width: calc(100% - 90px);
    box-sizing: border-box;
    position: relative;
    overflow-x: hidden;
}

nav.sidebar.sidebar-expanded ~ main {
    margin-left: 220px;
    width: calc(100% - 220px);
}

/* Disable main content transitions on page load */
nav.sidebar.no-transition ~ main {
    transition: none !important;
}

/* Headings */
h1, h2 {
    font-size: 24px;
    margin-bottom: 15px;
}

h3 {
    font-size: 18px;
    margin-bottom: 10px;
}
/* Table styles - Modern Redesign */
.table-container {
    max-height: calc(100vh - 260px);
    overflow-y: auto;
    padding-right: 8px;
    position: relative;
    margin-top: 20px;
    border-radius: 12px;
}

.table-container::-webkit-scrollbar {
    width: 8px;
}

.table-container::-webkit-scrollbar-track {
    background: rgba(15, 23, 42, 0.05);
    border-radius: 10px;
}

.table-container::-webkit-scrollbar-thumb {
    background: rgba(15, 23, 42, 0.25);
    border-radius: 10px;
}

.table-container::-webkit-scrollbar-thumb:hover {
    background: rgba(15, 23, 42, 0.4);
}

#productsTable {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 12px;
    margin-top: 0;
    background: transparent;
}

#productsTable thead {
    position: sticky;
    top: 0;
    z-index: 20;
    background: #333;
    transform: translateZ(0);
    isolation: isolate;
}

#productsTable thead tr {
    background: #333;
}

#productsTable th {
    background-color: #333 !important;
    color: #ffffff;
    padding: 16px 20px;
    text-align: left;
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    cursor: pointer;
    border: none;
    position: relative;
    white-space: nowrap;
    transition: background-color 0.3s ease;
    box-shadow: 0 4px 0 0 #333;
    border-bottom: 4px solid #333;
}

#productsTable th:first-child {
    border-top-left-radius: 12px;
    border-bottom-left-radius: 0;
}

#productsTable th:last-child {
    border-top-right-radius: 12px;
    border-bottom-right-radius: 0;
}

#productsTable th:hover {
    background-color: #444;
}

#productsTable tbody {
    position: relative;
    z-index: 1;
}

#productsTable tbody tr {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    margin-bottom: 12px;
}

#productsTable tbody tr:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
    background: #ffffff;
}

#productsTable td {
    padding: 18px 20px;
    text-align: left;
    font-size: 15px;
    color: #1e293b;
    border: none;
    vertical-align: middle;
}

#productsTable td.status-cell {
    min-width: 160px;
}

.status-form {
    display: inline-flex;
    align-items: center;
    margin: 0;
    padding: 0;
}

.column-header {
    display: flex;
    align-items: center;
    gap: 8px;
}

.status-toggle-btn {
    border: none;
    border-radius: 999px;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    color: #fff;
}

.status-toggle-btn.status-available {
    background: linear-gradient(135deg, #22c55e, #16a34a);
    box-shadow: 0 8px 18px rgba(34, 197, 94, 0.35);
}

.status-toggle-btn.status-unavailable {
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
}

.status-toggle-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(0, 0, 0, 0.18);
}

#productsTable tbody tr td:first-child {
    border-top-left-radius: 12px;
    border-bottom-left-radius: 12px;
}

#productsTable tbody tr td:last-child {
    border-top-right-radius: 12px;
    border-bottom-right-radius: 12px;
}
/* Modal styles */
.modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    align-items: center;
    justify-content: center;
    transition: opacity 0.3s ease;
    opacity: 0;
    pointer-events: none;
}

.modal.show {
    display: flex;
    opacity: 1;
    pointer-events: auto;
    animation: modalFadeIn 0.3s;
}

@keyframes modalFadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.modal-content {
    background-color: #ffffff;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
    max-width: 600px;
    max-height: 90vh;
    overflow-y: auto;
    border-radius: 15px;
    position: relative;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
    transition: transform 0.2s, box-shadow 0.2s;
}

.modal-content.modal-modern {
    padding: 0;
    border: none;
    overflow: hidden;
    background: #f5f5f5;
    box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
    max-width: 720px;
}

.modal-header {
    background: #333;
    color: #fff;
    padding: 28px 32px;
    display: flex;
    align-items: center;
    gap: 18px;
}

.modal-header .modal-icon {
    width: 54px;
    height: 54px;
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.14);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    color: #fff;
}

.modal-header h2 {
    margin: 0;
    font-size: 26px;
    color: #fff;
}

.modal-header p {
    margin: 4px 0 0;
    color: rgba(255, 255, 255, 0.88);
    font-size: 14px;
    line-height: 1.5;
}

.modal-body {
    padding: 30px;
    display: flex;
    flex-direction: column;
    gap: 24px;
    max-height: calc(90vh - 160px);
    overflow-y: auto;
}

.modal-body::-webkit-scrollbar {
    width: 8px;
}

.modal-body::-webkit-scrollbar-track {
    background: rgba(0, 0, 0, 0.05);
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb {
    background: rgba(51, 51, 51, 0.3);
    border-radius: 10px;
}

.modal-body::-webkit-scrollbar-thumb:hover {
    background: rgba(51, 51, 51, 0.5);
}


.section-card {
    background: #fff;
    border-radius: 18px;
    padding: 20px 22px 24px;
    border: 1px solid rgba(15, 23, 42, 0.08);
    box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
}

.section-header {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px;
}

.section-header .section-icon {
    width: 40px;
    height: 40px;
    border-radius: 12px;
    background: rgba(250, 206, 11, 0.2);
    color: #b58500;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
}

.section-header h3 {
    margin: 0;
    font-size: 18px;
    color: #0f172a;
}

.section-header p {
    display: none;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.modal-actions .btn-secondary,
.modal-actions .btn-primary {
    padding: 8px 16px;
    border-radius: 999px;
    font-weight: 600;
    font-size: 13px;
    border: none;
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
}

.modal-actions .btn-secondary {
    background: rgba(0, 0, 0, 0.1);
    color: #333;
}

.modal-actions .btn-secondary:hover {
    background: rgba(0, 0, 0, 0.2);
    transform: translateY(-1px);
}

.modal-actions .btn-primary {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

.modal-actions .btn-primary:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

.modal-content.modal-modern label {
    font-size: 13px;
    letter-spacing: 0.3px;
    color: #1e293b;
    text-transform: uppercase;
    font-weight: 600;
}

.modal-content.modal-modern .form-group label i {
    font-size: 14px;
    color: #64748b;
}

.modal-content.modal-modern .input-with-icon input,
.modal-content.modal-modern .input-with-icon select {
    border-radius: 10px;
    border: 2px solid #e2e8f0;
    padding: 14px 16px 14px 40px;
    transition: all 0.3s ease;
    background: white;
    color: #1e293b;
    font-size: 15px;
    box-sizing: border-box;
}

.modal-content.modal-modern .input-with-icon i:not(.fa-eye):not(.fa-eye-slash) {
    color: #64748b;
    font-size: 14px;
}

.modal-content.modal-modern .input-with-icon input:focus,
.modal-content.modal-modern .input-with-icon select:focus {
    border-color: #face0b;
    box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25);
    outline: none;
}

.modal-content.modal-modern .form-group small.form-hint {
    color: #64748b;
    font-size: 12px;
    margin-top: 6px;
    display: block;
    line-height: 1.5;
}

.modal-content.modal-modern .image-upload-container {
    border: 1px solid rgba(0, 0, 0, 0.1);
    border-radius: 14px;
    padding: 20px;
    background: #f8f9fa;
}
@keyframes slideIn {
    0% {
        opacity: 0;
        transform: translateY(-50px);
    }
    100% {
        opacity: 1;
        transform: translateY(0);
    }
}

#addModal .image-upload-container,
#editModal .image-upload-container {
    margin: 0;
    text-align: center;
}

#addModal .image-preview,
#editModal .image-preview {
    min-height: 200px;
    margin-top: 10px;
    border: 2px dashed rgba(0, 0, 0, 0.2);
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background-color: #f8f9fa;
    position: relative;
}

#addModal .upload-btn-wrapper,
#editModal .upload-btn-wrapper {
    position: relative;
    overflow: hidden;
    display: inline-block;
    margin-top: 10px;
}

#addModal .upload-btn,
#editModal .upload-btn {
    border: 2px solid #face0b;
    color: #face0b;
    background-color: transparent;
    padding: 8px 20px;
    border-radius: 8px;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
}

#addModal .upload-btn:hover,
#editModal .upload-btn:hover {
    background-color: #face0b;
    color: #1a1a1a;
}

#addModal .upload-btn i,
#editModal .upload-btn i {
    font-size: 18px;
}

#addModal input[type="file"],
#editModal input[type="file"] {
    position: absolute;
    left: 0;
    top: 0;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

#addModal .upload-text,
#editModal .upload-text {
    margin-top: 10px;
    color: rgba(0, 0, 0, 0.6);
    font-size: 14px;
}

#addModal #preview_img,
#editModal #preview_edit_img {
    max-width: 100%;
    max-height: 200px;
    object-fit: contain;
}

#addModal button[type="submit"],
#editModal button[type="submit"] {
    grid-column: span 2;
    width: 200px;
    margin: 20px auto 0;
    border-radius: 999px;
    padding: 8px 16px;
}

#addModal input[type="text"],
#addModal input[type="number"],
#addModal select,
#addModal input[type="file"],
#editModal input[type="text"],
#editModal input[type="number"],
#editModal select,
#editModal input[type="file"] {
    border-radius: 8px;
    padding: 10px;
    border: 1px solid #ccc;
    font-size: 14px;
}

/* Close button style */
.close {
    color: #fff;
    font-size: 28px;
    font-weight: bold;
    position: absolute;
    top: 12px;
    right: 18px;
    cursor: pointer;
    transition: color 0.3s;
    z-index: 10;
}

.close:hover,
.close:focus {
    color: rgba(255, 255, 255, 0.7);
}

/* Modal Input and Form Elements */
.modal-content input[type="text"],
.modal-content input[type="number"],
.modal-content select {
    width: 95%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 6px;
    border: 1px solid rgba(0,0,0,0.2);
    font-size: 16px;
    background: white;
    color: #333;
}

.modal-content button[type="submit"] {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #face0b;
    color: #1a1a1a;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.modal-content button[type="submit"]:hover {
    background-color: #e0b108;
}

/* Add/Create buttons should match app primary palette */
.modal-content button[type="submit"][name="add_product"],
.modal-content button[type="submit"][name="add_category"] {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

.modal-content button[type="submit"][name="add_product"]:hover,
.modal-content button[type="submit"][name="add_category"]:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

/* Responsive Table Design */
@media screen and (max-width: 768px) {
    .products-header {
        padding: 16px 20px;
    }
    
    .products-header-main {
        flex-direction: column;
        align-items: stretch;
        gap: 16px;
    }
    
    .header-title {
        justify-content: center;
    }
    
    .header-actions {
        flex-direction: column;
        width: 100%;
    }
    
    .search-container {
        width: 100%;
    }
    
    .search-container .input-with-icon {
        width: 100%;
    }
    
    #searchForm {
        flex-wrap: wrap;
        width: 100%;
        gap: 12px;
    }
    
    #searchForm input[type="text"] {
        width: 100%;
        min-width: auto;
    }
    
    #searchForm select {
        width: 100%;
        margin-left: 0;
    }
    
    #addProductButton {
        width: 100%;
        justify-content: center;
    }
    
    #productsTable {
        font-size: 12px;
    }
    
    #productsTable th,
    #productsTable td {
        padding: 12px 10px;
        font-size: 13px;
    }
    
    #productsTable th {
        font-size: 11px;
        padding: 12px 8px;
    }
    
    .product-image-cell {
        width: 70px;
        height: 70px;
    }
    
    #productsTable button[onclick^="openModal"],
    #productsTable button[onclick*="confirmRemoveProduct"] {
        padding: 8px 12px;
        font-size: 11px;
        margin: 2px;
    }
    
    .modal-content {
        width: 80%; /* Adjust modal width for smaller screens */
    }

    .modal-content input[type="text"],
    .modal-content input[type="number"],
    .modal-content select {
        font-size: 14px; /* Adjust input size for smaller screens */
    }

    .modal-content button[type="submit"] {
        font-size: 14px; /* Adjust button size for smaller screens */
    }
}


/* Buttons */
button {
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    border: none;
    border-radius: 999px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

button:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

/* Add product button styles moved to .products-header-actions section above */

/* Remove button specific styles (red color) */
button[type="submit"][name="remove_product"] {
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    color: white;
    box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
}

button[type="submit"][name="remove_product"]:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
}

/* Background color classes for quantity */
.red-background {
    background-color: #FF7276;
    color: black;
}

.orange-background {
    background-color: #90ee90;
}

.yellow-background {
    background-color: #ffff64;
}

/* Responsive design for smaller screens */
@media screen and (max-width: 768px) {
    main {
        margin-left: 0;
        width: 100%;
    }

    
    nav.sidebar {
        display: none;
    }

    .table-container {
        max-height: calc(100vh - 200px);
        overflow-x: auto;
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
    }

    #productsTable {
        min-width: 700px;
    }

    #productsTable th,
    #productsTable td {
        padding: 12px 10px;
        font-size: 13px;
    }

    #productsTable th {
        font-size: 12px;
        padding: 10px 8px;
    }

    .modal-content {
        width: 80%;
    }
}
.user-profile {
    display: flex;
    align-items: center;
    color: white;
    font-size: 1.1em;
    font-weight: bold;
    margin-right: 5%;
}

.user-profile .fullname {
    color: #face0b;
}


/* Dropdown container */
.dropdown {
    position: relative; /* Position relative for absolute positioning of dropdown content */
}

/* Dropdown button */
.dropbtn {
    color: white;
    padding: 14px 20px;
    text-decoration: none;
    display: block; /* Make it block element */
}

/* Dropdown content (hidden by default) */
.dropdown-content {
    display: none; /* Hidden by default */
    position: relative; /* Change to relative to push down other items */
    background-color: #444; /* Dark background color for emphasis */
    min-width: 200px; /* Minimum width */
    z-index: 1; /* Sit on top */
    border-radius: 5px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for better visibility */
}

/* Links inside the dropdown */
.dropdown-content a {
    color: white; /* Text color */
    padding: 12px 16px; /* Padding */
    text-decoration: none; /* No underline */
    display: flex; /* Use flexbox for alignment */
    align-items: center; /* Center items vertically */
}

/* Style for icons */
.dropdown-content a i {
    margin-right: 10px; /* Space between icon and text */
}

/* Show the dropdown content on hover */
.dropdown:hover .dropdown-content {
    display: block; /* Show the dropdown */
}

/* Change background color on hover */
.dropdown-content a:hover {
    background-color: #555; /* Light background on hover */
    color: white; /* Keep text color white on hover */
}
/* Add styles for the sort indicators (up/down arrows) */
th {
    cursor: pointer;
    position: relative;
    padding-right: 20px; /* Make space for the arrow */
}
.sort-indicator {
    position: absolute;
    right: 5px;
}
.asc::after {
    content: '\2191'; /* Up arrow */
}
.desc::after {
    content: '\2193'; /* Down arrow */
}
.sorted::after {
    content: '\2195'; /* Toggle indicator */
}
.sort-btn {
    background: none;
    border: none;
    cursor: pointer;
    padding: 0 5px;
    color: #666;
}

.sort-btn:hover {
    color: #333;
}

.sort-btn.active {
    color: #000;
}

th {
    position: relative;
    padding-right: 25px;
}

/* Action Buttons - Matching Sidebar Color Palette */
#productsTable button[onclick^="openModal"] {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    padding: 8px 16px;
    margin: 0 4px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
}

#productsTable button[onclick^="openModal"]:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}

#productsTable button[onclick*="confirmRemoveProduct"] {
    background: linear-gradient(135deg, #ef4444, #b91c1c);
    color: #fff;
    padding: 8px 16px;
    margin: 0 4px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
}

#productsTable button[onclick*="confirmRemoveProduct"]:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
}

#productsTable button i {
    font-size: 13px;
}

/* Add these styles to your existing CSS */
.image-upload-container {
    margin: 10px 0;
}

.image-preview {
    margin-top: 10px;
    border: 1px dashed #ccc;
    padding: 10px;
    text-align: center;
    min-height: 100px;
    display: flex;
    align-items: center;
    justify-content: center;
}

#product_image {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

#preview_img {
    max-width: 200px;
    max-height: 200px;
    object-fit: contain;
}

/* Product Image Cell - Enhanced */
#productsTable td:first-child {
    width: 120px;
    padding: 12px;
}

.product-image-cell {
    width: 100px;
    height: 100px;
    padding: 8px;
    background: #f8f9fa;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.product-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 8px;
    transition: transform 0.3s ease;
}

#productsTable tbody tr:hover .product-image {
    transform: scale(1.05);
}

/* Sort Button Styling - White color without background or shadows */
.sort-btn {
    background: none;
    border: none;
    color: #ffffff;
    padding: 4px 8px;
    border-radius: 0;
    cursor: pointer;
    margin-left: 8px;
    transition: color 0.2s ease;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    box-shadow: none;
}

.sort-btn:hover {
    background: none;
    color: #ffffff;
    transform: none;
    box-shadow: none;
}

.sort-btn.active {
    background: none;
    color: #ffffff;
    box-shadow: none;
}

.sort-btn i {
    font-size: 12px;
}

/* Table Content Styling - Matching Sidebar Palette */
#productsTable td:nth-child(2) {
    font-weight: 600;
    color: #333;
    font-size: 15px;
}

#productsTable td:nth-child(3) {
    font-weight: 700;
    color: #333;
    font-size: 16px;
}

#productsTable td:nth-child(4) {
    color: #666;
    font-size: 14px;
}

#productsTable td:nth-child(5) {
    color: #666;
    font-size: 13px;
}

/* Add these new styles for input icons */
.input-with-icon {
    position: relative;
    width: 100%;
}

.input-with-icon i {
    position: absolute;
    left: 12px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 14px;
    pointer-events: none;
}

.input-with-icon input,
.input-with-icon select {
    padding-left: 35px !important;
    width: 100% !important;
}

/* Update existing modal input styles */
.modal-content input[type="text"],
.modal-content input[type="number"],
.modal-content select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 4px;
    border: 1px solid #ccc;
    font-size: 16px;
    box-sizing: border-box;
}

/* Redesigned header bar */
.products-header {
    background: white;
    padding: 18px 24px;
    border-radius: 22px;
    margin: 0 0 24px 0;
    color: #333;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(0, 0, 0, 0.1);
}

.products-header-main {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
}

.header-title {
    display: flex;
    align-items: center;
    gap: 12px;
}

.header-title-icon {
    width: 60px;
    height: 60px;
    border-radius: 14px;
    background: rgba(250, 206, 11, 0.15);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 26px;
    color: #face0b;
}

.header-title h2 {
    margin: 0;
    font-size: 24px;
    font-weight: 700;
    color: #1e293b;
    letter-spacing: -0.5px;
}

.header-actions {
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
}

.products-toolbar {
    background: transparent;
    padding: 0;
    margin-top: 12px;
    box-shadow: none;
}

#searchForm {
    display: flex;
    flex-wrap: nowrap;
    gap: 12px;
    align-items: center;
    flex: 1;
}

.search-container {
    position: relative;
}

.search-container .input-with-icon {
    width: 300px;
    flex-shrink: 0;
}

.search-container .input-with-icon input {
    padding: 10px 14px 10px 40px;
    border: 1px solid #e2e8f0;
    border-radius: 15px;
    font-size: 14px;
    transition: border 0.2s ease, box-shadow 0.2s ease;
    background: white;
    width: 100%;
    box-sizing: border-box;
}

.search-container .input-with-icon input:focus {
    outline: none;
    border-color: #face0b;
    box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
}

.search-container .input-with-icon i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 14px;
}

.filter-select {
    flex: 0 1 220px;
    min-width: 180px;
    background: white;
    border-radius: 25px;
    border: 1px solid #ddd;
    padding: 8px 14px;
    transition: border 0.2s ease, box-shadow 0.2s ease, background 0.2s;
    font-size: 14px;
    color: #333;
    appearance: none;
    background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="%23333" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"%3E%3Cpolyline points="6 9 12 15 18 9"/%3E%3C/svg%3E');
    background-repeat: no-repeat;
    background-position: calc(100% - 14px) center;
    padding-right: 38px;
}

.filter-select:focus {
    border-color: #face0b;
    box-shadow: 0 0 5px rgba(250, 206, 11, 0.3);
    outline: none;
    background: white;
}

.search-container input[type="text"]::placeholder {
    color: rgba(0, 0, 0, 0.5);
}

.filter-select option {
    color: #0f172a;
}

#addProductButton {
    background: linear-gradient(135deg, #face0b, #f7b300);
    color: #000;
    padding: 8px 16px;
    border: none;
    border-radius: 999px;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
    flex-shrink: 0;
}

#addProductButton:hover {
    transform: translateY(-1px);
    box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
}
/* Search bar: same as User Management */
.search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
    padding: 10px 14px 10px 40px !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 15px !important;
    font-size: 14px !important;
    outline: none !important;
}
.search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
    border-color: #face0b !important;
    box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
}
.search-container { position: relative; }
.search-container .input-with-icon { position: relative; }
.search-container .input-with-icon i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
    font-size: 14px;
}
/* All buttons: no shadow */
button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
    box-shadow: none !important;
}
</style>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="manage_product.php" class="<?php echo isActive('manage_product.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Manage Product</span>
            </a>
            <a href="category.php" class="<?php echo isActive('category.php', $currentPage); ?>">
                <i class="fas fa-list-alt"></i>
                <span>Category</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

<main>
    <div class="products-header">
        <div class="products-header-main">
            <div class="header-title">
                <div class="header-title-icon">
                    <i class="fas fa-box"></i>
                </div>
                <h2>Product Management</h2>
            </div>
            <div class="header-actions">
                <form method="POST" action="" id="searchForm" style="display: flex; gap: 12px; align-items: center; flex-wrap: nowrap;">
                    <div class="search-container">
                        <div class="input-with-icon">
                            <i class="fas fa-search"></i>
                            <input type="text" name="search_term" id="search_term" placeholder="Search by name" value="<?php echo htmlspecialchars($searchTerm); ?>">
                        </div>
                    </div>
                    
                    <select class="filter-select" name="category_filter" id="category_filter">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?php echo $category['CategoryID']; ?>" <?php if ($category['CategoryID'] == $categoryFilter) echo 'selected'; ?>>
                                <?php echo $category['CategoryName']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <button type="button" id="addProductButton" onclick="openAddProductForm()"><i class="fas fa-plus"></i> Add Product</button>
                </form>
            </div>
        </div>
    </div>

<div class="table-container">
    <table id="productsTable">
        <thead>
            <tr>
                <th>Image</th>
                <th>
                    Name
                    <button onclick="sortTable('InventoryName')" class="sort-btn">
                        <i class="fas fa-sort"></i>
                    </button>
                </th>
                <th>
                    Price
                    <button onclick="sortTable('Price')" class="sort-btn">
                        <i class="fas fa-sort"></i>
                    </button>
                </th>
                <th>Category</th>
            <th>
                Status
                <button onclick="sortTable('is_available')" class="sort-btn">
                    <i class="fas fa-sort"></i>
                </button>
            </th>
            <th>
                    Date Created
                    <button onclick="sortTable('date_created')" class="sort-btn">
                        <i class="fas fa-sort"></i>
                    </button>
                </th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="productsTableBody">
            <?php while ($row = $result->fetch_assoc()): 
                $formattedPrice = '₱' . number_format($row['Price'], 2); 
                // Fix image path: if it starts with 'images/', prepend '../'
                $dbImagePath = $row['ImagePath'];
                if (!empty($dbImagePath)) {
                    $imagePath = (strpos($dbImagePath, '../') === 0) ? $dbImagePath : '../' . $dbImagePath;
                } else {
                    $imagePath = '../images/no-image.png';
                }
                $dateCreated = !empty($row['date_created']) ? date('Y-m-d h:i A', strtotime($row['date_created'])) : 'N/A';
            $isAvailable = (int)$row['is_available'] === 1;
            $statusLabel = $isAvailable ? 'Available' : 'Unavailable';
            $statusClass = $isAvailable ? 'status-available' : 'status-unavailable';
            echo "<tr>
                        <td class='product-image-cell'>
                            <img src='{$imagePath}' alt='{$row['InventoryName']}' class='product-image'>
                        </td>
                        <td>{$row['InventoryName']}</td>
                        <td>{$formattedPrice}</td>
                        <td>{$row['CategoryName']}</td>
                    <td class='status-cell'>
                        <form method='POST' class='status-form'>
                            <input type='hidden' name='inventory_id' value='{$row['InventoryID']}'>
                            <button type='submit' name='toggle_status' value='1' class='status-toggle-btn {$statusClass}'>{$statusLabel}</button>
                        </form>
                    </td>
                        <td>{$dateCreated}</td>
                        <td>
                        <button onclick=\"openModal({$row['InventoryID']}, '{$row['InventoryName']}', {$row['Price']}, {$row['CategoryID']})\"><i class=\"fas fa-edit\"></i> Edit</button>
                        <button onclick=\"confirmRemoveProduct({$row['InventoryID']}, '{$row['InventoryName']}')\"><i class=\"fas fa-trash-alt\"></i> Remove</button>
                    </td>
                      </tr>";
            endwhile; ?>
        </tbody>
    </table>
</div>
</main>

<!-- Modal for editing product -->
<div id="editModal" class="modal">
    <div class="modal-content modal-modern">
        <span class="close" id="closeEditModal">&times;</span>
        <div class="modal-header">
            <div class="modal-icon">
                <i class="fas fa-pen-nib"></i>
            </div>
            <div>
                <h2>Edit Product</h2>
                <p>Update product information, pricing, and media</p>
            </div>
        </div>
        <form id="editForm" method="POST" action="" enctype="multipart/form-data" class="modal-body">
            <input type="hidden" name="inventory_id" id="modal_inventory_id">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-icon">
                        <i class="fas fa-box-open"></i>
                    </div>
                    <div>
                        <h3>Product Information</h3>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="modal_inventory_name">Product Name</label>
                        <div class="input-with-icon">
                            <i class="fas fa-box"></i>
                            <input type="text" id="modal_inventory_name" name="inventory_name" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,100}$" title="2–100 characters, letters, numbers, spaces, basic punctuation">
                        </div>
                        <small class="form-hint">Enter the product name as it will appear in the system</small>
                    </div>
                    <div class="form-group">
                        <label for="modal_price">Price</label>
                        <div class="input-with-icon">
                            <i class="fas fa-coins"></i>
                            <input type="text" id="modal_price" name="price" required placeholder="0.00" pattern="^\d+(\.\d{1,2})?$" title="Positive number with up to 2 decimal places" inputmode="decimal">
                        </div>
                        <small class="form-hint">Enter the price in PHP (e.g., 99.99)</small>
                    </div>
                    <div class="form-group">
                        <label for="modal_category_id">Category</label>
                        <div class="input-with-icon">
                            <i class="fas fa-tag"></i>
                            <select id="modal_category_id" name="category_id" required>
                                <option value="">--Select a Category--</option>
                                <?php
                                foreach ($categories as $category) {
                                    echo "<option value='{$category['CategoryID']}'>{$category['CategoryName']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <small class="form-hint">Select the product category from the list</small>
                    </div>
                </div>
            </div>
            <div class="section-card">
                <div class="section-header">
                    <div class="section-icon">
                        <i class="fas fa-image"></i>
                    </div>
                    <div>
                        <h3>Media & Presentation</h3>
                    </div>
                </div>
                <label for="modal_product_image">Product Image</label>
                <div class="image-upload-container">
                    <div id="current_image" class="image-preview">
                        <img id="preview_edit_img" src="#" alt="Preview" style="display: none;">
                        <div class="upload-btn-wrapper">
                            <div class="upload-btn">
                                <i class="fas fa-cloud-upload-alt"></i>
                                Upload Image
                            </div>
                            <input type="file" id="modal_product_image" name="product_image" accept="image/*" onchange="previewEditImage(this)">
                        </div>
                        <div class="upload-text">Supported formats: JPG, JPEG, PNG</div>
                    </div>
                </div>
                <!-- removed image upload hint per request -->
                <div class="modal-actions">
                    <button type="submit" name="edit_product" class="btn-primary">Update Product</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Modal for adding new product -->
<div id="addModal" class="modal">
    <div class="modal-content modal-modern">
        <span class="close" id="closeAddModal">&times;</span>
        <div class="modal-header">
            <div class="modal-icon">
                <i class="fas fa-plus"></i>
            </div>
            <div>
                <h2>Add New Product</h2>
                <p>Create a new product with details, pricing, and image</p>
            </div>
        </div>
        <form id="addForm" method="POST" action="" enctype="multipart/form-data" class="modal-body">
            <div class="section-card">
                <div class="section-header">
                    <div class="section-icon">
                        <i class="fas fa-clipboard-list"></i>
                    </div>
                    <div>
                        <h3>Product Information</h3>
                    </div>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="add_inventory_name">Product Name</label>
                        <div class="input-with-icon">
                            <i class="fas fa-box"></i>
                            <input type="text" id="add_inventory_name" name="inventory_name" required pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,100}$" title="2–100 characters, letters, numbers, spaces, basic punctuation">
                        </div>
                        <small class="form-hint">Enter the product name as it will appear in the system</small>
                    </div>
                    <div class="form-group">
                        <label for="add_price">Price</label>
                        <div class="input-with-icon">
                            <i class="fas fa-coins"></i>
                            <input type="text" id="add_price" name="price" required placeholder="0.00" pattern="^\d+(\.\d{1,2})?$" title="Positive number with up to 2 decimal places" inputmode="decimal">
                        </div>
                        <small class="form-hint">Enter the price in PHP (e.g., 99.99)</small>
                    </div>
                    <div class="form-group">
                        <label for="add_category_id">Category</label>
                        <div class="input-with-icon">
                            <i class="fas fa-tag"></i>
                            <select id="add_category_id" name="category_id" required>
                                <option value="">--Select a Category--</option>
                                <?php
                                foreach ($categories as $category) {
                                    echo "<option value='{$category['CategoryID']}'>{$category['CategoryName']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <small class="form-hint">Select the product category from the list</small>
                    </div>
                </div>
            </div>
            <div class="section-card">
                <div class="section-header">
                    <div class="section-icon">
                        <i class="fas fa-camera-retro"></i>
                    </div>
                    <div>
                        <h3>Media Upload</h3>
                    </div>
                </div>
                <label for="product_image">Product Image</label>
                <div class="image-upload-container">
                    <div id="image_preview" class="image-preview">
                        <img id="preview_img" src="#" alt="Preview" style="display: none;">
                        <div class="upload-btn-wrapper">
                            <div class="upload-btn">
                                <i class="fas fa-cloud-upload-alt"></i>
                                Upload Image
                            </div>
                            <input type="file" id="product_image" name="product_image" accept="image/*" onchange="previewImage(this)">
                        </div>
                        <div class="upload-text">Supported formats: JPG, JPEG, PNG</div>
                    </div>
                </div>
                <!-- removed image upload hint per request -->
                <div class="modal-actions">
                    <button type="submit" name="add_product" class="btn-primary">Add Product</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    // Add this at the beginning of your script section
    <?php if(isset($_SESSION['error_message'])): ?>
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: '<?php echo $_SESSION['error_message']; ?>',
            confirmButtonColor: '#ef4444'
        });
        <?php unset($_SESSION['error_message']); ?>
    <?php endif; ?>

    <?php if(isset($_SESSION['success_message'])): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: '<?php echo $_SESSION['success_message']; ?>',
            confirmButtonColor: '#face0b'
        });
        <?php unset($_SESSION['success_message']); ?>
    <?php endif; ?>

    // Get the modals
    var editModal = document.getElementById("editModal");
    var addModal = document.getElementById("addModal");

    // Get the <span> elements that close the modals
    var closeEditModal = document.getElementById("closeEditModal");
    var closeAddModal = document.getElementById("closeAddModal");

    // Function to open the edit modal and populate it with data
    function openModal(id, name, price, categoryId) {
        document.getElementById("modal_inventory_id").value = id;
        document.getElementById("modal_inventory_name").value = name;
        document.getElementById("modal_price").value = price;
        document.getElementById("modal_category_id").value = categoryId;
        
        // Reset the image preview elements
        const preview = document.getElementById('preview_edit_img');
        const uploadBtn = document.querySelector('#editModal .upload-btn-wrapper');
        const uploadText = document.querySelector('#editModal .upload-text');
        
        // Fetch and display current image if exists
        fetch(`../api/get_product_image.php?id=${id}`)
            .then(response => response.json())
            .then(data => {
                if (data.imagePath) {
                    preview.src = data.imagePath;
                    preview.style.display = 'block';
                    uploadBtn.style.display = 'none';
                    uploadText.style.display = 'none';
                } else {
                    preview.src = '../images/no-image.png';
                    preview.style.display = 'none';
                    uploadBtn.style.display = 'block';
                    uploadText.style.display = 'block';
                }
            });
        
        editModal.style.display = "flex";
        editModal.classList.add('show');
    }

    // Function to open the add product modal
    function openAddProductForm() {
        document.getElementById("add_inventory_name").value = '';
        document.getElementById("add_price").value = '';
        document.getElementById("add_category_id").value = '';
        document.getElementById("product_image").value = '';
        document.getElementById("preview_img").style.display = 'none';
        addModal.style.display = "flex";
        addModal.classList.add('show');
    }

    function hideEditModal() {
        editModal.style.display = "none";
        editModal.classList.remove('show');
    }

    function hideAddModal() {
        addModal.style.display = "none";
        addModal.classList.remove('show');
    }

    // When the user clicks on <span> (x), close the modals
    closeEditModal.onclick = hideEditModal;
    closeAddModal.onclick = hideAddModal;

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == editModal) {
            hideEditModal();
        }
        if (event.target == addModal) {
            hideAddModal();
        }
    }

    let currentSort = {
        column: 'date_created',
        order: 'DESC'
    };

    function updateSortIcon(column) {
        // Remove active class from all sort buttons
        document.querySelectorAll('.sort-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to current sort button
        const currentBtn = document.querySelector(`button[onclick="sortTable('${column}')"]`);
        if (currentBtn) {
            currentBtn.classList.add('active');
            const icon = currentBtn.querySelector('i');
            icon.className = currentSort.order === 'ASC' ? 'fas fa-sort-up' : 'fas fa-sort-down';
        }
    }

    function sortTable(column) {
        if (currentSort.column === column) {
            // Toggle sort order if clicking the same column
            currentSort.order = currentSort.order === 'ASC' ? 'DESC' : 'ASC';
        } else {
            // Set new column and default to ascending
            currentSort.column = column;
            currentSort.order = 'ASC';
        }
        
        updateSortIcon(column);
        performSearch();
    }


    function performSearch() {
        const searchTerm = searchInput.value;
        const categoryId = categoryFilter.value;
        
        fetch(`../api/search_products.php?search_term=${encodeURIComponent(searchTerm)}&category_filter=${encodeURIComponent(categoryId)}&sort_column=${currentSort.column}&sort_order=${currentSort.order}`)
            .then(response => response.json())
            .then(products => {
                updateTable(products);
            })
            .catch(error => console.error('Error:', error));
    }

    // Initialize sort icons
    document.addEventListener('DOMContentLoaded', function() {
        updateSortIcon(currentSort.column);
    });

    function toggleSidebar() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('sidebar-expanded');
            // Save state to localStorage
            const isExpanded = sidebar.classList.contains('sidebar-expanded');
            localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
        }
    }
    
    // Restore sidebar state on page load (without transition)
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            // Disable transitions during state restoration
            sidebar.classList.add('no-transition');
            
            const savedState = localStorage.getItem('sidebarExpanded');
            if (savedState === 'true') {
                sidebar.classList.add('sidebar-expanded');
            } else {
                // Default to collapsed (no saved state or explicitly false)
                sidebar.classList.remove('sidebar-expanded');
            }
            
            // Re-enable transitions after a short delay
            setTimeout(function() {
                sidebar.classList.remove('no-transition');
            }, 50);
        }
    });

    function confirmLogout(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Logout Confirmation',
            text: "Are you sure you want to logout?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#face0b',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../authentication/logout.php';
            }
        });
    }
    function confirmRemoveProduct(inventoryId, inventoryName) {
        Swal.fire({
            title: 'Remove product?',
            text: `Do you want to remove the product "${inventoryName}"? Removed products can be recovered from the Backup & Recovery page.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, remove it'
        }).then((result) => {
            if (result.isConfirmed) {
                // Create and submit the form
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';

                const inventoryIdInput = document.createElement('input');
                inventoryIdInput.type = 'hidden';
                inventoryIdInput.name = 'inventory_id';
                inventoryIdInput.value = inventoryId;

                const removeProductInput = document.createElement('input');
                removeProductInput.type = 'hidden';
                removeProductInput.name = 'remove_product';
                removeProductInput.value = '1';

                form.appendChild(inventoryIdInput);
                form.appendChild(removeProductInput);
                document.body.appendChild(form);
                form.submit();
            }
        });
    }
    function formatNumber($number) {
        return number_format($number, 2, '.', ','); // Format with 2 decimal places and commas
    }

    // Add this new code for real-time search
    let searchTimeout;
    const searchInput = document.getElementById('search_term');
    const categoryFilter = document.getElementById('category_filter');
    const productsTableBody = document.getElementById('productsTableBody');

    function updateTable(products) {
        productsTableBody.innerHTML = '';
        products.forEach(product => {
            const formattedPrice = '₱' + parseFloat(product.Price).toFixed(2);
            // Fix image path: if it starts with 'images/', prepend '../'
            let imagePath = product.ImagePath || '../images/no-image.png';
            if (imagePath && !imagePath.startsWith('../')) {
                imagePath = '../' + imagePath;
            }
            const escapedName = product.InventoryName.replace(/'/g, "\\'");
            const dateCreated = product.date_created || 'N/A';
            const isAvailable = parseInt(product.is_available) === 1;
            const statusLabel = isAvailable ? 'Available' : 'Unavailable';
            const statusClass = isAvailable ? 'status-available' : 'status-unavailable';
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class='product-image-cell'>
                    <img src="${imagePath}" alt="${escapedName}" class='product-image'>
                </td>
                <td>${escapedName}</td>
                <td>${formattedPrice}</td>
                <td>${product.CategoryName}</td>
                <td class='status-cell'>
                    <form method="POST" class="status-form">
                        <input type="hidden" name="inventory_id" value="${product.InventoryID}">
                        <button type="submit" name="toggle_status" value="1" class="status-toggle-btn ${statusClass}">${statusLabel}</button>
                    </form>
                </td>
                <td>${dateCreated}</td>
                <td>
                    <button onclick="openModal(${product.InventoryID}, '${escapedName}', ${parseFloat(product.Price)}, ${product.CategoryID})"><i class="fas fa-edit"></i> Edit</button>
                    <button onclick="confirmRemoveProduct(${product.InventoryID}, '${escapedName}')"><i class="fas fa-trash-alt"></i> Remove</button>
                </td>
            `;
            productsTableBody.appendChild(row);
        });
    }

    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(performSearch, 300); // 300ms delay
    });

    categoryFilter.addEventListener('change', performSearch);

    function previewImage(input) {
        const preview = document.getElementById('preview_img');
        const uploadBtn = input.parentElement;
        const uploadText = document.querySelector('.upload-text');
        
        if (input.files && input.files[0]) {
            // Check if the file is an image
            const fileType = input.files[0].type;
            if (!fileType.startsWith('image/')) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Type',
                    text: 'Please upload an image file (JPG, JPEG, or PNG)',
                });
                input.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                uploadBtn.style.display = 'none';
                uploadText.style.display = 'none';
            }
            
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.src = '#';
            preview.style.display = 'none';
            uploadBtn.style.display = 'block';
            uploadText.style.display = 'block';
        }
    }

    function previewEditImage(input) {
        const preview = document.getElementById('preview_edit_img');
        const uploadBtn = input.parentElement;
        const uploadText = document.querySelector('#editModal .upload-text');
        
        if (input.files && input.files[0]) {
            // Check if the file is an image
            const fileType = input.files[0].type;
            if (!fileType.startsWith('image/')) {
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid File Type',
                    text: 'Please upload an image file (JPG, JPEG, or PNG)',
                });
                input.value = '';
                return;
            }

            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                uploadBtn.style.display = 'none';
                uploadText.style.display = 'none';
            }
            
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.src = '#';
            preview.style.display = 'none';
            uploadBtn.style.display = 'block';
            uploadText.style.display = 'block';
        }
    }

    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        
        // Format date: Day, Month DD, YYYY
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        
        // Format time: HH:MM:SS AM/PM
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }

    // Update immediately and then every second
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);
</script>
<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>