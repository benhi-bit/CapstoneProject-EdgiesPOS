<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php'; // Include your database connection
require_once __DIR__ . '/../lib/ensure_transactions_table.php';

ensureTransactionsTable($conn);

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');

// Initialize date range variables
$startDate = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-01');
$endDate = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-t');

// Get selected year for monthly sales
$selectedYear = isset($_POST['year']) ? $_POST['year'] : date('Y');

// Fetch total orders (overall)
$totalOrdersQuery = "SELECT COUNT(*) AS TotalOrders FROM transactions";
$totalOrdersStmt = $conn->prepare($totalOrdersQuery);
$totalOrdersStmt->execute();
$totalOrders = $totalOrdersStmt->get_result()->fetch_assoc()['TotalOrders'];

// Fetch total sales (overall)
$totalSalesQuery = "SELECT SUM(total_amount) AS TotalSales FROM transactions";
$totalSalesStmt = $conn->prepare($totalSalesQuery);
$totalSalesStmt->execute();
$totalSalesResult = $totalSalesStmt->get_result();
$totalSales = $totalSalesResult->fetch_assoc()['TotalSales'] ?? 0;

// Fetch today's sales
$todaySalesQuery = "SELECT SUM(total_amount) AS TodaySales 
                   FROM transactions 
                   WHERE DATE(transaction_date) = CURDATE()";
$todaySalesResult = $conn->query($todaySalesQuery);
$todaySales = $todaySalesResult->fetch_assoc()['TodaySales'] ?? 0;

// Fetch today's total orders (completed transactions)
$todayOrdersQuery = "SELECT COUNT(*) AS TodayOrders 
                    FROM transactions 
                    WHERE DATE(transaction_date) = CURDATE()";
$todayOrdersResult = $conn->query($todayOrdersQuery);
$todayOrders = $todayOrdersResult->fetch_assoc()['TodayOrders'] ?? 0;

// Fetch total categories
$totalCategoriesQuery = "SELECT COUNT(*) AS TotalCategories FROM categories";
$totalCategoriesResult = $conn->query($totalCategoriesQuery);
$totalCategories = $totalCategoriesResult->fetch_assoc()['TotalCategories'];

// Fetch product prices from inventory table
$productPrices = [];
$productPriceQuery = "SELECT InventoryName, Price FROM inventory";
if ($productPriceResult = $conn->query($productPriceQuery)) {
    while ($priceRow = $productPriceResult->fetch_assoc()) {
        $nameKey = strtolower(trim($priceRow['InventoryName']));
        if ($nameKey !== '') {
            $productPrices[$nameKey] = (float)$priceRow['Price'];
        }
    }
    $productPriceResult->free();
}

// Most Sold Products filter (separate from the sales chart date range)
$mostSoldYear = isset($_POST['most_sold_year']) ? (int)$_POST['most_sold_year'] : (int)date('Y');
$mostSoldMonth = isset($_POST['most_sold_month']) ? (int)$_POST['most_sold_month'] : (int)date('n'); // 1-12, or 0 = all months

if ($mostSoldYear < 2000 || $mostSoldYear > ((int)date('Y') + 1)) {
    $mostSoldYear = (int)date('Y');
}
if ($mostSoldMonth < 0 || $mostSoldMonth > 12) {
    $mostSoldMonth = (int)date('n');
}

if ($mostSoldMonth === 0) {
    $mostSoldStartDate = sprintf('%04d-01-01 00:00:00', $mostSoldYear);
    $mostSoldEndDate = sprintf('%04d-12-31 23:59:59', $mostSoldYear);
} else {
    $mostSoldStartDate = sprintf('%04d-%02d-01 00:00:00', $mostSoldYear, $mostSoldMonth);
    $mostSoldEndDate = date('Y-m-t 23:59:59', strtotime(sprintf('%04d-%02d-01', $mostSoldYear, $mostSoldMonth)));
}

// Get most sold products - properly parse all products from details field
$mostSoldQuery = "SELECT details FROM transactions WHERE transaction_date BETWEEN ? AND ?";
$mostSoldStmt = $conn->prepare($mostSoldQuery);
$mostSoldStmt->bind_param("ss", $mostSoldStartDate, $mostSoldEndDate);
$mostSoldStmt->execute();
$mostSoldResult = $mostSoldStmt->get_result();

// Parse all products from details and aggregate
$mostSoldProducts = [];
while ($row = $mostSoldResult->fetch_assoc()) {
    $details = $row['details'];
    $parsedProducts = parseProductsFromDetails($details, $productPrices);
    
    foreach ($parsedProducts as $productName => $data) {
        if (!isset($mostSoldProducts[$productName])) {
            $mostSoldProducts[$productName] = [
                'total_quantity' => 0,
                'total_sales' => 0
            ];
        }
        $mostSoldProducts[$productName]['total_quantity'] += $data['total_quantity'];
        $mostSoldProducts[$productName]['total_sales'] += $data['total_sales'];
    }
}

// Convert to array format for display and sort by quantity descending
$mostSoldProductsArray = [];
foreach ($mostSoldProducts as $productName => $data) {
    $mostSoldProductsArray[] = [
        'product_name' => $productName,
        'total_quantity' => $data['total_quantity'],
        'total_sales' => $data['total_sales']
    ];
}

// Sort by quantity descending (show all products, not just top 5)
usort($mostSoldProductsArray, function($a, $b) {
    return $b['total_quantity'] - $a['total_quantity'];
});

// Fetch sales data for graph
$salesDataQuery = "
    WITH RECURSIVE dates AS (
        SELECT ? as date
        UNION ALL
        SELECT DATE_ADD(date, INTERVAL 1 DAY)
        FROM dates
        WHERE date < ?
    )
    SELECT 
        dates.date AS OrderDate,
        COALESCE(SUM(transactions.total_amount), 0) AS TotalSales
    FROM dates
    LEFT JOIN transactions ON DATE(transactions.transaction_date) = dates.date
    GROUP BY dates.date
    ORDER BY dates.date
";
$salesDataStmt = $conn->prepare($salesDataQuery);
$salesDataStmt->bind_param("ss", $startDate, $endDate);
$salesDataStmt->execute();
$salesDataResult = $salesDataStmt->get_result();
$salesDates = [];
$salesAmounts = [];
while ($row = $salesDataResult->fetch_assoc()) {
    $salesDates[] = $row['OrderDate'];
    $salesAmounts[] = $row['TotalSales'];
}

// Function to parse products from transaction details and calculate sales using product prices
function parseProductsFromDetails($details, $productPrices) {
    $products = [];
    $items = explode(',', $details);
    
    foreach ($items as $item) {
        $item = trim($item);
        // Check if item has parentheses (product with quantity), skip cashier name (no parentheses)
        if (preg_match('/^(.+?)\((\d+)\)$/', $item, $matches)) {
            $productName = trim($matches[1]);
            $quantity = intval($matches[2]);
            
            // Get product price from inventory (case-insensitive match)
            $productNameKey = strtolower(trim($productName));
            $productPrice = isset($productPrices[$productNameKey]) ? $productPrices[$productNameKey] : 0;
            
            // Calculate sales: quantity * price
            $totalSales = $quantity * $productPrice;
            
            if (!isset($products[$productName])) {
                $products[$productName] = [
                    'total_quantity' => 0,
                    'total_sales' => 0
                ];
            }
            
            $products[$productName]['total_quantity'] += $quantity;
            $products[$productName]['total_sales'] += $totalSales;
        }
    }
    
    return $products;
}

// Get selected year for monthly sales
$selectedYear = isset($_POST['year']) ? $_POST['year'] : date('Y');

// Fetch monthly sales data
$monthlySalesQuery = "
    SELECT 
        MONTH(transaction_date) as month,
        SUM(total_amount) as total_sales
    FROM transactions 
    WHERE YEAR(transaction_date) = ?
    GROUP BY MONTH(transaction_date)
    ORDER BY month";
$monthlySalesStmt = $conn->prepare($monthlySalesQuery);
$monthlySalesStmt->bind_param("i", $selectedYear);
$monthlySalesStmt->execute();
$monthlySalesResult = $monthlySalesStmt->get_result();

// Initialize monthly sales array
$monthlySales = array_fill(1, 12, 0); // Initialize all months with 0
while ($row = $monthlySalesResult->fetch_assoc()) {
    $monthlySales[$row['month']] = $row['total_sales'];
}

// Build summary helpers for monthly sales
$yearlyTotal = 0;
$topMonthNumber = 1;
$topMonthSales = 0;
foreach ($monthlySales as $monthNum => $sales) {
    $yearlyTotal += $sales;
    if ($sales > $topMonthSales) {
        $topMonthSales = $sales;
        $topMonthNumber = $monthNum;
    }
}

// Define months array for the chart
$months = [
    1 => 'January', 2 => 'February', 3 => 'March',
    4 => 'April', 5 => 'May', 6 => 'June',
    7 => 'July', 8 => 'August', 9 => 'September',
    10 => 'October', 11 => 'November', 12 => 'December'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Add SweetAlert2 CSS and JS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
    </style>
    <style>
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, [class*="btn-"], input[type="submit"], input[type="button"] {
            box-shadow: none !important;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines when expanded */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }

        .dashboard-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
        }

        .dashboard-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
        }

        .dashboard-card i {
            font-size: 2em;
            margin-bottom: 10px;
            color: #face0b;
        }

        .dashboard-card .number {
            font-size: 2em;
            font-weight: bold;
            margin: 10px 0;
        }

        .dashboard-card .name {
            color: #666;
            font-size: 1.1em;
        }

        .charts-container {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-top: 20px;
            align-items: stretch;
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            transition: all 0.3s ease;
            min-height: 600px;
        }

        .chart-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
            height: 100%;
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            overflow: hidden;
        }

        .most-sold-container {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        
        .most-sold-container h3 {
            margin-top: 0;
            margin-bottom: 15px;
            flex-shrink: 0;
        }
        
        .most-sold-table-wrapper {
            flex: 1;
            overflow-y: auto;
            min-height: 0;
            max-height: 400px;
        }
        
        .most-sold-table-wrapper::-webkit-scrollbar {
            width: 8px;
        }
        
        .most-sold-table-wrapper::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        .most-sold-table-wrapper::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        
        .most-sold-table-wrapper::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        .most-sold-table-wrapper table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 0;
            table-layout: auto;
            max-width: 100%;
            background: transparent;
        }

        .most-sold-table-wrapper thead {
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .most-sold-table-wrapper thead tr {
            background: transparent;
        }

        .most-sold-table-wrapper th {
            background: linear-gradient(135deg, #333 0%, #444 100%);
            color: #ffffff;
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: none;
            position: sticky;
            top: 0;
            white-space: nowrap;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .most-sold-table-wrapper th:first-child {
            border-top-left-radius: 8px;
        }

        .most-sold-table-wrapper th:last-child {
            border-top-right-radius: 8px;
        }

        .most-sold-table-wrapper tbody tr {
            background: #ffffff;
            border-bottom: 1px solid #e9ecef;
            transition: all 0.2s ease;
        }

        .most-sold-table-wrapper tbody tr:hover {
            background: #f8f9fa;
            transform: translateX(2px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .most-sold-table-wrapper tbody tr:last-child {
            border-bottom: none;
        }

        .most-sold-table-wrapper td {
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            color: #1e293b;
            border: none;
            vertical-align: middle;
        }

        .most-sold-table-wrapper td:first-child {
            font-weight: 600;
            color: #0f172a;
        }

        .most-sold-table-wrapper td:nth-child(2) {
            color: #475569;
            font-weight: 500;
        }

        .most-sold-table-wrapper td:last-child {
            color: #059669;
            font-weight: 700;
            font-size: 15px;
        }

        .most-sold-table-wrapper tbody tr:empty {
            display: none;
        }

        th {
            background-color: #face0b;
            color: black;
        }

        /* Monthly Sales Section */
        .monthly-sales-section {
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            overflow: hidden;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .monthly-sales-content {
            flex: 1 1 0;
            display: flex;
            flex-direction: column;
            gap: 15px;
            min-height: 0;
            width: 100%;
        }

        /* Canvas elements should resize */
        canvas {
            max-width: 100%;
            width: 100% !important;
        }

        .date-selector {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .date-selector input[type="date"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }

        .date-selector button {
            padding: 8px 15px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .date-selector button:hover {
            background-color: #555;
        }

        /* Year Selector Styles */
        .year-selector {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .year-selector label {
            font-weight: 600;
            color: #495057;
            font-size: 14px;
            margin: 0;
        }

        .year-selector select {
            padding: 10px 20px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            background: white;
            color: #2d3748;
            cursor: pointer;
            transition: all 0.3s ease;
            min-width: 120px;
            text-align: center;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23333' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 40px;
        }

        .year-selector select:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .year-selector select:hover {
            border-color: #face0b;
        }

        .year-nav-buttons {
            display: flex;
            gap: 8px;
        }

        .year-nav-btn {
            width: 36px;
            height: 36px;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            background: white;
            color: #495057;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .year-nav-btn:hover {
            background: #face0b;
            border-color: #face0b;
            color: #000;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(250, 206, 11, 0.3);
        }

        .year-nav-btn:active {
            transform: translateY(0);
        }

        .year-nav-btn:disabled {
            opacity: 0.4;
            cursor: not-allowed;
            background: #f8f9fa;
        }

        .year-nav-btn:disabled:hover {
            transform: none;
            box-shadow: none;
            background: #f8f9fa;
            border-color: #dee2e6;
            color: #495057;
        }

        @media (max-width: 768px) {
            .charts-container {
                grid-template-columns: 1fr;
            }
            
            main {
                margin-left: 0;
                width: 100%;
            }
            
            
            nav.sidebar {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

<main>
    <h2>Dashboard Overview</h2>
    
    <div class="dashboard-container">
        <div class="dashboard-card" onclick="navigateToAllTransactions()" style="cursor: pointer;">
            <i class="fas fa-shopping-cart"></i>
            <div class="number"><?php echo $totalOrders; ?></div>
            <div class="name">Total Orders</div>
        </div>
        <div class="dashboard-card">
            <i class="fas fa-money-bill-wave"></i>
            <div class="number">₱ <?php echo number_format($totalSales, 2); ?></div>
            <div class="name">Total Sales</div>
        </div>
        <div class="dashboard-card">
            <i class="fas fa-calendar-day"></i>
            <div class="number">₱ <?php echo number_format($todaySales, 2); ?></div>
            <div class="name">Today's Sales</div>
        </div>
        <div class="dashboard-card" onclick="navigateToTodaysTransactions()" style="cursor: pointer;">
            <i class="fas fa-receipt"></i>
            <div class="number"><?php echo $todayOrders; ?></div>
            <div class="name">Today's Orders</div>
        </div>
        <div class="dashboard-card" onclick="window.location.href='category.php'" style="cursor: pointer;">
            <i class="fas fa-tags"></i>
            <div class="number"><?php echo $totalCategories; ?></div>
            <div class="name">Total Categories</div>
        </div>
    </div>

    <div class="charts-container">
        <div class="chart-container">
            <form method="POST" class="date-selector" style="margin-bottom: 20px;">
                <!-- Preserve Monthly Sales + Most Sold filters when applying date range -->
                <input type="hidden" name="year" value="<?php echo htmlspecialchars($selectedYear); ?>">
                <input type="hidden" name="most_sold_year" value="<?php echo htmlspecialchars($mostSoldYear ?? (int)date('Y')); ?>">
                <input type="hidden" name="most_sold_month" value="<?php echo htmlspecialchars($mostSoldMonth ?? (int)date('n')); ?>">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>" required>
                
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>" required>
                
                <button type="submit">Apply Filter</button>
            </form>
            <div style="flex: 1; position: relative; min-height: 0; width: 100%; max-width: 100%; overflow: hidden;">
                <canvas id="salesChart"></canvas>
            </div>
            
            <div class="most-sold-container" style="margin-top: 20px; flex: 1;">
                <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; margin-bottom: 14px;">
                    <h3 style="color: #1e293b; font-size: 20px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-chart-line" style="color: #face0b;"></i>
                    Most Sold Products
                </h3>

                    <form method="POST" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <!-- Preserve existing filters when submitting this form -->
                        <input type="hidden" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                        <input type="hidden" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                        <input type="hidden" name="year" value="<?php echo htmlspecialchars($selectedYear); ?>">

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <label for="most_sold_month" style="font-weight: 600; color: #495057; font-size: 13px; margin: 0;">Month:</label>
                            <select name="most_sold_month" id="most_sold_month" style="padding: 8px 12px; border: 2px solid #dee2e6; border-radius: 8px; font-weight: 600; cursor: pointer;">
                                <option value="0" <?php echo ($mostSoldMonth ?? (int)date('n')) === 0 ? 'selected' : ''; ?>>All</option>
                                <?php foreach ($months as $mNum => $mName): ?>
                                    <option value="<?php echo (int)$mNum; ?>" <?php echo ((int)($mostSoldMonth ?? (int)date('n')) === (int)$mNum) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($mName); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div style="display: flex; align-items: center; gap: 8px;">
                            <label for="most_sold_year" style="font-weight: 600; color: #495057; font-size: 13px; margin: 0;">Year:</label>
                            <select name="most_sold_year" id="most_sold_year" style="padding: 8px 12px; border: 2px solid #dee2e6; border-radius: 8px; font-weight: 600; cursor: pointer;">
                                <?php
                                $currentYear = (int)date('Y');
                                $minYear = $currentYear - 10;
                                $selMostYear = isset($mostSoldYear) ? (int)$mostSoldYear : $currentYear;
                                for ($y = $currentYear; $y >= $minYear; $y--) {
                                    $selected = ($y === $selMostYear) ? 'selected' : '';
                                    echo "<option value='{$y}' {$selected}>{$y}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <button type="submit" style="padding: 8px 14px; border-radius: 999px; border: none; font-weight: 700; cursor: pointer; background: linear-gradient(135deg, #face0b, #f7b300); color: #000;">
                            <i class="fas fa-filter" style="margin-right: 6px;"></i> Apply
                        </button>
                    </form>
                </div>
                <div class="most-sold-table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th><i class="fas fa-box" style="margin-right: 8px;"></i>Product</th>
                                <th><i class="fas fa-sort-numeric-up" style="margin-right: 8px;"></i>Quantity</th>
                                <th><i class="fas fa-money-bill-wave" style="margin-right: 8px;"></i>Total Sales</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($mostSoldProductsArray) > 0): ?>
                                <?php foreach ($mostSoldProductsArray as $index => $product): ?>
                                <tr>
                                    <td>
                                        <div style="display: flex; align-items: center; gap: 10px;">
                                            <span style="display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; background: linear-gradient(135deg, #face0b, #f7b300); color: #000; border-radius: 6px; font-weight: 700; font-size: 12px; flex-shrink: 0;">
                                                <?php echo $index + 1; ?>
                                            </span>
                                            <span><?php echo htmlspecialchars($product['product_name']); ?></span>
                                        </div>
                                    </td>
                                    <td>
                                        <span style="display: inline-flex; align-items: center; gap: 6px;">
                                            <i class="fas fa-shopping-bag" style="color: #64748b; font-size: 12px;"></i>
                                            <?php echo number_format($product['total_quantity']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="display: inline-flex; align-items: center; gap: 6px;">
                                            <i class="fas fa-peso-sign" style="color: #059669; font-size: 12px;"></i>
                                            ₱ <?php echo number_format($product['total_sales'], 2); ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" style="text-align: center; padding: 40px 20px; color: #64748b;">
                                        <div style="display: flex; flex-direction: column; align-items: center; gap: 10px;">
                                            <i class="fas fa-inbox" style="font-size: 48px; color: #cbd5e1;"></i>
                                            <p style="margin: 0; font-size: 14px;">No products sold in the selected date range</p>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div style="display: flex; flex-direction: column; height: 100%; min-height: 600px; width: 100%; max-width: 100%; box-sizing: border-box;">
            <div class="monthly-sales-section" style="background: white; border-radius: 10px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1 1 auto; display: flex; flex-direction: column; min-height: 0; width: 100%; max-width: 100%; box-sizing: border-box; overflow: hidden;">
                <h3 style="margin-top: 0; flex-shrink: 0; margin-bottom: 15px;">Monthly Sales Report</h3>
                <form method="POST" class="year-selector" id="yearSelectorForm" style="flex-shrink: 0; margin-bottom: 15px;">
                    <!-- Preserve Sales date range + Most Sold filters when changing Monthly Sales year -->
                    <input type="hidden" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
                    <input type="hidden" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
                    <input type="hidden" name="most_sold_year" value="<?php echo htmlspecialchars($mostSoldYear ?? (int)date('Y')); ?>">
                    <input type="hidden" name="most_sold_month" value="<?php echo htmlspecialchars($mostSoldMonth ?? (int)date('n')); ?>">
                    <div class="year-nav-buttons">
                        <button type="button" class="year-nav-btn" id="prevYearBtn" title="Previous Year">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                    </div>
                    <label for="year">Year:</label>
                    <select name="year" id="year" onchange="this.form.submit()">
                        <?php
                        $currentYear = date('Y');
                        $minYear = $currentYear - 10; // Show last 10 years
                        for ($year = $currentYear; $year >= $minYear; $year--) {
                            $selected = ($year == $selectedYear) ? 'selected' : '';
                            echo "<option value='$year' $selected>$year</option>";
                        }
                        ?>
                    </select>
                    <div class="year-nav-buttons">
                        <button type="button" class="year-nav-btn" id="nextYearBtn" title="Next Year">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </form>
                <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; flex-wrap: wrap; margin-bottom: 10px;">
                    <div style="font-weight: 600; color: #495057;">
                        <?php echo $months[$topMonthNumber]; ?> had the highest sales in <?php echo $selectedYear; ?>.
                    </div>
                    <div style="background: rgba(31, 89, 206, 0.1); color: #1f59ce; padding: 8px 14px; border-radius: 999px; font-weight: 600;">
                        Total: ₱ <?php echo number_format($yearlyTotal, 2); ?>
                    </div>
                </div>
                <div class="monthly-sales-content">
                    <div style="flex: 1 1 0; position: relative; min-height: 240px; width: 100%; max-width: 100%; overflow: hidden;">
                        <canvas id="monthlyDonutChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    // Add this before the existing chart initialization code
    function navigateToTodaysTransactions() {
        const today = new Date().toISOString().split('T')[0];
        window.location.href = `transaction_history.php?start_date=${today}&end_date=${today}`;
    }

    function navigateToAllTransactions() {
        window.location.href = 'transaction_history.php';
    }

    function formatDateLabel(dateStr) {
        const date = new Date(dateStr);
        if (isNaN(date)) {
            return dateStr;
        }
        return date.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
        });
    }

    function updateDashboardCards(data) {
        // Update total orders
        document.querySelector('.dashboard-card:nth-child(1) .number').textContent = data.transaction_count;
        
        // Update total sales
        document.querySelector('.dashboard-card:nth-child(2) .number').textContent = '₱ ' + 
            parseFloat(data.total_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        
        // Update today's sales
        document.querySelector('.dashboard-card:nth-child(3) .number').textContent = '₱ ' + 
            parseFloat(data.today_sales).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
        
        // Update today's orders
        document.querySelector('.dashboard-card:nth-child(4) .number').textContent = data.today_orders;
        
        // Update total categories
        document.querySelector('.dashboard-card:nth-child(5) .number').textContent = data.category_count;

        // Important: do NOT update charts via SSE, because charts are filter-based (date range / year selectors).
        // SSE data is global/latest and would cause chart values to appear from different dates than the selected filters.
    }

    // Initialize SSE connection
    const eventSource = new EventSource('../api/sse_handler.php');
    
    eventSource.onmessage = function(event) {
        const data = JSON.parse(event.data);
        updateDashboardCards(data);
    };

    eventSource.onerror = function(error) {
        console.error('SSE Error:', error);
        eventSource.close();
        // Try to reconnect after 5 seconds
        setTimeout(() => {
            eventSource = new EventSource('../api/sse_handler.php');
        }, 5000);
    };

    // Initialize charts with empty data first
    const ctx = document.getElementById('salesChart').getContext('2d');
    const initialSalesDates = <?php echo json_encode($salesDates); ?>;
    const formattedSalesDates = initialSalesDates.map(formatDateLabel);
    const salesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: formattedSalesDates,
            datasets: [{
                label: 'Sales',
                data: <?php echo json_encode($salesAmounts); ?>,
                backgroundColor: 'rgba(250, 206, 11, 0.2)',
                borderColor: 'rgba(250, 206, 11, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Sales Over Time',
                    font: {
                        size: 16
                    }
                },
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Amount (₱)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₱ ' + value.toLocaleString();
                        }
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Date'
                    },
                    ticks: {
                        maxRotation: 45,
                        minRotation: 45
                    }
                }
            }
        }
    });

    // Create the monthly sales donut chart
    const monthlyCtx = document.getElementById('monthlyDonutChart').getContext('2d');
    const monthlyData = <?php echo json_encode(array_values($monthlySales)); ?>;
    const monthLabels = <?php echo json_encode(array_values($months)); ?>;
    
    const monthlyDonutChart = new Chart(monthlyCtx, {
        type: 'doughnut',
        data: {
            labels: monthLabels,
            datasets: [{
                data: monthlyData,
                backgroundColor: [
                    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40',
                    '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Monthly Sales Distribution',
                    font: {
                        size: 16
                    },
                    padding: {
                        top: 20,
                        bottom: 20
                    }
                },
                legend: {
                    position: 'right',
                    labels: {
                        generateLabels: function(chart) {
                            const data = chart.data;
                            if (data.labels.length && data.datasets.length) {
                                return data.labels.map(function(label, i) {
                                    const value = data.datasets[0].data[i];
                                    const formattedValue = parseFloat(value).toLocaleString('en-US', {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    });
                                    return {
                                        text: `${label}: ₱${formattedValue}`,
                                        fillStyle: data.datasets[0].backgroundColor[i],
                                        hidden: isNaN(value) || value === 0,
                                        index: i
                                    };
                                });
                            }
                            return [];
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const formattedValue = parseFloat(value).toLocaleString('en-US', {
                                minimumFractionDigits: 2,
                                maximumFractionDigits: 2
                            });
                            return `${label}: ₱${formattedValue}`;
                        }
                    }
                }
            }
        }
    });

    function toggleSidebar() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('sidebar-expanded');
            // Save state to localStorage
            const isExpanded = sidebar.classList.contains('sidebar-expanded');
            localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
        }
    }
    
    // Restore sidebar state on page load (without transition)
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            // Disable transitions during state restoration
            sidebar.classList.add('no-transition');
            
            const savedState = localStorage.getItem('sidebarExpanded');
            if (savedState === 'true') {
                sidebar.classList.add('sidebar-expanded');
            } else {
                // Default to collapsed (no saved state or explicitly false)
                sidebar.classList.remove('sidebar-expanded');
            }
            
            // Re-enable transitions after a short delay
            setTimeout(function() {
                sidebar.classList.remove('no-transition');
            }, 50);
        }
    });

    function confirmLogout(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Logout Confirmation',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#face0b',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../authentication/logout.php';
            }
        });
    }

    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        
        // Format date: Day, Month DD, YYYY
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        
        // Format time: HH:MM:SS AM/PM
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }

    // Update immediately and then every second
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);

    // Year selector navigation
    const yearSelect = document.getElementById('year');
    const prevYearBtn = document.getElementById('prevYearBtn');
    const nextYearBtn = document.getElementById('nextYearBtn');
    const yearSelectorForm = document.getElementById('yearSelectorForm');
    const currentYear = new Date().getFullYear();
    const minYear = currentYear - 10;

    function updateYearButtons() {
        const selectedYear = parseInt(yearSelect.value);
        prevYearBtn.disabled = selectedYear <= minYear;
        nextYearBtn.disabled = selectedYear >= currentYear;
    }

    if (prevYearBtn && nextYearBtn && yearSelect) {
        prevYearBtn.addEventListener('click', function() {
            const currentValue = parseInt(yearSelect.value);
            if (currentValue > minYear) {
                yearSelect.value = currentValue - 1;
                yearSelectorForm.submit();
            }
        });

        nextYearBtn.addEventListener('click', function() {
            const currentValue = parseInt(yearSelect.value);
            if (currentValue < currentYear) {
                yearSelect.value = currentValue + 1;
                yearSelectorForm.submit();
            }
        });

        // Initialize button states
        updateYearButtons();
    }

    // Function to resize charts
    function resizeCharts() {
        if (typeof salesChart !== 'undefined' && salesChart) {
            salesChart.resize();
        }
        if (typeof monthlyDonutChart !== 'undefined' && monthlyDonutChart) {
            monthlyDonutChart.resize();
        }
    }

    // Resize charts when sidebar is toggled
    const sidebar = document.querySelector('nav.sidebar');
    if (sidebar) {
        // Resize charts when sidebar state changes
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.attributeName === 'class') {
                    setTimeout(function() {
                        resizeCharts();
                    }, 350); // Wait for sidebar transition to complete
                }
            });
        });
        
        observer.observe(sidebar, {
            attributes: true,
            attributeFilter: ['class']
        });
    }

    // Also resize on window resize
    window.addEventListener('resize', function() {
        resizeCharts();
    });
</script>

<script src="js/account_check.js"></script>
<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>

<?php
$conn->close();
?>