<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin') {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/recovery_helper.php';
require_once __DIR__ . '/../lib/backup_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');
$userQuery->close();

ensureRecoveryTableExists($conn);

$message = null;
$messageType = 'success';

// Automatic backup schedule (stored in config/backup_schedule.json)
$schedulePath = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'backup_schedule.json';
$scheduledRunAt = null;
$scheduleMeta = [
    'last_run_at' => null,
    'last_status' => null,
    'last_file' => null
];
if (is_file($schedulePath)) {
    $scheduleJson = json_decode(file_get_contents($schedulePath), true);
    if (is_array($scheduleJson) && !empty($scheduleJson['run_at'])) {
        $scheduledRunAt = $scheduleJson['run_at'];
    }
    if (is_array($scheduleJson)) {
        $scheduleMeta['last_run_at'] = $scheduleJson['last_run_at'] ?? null;
        $scheduleMeta['last_status'] = $scheduleJson['last_status'] ?? null;
        $scheduleMeta['last_file'] = $scheduleJson['last_file'] ?? null;
    }
}

// Handle recovery item restore
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['restore_item_id'])) {
        $itemId = (int)$_POST['restore_item_id'];
        $item = getRecoveryItem($conn, $itemId);

        if ($item) {
            $result = restoreRecoveryItem($conn, $itemId);
            if ($result['success']) {
                $message = 'Item restored successfully.';
                addSystemLog(
                    $conn,
                    'Recovery Restored',
                    sprintf("Restored %s (%s)", $item['item_name'] ?? 'Unknown', $item['item_type']),
                    $userFullName
                );
            } else {
                $message = $result['message'];
                $messageType = 'error';
            }
        } else {
            $message = 'Recovery item not found.';
            $messageType = 'error';
        }
    } elseif (isset($_POST['purge_item_id'])) {
        $itemId = (int)$_POST['purge_item_id'];
        $item = getRecoveryItem($conn, $itemId);

        if ($item && purgeRecoveryItem($conn, $itemId)) {
            $message = 'Item permanently deleted.';
            addSystemLog(
                $conn,
                'Recovery Purged',
                sprintf("Permanently removed %s (%s)", $item['item_name'] ?? 'Unknown', $item['item_type']),
                $userFullName
            );
        } else {
            $message = 'Failed to delete item.';
            $messageType = 'error';
        }
    }
}

$recoveryItems = fetchRecoveryItems($conn);
$recoveryCount = count($recoveryItems);
$lastRemovedAt = $recoveryCount > 0 ? date('M d, Y h:i A', strtotime($recoveryItems[0]['removed_at'])) : 'No items yet';

// Backup info (for display). Automatic backup runs at the set time via background script on any open admin page.
$backupDir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'backup';
ensureBackupDir($backupDir);

$latestBackupFile = null;
$latestBackupTime = null;
$backupFiles = glob($backupDir . DIRECTORY_SEPARATOR . '*.sql');
if ($backupFiles && count($backupFiles) > 0) {
    usort($backupFiles, function ($a, $b) {
        return filemtime($b) <=> filemtime($a);
    });
    $latestBackupFile = basename($backupFiles[0]);
    $latestBackupTime = date('M d, Y h:i A', filemtime($backupFiles[0]));
}

function formatDateTime($dateTime) {
    if (!$dateTime) {
        return 'N/A';
    }
    return date('Y-m-d h:i A', strtotime($dateTime));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Backup &amp; Restore</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .recovery-button, [class*="btn-"], input[type="submit"], input[type="button"] {
            box-shadow: none !important;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            background-color: #f5f5f5;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0;
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0;
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        .sidebar-footer {
            flex-shrink: 0;
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto;
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines when expanded */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span,
        nav.sidebar.sidebar-expanded a[href*="backup_recovery"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        /* Header Styles */
        .products-header {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        }

        .products-header-main {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .header-title-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            background: rgba(250, 206, 11, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #face0b;
        }

        .header-title h2 {
            margin: 0;
            font-size: 24px;
            color: #1e293b;
        }

        .header-actions {
            text-align: right;
        }

        .header-actions p {
            margin: 4px 0;
            color: #64748b;
            font-size: 14px;
        }

        .header-actions strong {
            color: #1e293b;
        }

        /* Cards Grid */
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        }

        .card-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 16px;
        }

        .card-header i {
            font-size: 32px;
            color: #face0b;
        }

        .card-header h3 {
            margin: 0;
            font-size: 20px;
            color: #1e293b;
        }

        .card p {
            margin: 8px 0;
            color: #64748b;
            font-size: 14px;
            line-height: 1.6;
        }

        .card ul {
            margin: 12px 0;
            padding-left: 20px;
            color: #475569;
            font-size: 14px;
            line-height: 1.8;
        }

        .card ul li {
            margin-bottom: 6px;
        }

        .recovery-button {
            background: #333;
            color: white;
            border: none;
            border-radius: 999px;
            padding: 10px 20px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
            transition: background 0.2s ease, transform 0.2s ease;
            margin-top: 12px;
        }

        .recovery-button:hover {
            background: #555;
            transform: translateY(-1px);
        }

        /* Recovery Table Container */
        .recovery-table-container {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-top: 20px;
        }

        .recovery-table-container h3 {
            margin: 0 0 20px 0;
            font-size: 20px;
            color: #1e293b;
        }

        .table-container {
            max-height: calc(100vh - 500px);
            overflow-y: auto;
            padding-right: 8px;
            position: relative;
        }

        .table-container::-webkit-scrollbar {
            width: 8px;
        }

        .table-container::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.05);
            border-radius: 15px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: rgba(15, 23, 42, 0.25);
            border-radius: 15px;
        }

        .table-container::-webkit-scrollbar-thumb:hover {
            background: rgba(15, 23, 42, 0.4);
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            margin-top: 0;
            background: transparent;
        }

        thead tr {
            background: transparent;
        }

        th {
            background-color: #333;
            color: #ffffff;
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: none;
        }

        tbody tr {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        }

        td {
            padding: 18px 20px;
            text-align: left;
            font-size: 15px;
            color: #1e293b;
            border: none;
            vertical-align: middle;
        }

        tbody tr td:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 12px;
        }

        tbody tr td:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        .tag {
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .tag.product {
            background: rgba(34, 197, 94, 0.15);
            color: #15803d;
        }

        .tag.category {
            background: rgba(249, 115, 22, 0.15);
            color: #c2410c;
        }

        .tag.user {
            background: rgba(14, 165, 233, 0.15);
            color: #0369a1;
        }

        .recovery-actions {
            display: flex;
            gap: 8px;
        }

        .recovery-actions form {
            margin: 0;
        }

        .recovery-actions button {
            border: none;
            border-radius: 999px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .recovery-actions button.restore {
            background: linear-gradient(135deg, #22c55e, #16a34a);
            color: white;
            box-shadow: 0 8px 18px rgba(34, 197, 94, 0.35);
        }

        .recovery-actions button.restore:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(34, 197, 94, 0.45);
        }

        .recovery-actions button.purge {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            color: white;
            box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
        }

        .recovery-actions button.purge:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #64748b;
        }

        .empty-state i {
            font-size: 48px;
            color: #cbd5e1;
            margin-bottom: 16px;
        }

        .empty-state p {
            font-size: 16px;
            margin: 0;
        }

        /* Change Schedule modal styling (match User Management modals) */
        .schedule-modal-popup {
            padding: 0 !important;
            border: none !important;
            overflow: hidden !important;
            background: #f5f5f5 !important;
            border-radius: 15px !important;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3) !important;
            max-width: 540px !important;
        }

        /* Header-like title bar */
        .schedule-modal-title {
            margin: 0 !important;
            padding: 22px 26px !important;
            background: #333 !important;
            color: #fff !important;
            font-size: 22px !important;
            font-weight: 700 !important;
            text-align: left !important;
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
        }
        .schedule-modal-title::before {
            content: "\f017";
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            width: 44px;
            height: 44px;
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.14);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: #fff;
        }

        /* Body spacing similar to .modal-body */
        .schedule-modal-popup .swal2-html-container {
            margin: 0 !important;
            padding: 26px !important;
            text-align: left !important;
        }

        .schedule-modal-content {
            color: #475569;
            font-size: 14px;
            line-height: 1.6;
        }
        .schedule-modal-text {
            margin: 0 0 14px 0;
            color: #0f172a;
            font-weight: 600;
        }
        .schedule-modal-input-wrapper {
            display: flex;
            flex-direction: column;
            gap: 12px;
            align-items: stretch;
            justify-content: center;
            width: 100%;
            margin: 0;
        }
        .schedule-modal-input {
            border-radius: 10px !important;
            border: 1px solid rgba(0, 0, 0, 0.15) !important;
            padding: 12px 12px !important;
            transition: border 0.2s ease, box-shadow 0.2s ease;
            background: #fff !important;
            color: #333 !important;
            font-size: 14px !important;
            height: 44px !important;
        }
        .schedule-modal-input:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.25) !important;
            outline: none !important;
        }
        #scheduleWeekday {
            width: 100%;
            padding-left: 14px !important;
            cursor: pointer;
        }
        #scheduleTime {
            width: 100%;
        }

        /* Buttons styled like .modal-actions in user management */
        .schedule-modal-popup .swal2-actions {
            margin: 0 !important;
            padding: 0 26px 22px !important;
            justify-content: flex-end !important;
            gap: 12px !important;
        }
        .schedule-modal-confirm,
        .schedule-modal-cancel {
            padding: 8px 16px !important;
            border-radius: 999px !important;
            font-weight: 600 !important;
            font-size: 13px !important;
            border: none !important;
            cursor: pointer !important;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 6px !important;
        }
        .schedule-modal-cancel {
            background: rgba(0, 0, 0, 0.1) !important;
            color: #333 !important;
        }
        .schedule-modal-cancel:hover {
            background: rgba(0, 0, 0, 0.2) !important;
            transform: translateY(-1px) !important;
        }
        .schedule-modal-confirm {
            background: linear-gradient(135deg, #face0b, #f7b300) !important;
            color: #000 !important;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35) !important;
        }
        .schedule-modal-confirm:hover {
            transform: translateY(-1px) !important;
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45) !important;
        }

        /* New redesigned schedule modal styles */
        .schedule-section {
            margin-bottom: 24px;
        }
        
        .schedule-label {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 12px;
            color: #1e293b;
            font-weight: 600;
            font-size: 14px;
        }
        
        .schedule-label i {
            color: #face0b;
            width: 16px;
        }
        
        .weekday-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .weekday-btn {
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            background: #fff;
            color: #64748b;
            font-weight: 600;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s ease;
            min-width: 50px;
        }
        
        .weekday-btn:hover {
            border-color: #face0b;
            color: #1e293b;
            transform: translateY(-1px);
        }
        
        .weekday-btn.active {
            background: #face0b;
            border-color: #face0b;
            color: #000;
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.3);
        }
        
        .time-input-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 8px;
        }
        
        .schedule-time-input {
            padding: 14px 18px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            background: #fff;
            color: #1e293b;
            font-size: 16px;
            font-weight: 600;
            text-align: center;
            transition: all 0.2s ease;
            width: 160px;
        }
        
        .schedule-time-input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }
        
        .time-helper {
            color: #94a3b8;
            font-size: 12px;
            font-style: italic;
        }
        
        .schedule-preview {
            background: linear-gradient(135deg, #f8fafc, #e2e8f0);
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            padding: 16px;
            display: flex;
            align-items: center;
            gap: 12px;
            margin-top: 20px;
        }
        
        .schedule-preview i {
            color: #3b82f6;
            font-size: 16px;
        }
        
        .schedule-preview span {
            color: #475569;
            font-size: 14px;
        }
        
        .schedule-preview strong {
            color: #1e293b;
        }

        /* Automatic Backup Card Styling */
        .auto-backup-info {
            margin-bottom: 20px;
        }
        
        .schedule-status {
            background: linear-gradient(135deg, #f0f9ff, #e0f2fe);
            border: 1px solid #bae6fd;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 16px;
        }
        
        .schedule-badge {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 8px;
        }
        
        .schedule-badge i {
            color: #0ea5e9;
            font-size: 14px;
        }
        
        .schedule-badge span {
            color: #0369a1;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .schedule-details {
            margin-left: 22px;
        }
        
        .schedule-details span {
            color: #1e293b;
            font-weight: 700;
            font-size: 16px;
        }
        
        .backup-features {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            color: #475569;
            font-size: 14px;
        }
        
        .feature-item i {
            color: #22c55e;
            font-size: 12px;
            width: 16px;
        }
        
        .last-backup-info {
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid #e2e8f0;
        }
        
        .backup-status-header {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 10px;
            color: #1e293b;
            font-size: 14px;
        }
        
        .backup-status-header i {
            color: #6366f1;
            font-size: 14px;
        }
        
        .backup-file-info {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
        }
        
        .file-name {
            color: #1e293b;
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 4px;
            word-break: break-all;
        }
        
        .file-date {
            color: #64748b;
            font-size: 12px;
        }
        
        .no-backup-info {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #94a3b8;
            font-size: 13px;
            font-style: italic;
        }
        
        .no-backup-info i {
            color: #cbd5e1;
        }

        /* Inline Schedule Editing */
        .schedule-display {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .schedule-display:hover {
            background: rgba(250, 206, 11, 0.1);
        }
        
        .schedule-edit-icon {
            color: #94a3b8;
            font-size: 12px;
            opacity: 0;
            transition: opacity 0.2s ease;
        }
        
        .schedule-display:hover .schedule-edit-icon {
            opacity: 1;
        }
        
        .schedule-editor {
            margin-top: 8px;
        }
        
        .inline-schedule-form {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        
        .inline-input {
            padding: 6px 10px;
            border: 1px solid #d1d5db;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            background: #fff;
            color: #1e293b;
            transition: border-color 0.2s ease;
        }
        
        .inline-input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 2px rgba(250, 206, 11, 0.2);
        }
        
        .at-text {
            color: #64748b;
            font-size: 14px;
            font-weight: 500;
        }
        
        .inline-actions {
            display: flex;
            gap: 4px;
            margin-left: 8px;
        }
        
        .save-btn, .cancel-btn {
            width: 28px;
            height: 28px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            transition: all 0.2s ease;
        }
        
        .save-btn {
            background: #22c55e;
            color: white;
        }
        
        .save-btn:hover {
            background: #16a34a;
            transform: translateY(-1px);
        }
        
        .cancel-btn {
            background: #ef4444;
            color: white;
        }
        
        .cancel-btn:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }

        @media (max-width: 768px) {
            main {
                margin-left: 0;
                width: 100%;
            }
            
            
            nav.sidebar {
                display: none;
            }

            .cards-grid {
                grid-template-columns: 1fr;
            }

            .products-header-main {
                flex-direction: column;
                align-items: flex-start;
            }

            .header-actions {
                text-align: left;
                width: 100%;
            }

            .table-container,
            .recovery-table-container {
                max-height: calc(100vh - 200px);
                overflow-x: auto;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch;
            }

            .recovery-table-container table,
            .table-container table {
                min-width: 600px;
            }

            .recovery-table-container table th,
            .recovery-table-container table td,
            .table-container table th,
            .table-container table td {
                padding: 12px 10px;
                font-size: 13px;
            }

            .recovery-table-container table th,
            .table-container table th {
                font-size: 12px;
                padding: 10px 8px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="product_management.php" class="<?php echo isActive('product_management.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Product Management</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>

    <main>
        <div class="products-header">
            <div class="products-header-main">
                <div class="header-title">
                    <div class="header-title-icon">
                        <i class="fas fa-database"></i>
                    </div>
                    <div>
                        <h2>Backup &amp; Restore</h2>
                    </div>
                </div>
                <div class="header-actions">
                    <p>Total items in recovery: <strong><?php echo $recoveryCount; ?></strong></p>
                    <p>Last removal: <strong><?php echo htmlspecialchars($lastRemovedAt); ?></strong></p>
                </div>
            </div>
        </div>

        <!-- Database Backup & Recovery Section -->
        <div class="cards-grid">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-download"></i>
                    <h3>Manual Backup</h3>
                </div>
                <p>Create a backup of your MySQL database right now. This will export all tables and data to a SQL file.</p>
                <ul>
                    <li>Includes all tables and data</li>
                    <li>Date-first filename</li>
                    <li>Choose your download location</li>
                    <li>Ready for import</li>
                </ul>
                <a href="backup_database.php" class="recovery-button" onclick="return confirmBackup(event);">
                    <i class="fas fa-download"></i> Download Backup
                </a>
            </div>

            <div class="card">
                <div class="card-header">
                    <i class="fas fa-clock"></i>
                    <h3>Automatic Backup</h3>
                </div>
                
                <div class="auto-backup-info">
                    <div class="schedule-status">
                        <div class="schedule-badge">
                            <i class="fas fa-calendar-check"></i>
                            <span>Scheduled</span>
                        </div>
                        <div class="schedule-details">
                            <div class="schedule-display" id="scheduleDisplay" onclick="editSchedule()">
                                <span id="autoScheduleText">
                                    <?php
                                    if ($scheduledRunAt) {
                                        $dt = DateTime::createFromFormat('Y-m-d\TH:i', $scheduledRunAt);
                                        if ($dt) {
                                            $weekday = ucfirst(strtolower($dt->format('l')));
                                            $time = $dt->format('h:i A');
                                            echo 'Every ' . htmlspecialchars($weekday) . ' at ' . htmlspecialchars($time);
                                        } else {
                                            echo 'Every Monday at 10:00 AM';
                                        }
                                    } else {
                                        echo 'Every Monday at 10:00 AM';
                                    }
                                    ?>
                                </span>
                                <i class="fas fa-edit schedule-edit-icon"></i>
                            </div>
                            
                            <div class="schedule-editor" id="scheduleEditor" style="display: none;">
                                <div class="inline-schedule-form">
                                    <select id="inlineWeekday" class="inline-input">
                                        <option value="1">Monday</option>
                                        <option value="2">Tuesday</option>
                                        <option value="3">Wednesday</option>
                                        <option value="4">Thursday</option>
                                        <option value="5">Friday</option>
                                        <option value="6">Saturday</option>
                                        <option value="0">Sunday</option>
                                    </select>
                                    <span class="at-text">at</span>
                                    <input type="time" id="inlineTime" class="inline-input">
                                    <div class="inline-actions">
                                        <button type="button" class="save-btn" onclick="saveSchedule()">
                                            <i class="fas fa-check"></i>
                                        </button>
                                        <button type="button" class="cancel-btn" onclick="cancelEdit()">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="backup-features">
                        <div class="feature-item">
                            <i class="fas fa-shield-alt"></i>
                            <span>Automatic protection</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-database"></i>
                            <span>Complete database backup</span>
                        </div>
                        <div class="feature-item">
                            <i class="fas fa-folder"></i>
                            <span>Saved to backup folder</span>
                        </div>
                    </div>
                </div>
                
                <div class="last-backup-info">
                    <div class="backup-status-header">
                        <i class="fas fa-history"></i>
                        <strong>Last Backup</strong>
                    </div>
                    <?php if ($latestBackupFile): ?>
                        <div class="backup-file-info">
                            <div class="file-name"><?php echo htmlspecialchars($latestBackupFile); ?></div>
                            <div class="file-date"><?php echo htmlspecialchars($latestBackupTime); ?></div>
                        </div>
                    <?php else: ?>
                        <div class="no-backup-info">
                            <i class="fas fa-info-circle"></i>
                            <span>No backups found yet</span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Database Restore Section -->
        <div class="cards-grid">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-upload"></i>
                    <h3>Database Restore</h3>
                </div>
                <p>Restore your database from a previously created backup file. This will replace all current data.</p>
                <ul>
                    <li>Upload .sql backup file</li>
                    <li>Complete database restore</li>
                    <li>All tables and data</li>
                </ul>
                <form id="restoreForm" method="POST" enctype="multipart/form-data" action="restore_database.php" style="margin-top: 12px;">
                    <input type="file" name="backup_file" id="backup_file" accept=".sql" required style="display: none;" onchange="handleFileSelect(this)">
                    <button type="button" class="recovery-button" onclick="document.getElementById('backup_file').click();">
                        <i class="fas fa-upload"></i> Choose File
                    </button>
                    <button type="submit" class="recovery-button" id="restoreBtn" style="display: none; margin-left: 8px;" onclick="return confirmRestoreDatabase(event);">
                        <i class="fas fa-upload"></i> Restore Database
                    </button>
                    <div id="fileName" style="margin-top: 8px; color: #64748b; font-size: 13px;"></div>
                </form>
            </div>
        </div>

        <!-- Recovery Items Table -->
        <div class="recovery-table-container">
            <h3>Recovery Items</h3>
            <?php if ($recoveryCount === 0): ?>
                <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>No items in recovery. Removed items will appear here.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Name</th>
                                <th>Removed By</th>
                                <th>Removed At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recoveryItems as $item): ?>
                                <tr>
                                    <td>
                                        <span class="tag <?php echo htmlspecialchars($item['item_type']); ?>">
                                            <?php echo ucfirst(htmlspecialchars($item['item_type'])); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($item['item_name'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($item['removed_by']); ?></td>
                                    <td><?php echo formatDateTime($item['removed_at']); ?></td>
                                    <td>
                                        <div class="recovery-actions">
                                            <form method="POST" onsubmit="return confirmRestoreItem(event);">
                                                <input type="hidden" name="restore_item_id" value="<?php echo (int)$item['id']; ?>">
                                                <button type="submit" class="restore">
                                                    <i class="fas fa-undo"></i> Restore
                                                </button>
                                            </form>
                                            <form method="POST" onsubmit="return confirmPurgeItem(event);">
                                                <input type="hidden" name="purge_item_id" value="<?php echo (int)$item['id']; ?>">
                                                <button type="submit" class="purge">
                                                    <i class="fas fa-times"></i> Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                sidebar.classList.toggle('sidebar-expanded');
                // Save state to localStorage
                const isExpanded = sidebar.classList.contains('sidebar-expanded');
                localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
            }
        }
        
        // Restore sidebar state on page load (without transition)
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.querySelector('nav.sidebar');
            if (sidebar) {
                // Disable transitions during state restoration
                sidebar.classList.add('no-transition');
                
                const savedState = localStorage.getItem('sidebarExpanded');
                if (savedState === 'true') {
                    sidebar.classList.add('sidebar-expanded');
                } else {
                    // Default to collapsed (no saved state or explicitly false)
                    sidebar.classList.remove('sidebar-expanded');
                }
                
                // Re-enable transitions after a short delay
                setTimeout(function() {
                    sidebar.classList.remove('no-transition');
                }, 50);
            }

        });

        function confirmLogout(event) {
            event.preventDefault();
            Swal.fire({
                title: 'Logout Confirmation',
                text: 'Are you sure you want to logout?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, logout',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '../authentication/logout.php';
                }
            });
        }

        function confirmBackup(event) {
            Swal.fire({
                title: 'Create Database Backup?',
                text: 'This will download a complete backup of your database.',
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Yes, download backup'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'backup_database.php';
                } else {
                    event.preventDefault();
                    return false;
                }
            });
            return false;
        }


        function openSchedulePicker() {
            const current = <?php echo json_encode($scheduledRunAt ?: ''); ?>;

            const pad = (n) => String(n).padStart(2, '0');
            const parseWeekday = (dt) => dt.getDay(); // 0=Sun ... 6=Sat

            let defaultWeekday = 1; // Monday
            let defaultTime = '10:00';

            if (current) {
                const dt = new Date(current.replace('T', ' ') );
                if (!isNaN(dt)) {
                    defaultWeekday = parseWeekday(dt);
                    defaultTime = `${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
                }
            }

            Swal.fire({
                title: 'Change Automatic Backup Schedule',
                html: `
                    <div class="schedule-modal-content">
                        <p class="schedule-modal-text">Configure when automatic backups should run</p>
                        
                        <div class="schedule-section">
                            <label class="schedule-label">
                                <i class="fas fa-calendar-day"></i>
                                Day of the Week
                            </label>
                            <div class="weekday-buttons">
                                <button type="button" class="weekday-btn" data-day="1">Mon</button>
                                <button type="button" class="weekday-btn" data-day="2">Tue</button>
                                <button type="button" class="weekday-btn" data-day="3">Wed</button>
                                <button type="button" class="weekday-btn" data-day="4">Thu</button>
                                <button type="button" class="weekday-btn" data-day="5">Fri</button>
                                <button type="button" class="weekday-btn" data-day="6">Sat</button>
                                <button type="button" class="weekday-btn" data-day="0">Sun</button>
                            </div>
                        </div>
                        
                        <div class="schedule-section">
                            <label class="schedule-label">
                                <i class="fas fa-clock"></i>
                                Time
                            </label>
                            <div class="time-input-wrapper">
                                <input id="scheduleTime" type="time" class="schedule-time-input" value="${defaultTime}">
                                <span class="time-helper">24-hour format</span>
                            </div>
                        </div>
                        
                        <div class="schedule-preview">
                            <i class="fas fa-info-circle"></i>
                            <span id="schedulePreview">Next backup: <strong>Monday at 10:00 AM</strong></span>
                        </div>
                    </div>
                `,
                customClass: {
                    popup: 'schedule-modal-popup',
                    title: 'schedule-modal-title',
                    confirmButton: 'schedule-modal-confirm',
                    cancelButton: 'schedule-modal-cancel'
                },
                showCancelButton: true,
                confirmButtonColor: '#face0b',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Save schedule',
                didOpen: () => {
                    // Set default selected weekday
                    const weekdayBtns = document.querySelectorAll('.weekday-btn');
                    weekdayBtns.forEach(btn => {
                        if (btn.dataset.day === String(defaultWeekday)) {
                            btn.classList.add('active');
                        }
                        btn.addEventListener('click', () => {
                            weekdayBtns.forEach(b => b.classList.remove('active'));
                            btn.classList.add('active');
                            updatePreview();
                        });
                    });
                    
                    // Set default time
                    const timeEl = document.getElementById('scheduleTime');
                    if (timeEl && !timeEl.value) timeEl.value = defaultTime;
                    
                    // Add time change listener
                    if (timeEl) {
                        timeEl.addEventListener('change', updatePreview);
                    }
                    
                    // Update preview function
                    function updatePreview() {
                        const activeBtn = document.querySelector('.weekday-btn.active');
                        const timeInput = document.getElementById('scheduleTime');
                        const preview = document.getElementById('schedulePreview');
                        
                        if (activeBtn && timeInput && preview) {
                            const dayName = activeBtn.textContent;
                            const time = timeInput.value;
                            if (time) {
                                const [hours, minutes] = time.split(':');
                                const timeObj = new Date();
                                timeObj.setHours(parseInt(hours), parseInt(minutes));
                                const formattedTime = timeObj.toLocaleTimeString('en-US', { 
                                    hour: 'numeric', 
                                    minute: '2-digit',
                                    hour12: true 
                                });
                                preview.innerHTML = `Next backup: <strong>${dayName}day at ${formattedTime}</strong>`;
                            }
                        }
                    }
                    
                    // Initial preview update
                    updatePreview();
                },
                preConfirm: () => {
                    const activeBtn = document.querySelector('.weekday-btn.active');
                    const timeEl = document.getElementById('scheduleTime');
                    
                    if (!activeBtn || !timeEl || !timeEl.value) {
                        Swal.showValidationMessage('Please select a day and time');
                        return false;
                    }
                    
                    const selectedWeekday = parseInt(activeBtn.dataset.day, 10);
                    const [h, m] = timeEl.value.split(':').map(Number);
                    
                    if (isNaN(selectedWeekday) || isNaN(h) || isNaN(m)) {
                        Swal.showValidationMessage('Invalid selection');
                        return false;
                    }

                    // Build next occurrence of selected weekday at selected time
                    const now = new Date();
                    let target = new Date(now);
                    target.setHours(h, m, 0, 0);
                    while (target.getDay() !== selectedWeekday || target <= now) {
                        target.setDate(target.getDate() + 1);
                    }

                    const iso = `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}T${pad(h)}:${pad(m)}`;
                    return iso;
                }
            }).then((result) => {
                if (!result.isConfirmed) return;

                fetch('update_backup_schedule.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `run_at=${encodeURIComponent(result.value)}`
                })
                .then(r => r.json())
                .then(data => {
                    if (!data.success) {
                        throw new Error(data.message || 'Failed to update schedule');
                    }

                    const displayDate = new Date(data.run_at.replace('T', ' ') );
                    const weekday = displayDate.toLocaleString('en-US', { weekday: 'long' });
                    const time = displayDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                    const weeklyText = `Backup is scheduled every ${weekday.toLowerCase()} at ${time}`;

                    const scheduleEl = document.getElementById('autoScheduleText');
                    if (scheduleEl) scheduleEl.textContent = weeklyText;

                    Swal.fire({
                        title: 'Saved!',
                        text: 'Automatic backup schedule updated.',
                        icon: 'success',
                        confirmButtonColor: '#face0b',
                        customClass: { popup: 'schedule-modal-popup' }
                    });
                })
                .catch(err => {
                    Swal.fire({
                        title: 'Error',
                        text: err.message || 'Failed to update schedule',
                        icon: 'error',
                        confirmButtonColor: '#face0b'
                    });
                });
            });
        }

        function handleFileSelect(input) {
            if (input.files && input.files[0]) {
                const fileName = input.files[0].name;
                document.getElementById('fileName').textContent = 'Selected: ' + fileName;
                document.getElementById('restoreBtn').style.display = 'inline-flex';
            }
        }

        function confirmRestoreDatabase(event) {
            event.preventDefault();
            const form = document.getElementById('restoreForm');
            const fileInput = document.getElementById('backup_file');

            if (!fileInput.files || !fileInput.files[0]) {
            Swal.fire({
                    title: 'No File Selected',
                    text: 'Please select a backup file first.',
                    icon: 'warning',
                    confirmButtonColor: '#face0b'
                });
                return false;
            }

            Swal.fire({
                title: 'Restore Database?',
                html: '<div style="text-align: left;"><strong>Warning:</strong><br>' +
                      '• This will replace ALL current database data<br>' +
                      '• The current database will be overwritten<br>' +
                      '• This action cannot be undone<br><br>' +
                      'Make sure you have a current backup before proceeding!</div>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Yes, restore database',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading
                    Swal.fire({
                        title: 'Restoring Database...',
                        text: 'Please wait, this may take a few moments.',
                        icon: 'info',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });

                    // Submit form via AJAX
                    const formData = new FormData(form);
                    fetch('restore_database.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            Swal.fire({
                                title: 'Success!',
                                text: data.message,
                                icon: 'success',
                                confirmButtonColor: '#face0b'
                            }).then(() => {
                                window.location.reload();
                            });
                        } else {
                            Swal.fire({
                                title: 'Restore Failed',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#face0b'
                            });
                        }
                    })
                    .catch(error => {
                        Swal.fire({
                            title: 'Error',
                            text: 'An error occurred during restore: ' + error.message,
                            icon: 'error',
                            confirmButtonColor: '#face0b'
                        });
                    });
                }
            });
            return false;
        }

        // Update sidebar date and time
        function updateSidebarDateTime() {
            const now = new Date();
            
            // Format date: Day, Month DD, YYYY
            const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
            const dateStr = now.toLocaleDateString('en-US', dateOptions);
            
            // Format time: HH:MM:SS AM/PM
            const timeStr = now.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit', 
                second: '2-digit',
                hour12: true 
            });
            
            const dateElement = document.getElementById('sidebar-date');
            const timeElement = document.getElementById('sidebar-time');
            
            if (dateElement) {
                dateElement.textContent = dateStr;
            }
            if (timeElement) {
                timeElement.textContent = timeStr;
            }
        }

        // Update immediately and then every second
        updateSidebarDateTime();
        setInterval(updateSidebarDateTime, 1000);

        function confirmRestoreItem(event) {
            event.preventDefault();
            const form = event.target.closest('form');

            Swal.fire({
                title: 'Restore Item?',
                text: 'This will restore the item back to its original location.',
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#22c55e',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Yes, restore it'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
            return false;
        }

        function confirmPurgeItem(event) {
            event.preventDefault();
            const form = event.target.closest('form');

            Swal.fire({
                title: 'Permanently Delete?',
                text: 'This action cannot be undone. The item will be permanently removed.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#6b7280',
                confirmButtonText: 'Yes, delete permanently'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
            return false;
        }

        <?php if ($message): ?>
        Swal.fire({
            title: '<?php echo $messageType === 'success' ? 'Success!' : 'Error!'; ?>',
            text: '<?php echo addslashes($message); ?>',
            icon: '<?php echo $messageType; ?>',
            confirmButtonColor: '#face0b'
        });
        <?php endif; ?>

        // Inline schedule editing functions
        let originalSchedule = null;

        function editSchedule() {
            const display = document.getElementById('scheduleDisplay');
            const editor = document.getElementById('scheduleEditor');
            
            // Store original values
            const current = <?php echo json_encode($scheduledRunAt ?: ''); ?>;
            let defaultWeekday = 1; // Monday
            let defaultTime = '10:00';

            if (current) {
                const dt = new Date(current.replace('T', ' '));
                if (!isNaN(dt)) {
                    defaultWeekday = dt.getDay();
                    const pad = (n) => String(n).padStart(2, '0');
                    defaultTime = `${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
                }
            }

            // Set form values
            document.getElementById('inlineWeekday').value = String(defaultWeekday);
            document.getElementById('inlineTime').value = defaultTime;
            
            // Store original for cancel
            originalSchedule = {
                weekday: defaultWeekday,
                time: defaultTime
            };

            // Toggle visibility
            display.style.display = 'none';
            editor.style.display = 'block';
            
            // Focus on first input
            document.getElementById('inlineWeekday').focus();
        }

        function cancelEdit() {
            const display = document.getElementById('scheduleDisplay');
            const editor = document.getElementById('scheduleEditor');
            
            display.style.display = 'flex';
            editor.style.display = 'none';
        }

        function saveSchedule() {
            const weekdayEl = document.getElementById('inlineWeekday');
            const timeEl = document.getElementById('inlineTime');
            
            if (!weekdayEl.value || !timeEl.value) {
                Swal.fire({
                    title: 'Invalid Input',
                    text: 'Please select both day and time',
                    icon: 'warning',
                    confirmButtonColor: '#face0b'
                });
                return;
            }

            const selectedWeekday = parseInt(weekdayEl.value, 10);
            const [h, m] = timeEl.value.split(':').map(Number);
            
            // Build next occurrence
            const now = new Date();
            let target = new Date(now);
            target.setHours(h, m, 0, 0);
            while (target.getDay() !== selectedWeekday || target <= now) {
                target.setDate(target.getDate() + 1);
            }

            const pad = (n) => String(n).padStart(2, '0');
            const iso = `${target.getFullYear()}-${pad(target.getMonth() + 1)}-${pad(target.getDate())}T${pad(h)}:${pad(m)}`;

            // Show loading
            const saveBtn = document.querySelector('.save-btn');
            const originalContent = saveBtn.innerHTML;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            saveBtn.disabled = true;

            fetch('update_backup_schedule.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `run_at=${encodeURIComponent(iso)}`
            })
            .then(r => r.json())
            .then(data => {
                if (!data.success) {
                    throw new Error(data.message || 'Failed to update schedule');
                }

                // Update display text
                const displayDate = new Date(data.run_at.replace('T', ' '));
                const weekday = displayDate.toLocaleString('en-US', { weekday: 'long' });
                const time = displayDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                const weeklyText = `Every ${weekday} at ${time}`;

                const scheduleEl = document.getElementById('autoScheduleText');
                if (scheduleEl) scheduleEl.textContent = weeklyText;

                // Hide editor, show display
                cancelEdit();

                // Show success message
                Swal.fire({
                    title: 'Saved!',
                    text: 'Backup schedule updated successfully',
                    icon: 'success',
                    confirmButtonColor: '#face0b',
                    timer: 2000,
                    showConfirmButton: false
                });
            })
            .catch(err => {
                Swal.fire({
                    title: 'Error',
                    text: err.message || 'Failed to update schedule',
                    icon: 'error',
                    confirmButtonColor: '#face0b'
                });
            })
            .finally(() => {
                saveBtn.innerHTML = originalContent;
                saveBtn.disabled = false;
            });
        }
    </script>
<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>
