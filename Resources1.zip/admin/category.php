<?php
session_start();
if (!isset($_SESSION['Username']) || $_SESSION['Role'] !== 'Admin' || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

require_once __DIR__ . '/../lib/prevent_back_button.php'; // Prevent back button navigation
require_once __DIR__ . '/../config/connection.php'; // Include your database connection
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/recovery_helper.php';

// Get user's full name
$userQuery = $conn->prepare("SELECT FullName, Username FROM loginaccount WHERE Username = ?");
$userQuery->bind_param("s", $_SESSION['Username']);
$userQuery->execute();
$userData = $userQuery->get_result()->fetch_assoc();
$userFullName = !empty($userData['FullName']) ? $userData['FullName'] : ($userData['Username'] ?? 'Administrator');
$userQuery->close();

ensureRecoveryTableExists($conn);

// Handle form submission for adding a new category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $categoryName = trim($_POST['category_name'] ?? '');

    // Validate category name: 2-50 chars, letters/numbers/spaces/basic punctuation
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,50}$/', $categoryName)) {
        $message = "Category name must be 2–50 characters (letters, numbers, spaces, basic punctuation).";
        $messageType = "error";
    } else {
        // Check if category name already exists
        $checkStmt = $conn->prepare("SELECT COUNT(*) as count FROM categories WHERE CategoryName = ?");
        $checkStmt->bind_param("s", $categoryName);
        $checkStmt->execute();
        $result = $checkStmt->get_result();
        $row = $result->fetch_assoc();
        $checkStmt->close();

        if ($row['count'] > 0) {
            $message = "A category with this name already exists!";
            $messageType = "error";
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (CategoryName, date_created) VALUES (?, NOW())");
            $stmt->bind_param("s", $categoryName);

            if ($stmt->execute()) {
                addSystemLog($conn, "Category Created", "New category created: " . $categoryName, $userFullName);
                $message = "Category added successfully!";
                $messageType = "success";
            } else {
                $message = "Error: " . $stmt->error;
                $messageType = "error";
            }

            $stmt->close();
        }
    }
}

// Handle category removal
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['remove_category'])) {
    $categoryId = (int)$_POST['category_id'];

    // Get category details before removal
    $stmt = $conn->prepare("SELECT * FROM categories WHERE CategoryID = ?");
    $stmt->bind_param("i", $categoryId);
    $stmt->execute();
    $categoryData = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$categoryData) {
        $message = "Category not found.";
        $messageType = "error";
    } else {
        storeRecoveryItem(
            $conn,
            'category',
            'categories',
            $categoryData['CategoryID'],
            $categoryData['CategoryName'],
            $categoryData,
            $userFullName
        );

        $stmt = $conn->prepare("DELETE FROM categories WHERE CategoryID = ?");
        $stmt->bind_param("i", $categoryId);

        if ($stmt->execute()) {
            addSystemLog($conn, "Category Removed", "Category removed: " . $categoryData['CategoryName'], $userFullName);
            $message = "Category removed successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $stmt->error;
            $messageType = "error";
        }

        $stmt->close();
    }
}

// Handle category editing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_category'])) {
    $categoryId = $_POST['category_id'];
    $categoryName = trim($_POST['category_name'] ?? '');

    // Validate category name
    if (!preg_match('/^[A-Za-z0-9À-ž\s.\'\/\-()&,]{2,50}$/', $categoryName)) {
        $message = "Category name must be 2–50 characters (letters, numbers, spaces, basic punctuation).";
        $messageType = "error";
    } else {
        $stmt = $conn->prepare("SELECT CategoryName FROM categories WHERE CategoryID = ?");
        $stmt->bind_param("i", $categoryId);
        $stmt->execute();
        $oldCategory = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        $stmt = $conn->prepare("UPDATE categories SET CategoryName = ? WHERE CategoryID = ?");
        $stmt->bind_param("si", $categoryName, $categoryId);

        if ($stmt->execute()) {
            addSystemLog($conn, "Category Updated", "Category name updated from '" . $oldCategory['CategoryName'] . "' to '" . $categoryName . "'", $userFullName);
            $message = "Category updated successfully!";
            $messageType = "success";
        } else {
            $message = "Error: " . $stmt->error;
            $messageType = "error";
        }

        $stmt->close();
    }
}

// Get sort parameters
$sortField = isset($_GET['sort']) ? $_GET['sort'] : 'date_created';
$sortOrder = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// Validate sort parameters to prevent SQL injection
$allowedFields = ['CategoryName', 'date_created'];
$allowedOrders = ['ASC', 'DESC'];

if (!in_array($sortField, $allowedFields)) {
    $sortField = 'date_created';
}
if (!in_array(strtoupper($sortOrder), $allowedOrders)) {
    $sortOrder = 'DESC';
}

// Fetch all categories for display with sorting
$categoryResult = $conn->query("SELECT *, DATE_FORMAT(date_created, '%Y-%m-%d %h:%i %p') as formatted_date 
                              FROM categories 
                              ORDER BY $sortField $sortOrder");

$totalCategoriesResult = $conn->query("SELECT COUNT(*) AS total FROM categories");
$totalCategories = $totalCategoriesResult ? (int)$totalCategoriesResult->fetch_assoc()['total'] : 0;
if ($totalCategoriesResult) {
    $totalCategoriesResult->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        /* Search bar: same as User Management */
        .search-box, .search-input, .search-container .input-with-icon input, .search-container input[type="text"], .search-form input[type="text"] {
            padding: 10px 14px 10px 40px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 15px !important;
            font-size: 14px !important;
            outline: none !important;
        }
        .search-box:focus, .search-input:focus, .search-container .input-with-icon input:focus, .search-container input[type="text"]:focus, .search-form input[type="text"]:focus {
            border-color: #face0b !important;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2) !important;
        }
        .search-container { position: relative; }
        .search-container .input-with-icon { position: relative; }
        .search-container .input-with-icon i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
        }
        /* All buttons: no shadow */
        button, .btn-primary, .btn-secondary, .btn-edit, .recovery-button, [class*="btn-"] {
            box-shadow: none !important;
        }
    </style>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            background-color: white;
        }

        /* Sidebar Styles */
        nav.sidebar {
            width: 70px;
            background-color: #333;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            z-index: 999;
            display: flex;
            flex-direction: column;
            transition: width 0.3s ease;
        }
        
        /* Disable transitions on page load */
        nav.sidebar.no-transition,
        nav.sidebar.no-transition * {
            transition: none !important;
        }

        nav.sidebar.sidebar-expanded {
            width: 200px;
        }

        /* Navigation items container - scrollable */
        .sidebar-nav-items {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            padding-top: 20px;
            padding-bottom: 10px;
            min-height: 0; /* Important for flex scrolling */
        }

        nav.sidebar.sidebar-expanded .sidebar-nav-items {
            overflow-y: auto;
        }

        /* Custom scrollbar styling */
        .sidebar-nav-items::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar-nav-items::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.2);
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }

        .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }

        .sidebar-logo {
            padding: 20px;
            text-align: center;
            flex-shrink: 0; /* Prevent logo from shrinking */
            margin-bottom: 0;
            cursor: pointer;
        }

        .sidebar-logo img {
            max-width: 100%;
            height: auto;
            max-height: 40px;
            object-fit: contain;
            margin-bottom: 5px;
            transition: max-height 0.3s ease, margin-bottom 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo img {
            max-height: 80px;
            margin-bottom: 10px;
        }

        .sidebar-logo .restaurant-name {
            color: white;
            font-size: 14px;
            font-weight: 600;
            line-height: 1.4;
            margin-top: 10px;
            transition: all 0.3s ease;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            text-align: center;
        }

        nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
            opacity: 1;
            max-height: 100px;
        }

        /* Sidebar Footer - Cashier Info at Bottom */
        .sidebar-footer {
            flex-shrink: 0; /* Prevent footer from shrinking */
            padding: 20px 15px;
            background-color: rgba(0, 0, 0, 0.3);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            transition: all 0.3s ease;
            margin-top: auto; /* Push to bottom */
        }

        .sidebar-footer .cashier-name {
            color: white;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.4;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .sidebar-footer .cashier-name i {
            font-size: 14px;
        }

        .sidebar-footer .cashier-name span {
            opacity: 0;
            width: 0;
            overflow: hidden;
            transition: all 0.3s ease;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
            opacity: 1;
            width: auto;
        }

        .sidebar-footer .sidebar-datetime {
            color: white;
            font-size: 14px;
            line-height: 1.6;
            text-align: center;
            transition: all 0.3s ease;
        }

        .sidebar-footer .sidebar-datetime #sidebar-date {
            font-weight: 500;
            margin-bottom: 5px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
            opacity: 1;
            max-height: 30px;
        }

        .sidebar-footer .sidebar-datetime #sidebar-time {
            font-weight: 600;
            color: #face0b;
            font-size: 16px;
            opacity: 0;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
            opacity: 1;
            max-height: 30px;
        }

        nav.sidebar a {
            color: white;
            padding: 14px 0;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: flex-start;
            text-align: left;
            padding-left: 20px;
        }

        nav.sidebar.sidebar-expanded a {
            padding: 14px 20px;
            text-align: left;
            justify-content: flex-start;
        }

        nav.sidebar a:hover {
            background-color: #ddd;
            color: black;
        }

        nav.sidebar a.active {
            background-color: #face0b;
            color: black;
        }

        nav.sidebar a i {
            margin-right: 0;
            width: 20px;
            text-align: center;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a i {
            margin-right: 10px;
        }

        nav.sidebar a span {
            transition: all 0.3s ease;
            opacity: 0;
            width: 0;
            overflow: hidden;
            display: inline-block;
        }

        nav.sidebar.sidebar-expanded a span {
            opacity: 1;
            width: auto;
            white-space: normal;
            word-wrap: break-word;
            overflow-wrap: break-word;
            line-height: 1.3;
            max-width: 140px;
            display: inline-block;
        }

        /* Allow specific long navigation items to wrap to 2 lines */
        nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
        nav.sidebar.sidebar-expanded a[href*="user_management"] span {
            max-width: 130px;
        }

        /* Main Content Area */
        main {
            margin-left: 90px;
            margin-top: 0;
            padding: 20px;
            flex-grow: 1;
            transition: margin-left 0.3s ease, width 0.3s ease;
            width: calc(100% - 90px);
            box-sizing: border-box;
            position: relative;
            overflow-x: hidden;
        }

        nav.sidebar.sidebar-expanded ~ main {
            margin-left: 220px;
            width: calc(100% - 220px);
        }
        
        /* Disable main content transitions on page load */
        nav.sidebar.no-transition ~ main {
            transition: none !important;
        }

        h1, h2 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        h3 {
            font-size: 18px;
            margin-bottom: 10px;
        }

        form {
            margin-bottom: 20px;
        }

        form label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
        }

        form input[type="text"] {
            padding: 10px;
            width: 300px;
            border-radius: 15px;
            border: 1px solid #ccc;
            margin-bottom: 15px;
            font-size: 1em;
        }

        form button {
            padding: 8px 16px;
            background: linear-gradient(135deg, #333, #444);
            color: white;
            border: none;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            box-shadow: 0 8px 18px rgba(0, 0, 0, 0.25);
        }

        form button:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(0, 0, 0, 0.35);
        }

        #categoriesTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            margin-top: 0;
            background: transparent;
        }

        #categoriesTable thead {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #333;
            transform: translateZ(0);
            isolation: isolate;
        }

        #categoriesTable thead tr {
            background: #333;
        }

        #categoriesTable th {
            background-color: #333 !important;
            color: #ffffff;
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            cursor: pointer;
            border: none;
            position: relative;
            white-space: nowrap;
            transition: background-color 0.3s ease;
            box-shadow: 0 4px 0 0 #333;
            border-bottom: 4px solid #333;
        }

        #categoriesTable th:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 0;
        }

        #categoriesTable th:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 0;
        }

        #categoriesTable th:hover {
            background-color: #444;
        }

        #categoriesTable tbody {
            position: relative;
            z-index: 1;
        }

        #categoriesTable tbody tr {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            margin-bottom: 12px;
        }

        #categoriesTable tbody tr:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
            background: #ffffff;
        }

        #categoriesTable td {
            padding: 18px 20px;
            text-align: left;
            font-size: 15px;
            color: #1e293b;
            border: none;
            vertical-align: middle;
        }

        #categoriesTable tbody tr td:first-child {
            border-top-left-radius: 12px;
            border-bottom-left-radius: 12px;
        }

        #categoriesTable tbody tr td:last-child {
            border-top-right-radius: 12px;
            border-bottom-right-radius: 12px;
        }

        /* Action Buttons - Status Button Style */
        #categoriesTable td button {
            border: none;
            border-radius: 999px;
            padding: 8px 16px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            color: #fff;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            margin: 0 4px;
        }

        #categoriesTable td button[onclick*="edit"]:not([onclick*="confirmRemoveCategory"]),
        #categoriesTable td button[onclick*="Edit"]:not([onclick*="confirmRemoveCategory"]),
        #categoriesTable td button[onclick*="openEditCategoryModal"] {
            background: linear-gradient(135deg, #face0b, #f7b300) !important;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35) !important;
            color: #000000 !important;
        }

        #categoriesTable td button[onclick*="edit"]:not([onclick*="confirmRemoveCategory"]) *,
        #categoriesTable td button[onclick*="Edit"]:not([onclick*="confirmRemoveCategory"]) *,
        #categoriesTable td button[onclick*="openEditCategoryModal"] * {
            color: #000000 !important;
        }

        #categoriesTable td button[onclick*="edit"]:not([onclick*="confirmRemoveCategory"]):hover,
        #categoriesTable td button[onclick*="Edit"]:not([onclick*="confirmRemoveCategory"]):hover,
        #categoriesTable td button[onclick*="openEditCategoryModal"]:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45) !important;
            color: #000000 !important;
        }

        #categoriesTable td button[onclick*="edit"]:not([onclick*="confirmRemoveCategory"]):hover *,
        #categoriesTable td button[onclick*="Edit"]:not([onclick*="confirmRemoveCategory"]):hover *,
        #categoriesTable td button[onclick*="openEditCategoryModal"]:hover * {
            color: #000000 !important;
        }

        #categoriesTable td button[onclick*="confirmRemoveCategory"] {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
            color: #fff;
        }

        #categoriesTable td button[onclick*="confirmRemoveCategory"]:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
        }

        /* Add Category Form */
        .add-category-section {
            margin-bottom: 30px;
            max-width: 600px; /* Reduced from 800px */
        }

        .add-category-section h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .add-category-form {
            background-color: white;
            padding: 15px; /* Reduced from 20px */
            border-radius: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            gap: 15px; /* Reduced from 20px */
            align-items: flex-end;
            flex-wrap: wrap;
        }

        .add-category-form .input-group {
            flex: 1;
            min-width: 200px; /* Reduced from 250px */
        }

        .add-category-form label {
            display: block;
            margin-bottom: 8px;
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
            white-space: nowrap;
        }

        .add-category-form input[type="text"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 0;
            border: 1px solid #ddd;
            border-radius: 15px;
            font-size: 16px;
            box-sizing: border-box;
        }

        .add-category-form button {
            background-color: #333;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 15px;
            cursor: pointer;
            font-size: 16px;
            width: 120px;
            height: 38px;
            margin: 0;
            white-space: nowrap;
            flex-shrink: 0;
        }

        .add-category-form button:hover {
            background-color: #555;
        }

        /* Inline Add Category Form */
        .add-category-form-container {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            border: 1px solid #e2e8f0;
        }

        .add-category-form-inline {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .form-input-group {
            flex: 1;
            min-width: 250px;
        }

        .form-input-group .input-with-icon input {
            width: 100%;
            padding: 12px 16px 12px 40px;
            border: 2px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: all 0.2s ease;
        }

        .form-input-group .input-with-icon input:focus {
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
            outline: none;
        }

        .form-actions-inline {
            display: flex;
            gap: 8px;
        }

        .btn-add-inline,
        .btn-cancel-inline {
            padding: 12px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .btn-add-inline {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.3);
        }

        .btn-add-inline:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 16px rgba(250, 206, 11, 0.4);
        }

        .btn-cancel-inline {
            background: #f1f5f9;
            color: #475569;
            border: 1px solid #e2e8f0;
        }

        .btn-cancel-inline:hover {
            background: #e2e8f0;
            color: #334155;
        }

        /* Inline Edit Form */
        .inline-edit-form {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }

        .inline-edit-input {
            flex: 1;
            min-width: 200px;
        }

        .inline-edit-input input {
            padding: 8px 12px;
            border: 2px solid #face0b;
            border-radius: 8px;
            font-size: 15px;
            width: 100%;
            transition: all 0.2s ease;
        }

        .inline-edit-input input:focus {
            outline: none;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .inline-edit-actions {
            display: flex;
            gap: 6px;
        }

        .btn-save-inline {
            padding: 8px 16px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            cursor: pointer;
            background: linear-gradient(135deg, #22c55e, #16a34a);
            color: white;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            transition: all 0.2s ease;
        }

        .btn-save-inline:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.3);
        }

        .edit-category-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .edit-category-form .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .edit-category-form label {
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
        }

        .edit-category-form input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 15px;
            font-size: 14px;
        }

        .edit-category-form button[type="submit"] {
            background-color: #333;
            color: white;
            padding: 12px 0;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 14px;
            width: 150px;
            margin: 20px auto 0;
            transition: background-color 0.3s ease;
        }

        .edit-category-form button[type="submit"]:hover {
            background-color: #555;
        }


        /* Sort button styles */
        .sort-btn {
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px 8px;
            color: #ffffff;
            border-radius: 0;
            transition: color 0.2s ease;
            box-shadow: none;
        }

        .sort-btn:hover {
            background: none;
            color: #ffffff;
            transform: none;
            box-shadow: none;
        }

        .sort-btn.active {
            background: none;
            color: #ffffff;
            box-shadow: none;
        }

        th {
            position: relative;
            padding-right: 25px;
        }

        .column-header {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Responsive styles */
        @media screen and (max-width: 768px) {
            main {
                margin-left: 0;
                width: 100%;
            }

            
            nav.sidebar {
                display: none;
            }

            .add-category-form {
                max-width: 100%;
            }

            .modal-content {
                width: 95%;
                margin: 10% auto;
            }

            .table-container {
                max-height: calc(100vh - 200px);
                overflow-x: auto;
                overflow-y: auto;
                -webkit-overflow-scrolling: touch;
            }

            #categoriesTable {
                min-width: 500px;
            }

            #categoriesTable th,
            #categoriesTable td {
                padding: 12px 10px;
                font-size: 13px;
            }

            #categoriesTable th {
                font-size: 12px;
                padding: 10px 8px;
            }
        }

        /* Add these button styles before the @media query */
        button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            border: none;
            border-radius: 15px;
            transition: background-color 0.3s ease;
        }

        /* Style for Add Category button */
        .add-category-form button[name="add_category"] {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            padding: 10px 20px;
            margin-top: 10px;
            height: 40px;
            min-width: 140px;
            justify-content: center;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        .add-category-form button[name="add_category"]:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        /* Style for table action buttons */
        td button {
            padding: 6px 12px;
            margin: 0 3px;
            min-width: 85px;
            justify-content: center;
        }

        td button:first-child {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        td button:last-child {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            color: #fff;
            box-shadow: 0 8px 18px rgba(239, 68, 68, 0.35);
        }

        td button:first-child:hover {
            background: linear-gradient(135deg, #face0b, #f7b300);
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
            color: #000;
        }

        td button:last-child:hover {
            background: linear-gradient(135deg, #ef4444, #b91c1c);
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(239, 68, 68, 0.45);
            color: #fff;
        }

        /* Style for Update Category button in modal */
        .edit-category-form button[name="edit_category"] {
            background-color: #333;
            color: #fff;
            padding: 12px 24px;
            min-width: 160px !important;
            margin: 20px auto 0;
            justify-content: center;
            height: 45px;
            box-shadow: 0 8px 18px rgba(15, 23, 42, 0.18);
        }

        .edit-category-form button[name="edit_category"]:hover {
            background-color: #444;
        }

        /* Override any conflicting styles */
        .add-category-form {
            background-color: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }

        .add-category-form .input-group {
            flex: 1;
            min-width: 250px;
        }

        .edit-category-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
            padding: 20px;
        }

        .edit-category-form .form-group {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 10px;
        }

        /* Ensure proper spacing for form inputs */
        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 15px;
            font-size: 14px;
            margin-bottom: 0;
        }

        /* Remove any conflicting width constraints */
        .edit-category-form input[type="text"] {
            width: 100%;
            box-sizing: border-box;
        }

        /* Input with icon styling */
        .input-with-icon {
            position: relative;
            width: 100%;
        }

        .input-with-icon i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
            z-index: 1;
            pointer-events: none;
        }

        .input-with-icon input {
            padding-left: 40px;
            width: 100%;
            box-sizing: border-box;
        }


        /* Button icon spacing */
        button i {
            margin-right: 8px;
        }

        /* Redesigned header bar - Modern Integrated Design */
        .products-header {
            background: white;
            padding: 20px 28px;
            border-radius: 18px;
            margin: 0 0 24px 0;
            color: #333;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            border: 1px solid rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .products-header-main {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
        }

        @media screen and (max-width: 768px) {
            .products-header {
                padding: 16px 20px;
            }

            .products-header-main {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
            }

            .header-title {
                justify-content: center;
            }

            .header-actions {
                flex-direction: column;
                width: 100%;
            }

            .search-container {
                width: 100%;
            }

            .search-container .input-with-icon {
                width: 100%;
            }

            #addCategoryButton {
                width: 100%;
                justify-content: center;
            }
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header-title-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            background: rgba(250, 206, 11, 0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: #face0b;
        }

        .header-title h2 {
            margin: 0;
            font-size: 24px;
            font-weight: 700;
            color: #1e293b;
            letter-spacing: -0.5px;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
        }

        .search-container {
            position: relative;
        }

        .search-container .input-with-icon {
            width: 300px;
        }

        .search-container .input-with-icon input {
            padding: 10px 14px 10px 40px;
            border: 1px solid #e2e8f0;
            border-radius: 15px;
            font-size: 14px;
            transition: border 0.2s ease, box-shadow 0.2s ease;
            background: white;
        }

        .search-container .input-with-icon input:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.2);
        }

        .search-container .input-with-icon i {
            display: block !important;
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
            pointer-events: none;
            z-index: 1;
        }

        .header-metrics {
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: wrap;
        }

        .metric-card {
            display: none;
        }

        .products-toolbar {
            background: transparent;
            padding: 0;
            margin: 0;
            box-shadow: none;
        }


        .ghost-btn {
            border-radius: 999px;
            border: 1px solid rgba(0, 0, 0, 0.2);
            background: white;
            color: #333;
            padding: 8px 16px;
            font-weight: 600;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .ghost-btn:hover {
            border-color: #face0b;
            color: #face0b;
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(250, 206, 11, 0.2);
        }

        #addCategoryButton {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            padding: 8px 16px;
            border: none;
            border-radius: 999px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
            height: 36px;
            line-height: 1.5;
            white-space: nowrap;
        }

        #addCategoryButton:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        .message-box {
            margin-bottom: 20px;
            border-radius: 12px;
            padding: 12px 16px;
            font-weight: 600;
        }

        .message-box.success {
            background: rgba(34, 197, 94, 0.15);
            color: #15803d;
            border: 1px solid rgba(34, 197, 94, 0.35);
        }

        .message-box.error {
            background: rgba(239, 68, 68, 0.15);
            color: #b91c1c;
            border: 1px solid rgba(239, 68, 68, 0.35);
        }

        .table-container {
            max-height: calc(100vh - 260px);
            overflow-y: auto;
            padding-right: 8px;
            position: relative;
            margin-top: 20px;
            border-radius: 12px;
        }

        .table-container::-webkit-scrollbar {
            width: 8px;
        }

        .table-container::-webkit-scrollbar-track {
            background: rgba(15, 23, 42, 0.05);
            border-radius: 15px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: rgba(15, 23, 42, 0.25);
            border-radius: 15px;
        }

        .table-container::-webkit-scrollbar-thumb:hover {
            background: rgba(15, 23, 42, 0.4);
        }

        #categoriesTable {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            margin-top: 0;
            background: transparent;
        }

        #categoriesTable thead tr {
            background: transparent;
        }

        #categoriesTable th {
            background-color: #333;
            color: #ffffff;
            padding: 16px 20px;
            text-align: left;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border: none;
        }

        #categoriesTable tbody tr {
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            margin-bottom: 12px;
        }

        #categoriesTable tbody tr:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
        }

        #categoriesTable td {
            padding: 18px 20px;
            font-size: 15px;
            color: #1e293b;
            border: none;
        }

        .sort-btn {
            background: none;
            border: none;
            color: #ffffff;
            padding: 4px 8px;
            border-radius: 0;
            cursor: pointer;
            margin-left: 8px;
            transition: color 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            box-shadow: none;
        }

        .sort-btn:hover {
            background: none;
            color: #ffffff;
            transform: none;
            box-shadow: none;
        }

        .sort-btn.active {
            background: none;
            color: #ffffff;
            box-shadow: none;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
            transition: opacity 0.3s ease;
            opacity: 0;
            pointer-events: none;
        }
        .modal.show {
            display: flex;
            opacity: 1;
            pointer-events: auto;
            animation: modalFadeIn 0.3s;
        }

        @keyframes modalFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: #ffffff;
            margin: auto;
            padding: 0;
            border: none;
            width: 50%;
            max-width: 600px;
            max-height: 90vh;
            overflow: hidden;
            border-radius: 15px;
            position: relative;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.3);
            animation: slideIn 0.3s cubic-bezier(.4,0,.2,1);
            background: #f5f5f5;
        }

        @keyframes slideIn {
            0% {
                opacity: 0;
                transform: translateY(-50px);
            }
            100% {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .modal-header {
            background: #333;
            color: #fff;
            padding: 28px 32px;
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .modal-header .modal-icon {
            width: 54px;
            height: 54px;
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.14);
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 26px;
            color: #fff;
        }

        .modal-header p {
            margin: 4px 0 0;
            color: rgba(255, 255, 255, 0.88);
            font-size: 14px;
            line-height: 1.5;
        }

        .modal-body {
            padding: 30px;
            display: flex;
            flex-direction: column;
            gap: 24px;
            max-height: calc(90vh - 160px);
            overflow-y: auto;
        }

        .modal-body::-webkit-scrollbar {
            width: 8px;
        }

        .modal-body::-webkit-scrollbar-track {
            background: rgba(0, 0, 0, 0.05);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb {
            background: rgba(51, 51, 51, 0.3);
            border-radius: 10px;
        }

        .modal-body::-webkit-scrollbar-thumb:hover {
            background: rgba(51, 51, 51, 0.5);
        }

        .close {
            color: #fff;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 12px;
            right: 18px;
            cursor: pointer;
            transition: color 0.3s;
            z-index: 10;
        }
        .close:hover,
        .close:focus {
            color: rgba(255, 255, 255, 0.7);
        }

        .section-card {
            background: #fff;
            border-radius: 18px;
            padding: 20px 22px 24px;
            border: 1px solid rgba(15, 23, 42, 0.08);
            box-shadow: 0 16px 30px rgba(15, 23, 42, 0.08);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 18px;
        }

        .section-header .section-icon {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: rgba(250, 206, 11, 0.2);
            color: #b58500;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }

        .section-header h3 {
            margin: 0;
            font-size: 18px;
            color: #0f172a;
        }

        .form-group {
            margin-bottom: 0;
        }

        .form-group label {
            font-size: 13px;
            letter-spacing: 0.3px;
            color: #1e293b;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 10px;
            display: block;
        }

        .form-group label i {
            font-size: 14px;
            color: #64748b;
            margin-right: 8px;
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            display: none;
        }

        /* Show icon only for search container */
        .search-container .input-with-icon i {
            display: block;
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
            pointer-events: none;
            z-index: 1;
        }

        .input-with-icon input {
            width: 100%;
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            padding: 14px 16px;
            transition: all 0.3s ease;
            background: white;
            color: #1e293b;
            font-size: 15px;
            box-sizing: border-box;
        }

        /* Add padding for search input to accommodate icon */
        .search-container .input-with-icon input {
            padding-left: 40px;
        }

        .input-with-icon input:focus {
            border-color: #face0b;
            box-shadow: 0 0 0 4px rgba(250, 206, 11, 0.15);
            outline: none;
        }

        .form-group small.form-hint {
            color: #64748b;
            font-size: 12px;
            margin-top: 6px;
            display: block;
            line-height: 1.5;
        }

        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 10px;
        }

        .modal-actions .btn-secondary,
        .modal-actions .btn-primary {
            padding: 8px 16px;
            border-radius: 999px;
            font-weight: 600;
            font-size: 13px;
            border: none;
            cursor: pointer;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .modal-actions .btn-secondary {
            background: #333;
            color: #fff;
            box-shadow: 0 8px 18px rgba(15, 23, 42, 0.18);
        }

        .modal-actions .btn-secondary:hover {
            background: #444;
            transform: translateY(-1px);
        }

        .modal-actions .btn-primary {
            background: linear-gradient(135deg, #face0b, #f7b300);
            color: #000;
            box-shadow: 0 8px 18px rgba(250, 206, 11, 0.35);
        }

        .modal-actions .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 12px 22px rgba(250, 206, 11, 0.45);
        }

        body.no-scroll {
            overflow: hidden !important;
        }

    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar">
        <?php
        // Function to check if a page is active
        function isActive($page, $current) {
            return ($page === $current) ? 'active' : '';
        }
        $currentPage = basename($_SERVER['PHP_SELF']);
        ?>
        
        <!-- Logo -->
        <div class="sidebar-logo" onclick="toggleSidebar()">
            <img src="../images/logo.png" alt="EDGIE'S POS Logo">
            <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
        </div>

        <!-- Navigation Items Container (Scrollable) -->
        <div class="sidebar-nav-items">
            <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            <a href="manage_product.php" class="<?php echo isActive('manage_product.php', $currentPage); ?>">
                <i class="fas fa-box"></i>
                <span>Manage Product</span>
            </a>
            <a href="category.php" class="<?php echo isActive('category.php', $currentPage); ?>">
                <i class="fas fa-list-alt"></i>
                <span>Category</span>
            </a>
            <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
                <i class="fas fa-receipt"></i>
                <span>Transaction<br>History</span>
            </a>
            <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
                <i class="fas fa-users-cog"></i>
                <span>User<br>Management</span>
            </a>
            <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
                <i class="fas fa-history"></i>
                <span>Log History</span>
            </a>
            <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
                <i class="fas fa-recycle"></i>
                <span>Backup &amp; Restore</span>
            </a>
            <a href="account_settings.php" class="<?php echo isActive('account_settings.php', $currentPage); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Account Settings</span>
            </a>
            <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('../authentication/logout.php', $currentPage); ?>">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>

        <!-- Cashier Info at Bottom -->
        <div class="sidebar-footer">
            <div class="cashier-name">
                <i class="fas fa-user"></i>
                <span><?php echo htmlspecialchars($userFullName); ?></span>
            </div>
            <div class="sidebar-datetime">
                <div id="sidebar-date"></div>
                <div id="sidebar-time"></div>
            </div>
        </div>
    </nav>
<main>
    <div class="products-header">
        <div class="products-header-main">
            <div class="header-title">
                <div class="header-title-icon">
                    <i class="fas fa-list-alt"></i>
                </div>
                <h2>Category Management</h2>
            </div>
            <div class="header-actions">
                <div class="search-container">
                    <div class="input-with-icon">
                        <i class="fas fa-search"></i>
                        <input type="text" id="searchInput" placeholder="Search categories..." onkeyup="filterCategories()">
                    </div>
                </div>
                <button type="button" id="addCategoryButton" onclick="openAddCategoryModal()">
                    <i class="fas fa-plus"></i> New Category
                </button>
            </div>
        </div>
    </div>

    <!-- Add Category Modal -->
    <div id="addCategoryModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddCategoryModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-plus"></i>
                </div>
                <div>
                    <h2>Add New Category</h2>
                    <p>Create a new product category for organizing items</p>
                </div>
            </div>
            <form method="POST" action="" id="addCategoryForm" class="modal-body">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-tag"></i>
                        </div>
                        <div>
                            <h3>Category Information</h3>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="add_category_name">
                            <i class="fas fa-tag"></i> Category Name <span style="color: #ef4444;">*</span>
                        </label>
                        <div class="input-with-icon">
                            <input type="text" id="add_category_name" name="category_name" required placeholder="Enter category name" pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,50}$" title="2–50 characters, letters, numbers, spaces, basic punctuation">
                        </div>
                        <small class="form-hint">Enter a unique category name (e.g., Beverages, Food, Desserts)</small>
                </div>
                <div class="modal-actions">
                    <button type="submit" name="add_category" class="btn-primary">
                        <i class="fas fa-check"></i> Add Category
                    </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div id="editCategoryModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditCategoryModal()">&times;</span>
            <div class="modal-header">
                <div class="modal-icon">
                    <i class="fas fa-edit"></i>
                </div>
                <div>
                    <h2>Edit Category</h2>
                    <p>Update the category name</p>
                </div>
            </div>
            <form method="POST" action="" id="editCategoryForm" class="modal-body">
                <input type="hidden" id="edit_category_id" name="category_id">
                <div class="section-card">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-tag"></i>
                        </div>
                        <div>
                            <h3>Category Information</h3>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="edit_category_name">
                            <i class="fas fa-tag"></i> Category Name <span style="color: #ef4444;">*</span>
                        </label>
                        <div class="input-with-icon">
                            <input type="text" id="edit_category_name" name="category_name" required placeholder="Enter category name" pattern="^[A-Za-z0-9À-ž\s.'\-\/()&,]{2,50}$" title="2–50 characters, letters, numbers, spaces, basic punctuation">
                        </div>
                        <small class="form-hint">Enter a unique category name (e.g., Beverages, Food, Desserts)</small>
                </div>
                <div class="modal-actions">
                    <button type="submit" name="edit_category" class="btn-primary">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="table-container">
        <table id="categoriesTable">
            <thead>
                <tr>
                    <th>
                        <div class="column-header">
                            Category Name
                            <button onclick="sortTable('CategoryName')" class="sort-btn">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                    <th>
                        <div class="column-header">
                            Date Created
                            <button onclick="sortTable('date_created')" class="sort-btn">
                                <i class="fas fa-sort"></i>
                            </button>
                        </div>
                    </th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="categoriesTableBody">
                <?php while ($row = $categoryResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['CategoryName']); ?></td>
                        <td><?php echo htmlspecialchars($row['formatted_date']); ?></td>
                        <td>
                            <button onclick="openEditCategoryModal(<?php echo $row['CategoryID']; ?>, '<?php echo htmlspecialchars($row['CategoryName'], ENT_QUOTES); ?>')"><i class="fas fa-edit"></i> Edit</button>
                            <button onclick="confirmRemoveCategory(<?php echo $row['CategoryID']; ?>, '<?php echo htmlspecialchars($row['CategoryName']); ?>')"><i class="fas fa-trash-alt"></i> Remove</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</main>
<script>
    function openAddCategoryModal() {
        const modal = document.getElementById('addCategoryModal');
        if (modal) {
            modal.style.display = 'flex';
        modal.classList.add('show');
            document.body.classList.add('no-scroll');
            setTimeout(() => {
                document.getElementById('add_category_name').focus();
            }, 100);
        }
    }

    function closeAddCategoryModal() {
        const modal = document.getElementById('addCategoryModal');
        if (modal) {
            modal.style.display = 'none';
        modal.classList.remove('show');
            document.body.classList.remove('no-scroll');
            document.getElementById('addCategoryForm').reset();
        }
    }

    function openEditCategoryModal(categoryId, categoryName) {
        const modal = document.getElementById('editCategoryModal');
        if (modal) {
            document.getElementById('edit_category_id').value = categoryId;
            document.getElementById('edit_category_name').value = categoryName;
            modal.style.display = 'flex';
            modal.classList.add('show');
            document.body.classList.add('no-scroll');
            setTimeout(() => {
                document.getElementById('edit_category_name').focus();
                document.getElementById('edit_category_name').select();
            }, 100);
        }
    }

    function closeEditCategoryModal() {
        const modal = document.getElementById('editCategoryModal');
        if (modal) {
            modal.style.display = 'none';
            modal.classList.remove('show');
            document.body.classList.remove('no-scroll');
            document.getElementById('editCategoryForm').reset();
        }
    }

    // Close modal when clicking outside of it
    window.addEventListener('click', function(event) {
        const addModal = document.getElementById('addCategoryModal');
        const editModal = document.getElementById('editCategoryModal');
        if (event.target == addModal) {
            closeAddCategoryModal();
        }
        if (event.target == editModal) {
            closeEditCategoryModal();
        }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            const addModal = document.getElementById('addCategoryModal');
            const editModal = document.getElementById('editCategoryModal');
            if (addModal && addModal.classList.contains('show')) {
            closeAddCategoryModal();
        }
            if (editModal && editModal.classList.contains('show')) {
                closeEditCategoryModal();
    }
        }
    });


    <?php if (isset($message)): ?>
        Swal.fire({
            title: '<?php echo $messageType === "success" ? "Success!" : "Error!"; ?>',
            text: '<?php echo $message; ?>',
            icon: '<?php echo $messageType === "success" ? "success" : "error"; ?>',
            confirmButtonColor: '<?php echo $messageType === "success" ? "#face0b" : "#ef4444"; ?>',
            confirmButtonText: 'OK'
        }).then(() => {
            <?php if ($messageType === "success"): ?>
                closeAddCategoryModal();
                closeEditCategoryModal();
                // Reload page to show updated category
                setTimeout(() => {
                    window.location.reload();
                }, 300);
            <?php endif; ?>
        });
    <?php endif; ?>

    function confirmRemoveCategory(categoryId, categoryName) {
        Swal.fire({
            title: 'Remove category?',
            text: `Do you want to remove the category "${categoryName}"? Removed categories can be restored from Backup & Recovery.`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, remove it'
        }).then((result) => {
            if (result.isConfirmed) {
                // Create and submit the form
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';

                const categoryIdInput = document.createElement('input');
                categoryIdInput.type = 'hidden';
                categoryIdInput.name = 'category_id';
                categoryIdInput.value = categoryId;

                const removeCategoryInput = document.createElement('input');
                removeCategoryInput.type = 'hidden';
                removeCategoryInput.name = 'remove_category';
                removeCategoryInput.value = '1';

                form.appendChild(categoryIdInput);
                form.appendChild(removeCategoryInput);
                document.body.appendChild(form);
                form.submit();
            }
        });
    }

    function toggleSidebar() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('sidebar-expanded');
            // Save state to localStorage
            const isExpanded = sidebar.classList.contains('sidebar-expanded');
            localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
        }
    }
    
    // Restore sidebar state on page load (without transition)
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            // Disable transitions during state restoration
            sidebar.classList.add('no-transition');
            
            const savedState = localStorage.getItem('sidebarExpanded');
            if (savedState === 'true') {
                sidebar.classList.add('sidebar-expanded');
            } else {
                // Default to collapsed (no saved state or explicitly false)
                sidebar.classList.remove('sidebar-expanded');
            }
            
            // Re-enable transitions after a short delay
            setTimeout(function() {
                sidebar.classList.remove('no-transition');
            }, 50);
        }
    });

    function confirmLogout(event) {
        event.preventDefault();
        Swal.fire({
            title: 'Logout Confirmation',
            text: 'Are you sure you want to logout?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, logout',
            cancelButtonText: 'No, stay'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../authentication/logout.php';
            }
        });
    }

    let currentSort = {
        column: 'date_created',
        order: 'DESC'
    };

    function updateSortIcon(column) {
        // Remove active class from all sort buttons
        document.querySelectorAll('.sort-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Add active class to current sort button
        const currentBtn = document.querySelector(`button[onclick="sortTable('${column}')"]`);
        if (currentBtn) {
            currentBtn.classList.add('active');
            const icon = currentBtn.querySelector('i');
            icon.className = currentSort.order === 'ASC' ? 'fas fa-sort-up' : 'fas fa-sort-down';
        }
    }

    function sortTable(column) {
        if (currentSort.column === column) {
            // Toggle sort order if clicking the same column
            currentSort.order = currentSort.order === 'ASC' ? 'DESC' : 'ASC';
        } else {
            // Set new column and default to ascending
            currentSort.column = column;
            currentSort.order = 'ASC';
        }
        
        updateSortIcon(column);
        
        // Redirect with new sort parameters
        window.location.href = `category.php?sort=${column}&sort_order=${currentSort.order}`;
    }

    // Initialize sort icons on page load
    document.addEventListener('DOMContentLoaded', function() {
        const urlParams = new URLSearchParams(window.location.search);
        const sortColumn = urlParams.get('sort') || 'date_created';
        const sortOrder = urlParams.get('sort_order') || 'DESC';
        
        currentSort.column = sortColumn;
        currentSort.order = sortOrder;
        
        updateSortIcon(sortColumn);
    });



    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        
        // Format date: Day, Month DD, YYYY
        const dateOptions = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' };
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        
        // Format time: HH:MM:SS AM/PM
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }

    // Update immediately and then every second
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);

    // Search functionality
    function filterCategories() {
        const searchInput = document.getElementById('searchInput');
        const filter = searchInput.value.toLowerCase();
        const table = document.getElementById('categoriesTable');
        const tbody = table.getElementsByTagName('tbody')[0];
        const rows = tbody.getElementsByTagName('tr');

        // Loop through all table rows
        for (let i = 0; i < rows.length; i++) {
            const categoryNameCell = rows[i].getElementsByTagName('td')[0];
            const dateCreatedCell = rows[i].getElementsByTagName('td')[1];
            
            if (categoryNameCell || dateCreatedCell) {
                const categoryName = categoryNameCell ? categoryNameCell.textContent || categoryNameCell.innerText : '';
                const dateCreated = dateCreatedCell ? dateCreatedCell.textContent || dateCreatedCell.innerText : '';
                
                // Check if the search term matches category name or date
                if (categoryName.toLowerCase().indexOf(filter) > -1 || dateCreated.toLowerCase().indexOf(filter) > -1) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }
        }
    }
</script>
<script src="js/prevent_back_button.js"></script>
<?php include __DIR__ . '/../includes/admin_auto_backup_trigger.php'; ?>
</body>
</html>
