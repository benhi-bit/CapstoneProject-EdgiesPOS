// Modal functionality for User Management
document.addEventListener('DOMContentLoaded', function() {
    // Get modal elements
    const userModal = document.getElementById('userModal');
    const editUserModal = document.getElementById('editUserModal');
    const addUserBtn = document.getElementById('addUserBtn');
    const closeBtn = document.querySelector('.close');
    const closeEditBtn = document.querySelector('.closeEdit');
    
    // Add User Modal - Open
    if (addUserBtn) {
        addUserBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (userModal) {
                userModal.style.display = 'flex';
                setTimeout(() => {
                    userModal.classList.add('show');
                }, 10);
            }
        });
    }
    
    // Add User Modal - Close
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            closeModal(userModal);
        });
    }
    
    // Edit User Modal - Close
    if (closeEditBtn) {
        closeEditBtn.addEventListener('click', function() {
            closeModal(editUserModal);
        });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === userModal) {
            closeModal(userModal);
        }
        if (event.target === editUserModal) {
            closeModal(editUserModal);
        }
    });
    
    // Function to close modal
    function closeModal(modal) {
        if (modal) {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.style.display = 'none';
            }, 300);
        }
    }
    
    // Edit User Button - Open Edit Modal
    const editBtns = document.querySelectorAll('.editBtn');
    editBtns.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Get data attributes
            const userId = this.getAttribute('data-id');
            const role = this.getAttribute('data-role');
            const fullname = this.getAttribute('data-fullname');
            const username = this.getAttribute('data-username');
            const email = this.getAttribute('data-email');
            
            // Populate form fields
            document.getElementById('editUserID').value = userId;
            const roleSelect = document.getElementById('editRole');
            if (roleSelect) {
                roleSelect.value = role;
            }
            document.getElementById('editFullName').value = fullname;
            document.getElementById('editUsername').value = username;
            document.getElementById('editEmail').value = email;
            
            // Open modal
            if (editUserModal) {
                editUserModal.style.display = 'flex';
                setTimeout(() => {
                    editUserModal.classList.add('show');
                }, 10);
            }
        });
    });
    
    // Remove User Button - Confirm removal
    const removeBtns = document.querySelectorAll('.removeBtn');
    removeBtns.forEach(function(btn) {
        btn.addEventListener('click', async function(e) {
            e.preventDefault();
            const userId = this.getAttribute('data-id');
            
            const result = await Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#333',
                confirmButtonText: 'Yes, remove user!',
                cancelButtonText: 'Cancel'
            });
            
            if (result.isConfirmed) {
                try {
                    // Show loading
                    Swal.fire({
                        title: 'Removing...',
                        text: 'Please wait',
                        icon: 'info',
                        allowOutsideClick: false,
                        allowEscapeKey: false,
                        showConfirmButton: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                    
                    // Make AJAX request to remove_user.php
                    const response = await fetch(`remove_user.php?id=${userId}`, {
                        method: 'GET',
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Show success message immediately
                        Swal.fire({
                            icon: 'success',
                            title: 'User Removed',
                            text: 'Account removed successfully!',
                            confirmButtonColor: '#face0b'
                        }).then(() => {
                            // Reload the page to refresh the user list
                            window.location.href = 'user_management.php';
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Unable to Remove User',
                            text: data.message || 'An error occurred while removing the user.',
                            confirmButtonColor: '#d33'
                        });
                    }
                } catch (err) {
                    console.error('Error removing user:', err);
                    Swal.fire({
                        icon: 'error',
                        title: 'Request Failed',
                        text: 'Unable to remove user right now. Please try again.',
                        confirmButtonColor: '#d33'
                    });
                }
            }
        });
    });
    
    // Form validation and submission
    const addUserForm = document.getElementById('addUserForm');
    if (addUserForm) {
        addUserForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const submitBtn = document.getElementById('submitBtn');
            const originalText = submitBtn ? submitBtn.innerHTML : '';

            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating...';
            }

            try {
                const formData = new FormData(addUserForm);
                const response = await fetch('add_user.php', {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                });

                const data = await response.json();

                if (data.success) {
                    // Close modal first
                    const userModal = document.getElementById('userModal');
                    if (userModal) {
                        userModal.classList.remove('show');
                        setTimeout(() => {
                            userModal.style.display = 'none';
                        }, 300);
                    }
                    
                    // Show SweetAlert after modal starts closing
                    setTimeout(() => {
                        Swal.fire({
                            icon: 'success',
                            title: 'User Added',
                            text: data.message || 'User added successfully!',
                            confirmButtonColor: '#face0b'
                        }).then(() => {
                            // Reload without query params to avoid duplicate SweetAlerts
                            window.location.href = 'user_management.php';
                        });
                    }, 300);
                } else {
                    // Close modal first
                    const userModal = document.getElementById('userModal');
                    if (userModal) {
                        userModal.classList.remove('show');
                        setTimeout(() => {
                            userModal.style.display = 'none';
                        }, 300);
                    }
                    
                    // Show error SweetAlert after modal starts closing
                    setTimeout(() => {
                        Swal.fire({
                            icon: 'error',
                            title: 'Unable to Add User',
                            text: data.message || 'An error occurred while adding the user.',
                            confirmButtonColor: '#d33'
                        });
                    }, 300);
                }
            } catch (err) {
                // Close modal first
                const userModal = document.getElementById('userModal');
                if (userModal) {
                    userModal.classList.remove('show');
                    setTimeout(() => {
                        userModal.style.display = 'none';
                    }, 300);
                }
                
                // Show error SweetAlert after modal starts closing
                setTimeout(() => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Request Failed',
                        text: 'Unable to add user right now. Please try again.',
                        confirmButtonColor: '#d33'
                    });
                }, 300);
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText || '<i class="fas fa-user-plus"></i> Create User';
                }
            }
        });
    }
    
    // Handle edit user form submission
    const editUserForm = document.getElementById('editUserForm');
    const editSubmitBtn = document.getElementById('editSubmitBtn');
    
    // Function to handle form submission
    async function handleEditUserSubmit(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        const form = document.getElementById('editUserForm');
        if (!form) {
            console.error('Edit user form not found');
            return false;
        }
        
        const submitBtn = document.getElementById('editSubmitBtn');
        const originalText = submitBtn ? submitBtn.innerHTML : '';

        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        }

        try {
            // Validate form first
            if (!form.checkValidity()) {
                form.reportValidity();
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText || '<i class="fas fa-save"></i> Save Changes';
                }
                return false;
            }

            const formData = new FormData(form);
            const response = await fetch('edit_user.php', {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: formData
            });

            // Check if response is ok
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            // Get response text first to handle both JSON and non-JSON
            const responseText = await response.text();
            let data;
            
            try {
                data = JSON.parse(responseText);
            } catch (parseError) {
                console.error('Failed to parse JSON:', responseText);
                throw new Error('Invalid response from server');
            }

            if (data.success) {
                // Close modal before showing success message
                const editUserModal = document.getElementById('editUserModal');
                if (editUserModal) {
                    editUserModal.classList.remove('show');
                    setTimeout(() => {
                        editUserModal.style.display = 'none';
                    }, 300);
                }

                Swal.fire({
                    icon: 'success',
                    title: 'User Updated',
                    text: data.message || 'User updated successfully!',
                    confirmButtonColor: '#face0b'
                }).then(() => {
                    // Reload the page to refresh the user list
                    window.location.href = 'user_management.php';
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Unable to Update User',
                    text: data.message || 'An error occurred while updating the user.',
                    confirmButtonColor: '#d33'
                });
                
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText || '<i class="fas fa-save"></i> Save Changes';
                }
            }
        } catch (err) {
            console.error('Error updating user:', err);
            Swal.fire({
                icon: 'error',
                title: 'Request Failed',
                text: 'Unable to update user right now. Please try again.',
                confirmButtonColor: '#d33'
            });
            
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText || '<i class="fas fa-save"></i> Save Changes';
            }
        }
        
        return false;
    }
    
    // Attach event listeners
    if (editUserForm) {
        // Remove any existing action to prevent normal form submission
        editUserForm.removeAttribute('action');
        editUserForm.addEventListener('submit', handleEditUserSubmit);
    }
    
    // Also attach to button click as backup
    if (editSubmitBtn) {
        editSubmitBtn.addEventListener('click', function(e) {
            e.preventDefault();
            handleEditUserSubmit(e);
        });
    }
    
    // Show success/error messages if present
    const urlParams = new URLSearchParams(window.location.search);
    const successMsg = urlParams.get('success');
    const errorMsg = urlParams.get('error');
    
    if (successMsg) {
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: successMsg,
            timer: 3000,
            showConfirmButton: false
        });
    }
    
    if (errorMsg) {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: errorMsg,
            timer: 3000,
            showConfirmButton: false
        });
    }
});

// Toggle password visibility
function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const button = field.parentElement.querySelector('.toggle-password');
    const icon = button.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

