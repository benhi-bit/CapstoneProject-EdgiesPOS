// Prevent back button navigation after logout
(function() {
    if (window.history && window.history.pushState) {
        window.history.pushState('forward', null, '');
        
        window.addEventListener('popstate', function() {
            window.history.pushState('forward', null, '');
        });
    }
})();
