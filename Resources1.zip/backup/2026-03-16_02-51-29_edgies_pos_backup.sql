-- MySQL Database Backup
-- Generated: 2026-03-16 02:51:29
-- Database: edgies_pos
-- 

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Table structure for table `active_sessions`
--

DROP TABLE IF EXISTS `active_sessions`;
CREATE TABLE `active_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `last_activity` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `active_sessions`
--

INSERT INTO `active_sessions` (`id`, `user_id`, `session_id`, `last_activity`) VALUES
('2', '24', 'raaeemmes582rg37931utla6ao', '2025-11-16 16:58:26'),
('3', '24', 'raaeemmes582rg37931utla6ao', '2025-11-16 17:26:06'),
('10', '1', 'jr03hob2i3oe0ip29hopfthrap', '2025-11-16 18:51:01'),
('0', '24', 'p1qf89ahl6chdbosmi650siltg', '2025-11-17 11:05:43'),
('0', '1', 'l51gi8dij39vthot76v00lf8ah', '2025-11-17 13:52:15'),
('0', '1', '8953uvkn2adr00nt1gu9m0fcj2', '2025-11-18 10:04:28'),
('0', '1', '8953uvkn2adr00nt1gu9m0fcj2', '2025-11-18 10:34:08'),
('0', '1', 'qe2it8h7ghfofq37tlis4ugpq5', '2025-11-19 08:36:26'),
('0', '1', 'apr2kjft6c95l2s864cm6kmhtp', '2025-11-21 10:11:26'),
('0', '1', 'tr9r8d0eos3fjnhmcukba2olab', '2025-11-24 10:29:53'),
('0', '24', 'orh4k18tti6nqms6up36mef22f', '2025-11-24 10:31:16'),
('0', '24', 'j8qu11eb7hau3f7uu6jeq2mdnj', '2025-11-24 10:34:14'),
('0', '1', 'mcbnb7t9a1l7tiecs6omflu8hn', '2025-11-26 10:06:43'),
('0', '1', 'mcbnb7t9a1l7tiecs6omflu8hn', '2025-11-26 10:14:21'),
('0', '1', 'mcbnb7t9a1l7tiecs6omflu8hn', '2025-11-26 10:19:31'),
('0', '24', 'mcbnb7t9a1l7tiecs6omflu8hn', '2025-11-26 10:20:50'),
('0', '1', '8jvavi5cd6cdnl6gt71e5drkht', '2026-01-08 12:41:46'),
('0', '1', '8jvavi5cd6cdnl6gt71e5drkht', '2026-01-08 12:57:23'),
('0', '24', 'h6rm8vqigll71tamvcdcncojv8', '2026-01-12 12:41:47'),
('0', '24', 'bo84gv3q9kt9i01ohprfpk66nv', '2026-01-13 10:39:49'),
('0', '1', '9b4imdtnbgmnacjk3e2n5dr31m', '2026-01-13 11:04:13'),
('0', '1', 'i90ou7gmi56mkqcn7defre06n9', '2026-01-21 09:57:27'),
('0', '1', '879fcloc9ei03cbc4hqqgo9jh4', '2026-02-06 13:47:59'),
('0', '24', 'jlcln572dap8jejoqq71e3bqqp', '2026-02-06 14:26:59'),
('0', '24', 'jlcln572dap8jejoqq71e3bqqp', '2026-02-06 14:33:49'),
('0', '1', 'garlrminm8r59sti411fopljgq', '2026-02-16 12:11:57'),
('0', '24', 'hfr889nlu0gsdk7m9kn0bqpecb', '2026-02-16 13:11:36'),
('0', '0', 'garlrminm8r59sti411fopljgq', '2026-02-16 13:56:21'),
('0', '24', 'qi7ureqi6tl33om55u7retbeqt', '2026-02-18 11:08:20'),
('0', '1', '5bcemq88hgpgil6dtrlqfjsdbg', '2026-02-22 14:52:41'),
('0', '1', 'c1q4vf69fflahkjgengmkuncl0', '2026-02-22 23:47:49'),
('0', '24', '4nop4fhskgs0iqc64h9m8dl79q', '2026-02-23 19:48:30'),
('0', '1', 'cpu6oahlk2un2u7ocbd82gc3e5', '2026-03-11 11:59:39'),
('0', '24', '8d18678raribkg1g6l5sj8qu6c', '2026-03-11 12:03:15'),
('0', '1', 'iesfc38a6m8td33u2dpf2dm6rd', '2026-03-16 09:19:51');

--
-- Table structure for table `backup_settings`
--

DROP TABLE IF EXISTS `backup_settings`;
CREATE TABLE `backup_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_day` varchar(10) NOT NULL DEFAULT 'Monday',
  `schedule_time` time NOT NULL DEFAULT '10:00:00',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `backup_settings`
--

INSERT INTO `backup_settings` (`id`, `schedule_day`, `schedule_time`, `enabled`, `updated_at`, `updated_by`) VALUES
('1', 'Monday', '10:00:00', '1', '2026-01-13 11:40:00', 'Jc Roberto');

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `CategoryID` int(11) NOT NULL,
  `CategoryName` varchar(255) NOT NULL,
  `date_created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`CategoryID`, `CategoryName`, `date_created`) VALUES
('1', 'All-Day Meals', '2025-05-16 22:44:26'),
('2', 'Sharing Menu', '2025-05-16 22:44:26'),
('3', 'Sizzling Plates', '2025-05-16 22:44:26'),
('4', 'Chicken Wings', '2025-05-16 22:44:26'),
('13', 'Add-Ons', '2025-05-16 22:44:26'),
('14', 'Pulutan', '2025-05-16 22:44:26'),
('15', 'Pancit Menu', '2025-05-16 22:44:26'),
('16', 'Cocktails & Drinks', '2025-05-16 22:44:26');

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `InventoryID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `InventoryName` varchar(255) NOT NULL,
  `Price` float NOT NULL,
  `Quantity` int(11) NOT NULL,
  `ImagePath` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `is_available` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`InventoryID`, `CategoryID`, `InventoryName`, `Price`, `Quantity`, `ImagePath`, `date_created`, `is_available`) VALUES
('3', '1', 'Porksilog', '135', '36', 'images/1747140805_porksilog.jpg', '2025-05-16 22:56:35', '1'),
('4', '1', 'Chicksilog', '115', '105', 'images/1747140628_chicksilog.jpg', '2025-05-16 22:56:35', '1'),
('6', '1', 'Bangsilog', '115', '19', 'images/1747140655_bangsilog.jpg', '2025-05-16 22:56:35', '0'),
('29', '1', 'Tapsilog', '135', '0', 'images/1747122014_de997ea762484232ad6e5c4d9c256ef3.jpg', '2025-05-16 22:56:35', '1'),
('30', '1', 'Liemposilog', '115', '0', 'images/1747140714_liemposilog.jpg', '2025-05-16 22:56:35', '1'),
('31', '1', 'Adobo Mix Binalot', '125', '0', 'images/1747140761_binalot.jpg', '2025-05-16 22:56:35', '0'),
('32', '2', 'Beef or Crispy Pork Kare-Kare', '395', '0', 'images/1747140869_karekare.jpg', '2025-05-16 22:56:35', '1'),
('33', '2', 'Lechon Kawali', '325', '0', 'images/1747140947_lechon kawali.jpg', '2025-05-16 22:56:35', '1'),
('34', '2', 'Pork Binagoongan w/ Talong', '375', '0', 'images/1747141040_binagoongan.jpg', '2025-05-16 22:56:35', '1'),
('35', '2', 'Adobo Mix (Pork & Chicken)', '355', '0', 'images/1747152618_adobo mix.jpg', '2025-05-16 22:56:35', '1'),
('36', '2', 'Beef Bulalo', '395', '0', 'images/1747152662_bulalo.jpg', '2025-05-16 22:56:35', '1'),
('37', '2', 'Sinigang na Hipon', '395', '0', 'images/1747152711_sinigang na hipon.jpg', '2025-05-16 22:56:35', '1'),
('38', '2', 'Chopsuey', '175', '0', 'images/1747152980_chopsuey .jpg', '2025-05-16 22:56:35', '1'),
('39', '14', 'Sizzling Bagnet', '225', '0', 'images/1747153067_Sizzling bagnet yarn.jpg', '2025-05-16 22:56:35', '1'),
('40', '14', 'Sizzling Hotdog', '155', '0', 'images/1747153145_sizzling hotdog.jpg', '2025-05-16 22:56:35', '1'),
('41', '14', 'Sizzling Gambas', '395', '0', 'images/1747153203_sizzling gambas.jpg', '2025-05-16 22:56:35', '1'),
('42', '14', 'Sizzling Corn', '155', '0', 'images/1747153258_sizzling corn.jpg', '2025-05-16 22:56:35', '1'),
('43', '14', 'Fried Tofu', '125', '0', 'images/1747153296_FRIED TOFU.jpg', '2025-05-16 22:56:35', '1'),
('44', '14', 'Kropek', '105', '0', 'images/1747153325_kropek.jpg', '2025-05-16 22:56:35', '1'),
('45', '14', 'Chicharon', '105', '0', 'images/1747153418_chicharon.jpg', '2025-05-16 22:56:35', '1'),
('46', '14', 'Street Food Combo', '105', '0', 'images/1747153486_streetfood combo.jpg', '2025-05-16 22:56:35', '1'),
('47', '14', 'French Fries', '105', '0', 'images/1747153520_french fries.jpg', '2025-05-16 22:56:35', '1'),
('48', '14', 'Okoy', '105', '0', 'images/1747153548_okoy.jpg', '2025-05-16 22:56:35', '1'),
('49', '14', 'Nuts', '105', '0', 'images/1747153609_nuts.jpg', '2025-05-16 22:56:35', '1'),
('50', '3', 'Sizzling Porkchop or Liempo', '145', '0', 'images/1747153715_sizzling prokchop or liempo.jpg', '2025-05-16 22:56:35', '1'),
('51', '3', 'Sizzling T-Bone', '250', '0', 'images/1747153757_sizzling t-bone.jpg', '2025-05-16 22:56:35', '1'),
('52', '3', 'Sizzling Tenderloin Tips', '175', '0', 'images/1747153814_sizzling tenderloin tips.jpg', '2025-05-16 22:56:35', '1'),
('53', '4', '4pcs Buffalo Wings', '135', '0', 'images/1747154049_buffalo.jpg', '2025-05-16 22:56:35', '1'),
('54', '4', '8pcs Buffalo Wings', '225', '0', 'images/1747154125_buffalo.jpg', '2025-05-16 22:56:35', '1'),
('55', '4', '12pcs Buffalo Wings', '375', '0', 'images/1747154169_buffalo.jpg', '2025-05-16 22:56:35', '1'),
('56', '4', '4pcs Soy Garlic Wings', '135', '0', 'images/1747154236_soy garlic.jpg', '2025-05-16 22:56:35', '1'),
('57', '4', '8pcs Soy Garlic Wings', '255', '0', 'images/1747154274_soy garlic.jpg', '2025-05-16 22:56:35', '1'),
('58', '4', '12pcs Soy Garlic Wings', '375', '0', 'images/1747154305_soy garlic.jpg', '2025-05-16 22:56:35', '1'),
('59', '4', '4pcs Salted Eggs Wings', '135', '0', 'images/1747154368_salted egg.jpg', '2025-05-16 22:56:35', '1'),
('60', '4', '8pcs Salted Eggs Wings', '255', '0', 'images/1747154395_salted egg.jpg', '2025-05-16 22:56:35', '1'),
('61', '4', '12pcs Salted Eggs Wings', '375', '0', 'images/1747154423_salted egg.jpg', '2025-05-16 22:56:35', '1'),
('62', '15', 'Pancit Mix (Sotanghon/Canton)', '185', '0', 'images/1747154533_pancit mix.jpg', '2025-05-16 22:56:35', '1'),
('63', '15', 'Pancit Mix Bilao Small - 15Pax', '700', '0', 'images/1747154609_pancit mix bilao.jpg', '2025-05-16 22:56:35', '1'),
('64', '15', 'Pancit Mix Bilao Medium - 25Pax', '900', '0', 'images/1747154723_pancit mix bilao.jpg', '2025-05-16 22:56:35', '1'),
('65', '15', 'Pancit Mix Bilao Large - 35Pax', '1200', '0', 'images/1747154788_pancit mix bilao.jpg', '2025-05-16 22:56:35', '1'),
('66', '16', 'Red Beach Bomb - 1.5L', '295', '0', 'images/1747154925_red beach bomb.jpg', '2025-05-16 22:56:35', '1'),
('68', '16', 'Green Mojito - 1.5L', '295', '0', 'images/1747155022_gren mojito.jpg', '2025-05-16 22:56:35', '1'),
('69', '16', 'Orange Zombie Chill - 1.5L', '295', '0', 'images/1747155186_orange zombae chill.jpg', '2025-05-16 22:56:35', '1'),
('70', '16', 'Alfonso Light', '400', '0', 'images/1747155240_alfonso light.jpg', '2025-05-16 22:56:35', '1');

--
-- Table structure for table `inventory_update`
--

DROP TABLE IF EXISTS `inventory_update`;
CREATE TABLE `inventory_update` (
  `InventoryID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Date_Updated` datetime NOT NULL DEFAULT current_timestamp(),
  `Action` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_update`
--

INSERT INTO `inventory_update` (`InventoryID`, `CategoryID`, `Quantity`, `Date_Updated`, `Action`) VALUES
('4', '0', '0', '2025-03-25 19:37:44', ''),
('7', '0', '0', '2025-03-27 23:17:57', ''),
('7', '0', '0', '2025-03-27 23:22:18', ''),
('9', '0', '3', '2025-03-27 17:06:52', 'Stock In'),
('1', '0', '2', '2025-03-27 17:07:47', 'Stock In'),
('9', '0', '6', '2025-03-27 17:13:42', 'Stock In'),
('4', '0', '13', '2025-03-27 17:19:56', 'Stock In'),
('0', '0', '13', '2025-03-27 17:22:21', 'Stock In'),
('0', '0', '13', '2025-03-27 17:22:45', 'Stock In'),
('6', '0', '10', '2025-03-27 17:22:54', 'Stock In'),
('0', '0', '20', '2025-03-27 17:25:15', 'Stock In'),
('0', '0', '50', '2025-03-27 17:26:14', 'Stock In'),
('0', '0', '20', '2025-03-27 17:29:02', 'Stock In'),
('4', '0', '2', '2025-03-27 17:29:46', 'Stock In'),
('7', '0', '0', '2025-03-28 02:20:47', ''),
('1', '0', '12', '2025-04-22 15:06:17', 'Stock In'),
('12', '0', '123', '2025-04-23 10:08:58', ''),
('13', '0', '123', '2025-04-23 10:09:53', ''),
('13', '0', '0', '2025-04-23 10:10:22', ''),
('14', '0', '324234', '2025-04-23 11:26:32', ''),
('15', '0', '43434', '2025-04-23 11:26:42', ''),
('16', '0', '54', '2025-04-23 11:26:54', ''),
('17', '0', '0', '2025-04-24 00:04:34', ''),
('18', '0', '0', '2025-04-24 00:08:09', ''),
('19', '0', '0', '2025-04-24 00:08:23', ''),
('20', '0', '0', '2025-04-24 00:49:00', ''),
('21', '0', '0', '2025-04-24 01:05:04', ''),
('22', '0', '0', '2025-05-10 22:47:50', ''),
('23', '0', '0', '2025-05-10 22:48:03', ''),
('24', '0', '0', '2025-05-10 22:49:01', ''),
('25', '0', '0', '2025-05-10 22:51:29', ''),
('26', '0', '0', '2025-05-10 22:51:36', ''),
('27', '0', '0', '2025-05-10 22:58:59', ''),
('28', '0', '0', '2025-05-13 15:26:12', ''),
('29', '0', '0', '2025-05-13 15:40:14', ''),
('30', '0', '0', '2025-05-13 20:51:54', ''),
('31', '0', '0', '2025-05-13 20:52:41', ''),
('32', '0', '0', '2025-05-13 20:54:29', ''),
('33', '0', '0', '2025-05-13 20:55:47', ''),
('34', '0', '0', '2025-05-13 20:57:20', ''),
('35', '0', '0', '2025-05-14 00:10:18', ''),
('36', '0', '0', '2025-05-14 00:11:02', ''),
('37', '0', '0', '2025-05-14 00:11:51', ''),
('38', '0', '0', '2025-05-14 00:16:20', ''),
('39', '0', '0', '2025-05-14 00:17:47', ''),
('40', '0', '0', '2025-05-14 00:19:05', ''),
('41', '0', '0', '2025-05-14 00:20:03', ''),
('42', '0', '0', '2025-05-14 00:20:58', ''),
('43', '0', '0', '2025-05-14 00:21:36', ''),
('44', '0', '0', '2025-05-14 00:22:05', ''),
('45', '0', '0', '2025-05-14 00:23:38', ''),
('46', '0', '0', '2025-05-14 00:24:46', ''),
('47', '0', '0', '2025-05-14 00:25:20', ''),
('48', '0', '0', '2025-05-14 00:25:48', ''),
('49', '0', '0', '2025-05-14 00:26:49', ''),
('50', '0', '0', '2025-05-14 00:28:35', ''),
('51', '0', '0', '2025-05-14 00:29:17', ''),
('52', '0', '0', '2025-05-14 00:30:14', ''),
('53', '0', '0', '2025-05-14 00:34:09', ''),
('54', '0', '0', '2025-05-14 00:34:50', ''),
('55', '0', '0', '2025-05-14 00:36:09', ''),
('56', '0', '0', '2025-05-14 00:37:16', ''),
('57', '0', '0', '2025-05-14 00:37:54', ''),
('58', '0', '0', '2025-05-14 00:38:25', ''),
('59', '0', '0', '2025-05-14 00:39:28', ''),
('60', '0', '0', '2025-05-14 00:39:55', ''),
('61', '0', '0', '2025-05-14 00:40:23', ''),
('62', '0', '0', '2025-05-14 00:42:13', ''),
('63', '0', '0', '2025-05-14 00:43:29', ''),
('64', '0', '0', '2025-05-14 00:45:23', ''),
('65', '0', '0', '2025-05-14 00:46:28', ''),
('66', '0', '0', '2025-05-14 00:48:45', ''),
('67', '0', '0', '2025-05-14 00:49:41', ''),
('68', '0', '0', '2025-05-14 00:50:22', ''),
('69', '0', '0', '2025-05-14 00:53:06', ''),
('70', '0', '0', '2025-05-14 00:54:00', ''),
('71', '0', '0', '2025-05-13 12:58:40', ''),
('72', '0', '0', '2025-05-17 00:17:23', '');

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `attempt_time` datetime DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `lockout_level` int(11) DEFAULT 0,
  `lockout_start` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `username`, `attempt_time`, `ip_address`, `lockout_level`, `lockout_start`) VALUES
('30', 'asdas', '2025-05-17 18:08:35', '::1', '0', NULL),
('31', 'asdasd', '2025-05-17 18:08:41', '::1', '0', NULL),
('32', 'asdasd', '2025-05-17 18:10:32', '::1', '0', NULL),
('33', 'asdasd', '2025-05-17 18:10:36', '::1', '0', NULL),
('52', 'jayzii', '2025-10-25 15:07:36', '::1', '0', NULL),
('53', 'jayzii', '2025-10-25 15:08:17', '::1', '0', NULL),
('54', 'jayzii', '2025-10-25 15:08:30', '::1', '0', NULL),
('0', 'grachel', '2025-11-13 22:02:15', '::1', '0', NULL);

--
-- Table structure for table `loginaccount`
--

DROP TABLE IF EXISTS `loginaccount`;
CREATE TABLE `loginaccount` (
  `UserID` int(11) NOT NULL,
  `Role` varchar(255) NOT NULL,
  `FullName` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) NOT NULL,
  `RecoveryQuestion` varchar(255) NOT NULL,
  `RecoveryAnswer` varchar(255) NOT NULL,
  `Date_Created` datetime NOT NULL,
  `two_factor_secret` varchar(255) DEFAULT NULL,
  `password_changed` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loginaccount`
--

INSERT INTO `loginaccount` (`UserID`, `Role`, `FullName`, `Username`, `Email`, `Password`, `RecoveryQuestion`, `RecoveryAnswer`, `Date_Created`, `two_factor_secret`, `password_changed`) VALUES
('1', 'Admin', 'Jc Roberto', 'jayziii', NULL, '$2y$10$zxZepQzegzpdMW10pSAlhOinfDi52jFnu8UpdyHWojyBF3PCA6lqO', 'What is your pet\'s name?', 'kia', '0000-00-00 00:00:00', 'U7P2DP42WMTRADDW', '1'),
('24', 'Cashier', 'Grachel Maravilla', 'grchla', 'mgrachelann@gmail.com', '$2y$10$WNwK/uhrABZlWeIUg0wil.7pGZpxalAaLIIIC5Grzht3mNuBuYu9a', 'What is your pet\'s name?', 'kia', '2025-05-16 20:26:55', 'N3D3SJGSNGSOY4EC', '1'),
('26', 'Cashier', 'Jk Divino', 'jeykey', 'jeykeydivino@gmail.com', '$2y$10$HevQb1ApQZju3zP.R397qOf9MjvQhvyoc/ybOg2370CFUo3ZFDKgu', 'What is your pet\'s name?', 'kia', '2025-05-17 08:33:24', NULL, '0'),
('0', 'Cashier', 'benjie', 'benjie', 'asdf@gmail.com', '$2y$10$dN/W9Y9gRaZaXkUOHugmEuQqlLNum8f4w2KKXoPsWtGVRToBg1WZO', 'What is your pet\'s name?', 'kia', '2026-02-16 05:13:27', '2HWPORM4YJMRLWRE', '0');

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `OrderID` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `OrderID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Total` decimal(10,2) NOT NULL,
  `Cash` decimal(10,2) NOT NULL,
  `T_Change` decimal(10,2) NOT NULL,
  `OrderDate` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`OrderID`, `Username`, `Total`, `Cash`, `T_Change`, `OrderDate`) VALUES
('1', 'grchla', '115.00', '180.00', '65.00', '2025-03-27 22:50:19'),
('2', 'grchla', '829.00', '1000.00', '171.00', '2025-03-27 22:51:29'),
('3', 'grchla', '417.00', '500.00', '83.00', '2025-03-27 23:16:15'),
('4', 'grchla', '1112.00', '2000.00', '888.00', '2025-03-27 23:16:57'),
('5', 'grchla', '3250.00', '4000.00', '750.00', '2025-03-27 23:17:35'),
('6', 'grchla', '409.00', '500.00', '91.00', '2025-03-27 23:22:30'),
('7', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:08'),
('8', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:10'),
('9', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:10'),
('10', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:10'),
('11', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:11'),
('12', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:11'),
('13', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:14'),
('14', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:15'),
('15', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:16'),
('16', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:16'),
('17', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:16'),
('18', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:18'),
('19', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:18'),
('20', 'grchla', '4345.00', '5000.00', '655.00', '2025-03-27 23:23:18'),
('21', 'grchla', '3950.00', '4000.00', '50.00', '2025-03-27 23:23:31'),
('22', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:48'),
('23', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:49'),
('24', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:49'),
('25', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:49'),
('26', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:49'),
('27', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:50'),
('28', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:51'),
('29', 'grchla', '395.00', '400.00', '5.00', '2025-03-27 23:47:51'),
('30', 'grchla', '230.00', '500.00', '270.00', '2025-04-24 03:08:23');

--
-- Table structure for table `recovery_items`
--

DROP TABLE IF EXISTS `recovery_items`;
CREATE TABLE `recovery_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type` varchar(50) NOT NULL,
  `source_table` varchar(100) NOT NULL,
  `reference_id` varchar(64) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `item_data` longtext NOT NULL,
  `removed_by` varchar(255) NOT NULL,
  `removed_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_item_type` (`item_type`),
  KEY `idx_removed_at` (`removed_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `recovery_items`
--

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `SalesID` int(11) NOT NULL,
  `Purchased_Date` datetime NOT NULL DEFAULT current_timestamp(),
  `Payment_Amount` float NOT NULL,
  `InventoryID` int(11) NOT NULL,
  `CategoryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `action_type` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `log_timestamp` datetime NOT NULL DEFAULT current_timestamp(),
  `transaction_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_logs`
--

INSERT INTO `system_logs` (`log_id`, `action_type`, `description`, `user_fullname`, `log_timestamp`, `transaction_id`) VALUES
('1', 'Logout', 'User logged out', 'Jc Roberto', '2025-11-13 20:49:33', NULL),
('2', 'POS Transaction', 'Transaction #00000001 completed', 'Grachel Maravilla', '2025-11-13 20:50:34', NULL),
('3', 'POS Logout', 'Cashier ended POS session', 'Grachel Maravilla', '2025-11-13 20:51:37', NULL),
('4', 'POS Transaction', 'Transaction #00000002 completed', 'Grachel Maravilla', '2025-11-13 22:02:49', NULL),
('5', 'Category Deleted', 'Category deleted: asdas', 'Jc Roberto', '2025-11-13 22:07:43', NULL),
('6', 'User Deleted', 'User account deleted: asdasd', 'Jc Roberto', '2025-11-13 22:08:08', NULL),
('7', 'User Updated', 'User account updated (): jeykey', 'Jc Roberto', '2025-11-13 22:13:12', NULL),
('8', 'User Updated', 'User account updated (): jeykey', 'Jc Roberto', '2025-11-13 22:16:51', NULL),
('9', 'User Updated', 'User account updated (): jeykey', 'Jc Roberto', '2025-11-13 22:17:14', NULL),
('10', 'User Updated', 'User account updated (): grchla', 'Jc Roberto', '2025-11-13 22:17:19', NULL),
('11', 'User Updated', 'User account updated (email updated): jeykey', 'Jc Roberto', '2025-11-13 22:21:05', NULL),
('12', 'User Updated', 'User account updated (email updated): grchla', 'Jc Roberto', '2025-11-13 22:21:18', NULL),
('13', 'User Updated', 'User account updated (email updated): grchla', 'Jc Roberto', '2025-11-13 22:28:03', NULL),
('14', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:01:28', NULL),
('15', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:04:10', NULL),
('16', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:38:48', NULL),
('17', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:41:04', NULL),
('18', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:46:30', NULL),
('19', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-14 09:48:01', NULL),
('20', 'Logout', 'User logged out', 'Jc Roberto', '2025-11-14 10:42:35', NULL),
('21', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱273.00', 'Grachel Maravilla', '2025-11-14 11:22:27', NULL),
('22', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:22:34', NULL),
('23', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱273.00', 'Grachel Maravilla', '2025-11-14 11:22:34', NULL),
('24', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:22:36', NULL),
('25', 'POS Transaction', 'Transaction #00000003 completed', 'Grachel Maravilla', '2025-11-14 11:22:54', NULL),
('26', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱76.00', 'Grachel Maravilla', '2025-11-14 11:27:03', NULL),
('27', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:27:04', NULL),
('28', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱76.00', 'Grachel Maravilla', '2025-11-14 11:27:05', NULL),
('29', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:27:06', NULL),
('30', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱382.00', 'Grachel Maravilla', '2025-11-14 11:30:22', NULL),
('31', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:30:24', NULL),
('32', 'Discount Applied', 'PWD/Senior Discount applied. Amount: ₱382.00', 'Grachel Maravilla', '2025-11-14 11:30:25', NULL),
('33', 'Discount Removed', 'PWD/Senior Discount removed', 'Grachel Maravilla', '2025-11-14 11:30:29', NULL),
('34', 'POS Login', 'Cashier started POS session (2FA setup completed)', 'Grachel Maravilla', '2025-11-17 11:05:43', NULL),
('35', 'POS Transaction', 'Transaction #00000004 completed', 'Grachel Maravilla', '2025-11-17 11:08:51', NULL),
('36', 'POS Transaction', 'Transaction #00000005 completed', 'Grachel Maravilla', '2025-11-17 12:36:52', NULL),
('37', 'Login', 'User logged in successfully (2FA setup completed)', 'Jc Roberto', '2025-11-17 13:52:15', NULL),
('38', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-18 10:04:28', NULL),
('39', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-18 10:34:08', NULL),
('40', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-19 08:36:26', NULL),
('41', 'Product Status Updated', 'Product status updated: Orange Zombie Chill - 1.5L is now Unavailable', 'Jc Roberto', '2025-11-19 08:36:33', NULL),
('42', 'Product Status Updated', 'Product status updated: Sizzling Bagnet is now Unavailable', 'Jc Roberto', '2025-11-19 08:36:42', NULL),
('43', 'Receipt Reprint', 'Receipt reprinted for Transaction #00000005', 'Jc Roberto', '2025-11-19 08:37:12', NULL),
('44', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2025-11-30', 'Jc Roberto', '2025-11-19 09:20:24', NULL),
('45', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:36:41', NULL),
('46', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Available', 'Jc Roberto', '2025-11-19 10:40:37', NULL),
('47', 'Product Status Updated', 'Product status updated: 8pcs Soy Garlic Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:40:40', NULL),
('48', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:40:45', NULL),
('49', 'Product Status Updated', 'Product status updated: 8pcs Soy Garlic Wings is now Available', 'Jc Roberto', '2025-11-19 10:40:47', NULL),
('50', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Available', 'Jc Roberto', '2025-11-19 10:40:49', NULL),
('51', 'Product Status Updated', 'Product status updated: Orange Zombie Chill - 1.5L is now Available', 'Jc Roberto', '2025-11-19 10:41:03', NULL),
('52', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:41:12', NULL),
('53', 'Product Status Updated', 'Product status updated: Sizzling Bagnet is now Available', 'Jc Roberto', '2025-11-19 10:41:17', NULL),
('54', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Available', 'Jc Roberto', '2025-11-19 10:41:18', NULL),
('55', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:48:28', NULL),
('56', 'Product Status Updated', 'Product status updated: 8pcs Soy Garlic Wings is now Unavailable', 'Jc Roberto', '2025-11-19 10:48:30', NULL),
('57', 'Product Status Updated', 'Product status updated: 8pcs Soy Garlic Wings is now Available', 'Jc Roberto', '2025-11-19 10:48:32', NULL),
('58', 'Product Status Updated', 'Product status updated: 12pcs Buffalo Wings is now Available', 'Jc Roberto', '2025-11-19 12:46:39', NULL),
('59', 'Product Status Updated', 'Product status updated: Sizzling Gambas is now Unavailable', 'Jc Roberto', '2025-11-19 12:46:44', NULL),
('60', 'Product Status Updated', 'Product status updated: Sizzling Gambas is now Available', 'Jc Roberto', '2025-11-19 12:46:50', NULL),
('61', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-21 10:11:26', NULL),
('62', 'Product Removed', 'Product removed: Blue Sonic Tonic - 1.5L (Price: ₱295.00, Category: Cocktails & Drinks)', 'Jc Roberto', '2025-11-21 12:30:58', NULL),
('63', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-24 10:29:53', NULL),
('64', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2025-11-24 10:31:16', NULL),
('65', 'POS Transaction', 'Transaction #00000006 completed', 'Grachel Maravilla', '2025-11-24 10:31:49', NULL),
('66', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2025-11-24 10:34:14', NULL),
('67', 'POS Transaction', 'Transaction #00000007 completed', 'Grachel Maravilla', '2025-11-24 10:34:33', NULL),
('68', 'POS Transaction', 'Transaction #00000008 completed', 'Grachel Maravilla', '2025-11-24 10:35:24', NULL),
('69', 'Recovery Restored', 'Restored Blue Sonic Tonic - 1.5L (product)', 'Jc Roberto', '2025-11-24 10:45:47', NULL),
('70', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-26 10:06:43', NULL),
('71', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-26 10:14:21', NULL),
('72', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2025-11-26 10:19:31', NULL),
('73', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2025-11-26 10:20:50', NULL),
('74', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-08 12:41:46', NULL),
('75', 'Product Status Updated', 'Product status updated: Chicharon is now Unavailable', 'Jc Roberto', '2026-01-08 12:42:16', NULL),
('76', 'Product Status Updated', 'Product status updated: Chicharon is now Available', 'Jc Roberto', '2026-01-08 12:42:18', NULL),
('77', 'Product Created', 'New product added: sdfgsdf (Price: ₱151.00, Category: All-Day Meals)', 'Jc Roberto', '2026-01-08 12:50:01', NULL),
('78', 'Product Removed', 'Product removed: Blue Sonic Tonic - 1.5L (Price: ₱295.00, Category: Cocktails & Drinks)', 'Jc Roberto', '2026-01-08 12:50:09', NULL),
('79', 'Recovery Purged', 'Permanently removed Blue Sonic Tonic - 1.5L (product)', 'Jc Roberto', '2026-01-08 12:50:22', NULL),
('80', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-08 12:57:23', NULL),
('81', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-01-12 12:41:47', NULL),
('82', 'POS Transaction', 'Transaction #00000009 completed', 'Grachel Maravilla', '2026-01-12 13:13:18', NULL),
('83', 'POS Transaction', 'Transaction #00000010 completed', 'Grachel Maravilla', '2026-01-12 13:16:17', NULL),
('84', 'POS Transaction', 'Transaction #00000011 completed', 'Grachel Maravilla', '2026-01-12 13:16:23', NULL),
('85', 'POS Transaction', 'Transaction #00000012 completed', 'Grachel Maravilla', '2026-01-12 13:50:31', NULL),
('86', 'POS Transaction', 'Transaction #00000013 completed', 'Grachel Maravilla', '2026-01-12 14:13:31', NULL),
('87', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-01-13 10:39:49', NULL),
('88', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-13 10:42:36', NULL),
('89', 'Logout', 'User logged out', 'Jc Roberto', '2026-01-13 10:51:39', NULL),
('90', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-13 10:52:06', NULL),
('91', 'Logout', 'User logged out', 'Jc Roberto', '2026-01-13 10:52:32', NULL),
('92', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-13 10:52:49', NULL),
('93', 'Logout', 'User logged out', 'Jc Roberto', '2026-01-13 11:03:12', NULL),
('94', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-13 11:04:13', NULL),
('95', 'Backup Schedule Updated', 'Schedule changed to: Monday at 09:00:00', 'Jc Roberto', '2026-01-13 11:39:51', NULL),
('96', 'Backup Schedule Updated', 'Schedule changed to: Monday at 10:00:00', 'Jc Roberto', '2026-01-13 11:40:00', NULL),
('97', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-01-21 09:57:27', NULL),
('98', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-06 10:51:16', NULL),
('99', 'Logout', 'User logged out', 'Jc Roberto', '2026-02-06 11:11:47', NULL),
('100', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-06 11:12:17', NULL),
('101', 'Logout', 'User logged out', 'Jc Roberto', '2026-02-06 11:12:52', NULL),
('102', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-06 11:17:10', NULL),
('103', 'Report Generated', 'Generated sales report for period 2025-10-01 to 2026-02-28', 'Jc Roberto', '2026-02-06 11:46:15', NULL),
('104', 'Report Generated', 'Generated sales report for period 2026-01-31 to 2026-02-27', 'Jc Roberto', '2026-02-06 11:59:41', NULL),
('105', 'Report Generated', 'Generated sales report for period 2025-11-01 to 2026-02-27', 'Jc Roberto', '2026-02-06 12:00:24', NULL),
('106', 'Report Generated', 'Generated sales report for period 2026-01-31 to 2026-02-27', 'Jc Roberto', '2026-02-06 12:12:02', NULL),
('107', 'Database Restore', 'Database successfully restored from file: 2026-02-06_06-04-46_edgies_pos_backup.sql', 'Jc Roberto', '2026-02-06 13:05:13', NULL),
('108', 'Logout', 'User logged out', 'Jc Roberto', '2026-02-06 13:12:07', NULL),
('109', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-06 13:47:59', NULL),
('110', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-02-06 14:26:59', NULL),
('111', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-02-06 14:33:49', NULL),
('112', 'Product Created', 'New product added: sdfgdfg (Price: ₱232.00, Category: All-Day Meals)', 'Jc Roberto', '2026-02-06 15:10:47', NULL),
('113', 'Product Updated', 'Product updated (price updated from ₱232.00 to ₱23233.00): sdfgdfg', 'Jc Roberto', '2026-02-06 15:10:55', NULL),
('114', 'Product Removed', 'Product removed: sdfgdfg (Price: ₱23233.00, Category: All-Day Meals)', 'Jc Roberto', '2026-02-06 15:11:46', NULL),
('115', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-16 12:11:57', NULL),
('116', 'User Created', 'New user account created: benjie', 'Jc Roberto', '2026-02-16 12:13:27', NULL),
('117', 'POS Login', 'Cashier started POS session (2FA setup completed)', 'benjie', '2026-02-16 12:14:37', NULL),
('118', 'POS Logout', 'Cashier ended POS session', 'benjie', '2026-02-16 12:20:30', NULL),
('119', 'POS Login', 'Cashier started POS session (2FA verified)', 'benjie', '2026-02-16 12:20:49', NULL),
('120', 'POS Logout', 'Cashier ended POS session', 'benjie', '2026-02-16 12:23:32', NULL),
('121', 'POS Login', 'Cashier started POS session (2FA verified)', 'benjie', '2026-02-16 12:23:48', NULL),
('122', 'POS Logout', 'Cashier ended POS session', 'benjie', '2026-02-16 12:25:04', NULL),
('123', 'POS Login', 'Cashier started POS session (2FA verified)', 'benjie', '2026-02-16 12:25:38', NULL),
('124', 'POS Logout', 'Cashier ended POS session', 'benjie', '2026-02-16 12:57:38', NULL),
('125', 'Database Backup', 'Database backup downloaded: 2026-02-16_06-00-36_edgies_pos_backup.sql', 'Jc Roberto', '2026-02-16 13:00:36', NULL),
('126', 'Category Updated', 'Category name updated from \'All-Day Meals\' to \'All-Day Meals\'', 'Jc Roberto', '2026-02-16 13:07:43', NULL),
('127', 'Category Updated', 'Category name updated from \'All-Day Meals\' to \'All-Day Meals\'', 'Jc Roberto', '2026-02-16 13:07:57', NULL),
('128', 'Category Updated', 'Category name updated from \'All-Day Meals\' to \'All-Day Meals1\'', 'Jc Roberto', '2026-02-16 13:08:16', NULL),
('129', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-02-16 13:11:36', NULL),
('130', 'Category Updated', 'Category name updated from \'All-Day Meals1\' to \'All-Day Meals1\'', 'Jc Roberto', '2026-02-16 13:12:00', NULL),
('131', 'Category Updated', 'Category name updated from \'All-Day Meals1\' to \'All-Day Meals\'', 'Jc Roberto', '2026-02-16 13:12:10', NULL),
('132', 'Category Updated', 'Category name updated from \'All-Day Meals\' to \'All-Day Meals1\'', 'Jc Roberto', '2026-02-16 13:14:09', NULL),
('133', 'Category Updated', 'Category name updated from \'All-Day Meals1\' to \'All-Day Meals1\'', 'Jc Roberto', '2026-02-16 13:14:14', NULL),
('134', 'Category Updated', 'Category name updated from \'All-Day Meals1\' to \'All-Day Meals\'', 'Jc Roberto', '2026-02-16 13:14:21', NULL),
('135', 'POS Login', 'Cashier started POS session (2FA verified)', 'benjie', '2026-02-16 13:56:21', NULL),
('136', 'POS Transaction', 'Transaction #00000014 completed', 'benjie', '2026-02-16 14:44:12', NULL),
('137', 'POS Transaction', 'Transaction #00000015 completed', 'benjie', '2026-02-16 14:44:22', NULL),
('138', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-02-18 11:08:20', NULL),
('139', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-22 14:52:41', NULL),
('140', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-02-22 23:47:49', NULL),
('141', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-02-23 19:48:30', NULL),
('142', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-03-11 11:59:39', NULL),
('143', 'Password Changed', 'Password changed on first login: jayziii', 'Jc Roberto', '2026-03-11 12:00:00', NULL),
('144', 'Recovery Purged', 'Permanently removed sdfgdfg (product)', 'Jc Roberto', '2026-03-11 12:00:27', NULL),
('145', 'Product Status Updated', 'Product status updated: 12pcs Salted Eggs Wings is now Unavailable', 'Jc Roberto', '2026-03-11 12:02:32', NULL),
('146', 'Product Status Updated', 'Product status updated: 12pcs Salted Eggs Wings is now Available', 'Jc Roberto', '2026-03-11 12:02:39', NULL),
('147', 'POS Login', 'Cashier started POS session (2FA verified)', 'Grachel Maravilla', '2026-03-11 12:03:15', NULL),
('148', 'Password Changed', 'Password changed on first login: grchla', 'Grachel Maravilla', '2026-03-11 12:03:27', NULL),
('149', 'POS Transaction', 'Transaction #00000016 completed', 'Grachel Maravilla', '2026-03-11 12:09:25', NULL),
('150', 'Product Status Updated', 'Product status updated: Adobo Mix Binalot is now Unavailable', 'Grachel Maravilla', '2026-03-11 12:13:47', NULL),
('151', 'Product Status Updated', 'Product status updated: Bangsilog is now Unavailable', 'Grachel Maravilla', '2026-03-11 12:13:48', NULL),
('152', 'Product Status Updated', 'Product status updated: Adobo Mix Binalot is now Available', 'Grachel Maravilla', '2026-03-11 12:47:42', NULL),
('153', 'Product Status Updated', 'Product status updated: Adobo Mix Binalot is now Unavailable', 'Grachel Maravilla', '2026-03-11 12:47:44', NULL),
('154', 'Login', 'User logged in successfully (2FA verified)', 'Jc Roberto', '2026-03-16 09:19:51', NULL);

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_num` varchar(10) NOT NULL,
  `transaction_num` int(11) NOT NULL,
  `sales_invoice_no` varchar(32) DEFAULT NULL COMMENT 'Customer-facing sales invoice number (e.g. INV-YYYYMMDD-00000001)',
  `transaction_date` datetime NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `details` text NOT NULL,
  `processed_by` varchar(255) DEFAULT NULL,
  `payment` decimal(10,2) DEFAULT 0.00,
  `change_amount` decimal(10,2) DEFAULT 0.00,
  `payment_method` varchar(20) DEFAULT 'cash',
  `reference_no` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_transaction_date` (`transaction_date`),
  KEY `idx_serial_num` (`serial_num`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `serial_num`, `transaction_num`, `transaction_date`, `total_amount`, `details`, `processed_by`, `payment`, `change_amount`, `payment_method`, `reference_no`) VALUES
('1', '', '1', '2025-11-13 20:50:34', '365.00', 'Porksilog(1), Chicksilog(1), Bangsilog(1), Grachel Maravilla', NULL, '500.00', '135.00', 'cash', NULL),
('2', '', '2', '2025-11-13 22:02:49', '345.00', 'Bangsilog(2), Chicksilog(1), Grachel Maravilla', NULL, '1000.00', '655.00', 'cash', NULL),
('3', '', '3', '2025-11-14 11:22:54', '1365.00', 'Tapsilog(1), Lechon Kawali(1), Chicksilog(1), Sinigang na Hipon(2), Grachel Maravilla', NULL, '2000.00', '635.00', 'cash', NULL),
('4', '', '4', '2025-11-17 11:08:51', '885.00', 'Tapsilog(1), Adobo Mix (Pork & Chicken)(1), Beef Bulalo(1), Grachel Maravilla', NULL, '1000.00', '115.00', 'cash', NULL),
('5', '', '5', '2025-11-17 12:36:52', '334.00', 'Bangsilog(1), Tapsilog(1), Adobo Mix Binalot(1), Grachel Maravilla', NULL, '1000.00', '665.18', 'cash', NULL),
('6', '', '6', '2025-11-24 10:31:49', '928.00', 'Tapsilog(1), Bangsilog(1), Beef Bulalo(1), Sinigang na Hipon(1), Grachel Maravilla', NULL, '1000.00', '71.43', 'cash', NULL),
('7', '', '7', '2025-11-24 10:34:33', '1366.00', 'Bangsilog(1), Tapsilog(1), Sizzling Hotdog(1), Pork Binagoongan w/ Talong(1), Adobo Mix (Pork & Chicken)(1), Sizzling Gambas(1), Grachel Maravilla', NULL, '10000.00', '8633.93', 'cash', NULL),
('8', '', '8', '2025-11-24 10:35:24', '400.00', 'Sizzling Gambas(1), French Fries(1), Grachel Maravilla', NULL, '1000.00', '600.00', 'cash', NULL),
('9', '', '9', '2026-01-12 13:13:18', '635.00', 'Liemposilog(1), Adobo Mix Binalot(1), Sinigang na Hipon(1), Grachel Maravilla', 'grchla', '34234.00', '33599.00', 'cash', NULL),
('10', '', '10', '2026-01-12 13:16:17', '915.00', 'Adobo Mix Binalot(1), Beef Bulalo(1), Sinigang na Hipon(1), Grachel Maravilla', 'grchla', '352345.00', '351430.00', 'cash', NULL),
('11', '', '11', '2026-01-12 13:16:23', '790.00', 'Beef Bulalo(1), Sinigang na Hipon(1), Grachel Maravilla', 'grchla', '365536.00', '364746.00', 'cash', NULL),
('12', '', '12', '2026-01-12 13:50:31', '1395.00', 'Chicksilog(1), Tapsilog(1), Adobo Mix (Pork & Chicken)(1), Beef Bulalo(1), Sinigang na Hipon(1), Grachel Maravilla', 'grchla', '99999999.99', '99999999.99', 'cash', NULL),
('13', '', '13', '2026-01-12 14:13:31', '280.00', 'Sizzling Corn(1), Fried Tofu(1), Grachel Maravilla', 'grchla', '2523.00', '2243.00', 'cash', NULL),
('14', '', '14', '2026-02-16 14:44:12', '548.80', 'Tapsilog(1), Adobo Mix (Pork & Chicken)(1), benjie', 'benjie', '10000.00', '9451.20', 'cash', NULL),
('15', '', '15', '2026-02-16 14:44:22', '700.00', 'Liemposilog(1), Adobo Mix (Pork & Chicken)(1), Sizzling Hotdog(1), benjie', 'benjie', '1000.00', '300.00', 'cash', NULL),
('16', '', '16', '2026-03-11 12:09:25', '980.00', 'Adobo Mix (Pork & Chicken)(1), Liemposilog(1), Tapsilog(1), Pork Binagoongan w/ Talong(1), Grachel Maravilla', 'grchla', '1000.00', '20.00', 'cash', NULL);

COMMIT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
