<?php
session_start();
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/ensure_2fa_column.php';
require_once __DIR__ . '/../lib/ensure_active_sessions_table.php';
require_once __DIR__ . '/../lib/ensure_password_changed_column.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../vendor/autoload.php';

use Sonata\GoogleAuthenticator\GoogleAuthenticator;

ensure2FAColumn($conn);
ensureActiveSessionsTable($conn);
ensurePasswordChangedColumn($conn);

// Check if user is in the middle of login process
if (!isset($_SESSION['pending_user_id']) || !isset($_SESSION['pending_username']) || !isset($_SESSION['pending_role'])) {
    header('Location: ../index.php');
    exit();
}

$error = '';
$ga = new GoogleAuthenticator();

// Get user's 2FA secret and password_changed status
$userQuery = $conn->prepare("SELECT two_factor_secret, password_changed FROM loginaccount WHERE UserID = ?");
$userQuery->bind_param("i", $_SESSION['pending_user_id']);
$userQuery->execute();
$userResult = $userQuery->get_result();
$userData = $userResult->fetch_assoc();
$userQuery->close();

$hasSecret = !empty($userData['two_factor_secret']);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = $_POST['code'] ?? '';
    
    if (empty($code)) {
        $error = 'Please enter the verification code';
    } else {
        if ($hasSecret) {
            // Verify the code
            if ($ga->checkCode($userData['two_factor_secret'], $code)) {
                // Code is valid, complete login
                $_SESSION['UserID'] = $_SESSION['pending_user_id'];
                $_SESSION['Username'] = $_SESSION['pending_username'];
                $_SESSION['Role'] = $_SESSION['pending_role'];
                $_SESSION['2fa_verified'] = true;
                
                // Record the new session
                $sessionStmt = $conn->prepare("INSERT INTO active_sessions (user_id, session_id) VALUES (?, ?)");
                $sessionStmt->bind_param("is", $_SESSION['pending_user_id'], session_id());
                $sessionStmt->execute();
                $sessionStmt->close();
                
                // Get user's full name for logging
                $userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE UserID = ?");
                $userQuery->bind_param("i", $_SESSION['pending_user_id']);
                $userQuery->execute();
                $userData = $userQuery->get_result()->fetch_assoc();
                $userFullName = $userData['FullName'] ?? $_SESSION['pending_username'];
                $userQuery->close();
                
                // Add login log with specific details for POS users
                if ($_SESSION['pending_role'] == 'Cashier') {
                    addSystemLog($conn, "POS Login", "Cashier started POS session (2FA verified)", $userFullName);
                } else {
                    addSystemLog($conn, "Login", "User logged in successfully (2FA verified)", $userFullName);
                }
                
                // Check if password needs to be changed on first login
                $passwordChanged = isset($userData['password_changed']) ? (bool)$userData['password_changed'] : false;
                
                // Clear pending session variables
                unset($_SESSION['pending_user_id']);
                unset($_SESSION['pending_username']);
                unset($_SESSION['pending_role']);
                
                // If password hasn't been changed, redirect to change password page
                if (!$passwordChanged) {
                    header("Location: change_password_first.php");
                    exit();
                }
                
                // Redirect based on role
                if ($_SESSION['Role'] == 'Admin') {
                    header("Location: ../admin/dashboard.php");
                } else {
                    header("Location: ../cashier/pos.php");
                }
                exit();
            } else {
                $error = 'Invalid verification code. Please try again.';
            }
        } else {
            $error = '2FA is not set up for this account.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Two-Factor Authentication</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .verify-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .verify-container h2 {
            margin-bottom: 10px;
            color: #2d3748;
            font-size: 24px;
            font-weight: 600;
        }

        .verify-container p {
            color: #4a5568;
            margin-bottom: 30px;
            font-size: 14px;
        }

        .icon-container {
            margin-bottom: 20px;
        }

        .icon-container i {
            font-size: 48px;
            color: #face0b;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 500;
            font-size: 14px;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 18px;
            text-align: center;
            letter-spacing: 8px;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .error-message {
            color: #e53e3e;
            font-size: 14px;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #fed7d7;
            border-radius: 8px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #face0b;
            color: #000000;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.2);
            background: #e6c009;
        }

        .help-text {
            color: #718096;
            font-size: 12px;
            margin-top: 15px;
        }

        .back-link {
            color: #2d3748;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            display: inline-block;
            margin-top: 20px;
            transition: color 0.3s ease;
        }

        .back-link:hover {
            color: #face0b;
        }
    </style>
</head>
<body>
    <div class="verify-container">
        <div class="icon-container">
            <i class="fas fa-shield-alt"></i>
        </div>
        <h2>Two-Factor Authentication</h2>
        <p>Please enter the 6-digit code from your authenticator app</p>
        
        <?php if ($error): ?>
            <div class="error-message show" id="errorMessage"><?php echo htmlspecialchars($error); ?></div>
        <?php else: ?>
            <div class="error-message" id="errorMessage"></div>
        <?php endif; ?>
        
        <form method="POST" action="" id="verifyForm">
            <div class="form-group">
                <label for="code">Verification Code</label>
                <input 
                    type="text" 
                    id="code" 
                    name="code" 
                    maxlength="6" 
                    pattern="[0-9]{6}" 
                    required 
                    autocomplete="off"
                    autofocus
                    placeholder="000000"
                >
            </div>
        </form>
        
        <p class="help-text">
            <i class="fas fa-info-circle"></i> Open your Google Authenticator app and enter the 6-digit code
        </p>
        
        <a href="../index.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Login
        </a>
    </div>

    <script>
        // Auto-focus and format input
        const codeInput = document.getElementById('code');
        
        // Only allow numbers
        codeInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Auto-submit when 6 digits are entered
        codeInput.addEventListener('input', function(e) {
            if (this.value.length === 6) {
                // Small delay to show the last digit
                setTimeout(() => {
                    document.getElementById('verifyForm').submit();
                }, 100);
            }
        });

        // Show error message if present
        <?php if ($error): ?>
            setTimeout(() => {
                document.getElementById('errorMessage').classList.add('show');
            }, 100);
        <?php endif; ?>
    </script>
</body>
</html>

<?php
$conn->close();
?>

