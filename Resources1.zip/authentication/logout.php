<?php
session_start();
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';

// Get the user's full name and role before destroying the session (case-sensitive)
$stmt = $conn->prepare("SELECT FullName, Role FROM loginaccount WHERE BINARY Username = ?");
$stmt->bind_param("s", $_SESSION['Username']);
$stmt->execute();
$userData = $stmt->get_result()->fetch_assoc();
$userFullName = $userData['FullName'];
$userRole = $userData['Role'];

// Remove active session from database
if (isset($_SESSION['UserID'])) {
    $removeSession = $conn->prepare("DELETE FROM active_sessions WHERE user_id = ? AND session_id = ?");
    $removeSession->bind_param("is", $_SESSION['UserID'], session_id());
    $removeSession->execute();
    $removeSession->close();
}

// Add logout log with specific details for POS users
if ($userRole == 'Cashier') {
    addSystemLog($conn, "POS Logout", "Cashier ended POS session", $userFullName);
} else {
    addSystemLog($conn, "Logout", "User logged out", $userFullName);
}

// Destroy the session
session_destroy();

// Redirect to login page
header("Location: ../index.php");
exit();
?>