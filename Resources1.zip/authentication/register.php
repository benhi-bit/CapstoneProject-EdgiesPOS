<?php

// Check for at least one capital letter
if (!preg_match('/[A-Z]/', $password)) {
    $errors[] = "Password must contain at least one capital letter";
} 