<?php
require_once __DIR__ . '/../config/connection.php';

// Get all users with plain text passwords
$stmt = $conn->prepare("SELECT UserID, Password FROM loginaccount WHERE LENGTH(Password) < 60");
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    // Hash the plain text password
    $hashedPassword = password_hash($row['Password'], PASSWORD_DEFAULT);
    
    // Update the password in the database
    $updateStmt = $conn->prepare("UPDATE loginaccount SET Password = ? WHERE UserID = ?");
    $updateStmt->bind_param("si", $hashedPassword, $row['UserID']);
    $updateStmt->execute();
    $updateStmt->close();
}

$stmt->close();
$conn->close();

echo "All passwords have been updated to hashed versions.";
?> 