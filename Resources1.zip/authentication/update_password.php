<?php
require_once __DIR__ . '/../config/connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['newPassword'])) {
    $username = $_POST['username'];
    $newPassword = $_POST['newPassword'];
    
    // Log the incoming request
    error_log("Password update attempt for username: " . $username);
    
    // Validate password format
    if (!preg_match('/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/', $newPassword)) {
        error_log("Password validation failed for username: " . $username);
        echo json_encode([
            'success' => false,
            'message' => 'Password must be at least 6 characters long and contain at least one uppercase letter and one number'
        ]);
        exit;
    }
    
    // Hash the password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // First check if the user exists (case-sensitive username check)
    $checkStmt = $conn->prepare("SELECT UserID, Password FROM loginaccount WHERE BINARY Username = ?");
    $checkStmt->bind_param("s", $username);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    
    if ($result->num_rows === 0) {
        error_log("User not found: " . $username);
        echo json_encode([
            'success' => false,
            'message' => 'User not found'
        ]);
        exit;
    }

    // Get the current password hash
    $row = $result->fetch_assoc();
    $currentPasswordHash = $row['Password'];
    $checkStmt->close();

    // Check if new password is same as old password
    if (password_verify($newPassword, $currentPasswordHash)) {
        error_log("New password is same as old password for username: " . $username);
        echo json_encode([
            'success' => false,
            'message' => 'New password cannot be the same as your old password'
        ]);
        exit;
    }
    
    // Update the password (case-sensitive username check)
    $stmt = $conn->prepare("UPDATE loginaccount SET Password = ? WHERE BINARY Username = ?");
    $stmt->bind_param("ss", $hashedPassword, $username);
    
    if ($stmt->execute()) {
        error_log("Password updated successfully for username: " . $username);
        echo json_encode([
            'success' => true,
            'message' => 'Password updated successfully'
        ]);
    } else {
        error_log("Error updating password for username: " . $username . ". Error: " . $stmt->error);
        echo json_encode([
            'success' => false,
            'message' => 'Error updating password: ' . $stmt->error
        ]);
    }
    
    $stmt->close();
} else {
    error_log("Invalid request received for password update");
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request - missing username or password'
    ]);
}

$conn->close();
?> 