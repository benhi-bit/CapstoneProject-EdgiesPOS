<?php
require_once __DIR__ . '/../config/connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username']) && isset($_POST['answer'])) {
    $username = $_POST['username'];
    $answer = $_POST['answer'];
    
    // Prepare and execute query (case-sensitive username check)
    $stmt = $conn->prepare("SELECT RecoveryAnswer FROM loginaccount WHERE BINARY Username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (strtolower($row['RecoveryAnswer']) === strtolower($answer)) {
            echo json_encode([
                'success' => true,
                'message' => 'Answer is correct'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Incorrect answer'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Username not found'
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}

$conn->close();
?> 