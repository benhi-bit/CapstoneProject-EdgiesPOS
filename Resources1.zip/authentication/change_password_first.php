<?php
session_start();
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/ensure_password_changed_column.php';
require_once __DIR__ . '/../lib/log_helper.php';

ensurePasswordChangedColumn($conn);

// Check if user is logged in
if (!isset($_SESSION['UserID']) || !isset($_SESSION['Username']) || !isset($_SESSION['Role']) || !isset($_SESSION['2fa_verified']) || $_SESSION['2fa_verified'] !== true) {
    header('Location: ../index.php');
    exit();
}

// Check if password has already been changed
$checkStmt = $conn->prepare("SELECT password_changed FROM loginaccount WHERE UserID = ?");
$checkStmt->bind_param("i", $_SESSION['UserID']);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();
$checkData = $checkResult->fetch_assoc();
$checkStmt->close();

if (isset($checkData['password_changed']) && (bool)$checkData['password_changed']) {
    // Password already changed, redirect to appropriate dashboard
    if ($_SESSION['Role'] == 'Admin') {
        header("Location: ../admin/dashboard.php");
    } else {
        header("Location: ../cashier/pos.php");
    }
    exit();
}

$error = '';
$success = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newPassword = trim($_POST['newPassword'] ?? '');
    $confirmPassword = trim($_POST['confirmPassword'] ?? '');
    
    if (empty($newPassword) || empty($confirmPassword)) {
        $error = 'All password fields are required.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'New passwords do not match.';
    } else {
        // Validate password pattern: at least 6 characters, 1 uppercase letter, 1 number
        $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/';
        if (!preg_match($passwordPattern, $newPassword)) {
            $error = 'Password must be at least 6 characters long and contain at least one uppercase letter and one number.';
        } else {
            // Get current password hash to check if new password is same as old
            $currentPasswordStmt = $conn->prepare("SELECT Password FROM loginaccount WHERE UserID = ?");
            $currentPasswordStmt->bind_param("i", $_SESSION['UserID']);
            $currentPasswordStmt->execute();
            $currentPasswordResult = $currentPasswordStmt->get_result();
            $currentPasswordData = $currentPasswordResult->fetch_assoc();
            $currentPasswordStmt->close();
            
            // Check if new password is same as old password
            if (password_verify($newPassword, $currentPasswordData['Password'])) {
                $error = 'New password cannot be the same as your current password. Please choose a different password.';
            } else {
                // Update password and set password_changed flag
                $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                $updateStmt = $conn->prepare("UPDATE loginaccount SET Password = ?, password_changed = 1 WHERE UserID = ?");
                $updateStmt->bind_param("si", $hashedPassword, $_SESSION['UserID']);
            
                if ($updateStmt->execute()) {
                    // Get user's full name for logging
                    $userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE UserID = ?");
                    $userQuery->bind_param("i", $_SESSION['UserID']);
                    $userQuery->execute();
                    $userData = $userQuery->get_result()->fetch_assoc();
                    $userFullName = $userData['FullName'] ?? $_SESSION['Username'];
                    $userQuery->close();
                    
                    // Log the change
                    $description = "Password changed on first login: " . $_SESSION['Username'];
                    addSystemLog($conn, "Password Changed", $description, $userFullName);
                    
                    $success = true;
                    
                    // Redirect after a short delay
                    if ($_SESSION['Role'] == 'Admin') {
                        header("Location: ../admin/dashboard.php");
                    } else {
                        header("Location: ../cashier/pos.php");
                    }
                    exit();
                } else {
                    $error = 'Error changing password: ' . $updateStmt->error;
                }
                $updateStmt->close();
            }
        }
    }
}

// Get user's full name for display
$userQuery = $conn->prepare("SELECT FullName FROM loginaccount WHERE UserID = ?");
$userQuery->bind_param("i", $_SESSION['UserID']);
$userQuery->execute();
$userResult = $userQuery->get_result();
$userData = $userResult->fetch_assoc();
$userFullName = $userData['FullName'] ?? $_SESSION['Username'];
$userQuery->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - First Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .change-password-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        .change-password-container h2 {
            margin-bottom: 10px;
            color: #2d3748;
            font-size: 24px;
            font-weight: 600;
        }

        .change-password-container p {
            color: #4a5568;
            margin-bottom: 30px;
            font-size: 14px;
            line-height: 1.6;
        }

        .icon-container {
            margin-bottom: 20px;
        }

        .icon-container i {
            font-size: 48px;
            color: #face0b;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 500;
            font-size: 14px;
        }

        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .error-message {
            color: #e53e3e;
            font-size: 14px;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #fed7d7;
            border-radius: 8px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #face0b;
            color: #000000;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.2);
            background: #e6c009;
        }

        .password-requirements {
            text-align: left;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 13px;
            color: #4a5568;
        }

        .password-requirements ul {
            margin: 0;
            padding-left: 20px;
        }

        .password-requirements li {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="change-password-container">
        <div class="icon-container">
            <i class="fas fa-key"></i>
        </div>
        <h2>Change Password Required</h2>
        <p>You must change your password before accessing the system.</p>
        
        <?php if ($error): ?>
            <div class="error-message show" id="errorMessage"><?php echo htmlspecialchars($error); ?></div>
        <?php else: ?>
            <div class="error-message" id="errorMessage"></div>
        <?php endif; ?>
        
        <div class="password-requirements">
            <strong>Password Requirements:</strong>
            <ul>
                <li>At least 6 characters long</li>
                <li>At least one uppercase letter</li>
                <li>At least one number</li>
            </ul>
        </div>
        
        <form method="POST" action="" id="changePasswordForm">
            <div class="form-group">
                <label for="newPassword">New Password</label>
                <input 
                    type="password" 
                    id="newPassword" 
                    name="newPassword" 
                    required 
                    autocomplete="new-password"
                    autofocus
                    placeholder="Enter new password"
                >
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm Password</label>
                <input 
                    type="password" 
                    id="confirmPassword" 
                    name="confirmPassword" 
                    required 
                    autocomplete="new-password"
                    placeholder="Confirm new password"
                >
            </div>
            <button type="submit">
                <i class="fas fa-key" style="margin-right: 6px;"></i>
                Change Password
            </button>
        </form>
    </div>

    <script>
        // Show error message if present
        <?php if ($error): ?>
            setTimeout(() => {
                document.getElementById('errorMessage').classList.add('show');
            }, 100);
        <?php endif; ?>

        // Validate passwords match on submit
        document.getElementById('changePasswordForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                document.getElementById('errorMessage').textContent = 'New passwords do not match.';
                document.getElementById('errorMessage').classList.add('show');
                return false;
            }
        });
    </script>
</body>
</html>

<?php
$conn->close();
?>
