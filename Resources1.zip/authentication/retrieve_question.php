<?php
require_once __DIR__ . '/../config/connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = $_POST['username'];
    
    // Prepare and execute query (case-sensitive username check)
    $stmt = $conn->prepare("SELECT RecoveryQuestion FROM loginaccount WHERE BINARY Username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Array of security questions
        $questions = [
            "What is your pet's name?",
            "What is your mother's maiden name?",
            "What was your first school?",
            "What is your favorite movie?",
            "What is your favorite color?",
            "What is your favorite food?",
            "What is your favorite book?",
            "What is your favorite sport?",
            "What is your favorite place?",
            "What is your favorite song?"
        ];
        
        echo json_encode([
            'success' => true,
            'questions' => $questions,
            'currentQuestion' => $row['RecoveryQuestion']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Username not found'
        ]);
    }
    
    $stmt->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request'
    ]);
}

$conn->close();
?> 