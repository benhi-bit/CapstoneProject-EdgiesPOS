<?php
// Database connection parameters
$servername = "localhost"; // Change if your database server is different
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "pos_inventory"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create active_sessions table if it doesn't exist
$createSessionsTable = "CREATE TABLE IF NOT EXISTS active_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_id VARCHAR(255) NOT NULL,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES loginaccount(UserID)
)";
$conn->query($createSessionsTable);

// Clean up expired sessions (older than 30 minutes)
$cleanupSessions = "DELETE FROM active_sessions WHERE last_activity < DATE_SUB(NOW(), INTERVAL 30 MINUTE)";
$conn->query($cleanupSessions);

session_start();
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../lib/ensure_2fa_column.php';

ensure2FAColumn($conn);

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the username and password from the form
    $username = $_POST['username']; // Make sure this matches the form input name
    $password = $_POST['password']; // Make sure this matches the form input name

    // Prepare and bind - now also get two_factor_secret (case-sensitive username check)
    $stmt = $conn->prepare("SELECT UserID, Username, Password, Role, FullName, two_factor_secret FROM loginaccount WHERE BINARY Username = ?");
    $stmt->bind_param("s", $username);

    // Execute the statement
    $stmt->execute();   
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows == 1) {
        // Fetch the user data
        $row = $result->fetch_assoc();
        
        if (password_verify($password, $row['Password'])) {
            // Check for existing active sessions
            $checkSession = $conn->prepare("SELECT * FROM active_sessions WHERE user_id = ?");
            $checkSession->bind_param("i", $row['UserID']);
            $checkSession->execute();
            $existingSession = $checkSession->get_result();
            
            if ($existingSession->num_rows > 0) {
                // User already has an active session
                header("Location: index.php?error=active_session");
                exit();
            }
            
            // Check if 2FA is enabled for this user
            $has2FA = !empty($row['two_factor_secret']);
            
            if ($has2FA) {
                // 2FA is enabled, redirect to verification page
                // Store pending login info in session (don't set full session yet)
                $_SESSION['pending_user_id'] = $row['UserID'];
                $_SESSION['pending_username'] = $row['Username'];
                $_SESSION['pending_role'] = $row['Role'];
                
                header("Location: verify_2fa.php");
                exit();
            } else {
                // 2FA is not set up, redirect to setup page
                // Store pending login info in session (don't set full session yet)
                $_SESSION['pending_user_id'] = $row['UserID'];
                $_SESSION['pending_username'] = $row['Username'];
                $_SESSION['pending_role'] = $row['Role'];
                
                header("Location: setup_2fa.php");
                exit();
            }
        } else {
            // Add failed login attempt log (case-sensitive username check)
            $stmt = $conn->prepare("SELECT FullName FROM loginaccount WHERE BINARY Username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $userData = $stmt->get_result()->fetch_assoc();
            $fullName = $userData ? $userData['FullName'] : 'Unknown User';
            addSystemLog($conn, "Login Failed", "Failed login attempt for username: " . $username, $fullName);
            
            header("Location: index.php?error=invalid");
        }
    } else {
        // Add failed login attempt log for non-existent user
        addSystemLog($conn, "Login Failed", "Failed login attempt for non-existent username: " . $username, "Unknown User");
        header("Location: index.php?error=invalid");
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>