<?php
session_start();
require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/ensure_2fa_column.php';
require_once __DIR__ . '/../lib/ensure_active_sessions_table.php';
require_once __DIR__ . '/../lib/ensure_password_changed_column.php';
require_once __DIR__ . '/../lib/log_helper.php';
require_once __DIR__ . '/../vendor/autoload.php';

use Sonata\GoogleAuthenticator\GoogleAuthenticator;
use Sonata\GoogleAuthenticator\GoogleQrUrl;

ensure2FAColumn($conn);
ensureActiveSessionsTable($conn);
ensurePasswordChangedColumn($conn);

// Check if user is in the middle of login process
if (!isset($_SESSION['pending_user_id']) || !isset($_SESSION['pending_username']) || !isset($_SESSION['pending_role'])) {
    header('Location: ../index.php');
    exit();
}

$ga = new GoogleAuthenticator();
$error = '';
$success = false;

// Get user info
$userQuery = $conn->prepare("SELECT FullName, two_factor_secret, password_changed FROM loginaccount WHERE UserID = ?");
$userQuery->bind_param("i", $_SESSION['pending_user_id']);
$userQuery->execute();
$userResult = $userQuery->get_result();
$userData = $userResult->fetch_assoc();
$userQuery->close();

// Check if 2FA is already set up
if (!empty($userData['two_factor_secret'])) {
    // Already set up, redirect to verification
    header('Location: verify_2fa.php');
    exit();
}

// Handle form submission first (before generating new secret)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = $_POST['code'] ?? '';
    
    // Get the secret from session (the one that was shown in QR code)
    if (!isset($_SESSION['2fa_secret']) || empty($_SESSION['2fa_secret'])) {
        $error = 'Session expired. Please refresh the page and try again.';
    } else {
        $secret = $_SESSION['2fa_secret'];
        
        if (empty($code)) {
            $error = 'Please enter the verification code';
        } else {
            // Verify the code using the same secret that was shown in QR code
            if ($ga->checkCode($secret, $code)) {
                // Code is valid, save secret to database
                $updateStmt = $conn->prepare("UPDATE loginaccount SET two_factor_secret = ? WHERE UserID = ?");
                $updateStmt->bind_param("si", $secret, $_SESSION['pending_user_id']);
                $updateStmt->execute();
                $updateStmt->close();
                
                // Clear the temporary secret from session
                unset($_SESSION['2fa_secret']);
                
                $success = true;
                
                // Complete login
                $_SESSION['UserID'] = $_SESSION['pending_user_id'];
                $_SESSION['Username'] = $_SESSION['pending_username'];
                $_SESSION['Role'] = $_SESSION['pending_role'];
                $_SESSION['2fa_verified'] = true;
                
                // Record the new session
                $sessionStmt = $conn->prepare("INSERT INTO active_sessions (user_id, session_id) VALUES (?, ?)");
                $sessionStmt->bind_param("is", $_SESSION['pending_user_id'], session_id());
                $sessionStmt->execute();
                $sessionStmt->close();
                
                // Add login log with specific details for POS users
                if ($_SESSION['pending_role'] == 'Cashier') {
                    addSystemLog($conn, "POS Login", "Cashier started POS session (2FA setup completed)", $userData['FullName']);
                } else {
                    addSystemLog($conn, "Login", "User logged in successfully (2FA setup completed)", $userData['FullName']);
                }
                
                // Check if password needs to be changed on first login
                $passwordChanged = isset($userData['password_changed']) ? (bool)$userData['password_changed'] : false;
                
                // Clear pending session variables
                unset($_SESSION['pending_user_id']);
                unset($_SESSION['pending_username']);
                unset($_SESSION['pending_role']);
                
                // If password hasn't been changed, redirect to change password page
                if (!$passwordChanged) {
                    header("Location: change_password_first.php");
                    exit();
                }
                
                // Redirect based on role
                if ($_SESSION['Role'] == 'Admin') {
                    header("Location: ../admin/dashboard.php");
                } else {
                    header("Location: ../cashier/pos.php");
                }
                exit();
            } else {
                $error = 'Invalid verification code. Please try again.';
            }
        }
    }
} else {
    // GET request - generate a new secret for this user account
    // Clear any existing session secret first to ensure it's fresh
    unset($_SESSION['2fa_secret']);
    $_SESSION['2fa_secret'] = $ga->generateSecret();
}

// Get the secret (either from session for POST, or newly generated for GET)
$secret = $_SESSION['2fa_secret'] ?? '';
$accountName = $userData['FullName'] . ' (' . $_SESSION['pending_username'] . ')';
$issuer = 'Edgie\'s POS System';
$qrCodeUrl = GoogleQrUrl::generate($accountName, $secret, $issuer, 200);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Two-Factor Authentication</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Remove yellow validation borders from SweetAlert */
        .swal2-input,
        .swal2-textarea,
        .swal2-select,
        .swal2-file {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-input.swal2-inputerror,
        .swal2-textarea.swal2-inputerror,
        .swal2-select.swal2-inputerror,
        .swal2-file.swal2-inputerror {
            border: 1px solid #d1d5db !important;
            box-shadow: none !important;
        }
        
        .swal2-validation-message {
            display: none !important;
        }
        
        /* Remove yellow borders from SweetAlert icons and popup */
        .swal2-icon.swal2-question {
            border-color: #c9dae1 !important;
            color: #87adbd !important;
        }
        
        .swal2-icon.swal2-warning {
            border-color: #face0b !important;
        }
        
        .swal2-popup {
            border: none !important;
        }
        
        /* Remove any yellow outlines or borders */
        .swal2-popup * {
            outline: none !important;
        }
        
        .swal2-popup:focus,
        .swal2-popup:focus-within {
            outline: none !important;
            box-shadow: none !important;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }

        .setup-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }

        .setup-container h2 {
            margin-bottom: 10px;
            color: #2d3748;
            font-size: 24px;
            font-weight: 600;
        }

        .setup-container p {
            color: #4a5568;
            margin-bottom: 30px;
            font-size: 14px;
            line-height: 1.6;
        }

        .icon-container {
            margin-bottom: 20px;
        }

        .icon-container i {
            font-size: 48px;
            color: #face0b;
        }

        .qr-code-container {
            margin: 30px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
        }

        .qr-code-container img {
            max-width: 100%;
            height: auto;
            border: 3px solid #fff;
            border-radius: 8px;
        }

        .secret-key {
            margin: 20px 0;
            padding: 15px;
            background-color: #edf2f7;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 16px;
            font-weight: 600;
            color: #2d3748;
            word-break: break-all;
            letter-spacing: 2px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #4a5568;
            font-weight: 500;
            font-size: 14px;
        }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 18px;
            text-align: center;
            letter-spacing: 8px;
            box-sizing: border-box;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus {
            outline: none;
            border-color: #face0b;
            box-shadow: 0 0 0 3px rgba(250, 206, 11, 0.1);
        }

        .error-message {
            color: #e53e3e;
            font-size: 14px;
            margin-bottom: 15px;
            padding: 10px;
            background-color: #fed7d7;
            border-radius: 8px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #face0b;
            color: #000000;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(250, 206, 11, 0.2);
            background: #e6c009;
        }

        .instructions {
            text-align: left;
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .instructions ol {
            margin: 0;
            padding-left: 20px;
        }

        .instructions li {
            margin-bottom: 10px;
            color: #4a5568;
            font-size: 14px;
        }

        .copy-btn {
            margin-top: 10px;
            padding: 8px 15px;
            background: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            transition: background 0.3s ease;
        }

        .copy-btn:hover {
            background: #555;
        }
    </style>
</head>
<body>
    <div class="setup-container">
        <div class="icon-container">
            <i class="fas fa-mobile-alt"></i>
        </div>
        <h2>Setup Two-Factor Authentication</h2>
        <p>Scan the QR code with your authenticator app to enable 2FA</p>
        
        <?php if ($error): ?>
            <div class="error-message show" id="errorMessage"><?php echo htmlspecialchars($error); ?></div>
        <?php else: ?>
            <div class="error-message" id="errorMessage"></div>
        <?php endif; ?>
        
        <div class="instructions">
            <ol>
                <li>Install Google Authenticator app on your mobile device</li>
                <li>Open the app and tap the "+" button</li>
                <li>Scan the QR code below or enter the secret key manually</li>
                <li>Enter the 6-digit code from the app to verify</li>
            </ol>
        </div>
        
        <div class="qr-code-container">
            <?php if (!empty($qrCodeUrl)): ?>
                <img src="<?php echo htmlspecialchars($qrCodeUrl); ?>" alt="QR Code" onerror="this.style.display='none'; document.getElementById('qrError').style.display='block';">
                <div id="qrError" style="display: none; color: #e53e3e; padding: 10px; background: #fed7d7; border-radius: 8px; margin-top: 10px;">
                    <p><strong>QR Code could not be loaded.</strong></p>
                    <p>Please use the secret key below to manually add the account to your authenticator app.</p>
                </div>
            <?php else: ?>
                <div style="color: #e53e3e; padding: 10px; background: #fed7d7; border-radius: 8px;">
                    <p><strong>QR Code could not be generated.</strong></p>
                    <p>Please use the secret key below to manually add the account to your authenticator app.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="secret-key">
            <strong>Secret Key:</strong><br>
            <span id="secretKey"><?php echo htmlspecialchars($secret); ?></span>
            <button class="copy-btn" onclick="copySecret()">
                <i class="fas fa-copy"></i> Copy Secret Key
            </button>
        </div>
        
        <form method="POST" action="" id="setupForm">
            <div class="form-group">
                <label for="code">Enter Verification Code</label>
                <input 
                    type="text" 
                    id="code" 
                    name="code" 
                    maxlength="6" 
                    pattern="[0-9]{6}" 
                    required 
                    autocomplete="off"
                    autofocus
                    placeholder="000000"
                >
            </div>
            <button type="submit">
                <i class="fas fa-shield-alt" style="margin-right: 6px;"></i>
                Verify & Complete Setup
            </button>
        </form>
    </div>

    <script>
        // Auto-focus and format input
        const codeInput = document.getElementById('code');
        
        // Only allow numbers
        codeInput.addEventListener('input', function(e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Auto-submit when 6 digits are entered
        codeInput.addEventListener('input', function(e) {
            if (this.value.length === 6) {
                // Small delay to show the last digit
                setTimeout(() => {
                    document.getElementById('setupForm').submit();
                }, 100);
            }
        });

        // Copy secret key to clipboard
        function copySecret() {
            const secretKey = document.getElementById('secretKey').textContent;
            navigator.clipboard.writeText(secretKey).then(function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Copied!',
                    text: 'Secret key copied to clipboard',
                    timer: 2000,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            }, function(err) {
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = secretKey;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                Swal.fire({
                    icon: 'success',
                    title: 'Copied!',
                    text: 'Secret key copied to clipboard',
                    timer: 2000,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            });
        }

        // Show error message if present
        <?php if ($error): ?>
            setTimeout(() => {
                document.getElementById('errorMessage').classList.add('show');
            }, 100);
        <?php endif; ?>
    </script>
</body>
</html>

<?php
$conn->close();
?>

