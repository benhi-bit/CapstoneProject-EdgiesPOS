// Function to check for new logs
function checkNewLogs() {
    fetch('../api/log_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.logs.length > 0) {
                data.logs.forEach(log => {
                    showNotification(log);
                });
            }
        })
        .catch(error => console.error('Error checking logs:', error));
}

// Function to show notification
function showNotification(log) {
    const Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 5000,
        timerProgressBar: true,
        didOpen: (toast) => {
            toast.addEventListener('mouseenter', Swal.stopTimer)
            toast.addEventListener('mouseleave', Swal.resumeTimer)
        }
    });

    Toast.fire({
        icon: getNotificationIcon(log.action),
        title: log.action,
        text: `${log.description} - by ${log.user}`,
        customClass: {
            popup: 'animated fadeInDown'
        }
    });
}

// Function to determine notification icon based on action
function getNotificationIcon(action) {
    const actionLower = action.toLowerCase();
    if (actionLower.includes('error') || actionLower.includes('failed')) {
        return 'error';
    } else if (actionLower.includes('warning')) {
        return 'warning';
    } else if (actionLower.includes('success') || actionLower.includes('created') || actionLower.includes('updated')) {
        return 'success';
    }
    return 'info';
}

// Check for new logs every 30 seconds
setInterval(checkNewLogs, 30000);

// Initial check when page loads
document.addEventListener('DOMContentLoaded', checkNewLogs); 