// Live Search Functionality
document.getElementById('searchInput').addEventListener('keyup', function() {
    let searchText = this.value.toLowerCase();
    let table = document.querySelector('table');
    let rows = table.getElementsByTagName('tr');

    // Start from index 1 to skip the header row
    for (let i = 1; i < rows.length; i++) {
        let row = rows[i];
        let cells = row.getElementsByTagName('td');
        let found = false;

        // Search through all cells in the row
        for (let j = 0; j < cells.length; j++) {
            let cell = cells[j];
            if (cell.textContent.toLowerCase().indexOf(searchText) > -1) {
                found = true;
                break;
            }
        }

        // Show/hide row based on search
        row.style.display = found ? '' : 'none';
    }
});

// Get the modal for adding user
var modal = document.getElementById("userModal");
var btn = document.getElementById("addUserBtn");
var span = document.getElementsByClassName("close")[0];

function openAddUserModal() {
    modal.style.display = "flex";
    modal.classList.add("show");
    document.body.classList.add("no-scroll");
}

function closeAddUserModal() {
    modal.style.display = "none";
    modal.classList.remove("show");
    document.body.classList.remove("no-scroll");
}

// Open the add user modal
btn.onclick = openAddUserModal;

// Close the add user modal
span.onclick = closeAddUserModal;

// Close the modal when clicking outside of it
window.addEventListener('click', function(event) {
    if (event.target == modal) {
        closeAddUserModal();
    }
});

// Get the modal for editing user
var editModal = document.getElementById("editUserModal");
var editSpan = document.getElementsByClassName("closeEdit")[0];

function openEditUserModal() {
    editModal.style.display = "flex";
    editModal.classList.add("show");
    document.body.classList.add("no-scroll");
    
    // Reset password fields when opening modal
    const editPassword = document.getElementById('editPassword');
    const editConfirmPassword = document.getElementById('editConfirmPassword');
    if (editPassword) editPassword.value = '';
    if (editConfirmPassword) editConfirmPassword.value = '';
    
    // Reset password validation indicators
    const reqLength = document.getElementById('edit-req-length');
    const reqUppercase = document.getElementById('edit-req-uppercase');
    const reqNumber = document.getElementById('edit-req-number');
    const passwordMatchIndicator = document.getElementById('edit-password-match-indicator');
    
    if (reqLength) {
        reqLength.classList.remove('valid');
        const icon = reqLength.querySelector('i');
        if (icon) icon.className = 'fas fa-circle';
    }
    if (reqUppercase) {
        reqUppercase.classList.remove('valid');
        const icon = reqUppercase.querySelector('i');
        if (icon) icon.className = 'fas fa-circle';
    }
    if (reqNumber) {
        reqNumber.classList.remove('valid');
        const icon = reqNumber.querySelector('i');
        if (icon) icon.className = 'fas fa-circle';
    }
    if (passwordMatchIndicator) {
        passwordMatchIndicator.textContent = 'Enter the same password again if changing';
        passwordMatchIndicator.classList.remove('match', 'mismatch');
    }
}

function closeEditUserModal() {
    editModal.style.display = "none";
    editModal.classList.remove("show");
    document.body.classList.remove("no-scroll");
}

// Event listener for edit buttons
document.querySelectorAll('.editBtn').forEach(button => {
    button.onclick = function() {
        var userId = this.getAttribute('data-id');
        var role = this.getAttribute('data-role');
        var fullName = this.getAttribute('data-fullname');
        var username = this.getAttribute('data-username');
        var email = this.getAttribute('data-email');

        document.getElementById("editUserID").value = userId;
        document.getElementById("editRole").value = role;
        document.getElementById("editFullName").value = fullName;
        document.getElementById("editUsername").value = username;
        document.getElementById("editEmail").value = email;
        var previousEmailLabel = document.getElementById("previousEmailDisplay");
        if (previousEmailLabel) {
            previousEmailLabel.textContent = email ? `Previous email: ${email}` : '';
        }

        openEditUserModal();
    }
});

// Close the edit user modal
editSpan.onclick = closeEditUserModal;

// Close the modal when clicking outside of it
window.addEventListener('click', function(event) {
    if (event.target == editModal) {
        closeEditUserModal();
    }
});

// Add this to your existing script section
function showSuccessMessage() {
    Swal.fire({
        title: 'Success!',
        text: 'User added successfully!',
        icon: 'success',
        confirmButtonColor: '#face0b',
        timer: 3000,
        timerProgressBar: true,
        customClass: {
            container: 'swal-above-modal'
        }
    });
}

// Add password validation to the form submission
document.getElementById('addUserForm').addEventListener('submit', function(event) {
    const fullName = document.getElementById('fullName').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const passwordPattern = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/;
    const namePattern = /^[A-Za-z\s]+$/;
    
    if (!namePattern.test(fullName)) {
        event.preventDefault();
        Swal.fire({
            title: 'Invalid Full Name!',
            text: 'Full name should only contain letters and spaces',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
        return false;
    }

    if (!passwordPattern.test(password)) {
        event.preventDefault();
        Swal.fire({
            title: 'Invalid Password!',
            text: 'Password must be at least 6 characters long and contain at least one uppercase letter and one number',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
        return false;
    }

    if (password !== confirmPassword) {
        event.preventDefault();
        Swal.fire({
            title: 'Passwords Do Not Match!',
            text: 'Please make sure both passwords are identical',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
        return false;
    }
    
    // Continue with the existing form submission code...
    event.preventDefault();
    
    const form = this;
    const formData = new FormData(form);

    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]') || form.querySelector('input[type="submit"]');
    if (!submitButton) {
        console.error('Submit button not found');
        return;
    }
    const originalButtonText = submitButton.textContent || submitButton.value;
    if (submitButton.tagName === 'BUTTON') {
        submitButton.textContent = 'Adding...';
    } else {
    submitButton.value = 'Adding...';
    }
    submitButton.disabled = true;

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message using SweetAlert2
            Swal.fire({
                title: 'Success!',
                text: 'User added successfully!',
                icon: 'success',
                confirmButtonColor: '#face0b',
                timer: 1500,
                timerProgressBar: true,
                customClass: {
                    container: 'swal-above-modal'
                }
            });
            
            // Reset form and close modal
            form.reset();
            closeAddUserModal();
            
            // Reload the page to show new user
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            // Show specific error message
            Swal.fire({
                title: 'Error!',
                text: data.message,
                icon: 'error',
                confirmButtonColor: '#face0b',
                customClass: {
                    container: 'swal-above-modal'
                }
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            title: 'Error!',
            text: 'Error adding user. Please try again.',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
    })
    .finally(() => {
        // Reset button state
        if (submitButton.tagName === 'BUTTON') {
            submitButton.textContent = originalButtonText;
        } else {
        submitButton.value = originalButtonText;
        }
        submitButton.disabled = false;
    });
});

// Add remove functionality
document.querySelectorAll('.removeBtn').forEach(button => {
    button.onclick = function() {
        Swal.fire({
            title: 'Remove this user?',
            text: "Removed accounts move to Backup & Recovery where they can be restored.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#333',
            confirmButtonText: 'Yes, remove'
        }).then((result) => {
            if (result.isConfirmed) {
                const userId = this.getAttribute('data-id');
                
                // AJAX request to remove user
                fetch('remove_user.php?id=' + userId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Show success message
                            Swal.fire({
                                title: 'Removed!',
                                text: 'User has been moved to recovery.',
                                icon: 'success',
                                confirmButtonColor: '#face0b'
                            });
                            
                            // Remove the row from the table
                            this.closest('tr').remove();
                        } else {
                            Swal.fire({
                                title: 'Error!',
                                text: data.message || 'Error removing user. Please try again.',
                                icon: 'error',
                                confirmButtonColor: '#face0b'
                            });
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        Swal.fire({
                            title: 'Error!',
                            text: 'Error removing user. Please try again.',
                            icon: 'error',
                            confirmButtonColor: '#face0b'
                        });
                    });
            }
        });
    }
});

// Add edit form submission handler
document.getElementById('editUserForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const form = this;
    const fullName = document.getElementById('editFullName').value;
    const password = document.getElementById('editPassword').value;
    const confirmPassword = document.getElementById('editConfirmPassword').value;
    const namePattern = /^[A-Za-z\s]+$/;
    
    // Validate full name
    if (!namePattern.test(fullName)) {
        Swal.fire({
            title: 'Invalid Full Name!',
            text: 'Full name should only contain letters and spaces',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
        return false;
    }

    // Validate password if provided
    if (password || confirmPassword) {
        if (!password || !confirmPassword) {
            Swal.fire({
                title: 'Password Required!',
                text: 'Please enter and confirm the new password, or leave both fields blank to keep the current password.',
                icon: 'error',
                confirmButtonColor: '#face0b',
                customClass: {
                    container: 'swal-above-modal'
                }
            });
            return false;
        }

        const passwordPattern = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/;
        if (!passwordPattern.test(password)) {
            Swal.fire({
                title: 'Invalid Password!',
                text: 'Password must be at least 6 characters long and contain at least one uppercase letter and one number',
                icon: 'error',
                confirmButtonColor: '#face0b',
                customClass: {
                    container: 'swal-above-modal'
                }
            });
            return false;
        }

        if (password !== confirmPassword) {
            Swal.fire({
                title: 'Passwords Do Not Match!',
                text: 'Please make sure both passwords are identical',
                icon: 'error',
                confirmButtonColor: '#face0b',
                customClass: {
                    container: 'swal-above-modal'
                }
            });
            return false;
        }
    }
    
    const formData = new FormData(form);

    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]') || form.querySelector('input[type="submit"]');
    if (!submitButton) {
        console.error('Submit button not found');
        return;
    }
    const originalButtonText = submitButton.textContent || submitButton.value;
    if (submitButton.tagName === 'BUTTON') {
        submitButton.textContent = 'Updating...';
    } else {
    submitButton.value = 'Updating...';
    }
    submitButton.disabled = true;

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success message
            Swal.fire({
                title: 'Success!',
                text: data.message,
                icon: 'success',
                confirmButtonColor: '#face0b',
                timer: 1500,
                timerProgressBar: true,
                customClass: {
                    container: 'swal-above-modal'
                }
            });
            
            // Close modal
            closeEditUserModal();
            
            // Reload the page to show updated data
            setTimeout(() => {
                window.location.reload();
            }, 1500);
        } else {
            Swal.fire({
                title: 'Error!',
                text: data.message || 'Error updating user. Please try again.',
                icon: 'error',
                confirmButtonColor: '#face0b',
                customClass: {
                    container: 'swal-above-modal'
                }
            });
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire({
            title: 'Error!',
            text: 'Error updating user. Please try again.',
            icon: 'error',
            confirmButtonColor: '#face0b',
            customClass: {
                container: 'swal-above-modal'
            }
        });
    })
    .finally(() => {
        // Reset button state
        if (submitButton.tagName === 'BUTTON') {
            submitButton.textContent = originalButtonText;
        } else {
        submitButton.value = originalButtonText;
        }
        submitButton.disabled = false;
    });
});

// Add this function to toggle password visibility
function togglePassword(inputId) {
    const passwordInput = document.getElementById(inputId);
    const button = passwordInput.parentElement.querySelector('.toggle-password');
    const icon = button.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Real-time password validation and form enhancements
document.addEventListener('DOMContentLoaded', function() {
    // Full name auto-capitalization
    const fullNameInput = document.getElementById('fullName');
    if (fullNameInput) {
        fullNameInput.addEventListener('input', function(e) {
            let value = e.target.value;
            if (value) {
                e.target.value = capitalizeWords(value);
            }
        });
    }
    
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const passwordMatchIndicator = document.getElementById('password-match-indicator');
    
    if (passwordInput) {
        // Password strength validation
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const reqLength = document.getElementById('req-length');
            const reqUppercase = document.getElementById('req-uppercase');
            const reqNumber = document.getElementById('req-number');
            
            // Check length
            if (reqLength) {
                if (password.length >= 6) {
                    reqLength.classList.add('valid');
                    const icon = reqLength.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqLength.classList.remove('valid');
                    const icon = reqLength.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check uppercase
            if (reqUppercase) {
                if (/[A-Z]/.test(password)) {
                    reqUppercase.classList.add('valid');
                    const icon = reqUppercase.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqUppercase.classList.remove('valid');
                    const icon = reqUppercase.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check number
            if (reqNumber) {
                if (/\d/.test(password)) {
                    reqNumber.classList.add('valid');
                    const icon = reqNumber.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqNumber.classList.remove('valid');
                    const icon = reqNumber.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check password match if confirm password has value
            if (confirmPasswordInput && confirmPasswordInput.value && passwordMatchIndicator) {
                checkPasswordMatch();
            }
        });
    }
    
    // Password match validation
    function checkPasswordMatch() {
        if (!passwordInput || !confirmPasswordInput || !passwordMatchIndicator) return;
        
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        if (confirmPassword === '') {
            passwordMatchIndicator.textContent = 'Enter the same password again';
            passwordMatchIndicator.classList.remove('match', 'mismatch');
            return;
        }
        
        if (password === confirmPassword && password !== '') {
            passwordMatchIndicator.textContent = '✓ Passwords match';
            passwordMatchIndicator.classList.add('match');
            passwordMatchIndicator.classList.remove('mismatch');
        } else {
            passwordMatchIndicator.textContent = '✗ Passwords do not match';
            passwordMatchIndicator.classList.add('mismatch');
            passwordMatchIndicator.classList.remove('match');
        }
    }
    
    if (confirmPasswordInput && passwordMatchIndicator) {
        confirmPasswordInput.addEventListener('input', checkPasswordMatch);
    }
});

// Add this function to capitalize first letter of each word
function capitalizeWords(input) {
    return input.replace(/\b\w/g, function(char) {
        return char.toUpperCase();
    });
}

// Add event listener to the edit form full name input field
document.addEventListener('DOMContentLoaded', function() {
    const editFullNameInput = document.getElementById('editFullName');
    if (editFullNameInput) {
        editFullNameInput.addEventListener('input', function(e) {
    let value = e.target.value;
    // Only process if there's a value
    if (value) {
        e.target.value = capitalizeWords(value);
    }
});
    }
    
    // Password validation for edit form
    const editPasswordInput = document.getElementById('editPassword');
    const editConfirmPasswordInput = document.getElementById('editConfirmPassword');
    const editPasswordMatchIndicator = document.getElementById('edit-password-match-indicator');
    
    if (editPasswordInput) {
        editPasswordInput.addEventListener('input', function() {
            const password = this.value;
            const reqLength = document.getElementById('edit-req-length');
            const reqUppercase = document.getElementById('edit-req-uppercase');
            const reqNumber = document.getElementById('edit-req-number');
            
            // Only show validation if password is being entered
            if (password === '') {
                if (reqLength) {
                    reqLength.classList.remove('valid');
                    const icon = reqLength.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
                if (reqUppercase) {
                    reqUppercase.classList.remove('valid');
                    const icon = reqUppercase.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
                if (reqNumber) {
                    reqNumber.classList.remove('valid');
                    const icon = reqNumber.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
                return;
            }
            
            // Check length
            if (reqLength) {
                if (password.length >= 6) {
                    reqLength.classList.add('valid');
                    const icon = reqLength.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqLength.classList.remove('valid');
                    const icon = reqLength.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check uppercase
            if (reqUppercase) {
                if (/[A-Z]/.test(password)) {
                    reqUppercase.classList.add('valid');
                    const icon = reqUppercase.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqUppercase.classList.remove('valid');
                    const icon = reqUppercase.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check number
            if (reqNumber) {
                if (/\d/.test(password)) {
                    reqNumber.classList.add('valid');
                    const icon = reqNumber.querySelector('i');
                    if (icon) icon.className = 'fas fa-check-circle';
                } else {
                    reqNumber.classList.remove('valid');
                    const icon = reqNumber.querySelector('i');
                    if (icon) icon.className = 'fas fa-circle';
                }
            }
            
            // Check password match if confirm password has value
            if (editConfirmPasswordInput && editConfirmPasswordInput.value && editPasswordMatchIndicator) {
                checkEditPasswordMatch();
            }
        });
    }
    
    // Password match validation for edit form
    function checkEditPasswordMatch() {
        if (!editPasswordInput || !editConfirmPasswordInput || !editPasswordMatchIndicator) return;
        
        const password = editPasswordInput.value;
        const confirmPassword = editConfirmPasswordInput.value;
        
        if (password === '' && confirmPassword === '') {
            editPasswordMatchIndicator.textContent = 'Enter the same password again if changing';
            editPasswordMatchIndicator.classList.remove('match', 'mismatch');
            return;
        }
        
        if (password === confirmPassword && password !== '') {
            editPasswordMatchIndicator.textContent = '✓ Passwords match';
            editPasswordMatchIndicator.classList.add('match');
            editPasswordMatchIndicator.classList.remove('mismatch');
        } else if (confirmPassword !== '') {
            editPasswordMatchIndicator.textContent = '✗ Passwords do not match';
            editPasswordMatchIndicator.classList.add('mismatch');
            editPasswordMatchIndicator.classList.remove('match');
        }
    }
    
    if (editConfirmPasswordInput && editPasswordMatchIndicator) {
        editConfirmPasswordInput.addEventListener('input', checkEditPasswordMatch);
    }
}); 