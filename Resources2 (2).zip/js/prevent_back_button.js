/**
 * Prevents users from accessing pages using browser back/forward buttons
 * When back/forward is detected, user is redirected to login page
 */

(function() {
    'use strict';
    
    // Check if we're on a protected page (not login page or 2FA pages)
    const currentPath = window.location.pathname.toLowerCase();
    const isProtectedPage = !currentPath.includes('index.php') &&
                           !currentPath.includes('verify_2fa.php') &&
                           !currentPath.includes('setup_2fa.php') &&
                           !currentPath.includes('login_process.php');
    
    if (isProtectedPage) {
        // Method 1: Use history API to detect back/forward navigation
        let isNavigating = false;
        
        // Push a new state when page loads
        if (window.history && window.history.pushState) {
            window.history.pushState(null, null, window.location.href);
            
            // Listen for popstate event (back/forward button)
            window.addEventListener('popstate', function(event) {
                if (!isNavigating) {
                    isNavigating = true;
                    // Redirect to login page
                    window.location.href = '../index.php';
                }
            });
        }
        
        // Method 2: Use pageshow event to detect back/forward navigation
        window.addEventListener('pageshow', function(event) {
            // If page was loaded from cache (back/forward button), redirect
            if (event.persisted) {
                window.location.href = '../index.php';
            }
        });
        
        // Method 3: Prevent form resubmission on back button
        if (window.history && window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
        
        // Method 4: Additional check using performance navigation API (legacy)
        if (window.performance && window.performance.navigation) {
            // TYPE_BACK_FORWARD = 2
            if (window.performance.navigation.type === 2) {
                window.location.href = '../index.php';
            }
        }
        
        // Method 5: Check using Navigation Timing API (modern browsers)
        if (window.performance && window.performance.getEntriesByType) {
            try {
                const navEntries = window.performance.getEntriesByType('navigation');
                if (navEntries.length > 0 && navEntries[0].type === 'back_forward') {
                    window.location.href = '../index.php';
                }
            } catch (e) {
                // Navigation Timing API not supported, continue with other methods
            }
        }
    }
})();

