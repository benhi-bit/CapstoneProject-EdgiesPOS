// Function to check if user account still exists
function checkUserAccount() {
    fetch('../api/check_user_exists.php')
        .then(response => response.json())
        .then(data => {
            if (!data.exists) {
                // Show alert and redirect to login page
                Swal.fire({
                    icon: 'warning',
                    title: 'Account Deleted',
                    text: 'Your account has been deleted. You will be redirected to the login page.',
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#face0b',
                    allowOutsideClick: false
                }).then(() => {
                    window.location.href = '../authentication/logout.php';
                });
            }
        })
        .catch(error => {
            console.error('Error checking user account:', error);
        });
}

// Check user account every 30 seconds
setInterval(checkUserAccount, 30000);

// Also check when the page loads
document.addEventListener('DOMContentLoaded', checkUserAccount); 