<?php
// Include this on every admin page (before </body>) so scheduled backup runs at the set time.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['Role']) || $_SESSION['Role'] !== 'Admin') {
    return;
}
?>
<script>
(function() {
    var POLL_INTERVAL_MS = 10000;

    function fetchSchedule() {
        return fetch('get_backup_schedule.php', { credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .catch(function() { return {}; });
    }

    function triggerBackupDownload() {
        var url = 'run_scheduled_backup_and_download.php?t=' + Date.now();
        fetch(url, { credentials: 'same-origin' })
            .then(function(res) {
                var ct = (res.headers.get('Content-Type') || '').toLowerCase();
                if (!res.ok || (ct.indexOf('octet-stream') === -1 && ct.indexOf('application/sql') === -1)) return;
                var disp = res.headers.get('Content-Disposition') || '';
                var filename = 'edgies_pos_backup.sql';
                var m = disp.match(/filename="?([^";\n]+)"?/);
                if (m) filename = m[1].trim();
                return res.blob().then(function(blob) {
                    if (blob.size === 0) return;
                    var u = URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = u;
                    a.download = filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(u);
                });
            })
            .catch(function() {});
    }

    function tick() {
        fetchSchedule().then(function(data) {
            if (data.is_due) {
                triggerBackupDownload();
            }
        });
    }

    function startPolling() {
        tick();
        setInterval(tick, POLL_INTERVAL_MS);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startPolling);
    } else {
        startPolling();
    }
})();
</script>
