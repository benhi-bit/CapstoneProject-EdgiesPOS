<?php
// Admin Sidebar component for EDGIE'S POS System
// Usage: include 'includes/admin_sidebar.php'; 
// The $currentPage variable should be set before including this file
// Note: This sidebar is designed for admin pages with user management functionality

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current page if not set
if (!isset($currentPage)) {
    $currentPage = basename($_SERVER['PHP_SELF']);
}

// Get user role and full name
$userRole = isset($_SESSION['Role']) ? $_SESSION['Role'] : '';
$userFullName = isset($userFullName) ? $userFullName : (isset($_SESSION['FullName']) ? $_SESSION['FullName'] : 'Admin');

// Function to check if a page is active
if (!function_exists('isActive')) {
    function isActive($page, $current) {
        return ($page === $current) ? 'active' : '';
    }
}
?>

<!-- Sidebar -->
<nav class="sidebar">
    <?php
    // Function to check if a page is active (local scope)
    function isActiveSidebar($page, $current) {
        return ($page === $current) ? 'active' : '';
    }
    ?>
    
    <!-- Logo -->
    <div class="sidebar-logo" onclick="toggleSidebar()">
        <img src="../images/logo.png" alt="EDGIE'S POS Logo">
        <div class="restaurant-name">Edgie's Restaurant and Events Place</div>
    </div>

    <!-- Navigation Items Container (Scrollable) -->
    <div class="sidebar-nav-items">
        <a href="dashboard.php" class="<?php echo isActiveSidebar('dashboard.php', $currentPage); ?>">
            <i class="fas fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
        <a href="manage_product.php" class="<?php echo isActiveSidebar('manage_product.php', $currentPage); ?>">
            <i class="fas fa-box"></i>
            <span>Manage Product</span>
        </a>
        <a href="category.php" class="<?php echo isActiveSidebar('category.php', $currentPage); ?>">
            <i class="fas fa-list-alt"></i>
            <span>Category</span>
        </a>
        <a href="transaction_history.php" class="<?php echo isActiveSidebar('transaction_history.php', $currentPage); ?>">
            <i class="fas fa-receipt"></i>
            <span>Transaction<br>History</span>
        </a>
        <a href="user_management.php" class="<?php echo isActiveSidebar('user_management.php', $currentPage); ?>">
            <i class="fas fa-users-cog"></i>
            <span>User<br>Management</span>
        </a>
        <a href="log_history.php" class="<?php echo isActiveSidebar('log_history.php', $currentPage); ?>">
            <i class="fas fa-history"></i>
            <span>Log History</span>
        </a>
        <a href="backup_recovery.php" class="<?php echo isActiveSidebar('backup_recovery.php', $currentPage); ?>">
            <i class="fas fa-recycle"></i>
            <span>Backup &amp; Restore</span>
        </a>
        <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActiveSidebar('../authentication/logout.php', $currentPage); ?>">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>

    <!-- Admin Info at Bottom -->
    <div class="sidebar-footer">
        <div class="cashier-name">
            <i class="fas fa-user"></i>
            <span><?php echo htmlspecialchars($userFullName); ?></span>
        </div>
        <div class="sidebar-datetime">
            <div id="sidebar-date"></div>
            <div id="sidebar-time"></div>
        </div>
    </div>
</nav>

<style>
    /* Sidebar Styles */
    nav.sidebar {
        width: 70px;
        background-color: #333;
        height: 100vh;
        position: fixed;
        top: 0;
        left: 0;
        overflow-x: hidden;
        overflow-y: auto;
        z-index: 999;
        display: flex;
        flex-direction: column;
        transition: width 0.3s ease;
    }
    
    /* Disable transitions on page load */
    nav.sidebar.no-transition,
    nav.sidebar.no-transition * {
        transition: none !important;
    }

    nav.sidebar.sidebar-expanded {
        width: 200px;
    }

    /* Navigation items container - scrollable */
    .sidebar-nav-items {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        padding-top: 20px;
        padding-bottom: 10px;
        min-height: 0; /* Important for flex scrolling */
    }

    nav.sidebar.sidebar-expanded .sidebar-nav-items {
        overflow-y: auto;
    }

    /* Custom scrollbar styling */
    .sidebar-nav-items::-webkit-scrollbar {
        width: 6px;
    }

    .sidebar-nav-items::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.2);
    }

    .sidebar-nav-items::-webkit-scrollbar-thumb {
        background: rgba(255, 255, 255, 0.3);
        border-radius: 3px;
    }

    .sidebar-nav-items::-webkit-scrollbar-thumb:hover {
        background: rgba(255, 255, 255, 0.5);
    }

    .sidebar-logo {
        padding: 20px;
        text-align: center;
        flex-shrink: 0; /* Prevent logo from shrinking */
        margin-bottom: 0;
        cursor: pointer;
    }

    .sidebar-logo img {
        max-width: 100%;
        height: auto;
        max-height: 40px;
        object-fit: contain;
        margin-bottom: 5px;
        transition: max-height 0.3s ease, margin-bottom 0.3s ease;
    }

    nav.sidebar.sidebar-expanded .sidebar-logo img {
        max-height: 80px;
        margin-bottom: 10px;
    }

    .sidebar-logo .restaurant-name {
        color: white;
        font-size: 14px;
        font-weight: 600;
        line-height: 1.4;
        margin-top: 10px;
        transition: all 0.3s ease;
        opacity: 0;
        max-height: 0;
        overflow: hidden;
        text-align: center;
    }

    nav.sidebar.sidebar-expanded .sidebar-logo .restaurant-name {
        opacity: 1;
        max-height: 100px;
    }

    /* Sidebar Footer - Admin Info at Bottom */
    .sidebar-footer {
        flex-shrink: 0; /* Prevent footer from shrinking */
        padding: 20px 15px;
        background-color: rgba(0, 0, 0, 0.3);
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        text-align: center;
        transition: all 0.3s ease;
        margin-top: auto; /* Push to bottom */
    }

    .sidebar-footer .cashier-name {
        color: white;
        font-size: 16px;
        font-weight: 500;
        line-height: 1.4;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        transition: all 0.3s ease;
    }

    .sidebar-footer .cashier-name i {
        font-size: 14px;
    }

    .sidebar-footer .cashier-name span {
        opacity: 0;
        width: 0;
        overflow: hidden;
        transition: all 0.3s ease;
        display: inline-block;
    }

    nav.sidebar.sidebar-expanded .sidebar-footer .cashier-name span {
        opacity: 1;
        width: auto;
    }

    .sidebar-footer .sidebar-datetime {
        color: white;
        font-size: 14px;
        line-height: 1.6;
        text-align: center;
        transition: all 0.3s ease;
    }

    .sidebar-footer .sidebar-datetime #sidebar-date {
        font-weight: 500;
        margin-bottom: 5px;
        opacity: 0;
        max-height: 0;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .sidebar-footer .sidebar-datetime #sidebar-time {
        font-weight: 600;
        color: #face0b;
        font-size: 16px;
        opacity: 0;
        max-height: 0;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-date {
        opacity: 1;
        max-height: 30px;
    }

    nav.sidebar.sidebar-expanded .sidebar-footer .sidebar-datetime #sidebar-time {
        opacity: 1;
        max-height: 30px;
    }

    nav.sidebar a {
        color: white;
        padding: 14px 0;
        text-decoration: none;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        text-align: left;
        padding-left: 20px;
    }

    nav.sidebar a:hover {
        background-color: #ddd;
        color: black;
    }

    nav.sidebar a.active {
        background-color: #face0b;
        color: black;
    }

    nav.sidebar a i {
        margin-right: 0;
        width: 20px;
        text-align: center;
        display: inline-block;
    }

    nav.sidebar.sidebar-expanded a i {
        margin-right: 10px;
    }

    nav.sidebar a span {
        transition: all 0.3s ease;
        opacity: 0;
        width: 0;
        overflow: hidden;
        display: inline-block;
    }

    nav.sidebar.sidebar-expanded a span {
        opacity: 1;
        width: auto;
        white-space: normal;
        word-wrap: break-word;
        overflow-wrap: break-word;
        line-height: 1.3;
        max-width: 140px;
        display: inline-block;
    }

    /* Allow specific long navigation items to wrap to 2 lines when expanded */
    nav.sidebar.sidebar-expanded a[href*="transaction_history"] span,
    nav.sidebar.sidebar-expanded a[href*="user_management"] span {
        max-width: 130px;
    }

    /* Main Content Area */
    main {
        margin-left: 90px;
        margin-top: 0;
        padding: 20px;
        flex-grow: 1;
        transition: margin-left 0.3s ease;
    }

    nav.sidebar.sidebar-expanded ~ main {
        margin-left: 220px;
    }
    
    /* Disable main content transitions on page load */
    nav.sidebar.no-transition ~ main {
        transition: none !important;
    }

    /* Responsive adjustments */
    @media screen and (max-width: 768px) {
        main {
            margin-left: 0;
            width: 100%;
        }
        
        
        nav.sidebar {
            display: none;
        }
    }
</style>

<script>
    // Sidebar toggle functionality with persistence
    function toggleSidebar() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('sidebar-expanded');
            // Save state to localStorage
            const isExpanded = sidebar.classList.contains('sidebar-expanded');
            localStorage.setItem('sidebarExpanded', isExpanded ? 'true' : 'false');
        }
    }

    // Restore sidebar state on page load (without transition)
    document.addEventListener('DOMContentLoaded', function() {
        const sidebar = document.querySelector('nav.sidebar');
        if (sidebar) {
            // Disable transitions during state restoration
            sidebar.classList.add('no-transition');
            
            // Check localStorage for saved state
            const savedState = localStorage.getItem('sidebarExpanded');
            if (savedState === 'true') {
                sidebar.classList.add('sidebar-expanded');
            } else {
                // Default to collapsed (no saved state or explicitly false)
                sidebar.classList.remove('sidebar-expanded');
            }
            
            // Re-enable transitions after a short delay
            setTimeout(function() {
                sidebar.classList.remove('no-transition');
            }, 50);
        }
    });

    // Update sidebar date and time
    function updateSidebarDateTime() {
        const now = new Date();
        const dateOptions = { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        };
        const timeOptions = { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true
        };
        
        const dateStr = now.toLocaleDateString('en-US', dateOptions);
        const timeStr = now.toLocaleTimeString('en-US', timeOptions);
        
        const dateElement = document.getElementById('sidebar-date');
        const timeElement = document.getElementById('sidebar-time');
        
        if (dateElement) {
            dateElement.textContent = dateStr;
        }
        if (timeElement) {
            timeElement.textContent = timeStr;
        }
    }

    // Update immediately and then every second
    updateSidebarDateTime();
    setInterval(updateSidebarDateTime, 1000);

    // Logout confirmation function (if not already defined)
    if (typeof confirmLogout === 'undefined') {
        function confirmLogout(event) {
            event.preventDefault();
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout Confirmation',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#face0b',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../authentication/logout.php';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../authentication/logout.php';
                }
            }
        }
    }
</script>