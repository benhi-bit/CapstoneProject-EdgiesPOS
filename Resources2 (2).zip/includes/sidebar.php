<?php
// Sidebar component for EDGIE'S POS System (Admin Layout Style)
// Usage: include 'sidebar.php'; 
// The $currentPage variable should be set before including this file
// Note: This sidebar is designed for admin pages with a header bar above it
// For POS pages, use the sidebar structure from pos.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current page if not set
if (!isset($currentPage)) {
    $currentPage = basename($_SERVER['PHP_SELF']);
}

// Get user role
$userRole = isset($_SESSION['Role']) ? $_SESSION['Role'] : '';

// Function to check if a page is active
function isActive($page, $current) {
    return ($page === $current) ? 'active' : '';
}
?>

<nav class="sidebar">
    <?php if ($userRole === 'Admin'): ?>
        <!-- Admin Menu Items -->
        <a href="dashboard.php" class="<?php echo isActive('dashboard.php', $currentPage); ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <a href="manage_product.php" class="<?php echo isActive('manage_product.php', $currentPage); ?>">
            <i class="fas fa-box"></i> Manage Product
        </a>
        <a href="category.php" class="<?php echo isActive('category.php', $currentPage); ?>">
            <i class="fas fa-list-alt"></i> Category
        </a>
        <a href="transaction_history.php" class="<?php echo isActive('transaction_history.php', $currentPage); ?>">
            <i class="fas fa-receipt"></i> Transaction History
        </a>
        <a href="user_management.php" class="<?php echo isActive('user_management.php', $currentPage); ?>">
            <i class="fas fa-users-cog"></i> User Management
        </a>
        <a href="log_history.php" class="<?php echo isActive('log_history.php', $currentPage); ?>">
            <i class="fas fa-history"></i> Log History
        </a>
        <a href="backup_recovery.php" class="<?php echo isActive('backup_recovery.php', $currentPage); ?>">
            <i class="fas fa-recycle"></i> Backup & Restore
        </a>
        <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('logout.php', $currentPage); ?>">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    <?php elseif ($userRole === 'Cashier'): ?>
        <!-- Cashier Menu Items (for admin-style pages, not POS) -->
        <a href="cashier_sales_report.php" class="<?php echo isActive('cashier_sales_report.php', $currentPage); ?>">
            <i class="fas fa-chart-line"></i> Sales Report
        </a>
        <a href="cashier_transaction_history.php" class="<?php echo isActive('cashier_transaction_history.php', $currentPage); ?>">
            <i class="fas fa-receipt"></i> Transaction History
        </a>
        <a href="cashier_inventory_history.php" class="<?php echo isActive('cashier_inventory_history.php', $currentPage); ?>">
            <i class="fas fa-box"></i> Inventory History
        </a>
        <a href="../authentication/logout.php" onclick="confirmLogout(event); return false;" class="<?php echo isActive('logout.php', $currentPage); ?>">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    <?php else: ?>
        <!-- Default/No Role Menu -->
        <a href="../index.php">
            <i class="fas fa-home"></i> Home
        </a>
    <?php endif; ?>
</nav>

<style>
    /* Sidebar Styles - Admin Layout (positioned below header) */
    nav.sidebar {
        width: 200px;
        background-color: #333;
        height: 100vh;
        position: fixed;
        top: 60px;
        left: 0;
        overflow: auto;
        padding-top: 20px;
        z-index: 999;
    }

    nav.sidebar a {
        color: white;
        padding: 14px 20px;
        text-decoration: none;
        display: block;
        text-align: left;
    }

    nav.sidebar a:hover {
        background-color: #ddd;
        color: black;
    }

    nav.sidebar a.active {
        background-color: #face0b;
        color: black;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        nav.sidebar {
            display: none;
        }
    }
</style>

<script>
    // Logout confirmation function (if not already defined)
    if (typeof confirmLogout === 'undefined') {
        function confirmLogout(event) {
            event.preventDefault();
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    title: 'Logout Confirmation',
                    text: 'Are you sure you want to logout?',
                    icon: 'question',
                    showCancelButton: true,
                    confirmButtonColor: '#face0b',
                    cancelButtonColor: '#333',
                    confirmButtonText: 'Yes, logout',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '../authentication/logout.php';
                    }
                });
            } else {
                if (confirm('Are you sure you want to logout?')) {
                    window.location.href = '../authentication/logout.php';
                }
            }
        }
    }
</script>

