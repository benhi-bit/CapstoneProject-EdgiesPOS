<?php
/**
 * CLI entrypoint for automatic weekly backups.
 *
 * Recommended use (Windows Task Scheduler):
 * - Program/script: C:\xampp\php\php.exe
 * - Add arguments: -f "C:\xampp\htdocs\Edgies POS System\tools\scheduled_backup.php"
 * - Trigger: Weekly, Monday, 10:00 AM
 */

// Force CLI usage (avoid web execution by accident)
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    echo "Forbidden\n";
    exit(1);
}

require_once __DIR__ . '/../config/connection.php';
require_once __DIR__ . '/../lib/backup_helper.php';

$dbname = "edgies_pos";
$backupDir = realpath(__DIR__ . '/..') . DIRECTORY_SEPARATOR . 'backup';
$adminEmail = "support@edgiespos.online";

/**
 * Send backup file via email
 */
function sendBackupEmail($filePath, $adminEmail) {
    if (!file_exists($filePath)) {
        return false;
    }
    
    $subject = "Edgie's POS System - Automatic Database Backup - " . date('Y-m-d H:i:s');
    $message = "This is an automatic database backup from Edgie's POS System.\n\n";
    $message .= "Backup Date: " . date('Y-m-d H:i:s') . "\n";
    $message .= "File: " . basename($filePath) . "\n\n";
    $message .= "Please keep this backup file secure.";
    
    $boundary = md5(time());
    $headers = "From: Edgie's POS System <noreply@edgiespos.online>\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"\r\n";
    
    $body = "--{$boundary}\r\n";
    $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
    $body .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
    $body .= $message . "\r\n";
    $body .= "--{$boundary}\r\n";
    $body .= "Content-Type: application/sql; name=\"" . basename($filePath) . "\"\r\n";
    $body .= "Content-Transfer-Encoding: base64\r\n";
    $body .= "Content-Disposition: attachment; filename=\"" . basename($filePath) . "\"\r\n\r\n";
    $body .= chunk_split(base64_encode(file_get_contents($filePath))) . "\r\n";
    $body .= "--{$boundary}--";
    
    return mail($adminEmail, $subject, $body, $headers);
}

try {
    $sql = generateDatabaseBackupSql($conn, $dbname);
    $filename = makeBackupFilename($dbname);
    $path = saveBackupSqlToFile($backupDir, $filename, $sql);
    echo "Backup saved: {$path}\n";
    
    // Send backup via email
    if (sendBackupEmail($path, $adminEmail)) {
        echo "Backup sent to {$adminEmail}\n";
    } else {
        fwrite(STDERR, "Warning: Failed to send backup email to {$adminEmail}\n");
    }
    
    exit(0);
} catch (Throwable $e) {
    fwrite(STDERR, "Backup failed: " . $e->getMessage() . "\n");
    exit(1);
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}

