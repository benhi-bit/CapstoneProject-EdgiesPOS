<?php
function addSystemLog($conn, $action, $description, $userFullName = null) {
    // If userFullName is not provided, try to get it from session
    if ($userFullName === null && isset($_SESSION['Username'])) {
        $stmt = $conn->prepare("SELECT FullName FROM loginaccount WHERE Username = ?");
        $stmt->bind_param("s", $_SESSION['Username']);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $userFullName = $row['FullName'];
        }
        $stmt->close();
    }

    // Prepare and execute the log entry with the correct column names
    $stmt = $conn->prepare("INSERT INTO system_logs (action_type, description, user_fullname, log_timestamp) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("sss", $action, $description, $userFullName);
    
    try {
        $stmt->execute();
        return true;
    } catch (Exception $e) {
        error_log("Error adding system log: " . $e->getMessage());
        return false;
    } finally {
        $stmt->close();
    }
}

// Function to format log message for display
function formatLogMessage($action, $description, $userInfo, $timestamp) {
    return array(
        'action' => htmlspecialchars($action),
        'description' => htmlspecialchars($description),
        'user' => htmlspecialchars($userInfo),
        'timestamp' => date('Y-m-d H:i:s', strtotime($timestamp))
    );
}
?> 