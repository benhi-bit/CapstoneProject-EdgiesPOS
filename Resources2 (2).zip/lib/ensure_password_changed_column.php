<?php

/**
 * Ensure the `password_changed` column exists in the `loginaccount` table.
 *
 * This check runs once per request. It creates the column if missing.
 *
 * @param mysqli $conn
 */
function ensurePasswordChangedColumn(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $columnCheckResult = $conn->query("SHOW COLUMNS FROM `loginaccount` LIKE 'password_changed'");
    if ($columnCheckResult === false) {
        die("Failed to verify column 'password_changed' on 'loginaccount' table: " . $conn->error);
    }

    if ($columnCheckResult->num_rows === 0) {
        $alterSql = "ALTER TABLE `loginaccount` ADD COLUMN `password_changed` TINYINT(1) DEFAULT 0";
        if (!$conn->query($alterSql)) {
            die("Failed to add column 'password_changed' to 'loginaccount' table: " . $conn->error . ". Please apply the latest database migrations.");
        }
    }

    $columnCheckResult->free();
    $checked = true;
}
