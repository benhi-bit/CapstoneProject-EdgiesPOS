<?php
// Prevent browser caching of protected pages
// This ensures that when users click back/forward, they get fresh content
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// Set a unique page identifier to track navigation
if (!isset($_SESSION['page_token'])) {
    $_SESSION['page_token'] = bin2hex(random_bytes(16));
}
?>

