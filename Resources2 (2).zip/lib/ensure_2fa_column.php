<?php

/**
 * Ensure the `two_factor_secret` column exists in the `loginaccount` table.
 *
 * This check runs once per request. It creates the column if missing.
 *
 * @param mysqli $conn
 */
function ensure2FAColumn(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $columnCheckResult = $conn->query("SHOW COLUMNS FROM `loginaccount` LIKE 'two_factor_secret'");
    if ($columnCheckResult === false) {
        die("Failed to verify column 'two_factor_secret' on 'loginaccount' table: " . $conn->error);
    }

    if ($columnCheckResult->num_rows === 0) {
        $alterSql = "ALTER TABLE `loginaccount` ADD COLUMN `two_factor_secret` VARCHAR(255) DEFAULT NULL";
        if (!$conn->query($alterSql)) {
            die("Failed to add column 'two_factor_secret' to 'loginaccount' table: " . $conn->error . ". Please apply the latest database migrations.");
        }
    }

    $columnCheckResult->free();
    $checked = true;
}

