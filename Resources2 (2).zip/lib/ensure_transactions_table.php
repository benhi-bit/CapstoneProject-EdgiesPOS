<?php

/**
 * Ensure the `transactions` table exists with required columns.
 *
 * This check runs once per request. It creates the table if missing,
 * and ensures the `payment` and `change_amount` columns exist.
 *
 * @param mysqli $conn
 */
function ensureTransactionsTable(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $tableCheckResult = $conn->query("SHOW TABLES LIKE 'transactions'");
    if ($tableCheckResult === false) {
        die("Failed to verify transactions table: " . $conn->error);
    }

    $tableExists = ($tableCheckResult->num_rows > 0);
    $tableCheckResult->free();

    if (!$tableExists) {
        $createTransactionsTableSql = "
            CREATE TABLE `transactions` (
                `id` INT(11) NOT NULL AUTO_INCREMENT,
                `serial_num` VARCHAR(10) NOT NULL,
                `transaction_num` INT(11) NOT NULL,
                `sales_invoice_no` VARCHAR(32) DEFAULT NULL COMMENT 'Customer-facing invoice number (e.g. 202603001)',
                `transaction_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `total_amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
                `payment` DECIMAL(10,2) DEFAULT 0.00,
                `change_amount` DECIMAL(10,2) DEFAULT 0.00,
                `details` TEXT NOT NULL,
                `processed_by` VARCHAR(255) DEFAULT NULL,
                PRIMARY KEY (`id`),
                KEY `idx_transaction_date` (`transaction_date`),
                KEY `idx_serial_num` (`serial_num`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
        ";

        if (!$conn->query($createTransactionsTableSql)) {
            die("Failed to create required table 'transactions': " . $conn->error . ". Please import the latest database schema.");
        }

        $checked = true;
        return;
    }

    foreach ([
        'payment' => "ALTER TABLE `transactions` ADD COLUMN `payment` DECIMAL(10,2) DEFAULT 0.00",
        'change_amount' => "ALTER TABLE `transactions` ADD COLUMN `change_amount` DECIMAL(10,2) DEFAULT 0.00",
        'payment_method' => "ALTER TABLE `transactions` ADD COLUMN `payment_method` VARCHAR(20) DEFAULT 'cash'",
        'reference_no' => "ALTER TABLE `transactions` ADD COLUMN `reference_no` VARCHAR(60) DEFAULT NULL",
        'sales_invoice_no' => "ALTER TABLE `transactions` ADD COLUMN `sales_invoice_no` VARCHAR(32) DEFAULT NULL COMMENT 'Customer-facing invoice number (e.g. INV-YYYYMMDD-00000001)'"
    ] as $column => $alterSql) {
        $columnCheckResult = $conn->query("SHOW COLUMNS FROM `transactions` LIKE '{$column}'");
        if ($columnCheckResult === false) {
            die("Failed to verify column '{$column}' on 'transactions' table: " . $conn->error);
        }

        if ($columnCheckResult->num_rows === 0) {
            if (!$conn->query($alterSql)) {
                die("Failed to add column '{$column}' to 'transactions' table: " . $conn->error . ". Please apply the latest database migrations.");
            }
        }

        $columnCheckResult->free();
    }

    $checked = true;
}

