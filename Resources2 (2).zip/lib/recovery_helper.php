<?php

/**
 * Utility helper for backup and recovery operations.
 */

function ensureRecoveryTableExists($conn) {
    static $tableChecked = false;

    if ($tableChecked) {
        return;
    }

    $createTableSql = "
        CREATE TABLE IF NOT EXISTS recovery_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            item_type VARCHAR(50) NOT NULL,
            source_table VARCHAR(100) NOT NULL,
            reference_id VARCHAR(64) DEFAULT NULL,
            item_name VARCHAR(255) DEFAULT NULL,
            item_data LONGTEXT NOT NULL,
            removed_by VARCHAR(255) NOT NULL,
            removed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_item_type (item_type),
            INDEX idx_removed_at (removed_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";

    $conn->query($createTableSql);
    $tableChecked = true;
}

function storeRecoveryItem($conn, $itemType, $sourceTable, $referenceId, $itemName, array $itemData, $removedBy) {
    ensureRecoveryTableExists($conn);

    $jsonData = json_encode($itemData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($jsonData === false) {
        return false;
    }

    $stmt = $conn->prepare("
        INSERT INTO recovery_items (item_type, source_table, reference_id, item_name, item_data, removed_by)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $reference = $referenceId !== null ? (string)$referenceId : null;
    $stmt->bind_param("ssssss", $itemType, $sourceTable, $reference, $itemName, $jsonData, $removedBy);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

function fetchRecoveryItems($conn) {
    ensureRecoveryTableExists($conn);

    $items = [];
    $result = $conn->query("SELECT * FROM recovery_items ORDER BY removed_at DESC");

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        $result->close();
    }

    return $items;
}

function getRecoveryItem($conn, $itemId) {
    ensureRecoveryTableExists($conn);

    $stmt = $conn->prepare("SELECT * FROM recovery_items WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $stmt->execute();
    $item = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    return $item;
}

function getRecoveryTableMap() {
    return [
        'categories' => 'CategoryID',
        'inventory' => 'InventoryID',
        'loginaccount' => 'UserID',
        'system_logs' => 'log_id'
    ];
}

function restoreRecoveryItem($conn, $itemId) {
    ensureRecoveryTableExists($conn);

    $item = getRecoveryItem($conn, $itemId);
    if (!$item) {
        return ['success' => false, 'message' => 'Recovery item not found.'];
    }

    $data = json_decode($item['item_data'], true);
    if (!is_array($data)) {
        return ['success' => false, 'message' => 'Invalid recovery data.'];
    }

    $tableMap = getRecoveryTableMap();
    $sourceTable = $item['source_table'];

    if (!array_key_exists($sourceTable, $tableMap)) {
        return ['success' => false, 'message' => 'Unsupported recovery type.'];
    }

    $primaryKey = $tableMap[$sourceTable];
    unset($data[$primaryKey]);

    $columns = array_keys($data);
    if (empty($columns)) {
        return ['success' => false, 'message' => 'Recovery data is incomplete.'];
    }

    $columnList = implode(', ', array_map(function ($col) {
        return "`{$col}`";
    }, $columns));
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));

    $sql = "INSERT INTO {$sourceTable} ({$columnList}) VALUES ({$placeholders})";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        return ['success' => false, 'message' => 'Failed to prepare restore statement.'];
    }

    $types = str_repeat('s', count($columns));
    $values = array_map(function ($value) {
        if ($value === null) {
            return null;
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        return (string)$value;
    }, array_values($data));

    $bindParams = [];
    $bindParams[] = $types;
    foreach ($values as $key => $value) {
        $bindParams[] = &$values[$key];
    }

    call_user_func_array([$stmt, 'bind_param'], $bindParams);

    if (!$stmt->execute()) {
        $error = $stmt->error;
        $stmt->close();
        return ['success' => false, 'message' => "Failed to restore item: {$error}"];
    }

    $stmt->close();

    $deleteStmt = $conn->prepare("DELETE FROM recovery_items WHERE id = ?");
    $deleteStmt->bind_param("i", $itemId);
    $deleteStmt->execute();
    $deleteStmt->close();

    return ['success' => true, 'message' => 'Item restored successfully.', 'item' => $item];
}

function purgeRecoveryItem($conn, $itemId) {
    ensureRecoveryTableExists($conn);

    $stmt = $conn->prepare("DELETE FROM recovery_items WHERE id = ?");
    $stmt->bind_param("i", $itemId);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

