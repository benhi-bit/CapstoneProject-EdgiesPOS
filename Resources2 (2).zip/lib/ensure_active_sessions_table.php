<?php

/**
 * Ensure the `active_sessions` table exists.
 *
 * This check runs once per request. It creates the table if missing.
 *
 * @param mysqli $conn
 */
function ensureActiveSessionsTable(mysqli $conn): void
{
    static $checked = false;

    if ($checked) {
        return;
    }

    $tableCheckResult = $conn->query("SHOW TABLES LIKE 'active_sessions'");
    if ($tableCheckResult === false) {
        die("Failed to verify active_sessions table: " . $conn->error);
    }

    if ($tableCheckResult->num_rows === 0) {
        // Create table without foreign key constraint first (to avoid constraint errors)
        $createSessionsTable = "CREATE TABLE IF NOT EXISTS active_sessions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT(11) NOT NULL,
            session_id VARCHAR(255) NOT NULL,
            last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        if (!$conn->query($createSessionsTable)) {
            die("Failed to create required table 'active_sessions': " . $conn->error . ". Please import the latest database schema.");
        }
        
        // Try to add foreign key constraint if UserID is a primary key
        // Check if UserID is a primary key in loginaccount
        $checkPK = $conn->query("SHOW KEYS FROM loginaccount WHERE Key_name = 'PRIMARY' AND Column_name = 'UserID'");
        if ($checkPK && $checkPK->num_rows > 0) {
            // Check if foreign key already exists
            $checkFK = $conn->query("SELECT CONSTRAINT_NAME FROM information_schema.TABLE_CONSTRAINTS 
                                    WHERE TABLE_SCHEMA = DATABASE() 
                                    AND TABLE_NAME = 'active_sessions' 
                                    AND CONSTRAINT_TYPE = 'FOREIGN KEY' 
                                    AND CONSTRAINT_NAME = 'fk_active_sessions_user'");
            
            if (!$checkFK || $checkFK->num_rows === 0) {
                // Try to add foreign key constraint
                $addFK = "ALTER TABLE active_sessions 
                         ADD CONSTRAINT fk_active_sessions_user 
                         FOREIGN KEY (user_id) REFERENCES loginaccount(UserID) 
                         ON DELETE CASCADE ON UPDATE CASCADE";
                $conn->query($addFK); // Ignore errors if it fails - not critical for functionality
            }
            if ($checkFK) {
                $checkFK->free();
            }
        }
        if ($checkPK) {
            $checkPK->free();
        }
    }

    $tableCheckResult->free();
    $checked = true;
}

