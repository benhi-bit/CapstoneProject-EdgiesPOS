<?php
/**
 * Backup helper utilities for database dumps.
 *
 * Produces a SQL dump similar to the existing manual backup download,
 * but can be reused for manual/automatic backups that also save to disk.
 */

/**
 * Generate a SQL dump of all tables in the currently connected database.
 *
 * @param mysqli $conn
 * @param string $dbname
 * @return string
 */
function generateDatabaseBackupSql(mysqli $conn, string $dbname): string
{
    // SQL file header
    $out = '';
    $out .= "-- MySQL Database Backup\n";
    $out .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $out .= "-- Database: {$dbname}\n";
    $out .= "-- \n\n";
    $out .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $out .= "SET AUTOCOMMIT = 0;\n";
    $out .= "START TRANSACTION;\n";
    $out .= "SET time_zone = \"+00:00\";\n\n";
    $out .= "/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;\n";
    $out .= "/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;\n";
    $out .= "/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;\n";
    $out .= "/*!40101 SET NAMES utf8mb4 */;\n\n";

    // Get all tables
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
        $result->close();
    }

    foreach ($tables as $table) {
        // Table structure
        $out .= "--\n";
        $out .= "-- Table structure for table `{$table}`\n";
        $out .= "--\n\n";
        $out .= "DROP TABLE IF EXISTS `{$table}`;\n";

        $createTable = $conn->query("SHOW CREATE TABLE `{$table}`");
        if ($createTable) {
            $row = $createTable->fetch_array();
            $out .= $row[1] . ";\n\n";
            $createTable->close();
        }

        // Table data
        $out .= "--\n";
        $out .= "-- Dumping data for table `{$table}`\n";
        $out .= "--\n\n";

        $data = $conn->query("SELECT * FROM `{$table}`");
        if ($data && $data->num_rows > 0) {
            $columns = [];
            $fields = $data->fetch_fields();
            foreach ($fields as $field) {
                $columns[] = "`{$field->name}`";
            }
            $columnList = implode(', ', $columns);

            $out .= "INSERT INTO `{$table}` ({$columnList}) VALUES\n";

            $rows = [];
            while ($row = $data->fetch_assoc()) {
                $values = [];
                foreach ($row as $value) {
                    if ($value === null) {
                        $values[] = 'NULL';
                    } else {
                        $values[] = "'" . $conn->real_escape_string($value) . "'";
                    }
                }
                $rows[] = "(" . implode(', ', $values) . ")";
            }

            $out .= implode(",\n", $rows) . ";\n\n";
            $data->close();
        }
    }

    // Footer
    $out .= "COMMIT;\n";
    $out .= "/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;\n";
    $out .= "/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;\n";
    $out .= "/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;\n";

    return $out;
}

/**
 * Ensure backup directory exists.
 *
 * @param string $backupDir
 * @return void
 */
function ensureBackupDir(string $backupDir): void
{
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0775, true);
    }
}

/**
 * Create a backup filename that starts with the date.
 *
 * Example: 2026-01-21_10-00-00_edgies_pos_backup.sql
 *
 * @param string $dbname
 * @return string
 */
function makeBackupFilename(string $dbname): string
{
    // Starts with date, then time, then db name.
    return date('Y-m-d_H-i-s') . '_' . $dbname . '_backup.sql';
}

/**
 * Save a backup SQL string to the backup folder.
 *
 * @param string $backupDir
 * @param string $filename
 * @param string $sql
 * @return string Absolute/relative file path that was written.
 * @throws RuntimeException
 */
function saveBackupSqlToFile(string $backupDir, string $filename, string $sql): string
{
    ensureBackupDir($backupDir);
    $path = rtrim($backupDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $filename;

    $bytes = file_put_contents($path, $sql);
    if ($bytes === false) {
        throw new RuntimeException("Failed to write backup file to: {$path}");
    }

    return $path;
}

/**
 * Run scheduled backup if due (by time and not already run for that slot).
 * Used by backup_recovery.php and by run_scheduled_backup_and_download.php.
 *
 * @param mysqli $conn
 * @param string $dbname
 * @param string $backupDir
 * @param string $schedulePath Path to config/backup_schedule.json
 * @return array{ran: bool, path: ?string} path is absolute path to the created file when ran
 */
function runScheduledBackupIfDue(mysqli $conn, string $dbname, string $backupDir, string $schedulePath): array
{
    $result = ['ran' => false, 'path' => null];

    if (!is_file($schedulePath)) {
        return $result;
    }

    $scheduleJson = @file_get_contents($schedulePath);
    if ($scheduleJson === false) {
        return $result;
    }

    $schedule = json_decode($scheduleJson, true);
    if (!is_array($schedule) || empty($schedule['run_at'])) {
        return $result;
    }

    $scheduledRunAt = $schedule['run_at'];
    $runAt = \DateTime::createFromFormat('Y-m-d\TH:i', $scheduledRunAt);
    if (!$runAt) {
        return $result;
    }

    $now = new \DateTime('now');
    if ($now < $runAt) {
        return $result;
    }

    $lastRunAt = null;
    if (!empty($schedule['last_run_at'])) {
        $lastRunAt = \DateTime::createFromFormat('Y-m-d\TH:i', (string)$schedule['last_run_at']);
    }
    if ($lastRunAt && $lastRunAt >= $runAt) {
        return $result;
    }

    try {
        $sql = generateDatabaseBackupSql($conn, $dbname);
        $filename = makeBackupFilename($dbname);
        $path = saveBackupSqlToFile($backupDir, $filename, $sql);

        $next = clone $runAt;
        $next->modify('+7 days');
        $payload = [
            'run_at' => $next->format('Y-m-d\TH:i'),
            'last_run_at' => $runAt->format('Y-m-d\TH:i'),
            'last_status' => 'success',
            'last_file' => basename($path),
        ];
        @file_put_contents($schedulePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

        $result['ran'] = true;
        $result['path'] = $path;
        return $result;
    } catch (\Throwable $e) {
        $payload = [
            'run_at' => $scheduledRunAt,
            'last_run_at' => $runAt->format('Y-m-d\TH:i'),
            'last_status' => 'failed',
            'last_file' => $schedule['last_file'] ?? null,
        ];
        @file_put_contents($schedulePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        return $result;
    }
}

/**
 * Run a backup now (e.g. for "run now" or when schedule is due).
 * Saves to backup folder and updates schedule to next week.
 *
 * @param mysqli $conn
 * @param string $dbname
 * @param string $backupDir
 * @param string $schedulePath
 * @return array{ran: bool, path: ?string}
 */
function runBackupNow(mysqli $conn, string $dbname, string $backupDir, string $schedulePath): array
{
    $result = ['ran' => false, 'path' => null];
    try {
        ensureBackupDir($backupDir);
        $sql = generateDatabaseBackupSql($conn, $dbname);
        $filename = makeBackupFilename($dbname);
        $path = saveBackupSqlToFile($backupDir, $filename, $sql);

        $now = new \DateTime('now');
        $next = clone $now;
        $next->modify('+7 days');
        $payload = [
            'run_at' => $next->format('Y-m-d\TH:i'),
            'last_run_at' => $now->format('Y-m-d\TH:i'),
            'last_status' => 'success',
            'last_file' => basename($path),
        ];
        if (is_file($schedulePath)) {
            @file_put_contents($schedulePath, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $result['ran'] = true;
        $result['path'] = $path;
    } catch (\Throwable $e) {
        // leave result as ran=false
    }
    return $result;
}

